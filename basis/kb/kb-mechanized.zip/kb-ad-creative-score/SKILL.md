---
name: kb-ad-creative-score
description: >-
  Score an ad creative or a creative-test plan against the ad-creative gate system before it
  ships budget, and return PASS / WARN / BLOCK with per-field evidence. Use to grade a creative
  matrix, a dynamic-creative test, a hook plan, a competitor swipe, or a scaling/budget
  decision (written by a human, kb-ad-creative-write, or any source). Hard-gates only the
  countable (combination counts, the ≤20 cap, 2× AOV, the 3-2-2 / 1×2×4 structures, the 7-day
  +~50-purchase read, +20%/48–72h, MDS floors, the competitor filter); soft-caps the heuristic
  (thumbnail signal, filler density); treats ad↔landing-page congruency as a pairwise-vs-specimen
  signal, never self-graded. Run as a SEPARATE pass from the writer. Triggers: "score this
  creative", "is this test plan valid", "check this against the benchmarks", "grade this swipe".
---

# Ad creative — score the plan before it spends

Grade each judged field against its gate, then band it. **Do not run this in the same pass that
wrote the creative** — a writer grading itself rates its own output higher. Anchor Angle,
Awareness level, UM, Hook to the term registry; never redefine them.

Tier discipline (the rule a fused skill breaks): **hard-gate only the countable**; **soft-cap
the heuristic**; **compare the felt against a specimen — never hard-FALSE it, never self-grade it.**

## Fields and tiers (each: positive target → how it's judged → tier)

- **COUNTABLE gates G1–G27** — arithmetic / threshold / enum membership. *Judge:* **script gate**,
  pass/fail, deterministic. Examples: combinations == product of variables (G1); dynamic-creative
  total ≤ 20 (G2); ad-set budget == 2× AOV (G3); ≥ 3 hook variants (G4); pre-validation budget
  ≤ $100 (G5); hook rate ≥ 50% (G6); 3-2-2 + ≥ 7-day window (G11); Winner/Loser bands by spend-share
  + KPI (G12); composite-only kill on a 7-day window (G14); ≥ ~50 purchases for a conclusive read
  (G15); +20% per 48–72h (G17); MDS floors (G18); competitor filter membership (G26). Full
  predicates and thresholds: `references/gate-tests.md`.
- **HEURISTIC caps H1–H2** — thumbnail top-performer signal; minimalist-edit filler density.
  *Judge:* **soft-cap → WARN**, never a hard fail (detectors over-flag).
- **FELT signal F1** — ad↔landing-page congruency. *Judge:* **pairwise vs the congruency specimen**
  in `references/specimens.md`; return `prefer | tie | weaker`; never a hard FALSE, never self-graded.

A COUNTABLE gate that cannot be evaluated (the input is missing the number) returns
`BLOCKED:<gate>` — not a silent pass.

## ROUTE rules stay contract (selection / sequencing — no wording, no band)

Check that the plan SELECTED and SEQUENCED correctly; do not grade copy. Each returns
`ordered | misordered | missing-slot` or `correct-selection | wrong-selection`, not a band.
Full list (angle→4-awareness mapping, slot orders, Marksman→Sniper, ABO→CBO, hook pre-validation,
post-ID migration, drip-feed, 3BM, variation-impact ranking R20, scenario/meme/inclusive
selection R21) in `references/route-contract.md`. Named production procedures + the AI tool
stack/costs (Swipe-Script-Source-Edit, Sora 2 workflow, Four-Document foundation) are in
`references/procedures.md`; strategy frameworks, decision rules, and worked examples (Taft's
viral, meme social-proof, Coconut inclusive, creator/UGC sourcing) are in `references/strategies.md`.

## Bands (derive from gates that actually passed — not a hollow count)

- **BLOCK** — any COUNTABLE gate the plan touches returns FALSE, or a `BLOCKED:<gate>` field.
- **WARN** — all COUNTABLE gates pass but a HEURISTIC cap fired, or F1 returns `weaker`.
- **PASS** — every COUNTABLE gate the plan touches passes; F1 `prefer|tie`; no cap fired.

Count only gates that passed their tier's check. A HEURISTIC or FELT result never manufactures
a PASS on its own and never forces a BLOCK on its own.

## The negatives live here (≤5), each paired with a positive target

Moved out of the writer (where banning a token summons it). Each is a checker rule:

- **>20 dynamic-creative combinations** → BLOCK; positive: structure to 1×2×4, total ≤ 20 (G2).
- **Single-metric kill** (ROAS-only, or a 3-day read called conclusive) → BLOCK; positive:
  composite kill across a 7-day window (G14).
- **"Conclusive" on < ~50 purchases** → BLOCK; positive: hold for ≥ ~50 purchases (G15).
- **Competitor asset cloned one-for-one** → BLOCK; positive: reuse structure, original asset (G27).
- **25–50 variations of the same asset post-Andromeda** → BLOCK; positive: 25–50 genuinely
  distinct concepts (G9).

## Output contract (per scored object)

```
target: "<verbatim creative line, plan field, or decision>"
countable_gates: [ {id, target, verdict: pass|fail|blocked, evidence_quote, source} ]
heuristic_caps:  [ {id, verdict: ok|warn, evidence} ]            # soft-cap only
felt_signal:     {F1_congruency: prefer|tie|weaker, vs_specimen, reason}  # pairwise, not self-graded
route_checks:    [ {id, verdict: ordered|misordered|missing-slot|correct-selection|wrong-selection} ]
band: PASS | WARN | BLOCK
flags: [ ... ]   # from the negatives list
```

`source` ∈ `{operator_verbatim | traces_to:<input_id> | kb:<gate-id> | agent_inference}`.
Each COUNTABLE `pass` carries an `evidence_quote` — a verbatim substring of the scored input.

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every COUNTABLE gate the plan touches has a verdict; F1 has a value; band present.
**SOUNDNESS:** every COUNTABLE verdict came from the script (not eyeballed); every fail/blocked
names its gate id; F1 is pairwise-vs-specimen, not self-graded; band derived only from gates that
passed their tier's check; each `pass` carries a verbatim `evidence_quote`.
`emit_ready` ONLY if every SOUNDNESS box holds; else `BLOCKED:<field>`.

## Self-test (is this grader sound?) — any NO, fix

- Are only the COUNTABLE gates hard-gated (by script), with H1/H2 soft-capped and F1 pairwise-vs-specimen?
- Is the felt judgment run separately from the writer, against a real specimen?
- Does the band come from gates that passed their tier's check, not a raw count?
- Are the negatives ≤ 5, here in the checker, each paired with a positive target?
- Are ROUTE rules kept as selection/sequencing contract (no wording, no band)?
- Is every quoted specimen a verbatim substring of a source file (no composites)?
