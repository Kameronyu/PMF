# Creative strategies & decision rules (faithful to source)

Strategy frameworks, named worked examples, and decision rules that tell an operator WHERE to
concentrate effort and WHICH format/approach to select. These are routing/strategy knowledge,
not countable gates. Where a rule is a clean named-trigger selection, the scorer may check it as
a ROUTE rule (`correct-selection | wrong-selection`); it never grades wording or assigns a band.

---

## Variation-impact ranking — where to concentrate variation effort (Source: Carl Weische)

A decision rule for the creative matrix (creative asset × messaging/copy × CTA):

- **Changing messaging has the largest impact on conversion; CTA changes have the lowest impact.**

So concentrate variation effort on messaging first, creative second, CTA last. (Matrix math
for reference: 3 creatives × 3 messaging × 3 CTAs = 27 distinct ads; 30 copies × 15 creatives
= 450 ads. Myle brand runs 240+ active ads simultaneously using this approach.)

---

## Viral / Scenario-Based Content Strategy (Source: Carl Weische — Taft's Chocolate Case Study)

Create scenario-based, curiosity-driven content rather than direct product advertising for
categories where traditional ads face fatigue or controversy.

- Taft's: created viral scenario of guys discovering "sex chocolate" left by an Airbnb host —
  unconventional positioning generated mass comments and engagement with zero traditional ad
  budget
- Test multiple angles before committing to scale
- **Give micro-influencers creative freedom to adapt content for their specific audiences — do
  not use rigid brand guidelines**
- **Validate viral angles first, then scale via micro-influencers**

Decision rule: validate the viral angle first → then scale through micro-influencers given
creative freedom (no rigid brand guidelines).

---

## Meme-Style High-Engagement Social Proof Ads (Source: Carl Weische)

Meme-format ads optimized for comments and tags create viral amplification loops that compound
paid reach while publicly accumulating social proof.

- High-engagement posts reduce perceived risk for new viewers seeing accumulated comments
- Viral amplification reduces effective CPM and traffic acquisition costs
- Social proof on the ad post itself functions as conversion mechanism

Format-selection rule: when the goal is cheap reach + accumulating social proof, select the
meme format and optimize for comments/tags (engagement as a CPM-lowering lever), not for direct
click-through alone.

---

## Inclusive Creative for Broad Audience Reach (Source: Carl Weische — Coconut Beauty Case Study)

Represent diverse customer types (body type, skin tone, face shape, hair type) within a single
campaign so all potential buyers can self-identify with the creative.

- Coconut Beauty "curly method" campaign: multiple hair structures, face shapes, and skin tones
  shown
- Combined with bundle offer ($70+ AOV) and before/after social proof on landing page
- Landing page headline: "Don't dream of perfect curls, get them" — direct outcome statement
- **Creative diversity expands effective audience without requiring separate campaigns per
  segment**

Decision rule: to broaden reach, build diversity INTO one campaign's creative rather than
spinning up separate campaigns per segment.

---

## Creator Selection and UGC Sourcing Strategy (Source: Carl Weische)

Match creator demographics to target audience. Selling to 50+ women means using 50+ UGC
creators. Split test with opposite demographics to discover unexpected resonance.

- B-roll only briefs increase content recyclability and reduce booking frequency
- B-roll approach allows testing more concepts without re-engaging creators weekly
- Do not underpay creators — they can make or break an entire ad account

Decision rules:
- **Match creator demographics to the target audience** (e.g., 50+ women → 50+ creators).
- **Split test with the opposite demographic** to discover unexpected resonance.
- **Brief for B-roll only** to raise recyclability and cut booking frequency.
- **Do not underpay creators** — creator quality directly impacts ad-account performance.
