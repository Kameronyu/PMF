# Per-field membership tests + the COUNTABLE threshold registry

Each gate below is a script-checkable predicate that can return FALSE by shape. Anchor terms
(Angle, Awareness level, UM, Hook) to the registry — never redefined here. Tier in brackets.

---

## COUNTABLE gates (hard-gate — deterministic; a wrong value fails by arithmetic/threshold)

**G1 Matrix / batch arithmetic** [COUNTABLE]
- `combination_count == product(variables)`. e.g. 3 creatives × 3 messaging × 3 CTAs == 27;
  30 copies × 15 creatives == 450; first batch == 4 angles × 10 == 40.
- FAIL: claimed total ≠ the product (e.g. "4 angles × 10 = 36").

**G2 Dynamic-creative cap** [COUNTABLE]
- Structure == `1 copy × 2 headlines × 4 video` AND `total_combinations <= 20`.
- FAIL: >20 combinations (starves minority variants).

**G3 Ad-set test budget** [COUNTABLE]
- `ad_set_test_budget == 2 * AOV`.
- FAIL: any other multiple of AOV.

**G4 Hook variant count + decomposition** [COUNTABLE]
- `hook_variants >= 3`, tested against identical body + CTA.
- Hook component share ≈ copy 80% / visual 15% / audio 5% (declared, not eyeballed).
- FAIL: <3 variants, or variants differ in body/CTA too.

**G5 Hook pre-validation budget** [COUNTABLE]
- `total_test_budget <= 100` (range $50–100), 10 variants, 1,000 impressions each.
- FAIL: budget over $100, or variant count ≠ 10.

**G6 Target hook rate** [COUNTABLE]
- `hook_rate >= 0.50` for video.
- FAIL: below 50%.

**G7 Image-ad fatigue threshold** [COUNTABLE]
- Creative fatigue is only relevant at `$10K–$50K spend per creative`; not before.
- FAIL: declaring fatigue below $10K/creative.

**G8 Weekly volume + win rate + post-Andromeda split** [COUNTABLE]
- `new_creatives_per_week >= 20` (baseline; top brands 20–30/day).
- `win_rate in [0.30, 0.50]`; post-Andromeda split == 80% new concepts / 20% variations;
  a new concept must be able to sustain `$50K–$100K+` spend.
- FAIL: <20/week, or win-rate target outside 30–50%, or pre-Andromeda 80/20 variation-heavy.

**G9 Creative diversity per ad set** [COUNTABLE]
- `concepts_per_ad_set in [25, 50]` AND all genuinely distinct (no near-duplicates).
- FAIL: <25, or 25–50 variations of the same asset.

**G10 Analysis:production time ratio** [COUNTABLE]
- `analysis_hours : production_hours == 1 : 5` (not the reverse).
- FAIL: more analysis than 1/5 of production.

**G11 3-2-2 test structure + window** [COUNTABLE]
- Structure == `3 creatives × 2 body × 2 headlines`; `evaluation_days >= 7`.
- FAIL: different structure, or window <7 days.

**G12 Winner / Loser / Super Winner bands** [COUNTABLE]
- Loser: `spend_share < 0.10` after 7 days AND/OR below KPI ROAS.
- Winner: `spend_share >= 0.10` AND hits KPI ROAS.
- Super Winner: scales budget while holding KPI at majority of account spend.
- FAIL: band assigned that contradicts the spend-share/KPI test.

**G13 Performance measure** [COUNTABLE]
- Performance == ad's `% of account spend` (Meta's allocation), not ROAS in isolation.
- FAIL: a kill/keep verdict from ROAS alone at near-zero spend.

**G14 Composite kill rule + window** [COUNTABLE]
- Decision window == 7 days; kill requires composite == `low spend% + below KPI ROAS + low CTR`.
- FAIL: single-metric kill, or a kill on a 3-day read treated as conclusive.

**G15 ROAS read sample size** [COUNTABLE]
- `purchases >= ~50` for a conclusive read; 3-day min / 7-day optimal window.
- FAIL: "conclusive" claimed on <50 purchases.

**G16 Budget-adjustment hold** [COUNTABLE]
- No budget change inside a `40–48 hour` hold.
- FAIL: adjustment inside the hold window.

**G17 Scale increment** [COUNTABLE]
- Standard scale == `+20% per 48–72h` cycle.
- FAIL: larger jump on the standard path, or shorter than 48h.

**G18 Minimum Daily Spend floors** [COUNTABLE]
- Early-stage floor `$100–200/day`; large brand `$10K+/day`; at MDS, stop cutting.
- FAIL: cutting below the floor.

**G19 EAM scaling tree** [COUNTABLE]
- Scale-up requires `60%+ click-based attribution`; standard `+20%`; aggressive == match the
  ROAS surplus % when ROAS is `50%+ above KPI`; scale-down `−20%` at break-even miss.
- FAIL: scaling up below 60% click attribution, or wrong increment for the branch.

**G20 Delta-based ROAS target reset** [COUNTABLE]
- `New Target ROAS == New Break-Even ROAS + (Old Target − Old Break-Even)`;
  rule of thumb `Target == Break-Even + 1.0`.
- FAIL: target not equal to the formula output.

**G21 Frequency band** [COUNTABLE]
- `1.0–2.0 == prospecting`; `3.0+ == retargeting`.
- FAIL: retargeting-frequency ad judged on prospecting ROAS benchmarks.

**G22 CPC role band** [COUNTABLE]
- Low CPC == prospecting; high CPC + high ROAS == retargeting.
- FAIL: band assigned against the CPC/ROAS combination.

**G23 Experimental ABO cap** [COUNTABLE]
- Experimental/unproven format spend cap ≈ `£50/day`, in ABO not CBO.
- FAIL: experimental format run in CBO or above the cap.

**G24 Original-content transition threshold** [COUNTABLE]
- Move supplier → fully-original content at `~$500K–$800K revenue`.
- FAIL: transition claimed required before this band.

**G25 Native-ad presence checks** [COUNTABLE]
- headline contains a price/value token; benefit (not feature) phrasing; before/after present;
  no person depicted under 20; optional dynamic city-name token.
- FAIL: missing price token, feature-only headline, person under 20, etc.

**G26 Competitor-filter membership** [COUNTABLE — enum/threshold set]
- 4–5 star; currently running; English; video < 60s (or image format); runtime `>= 7 days`;
  `>= 5` ad-library usages; brand `300,000+` monthly visits; `30+` active ads.
- FAIL: any single criterion not met → the source is not a validated swipe candidate.

**G27 One-for-one copy check** [COUNTABLE — presence]
- `is_one_for_one_copy == false` (structure reused, not the asset cloned).
- FAIL: asset is a direct clone of competitor content → shutdown risk.

---

## HEURISTIC gates (soft-cap — warn, never hard-fail; detectors over-flag)

**H1 Thumbnail top-performer signal** [HEURISTIC]
- Split-screen collaboration and close-up pattern/texture thumbnails *trend* as top performers;
  thumbnails tested independently from other variables. Warn if neither tested; never fail.

**H2 Minimalist-edit filler density** [HEURISTIC]
- Three required elements present (good script, scroll-stopper opening, clear AI voiceover);
  raw + basic cuts/captions preferred; excessive emojis/effects warned, not failed.

---

## FELT signal (pairwise-vs-specimen — never a hard FALSE, never self-graded)

**F1 Ad-to-landing-page congruency** [FELT]
- Target: every visible element of the ad matches the destination page (offer, hook, imagery,
  outcome promise). Judge pairwise against the congruency specimen in
  `references/specimens.md`: does this pair feel as congruent as the specimen? Return
  `prefer | tie | weaker`. `weaker` is a flag, not a kill.
