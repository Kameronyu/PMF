# Production procedures & tool stack (faithful to source)

Named execution procedures and the concrete tool stack the source prescribes. These are
sequenced workflows and named tools/costs — restored here so an executing agent has the
actual "how" and "with what," not just the gates. The scorer can check that a plan
SELECTED and SEQUENCED these correctly (returns `ordered | misordered | missing-slot` or
`correct-selection | wrong-selection`); it does not grade wording.

---

## Four-Step Video Ad Creation Process (Swipe-Script-Source-Edit) (Source: Mark Builds Brands)

A sequenced procedure. Order matters: Swipe → Script → Source → Edit (→ Scale).

1. **Swipe:** Find winning competitor ads via GetHooked/Get Hooked (enhanced Facebook Ads
   Library). Filter: 4–5 star rating, currently running, English, under 60 seconds, video
   format, minimum 7-day runtime, minimum 5 usages in ad library. Target competitor brands
   with 300,000+ monthly website visits and 30+ active ads running.
2. **Script:** Rewrite competitor script using Claude 3.7 Sonnet for your specific product.
   Preserve proven structure; do not copy directly. Research by downloading competitor sales
   pages as PDFs and uploading to ChatGPT with deep research prompts.
3. **Source content:** AI UGC (Make UGC AI, $7–10/video), B-roll from Gridbank or Runway V3,
   custom product footage (ship to Fiverr creator or film with iPhone, $100–300/ad).
4. **Edit:** CapCut (free) or Fiverr editors (~$50–100/ad). Raw, minimally edited content with
   basic cuts and captions outperforms over-produced content. Excessive emojis and effects
   reduce performance.
5. **Bonus — Scale:** Increase spend on winning creatives once validated.

**Never steal competitor content one-for-one.** Facebook metadata detection and AI detection
in 2025 cause account shutdowns. Original content achieves better CTR and day-one profitability.
(This is the source of the G27 gate; the four-step workflow is the procedure it sits inside.)

---

## AI-Powered Video Ad Creation System — tool stack + costs (Source: Mark Builds Brands)

**Tool stack by function:**
- **Scripts/hooks:** Claude 3.7 Sonnet (outperforms other models in split tests)
- **B-roll footage:** Runway V3 (nightmare/dream scenario footage)
- **AI UGC:** Make UGC AI ($7–10/video) or Cling AI (image-to-video animation)
- **Product shots:** ChatGPT for mockups → Kling AI image-to-video to animate
- **Full video generation:** Sora 2 (maximum 15-second clips, portrait orientation, up to 3
  simultaneous generations; mobile app supports custom characters for cross-clip consistency)
- **Realistic static images:** Higgsfield Soul model (most realistic image generation currently
  available)

**Sora 2 workflow:** Storyboard script into 15-second segments → generate Claude-written prompts
per segment → generate in Sora 2 → assemble in editor. Full process executable in under one hour.

**Target hook rate: 50%+** for video ads.

---

## Image-ad research-first production (Four-Document Foundation) (Source: Mark Builds Brands)

The image-ad analogue, already referenced as R12. Full procedure:

1. Capture successful competitor's full sales page
2. Use ChatGPT to generate: customer avatar, operational brief, necessary beliefs document,
   research compilation
3. Feed these documents + reference image from Get Hooked into ChatGPT
4. Ask ChatGPT to write the image generation prompt (do not write prompts manually — AI-written
   prompts are significantly more detailed and effective)
5. Generate using Higgsfield (Soul for realistic UGC, Flux Context Max for animated style,
   GPT Image for text-on-creative)

**Sources for winning image models:** Get Hooked with filters: 4–5 star, image format, still
running, minimum 7 days, English, Facebook/Instagram, 3+ creative usages, brand library 100+ ads.
