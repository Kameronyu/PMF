# ROUTE rules — selection / sequencing contract (no wording, no verdict band)

These are named-trigger selection and ordering rules. The scorer checks that the plan SELECTED
and SEQUENCED correctly — it does not grade wording (that is the writer's job). Anchor Angle,
Awareness level, UM, Hook to the registry.

## Angle & batching
- **R1** Translate the UM into **4 angles across the awareness spectrum**
  (unaware → problem aware → solution aware → most aware); angles cover pain, desired outcome,
  new-mechanism reveal, comparison.
- **R2** Organize production around angle; **format follows angle** (group ad sets by angle,
  vary format within).

## Structural slot order (sequencing — check order, not copy)
- **R3** Ad structure order: qualification hook → social proof → product demonstration →
  close-up quality shots → secondary value props.
- **R4** Sales-call order: hook → qualify → demonstrate → handle objections → close.
- **R5** Ad anatomy order: qualifying opener → urgency → pattern interrupt → objection handling
  → social proof → CTA.
- **R6** Objection sequence order: size → materials → use cases → gifting/unboxing.
- **R7** 5-part video order: Hook → Body → mid-ad first CTA → Testimonials/Social Proof →
  Implied close; length 60–90s.

## Format & method selection (by named trigger)
- **R8** Format by awareness/funnel role: Cartoon-Textbook / POV / Authority / Short-Form VSL;
  video for scaling, image for early testing, simple static for retargeting, founder &
  interview formats for trust / fatigue reduction.
- **R9** Method selection: Marksman (wide, one execution per angle, directional) → Sniper (one
  confirmed angle, deep) AFTER Marksman; Shotgun only for creator pipelines, never internal.
- **R10** Use ABO (not CBO) for experimental formats; migrate ABO → CBO only after validation.

## Production / operational sequencing
- **R11** Hook pre-validation procedure: traffic (not conversion) campaign; 10 white-box
  hook-text ads; auto-off at 1,000 impressions; highest-CTR hook wins.
- **R12** Four-document research foundation → AI writes the generation prompt (do not hand-write).
- **R13** After Facebook identifies winners → extract by post ID → migrate to scaling campaigns.
- **R14** Feedback loop: document hypothesis before test → ranked post-mortem after → track hit rate.
- **R15** Turn-off gate: before killing a high-spend ad, ask "Would redistributed spend achieve
  better ROAS?" — never kill without it.
- **R16** Weekly drip-feed: launch 3–4 videos Monday midnight; never dump all at once.
- **R17** Mirror top-performing organic in the target feed; match creator demographics to
  audience, **split-test the opposite demographic**, brief **B-roll only** for recyclability,
  and **don't underpay creators**. Full creator/UGC sourcing decision rules: `references/strategies.md`.
- **R20** Concentrate variation effort by impact: **messaging > creative > CTA**
  (messaging changes move conversion most; CTA least). See `references/strategies.md`.
- **R21** Format/strategy selection by goal: **scenario/viral** content (validate angle → scale
  via micro-influencers with creative freedom); **meme-format** social-proof ads (optimize for
  comments/tags, engagement as a CPM lever); **inclusive single-campaign** creative (diversity
  in one campaign, not separate campaigns per segment). Detail + worked examples:
  `references/strategies.md`.

## Account infrastructure
- **R18** 3BM structure: BM1 pixel / BM2 holding / BM3 ad-account; 3+ admins each; required at $1K+/day.
- **R19** Account warming: Method A (7-day engagement) or Method B (pyramid) for fresh/reset accounts.

A ROUTE check returns `ordered | misordered | missing-slot` (sequence) or
`correct-selection | wrong-selection` (selection) — not a pass/fail band.
