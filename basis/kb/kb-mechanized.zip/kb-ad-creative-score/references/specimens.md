# Specimens — verbatim source lines to judge the FELT signal against

These are real lines from the source KB. Felt criterion F1 (ad↔landing-page congruency) is
scored **pairwise against the congruency specimen below**, never on an absolute scale and never
by the agent that produced the candidate. All quotes are verbatim substrings of the source
files — the `check_specimens.py` gate enforces this.

## Congruency reference (judge F1 against this)

A congruent ad→landing-page pair the source holds up as the standard — the same outcome
promise carried from creative to destination, with matching before/after proof:

- "Landing page headline: "Don't dream of perfect curls, get them" — direct outcome statement"
- "Combined with bundle offer ($70+ AOV) and before/after social proof on landing page"

The source's own rule for this criterion:

- "Ad-to-landing page congruency is non-negotiable — every element must match"

Ask: does the candidate pair carry the ad's offer, outcome promise, and proof onto the page as
fully as this specimen does? Return `prefer | tie | weaker`. `weaker` is a flag, not a kill.

## Worked-good supporting lines (presence cues the congruent pair satisfies)

- "Personalize and localize using dynamic keywords (city names) to improve CTR"
- "Include price or value proposition directly in the headline"
- "Before/after images generate strong CTRs"

## Anti-pattern foil (NOT a specimen — deliberately not used as a winner)

Round-number anti-pattern: a price like "$10,000" is a contrast example, not a winner.
(Flagged so the checker skips it; never quote it as a passing specimen.)
