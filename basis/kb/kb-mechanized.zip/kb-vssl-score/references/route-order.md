# ROUTE contract — named-trigger ordering, placement, and prerequisites

These are sequencing checks: each asks "are the named slots present in the correct order?"
not "is the wording good?". A ROUTE violation is flagged; it does not assign a quality
verdict and (except where noted) does not auto-band. Wording quality lives in the writer.

## 8-stage narrative order (Carl Weische)
Hook → Expand the Promise → Authority Building → Personal Story-Driven Epiphany → Problem
Education + Downstream Consequences → Product Introduction → Solution Education → CTA with
Binary Options Close.
- Check: the eight named stages appear in this order; Product Introduction sits at stage 6
  (~2/3 in), consistent with G1.

## 9-ingredient order (Mark Builds Brands)
Micro Lead → The Lead → Discovery Story → Unique Mechanism of the Problem → Unique Mechanism
of the Solution → Product Reveal → Price Drop → Risk Reversal → Social Proof.
- Check: the nine named ingredients appear in this order.
- **Placement rule:** Social Proof is placed AFTER product reveal and pricing, not before.
  Social proof before product reveal/pricing → ROUTE violation, flag.
- Sub-structure (presence, not order-gated): Micro Lead fires Copy + Scroll Stopper + Audio
  simultaneously; the Lead opens loops in the first 20s; Discovery Story uses a hero's-journey
  arc (failed attempts → chance encounter → solution).

## Prerequisite gate
All three brief documents — Avatar Sheet, Offer Brief, Necessary Beliefs Document — must be
completed BEFORE any copy is written. A missing brief is a prerequisite violation → flag.

## Funnel order
Ad → Advertorial → VSL Page → Order Page. The VSL page contains nothing except the video
(no navigation, no competing elements, no product listings).

## Shade-throwing placement
Critique of alternatives is placed AFTER the founder's story and problem education, and is
limited to believable alternatives the prospect has already tried or considered. Placement
check only — the critique wording itself is a writer concern.

## Hero's-Journey YouTube route (selection by named trigger)
When the chosen route is YouTube scaling: 10–30 minute VSL, broad or interest-based
targeting, viewers sent directly to checkout with no intermediate funnel steps. This is a
route selection, not a quality gate.
