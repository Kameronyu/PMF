# Per-gate membership tests + COUNTABLE token definitions

All six gates are COUNTABLE (hard-gate). Each test is deterministic — a script returns the
same verdict every time. Each `pass` must carry an `evidence_quote` that is a verbatim
substring of the input (the script/plan/research artifact being scored). No quote → no pass.

## G1 — Product-mention position (COUNTABLE, hard-gate; carries an override)
- `first_mention_pct = (timestamp of first product mention) / (total runtime) * 100`
- PASS iff `first_mention_pct ≥ 50`. SOFT-WARN if `50 ≤ first_mention_pct < 66` (target is 66%+).
- FAIL → caps the band at REWORK regardless of other gates.
- Anchor: "Product is never mentioned in the first 50% of the VSL"; "Product introduction
  target: no earlier than 50% through VSL, ideally at 66%+".

## G2 — Readability (COUNTABLE, hard-gate)
- `grade_level = readability grade of the full script` (e.g. Flesch–Kincaid grade).
- PASS iff `grade_level ≤ 7` (seventh-grade reading level or below).
- Anchor: "Readability standard: seventh-grade reading level or below".

## G3 — Research depth (COUNTABLE, hard-gate)
- `pages = page count of the prospect-intelligence research output produced before writing`.
- PASS iff `pages ≥ 5`.
- The research must capture pains, desires, motivations, and verbatim language patterns
  (a presence check on the artifact, not a re-scoring of its quality).
- Anchor: "Generate minimum 5 pages of prospect intelligence output".
- The procedure that produces this artifact (six-step ChatGPT + OpenAI Operator workflow) is
  in `references/upstream-procedures.md` — score the artifact it yields, not the workflow.

## G4 — Necessary-beliefs count (COUNTABLE, hard-gate)
- `belief_count = number of distinct purchase beliefs listed in the Necessary Beliefs Document`.
- PASS iff `3 ≤ belief_count ≤ 7`.
- Each entry must be a specific belief the prospect must hold to purchase (a stated belief,
  not a topic label). Anchor: "3–7 specific beliefs prospect must hold to purchase".

## G5 — Swipe filter (COUNTABLE, hard-gate; conjunction)
- A swipe qualifies only if ALL three hold:
  - `dur_min ≥ 3` (duration in minutes)
  - `run_days ≥ 7` (active run time)
  - `active_ads ≥ 30` (brand running ≥30 active ads simultaneously)
- PASS iff `dur_min ≥ 3 AND run_days ≥ 7 AND active_ads ≥ 30`. Any one short → FAIL.
- Anchor: "Duration: 3+ minutes / Active run time: 7+ days / Brand scale: 30+ active ads".
- This filter only validates a swipe's qualification. The swipe-research *execution* it gates
  (search cross-industry, transcribe winners, use as structure-not-copy) is in
  `references/upstream-procedures.md`.

## G6 — Micro-lead test volume (COUNTABLE, hard-gate)
- `variants_per_week = number of VSL variants tested per week, varied at the micro-lead level`.
- PASS iff `10 ≤ variants_per_week ≤ 20`.
- Anchor: "Run 10–20 VSL variants per week with variation concentrated at the micro lead level".

## Why the tiers
Hard-gating a countable check (a percentage, a grade level, a page count, a conjunction of
numeric thresholds) is reproducible and safe — the number is or is not above the bound.
Hard-gating a felt check (does the Stage-1 promise "match" the ad hook?) produces
confident-but-wrong FALSEs, so congruence stays a pairwise-vs-specimen signal (see
`scoring-specimens.md`). Ordering is a ROUTE contract (`route-order.md`), not a quality gate.
