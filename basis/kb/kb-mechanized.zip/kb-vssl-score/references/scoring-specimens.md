# Scoring specimens — the known-good lines to judge the FELT signal against

The one FELT signal (ad-to-VSL congruence) is scored **pairwise against these specimens**,
not on an absolute scale and never by the model that wrote the candidate. Randomize
presentation order; treat any single verdict as a triage signal, not a certification.
Every line below is verbatim from a source VSL file.

## Ad-to-VSL congruence reference (judge the Stage-1 promise against these)

The standard the candidate's Stage-1 big promise must match the ad hook against:
"same angle, same language, same promise". A congruent Stage-1 promise reads like a
direct continuation of the winning ad hook.

Reference desired-situation promise (the vivid, specific Stage-1 outcome a hook lands):
- "get chased, loved, and adored by 10 out of 10 women"

Reference current-pain callout (the specific struggle the promise resolves):
- "while you may struggle to get a text back, quality matches on Tinder, let alone serious dates"

Reference micro-lead hook (a 2-second promise that names the moment of need):
- "Watch this before removing facial hair"

Ask: does the candidate's Stage-1 promise continue its ad hook as tightly as these specimen
lines fit their own avatar's moment? → prefer | tie | weaker.

## Supporting felt-craft reference lines (verbatim — for register, not gates)

These show the emotional register a congruent VSL sustains; they are reference points, not
pass/fail tests:
- pattern-interrupt transition: "let's cut the crap"
- binary-close inaction framing: "tomorrow becomes next week, next month, next year"
- risk-reversal line: "you literally have nothing to lose"
- identity appeal: "rare 5% who take action"
- nightmare-scenario lead tone: "I was like you, but worse"

## How to run the pairwise judge
1. Present the candidate's Stage-1 promise (with its ad hook) + one specimen, order randomized.
2. Ask which better satisfies same-angle/same-language/same-promise congruence, and why
   (reasoning before verdict).
3. Record `prefer | tie | weaker` + the reason. `weaker` drops the band one notch and flags
   the realign-Stage-1-promise-to-the-ad-hook action; it never manufactures a pass.
4. Never let the model that generated the candidate be the judge.
