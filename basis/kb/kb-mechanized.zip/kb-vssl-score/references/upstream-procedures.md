# Upstream procedures — how the gated artifacts are produced (faithful to source)

The scorer counts artifacts (research pages for G3, swipe qualification for G5) and checks
prerequisites (the editor-direction system). These are the procedures that produce those
artifacts, kept here so a checker understands what a sound input looks like. The scorer grades
the *artifact*, not the workflow — but knowing the workflow tells you what a missing or thin
artifact implies.

---

## AI-Powered VSL Research Process (Source: Mark Builds Brands) — produces the G3 artifact

Six-step pre-writing research workflow:

1. Draft research prompts in ChatGPT
2. Execute those prompts in **OpenAI Operator agent** (automated web research)
3. Generate minimum **5 pages** of prospect intelligence output
4. Research must capture: pain points, desires, motivations, and verbatim language patterns
5. Upload research document to AI to auto-populate the three brief documents (Avatar Sheet,
   Offer Brief, Necessary Beliefs Document)
6. Use populated documents as copy foundation — no guessing at prospect psychology

**Tools:** ChatGPT (prompt drafting) + OpenAI Operator (research execution)

G3 counts the ≥5 pages this step yields, and checks the four required captures (pains,
desires, motivations, verbatim language) are present.

---

## Swipe-research execution (Source: Mark Builds Brands) — what G5 gates

G5 validates a swipe's qualification (duration ≥3 min, run ≥7 days, brand ≥30 active ads).
The execution that produces the swipe pool:

- Cross-industry VSL structures transfer — **do not limit research to your product category.**
- Generate full transcripts of winning ads.
- Use swipe as **structural inspiration only**, not copy to plagiarize.
- Adapt the architecture to your product's unique mechanism and avatar.

Tooling: **Get Hooked AI** to locate winning ads.

A checker note: a swipe drawn only from the candidate's own vertical is a thin pool even when
each individual swipe passes G5 — flag "restrict swipe research to own industry" as a process
weakness (it is also a negative, see SKILL.md).

---

## Editor-direction system (Source: Mark Builds Brands) — prerequisite, paired with a negative

**Editor direction system:** Build a Google Sheets document mapping every line of copy to a
specific video clip. Most editors have no VSL experience; without this map, they will
misinterpret pacing and emotional sequencing. The sheet eliminates ambiguity in
post-production.

Its absence is the negative **"No editor direction system"** — sending scripts to editors
without a clip-by-clip Google Sheets map results in pacing and emotional sequencing errors
from editors unfamiliar with VSL conventions. Treat as a production prerequisite violation:
flag, does not auto-band.
