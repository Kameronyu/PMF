# Scoring specimens — known-good lines to judge HEURISTIC fields against

Felt fields (H1 placement, H2 relevance, H3 AOV-framing, H4 value-add) are scored
**pairwise against these**, returning `prefer | tie | weaker` — never on an absolute scale,
never by the agent that authored the config. `weaker` contributes no pass for that field.

## Testimonial-placement reference (judge H1 against this)
- "position them adjacent to the CTA button and price display"
- "Embedded directly on order page to reduce abandonment at the point of highest purchase anxiety. Testimonials should address objections specific to the transaction"

## Upsell-relevance reference (judge H2 against this)
- "every offer should be a logical extension of what the customer already bought"
- "Low-cost, high-relevance add-ons presented at checkout"

## AOV-not-volume reference (judge H3 against this)
- "a 25% AOV increase has the same revenue impact as a 25% increase in conversion rate"

## Value-add-vs-manipulation reference (judge H4 against this)
- "every element must feel like value-add, not manipulation"
- "Aggressive AOV stacking that damages trust reduces LTV"

## How to run the pairwise judge
1. Present the candidate config field + one specimen, order randomized.
2. Ask which better satisfies the named field and why (criterion before verdict).
3. Record `prefer|tie|weaker` + the reason. `weaker` contributes no pass.
4. Never let the agent that produced the config be the judge.
