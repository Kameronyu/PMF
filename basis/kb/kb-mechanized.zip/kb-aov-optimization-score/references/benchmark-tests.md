# Per-field membership tests + COUNTABLE gate definitions

All COUNTABLE gates are **advisory**: an out-of-band value is FLAGGED, never kills the
config. Heuristic fields are pairwise-vs-specimen signals (`prefer|tie|weaker`), never a
hard FALSE, never self-graded.

## COUNTABLE gates (script-decidable: number-vs-band / count-vs-cap)

**B1 Order-bump attach rate** — `in_band = 20 <= attach_pct <= 40`.
- attach_pct = % of converting customers who take the bump. Outside band → flag
  `attach-out-of-band` (low: bump mismatched/over-priced; high: verify measurement).

**B2 Quantity-booster lift** — `in_band = 25 <= aov_lift_pct <= 60`.
- aov_lift_pct = AOV of multi-unit tier vs single-unit baseline. Below 25 → flag
  `weak-quantity-lift` (tier discount too shallow to move math).

*Mechanism (why the band exists):* quantity boosters share the same anchoring logic as the
offer-variation tiers (route-rules R5) — exposing the per-unit price across tiers makes the
volume math visible, so the multi-unit purchase reads as a rational decision rather than an
impulse buy. A discount too shallow to move that visible per-unit math is what produces a
below-25% lift.
- Quote: "Quantity boosters work on the same principle — per-unit price decreases with volume, making the math visible and the multi-unit purchase feel rational rather than impulsive."

**B3 Post-purchase OTO 1 conversion** — `in_band = 15 <= oto1_conv_pct <= 35`
  AND `1.5 <= oto1_price_ratio <= 2` (ratio = OTO1 price ÷ core price).
- Either out → flag `oto1-out-of-band`.

**B4 Order-page stacking lift** — `in_band = 20 <= stack_aov_pct <= 30`.
- stack_aov_pct = AOV improvement from quantity + bump + variations together, at fixed ad
  spend/traffic. Below 20 → flag `weak-stack`.

**E1 Element-count cap (hard advisory cap)** — `within_cap = element_count <= 3`.
- element_count = distinct high-impact order-page elements (quantity / bump / social proof
  / variations). `> 3` → flag `cognitive-overload` (abandonment risk; prioritize 2-3).

**E2 Order-bump price ratio (hard advisory cap)** — `no_brainer = 10 <= bump_pct <= 30`
  (bump_pct = bump price ÷ core offer price). `> 30` → flag `bump-priced-too-high`
  (attach-rate penalty; keep it a "no-brainer" add-on).

## HEURISTIC fields (FELT — pairwise vs specimen in `references/scoring-specimens.md`)

**H1 Testimonial placement** — *target:* social proof sits adjacent to the CTA button /
price, not below the fold. *Judge:* signal `prefer|tie|weaker` vs the placement specimen.
Never a hard FALSE.

**H2 Upsell relevance** — *target:* every OTO/downsell reads as a logical extension of what
the customer already bought. *Judge:* pairwise vs the relevance specimen.

**H3 AOV-not-volume framing** — *target:* the plan treats an AOV gain as equal in revenue
impact to the same-size conversion gain, rather than chasing volume only. *Judge:* pairwise
signal, not a gate.

**H4 Value-add vs manipulation** — *target:* stacking preserves the customer relationship;
each element reads as value-add. *Judge:* pairwise vs the trust specimen. This is steering,
not a kill switch.

## Why the tiers
A benchmark band and an element count are reproducible — a script marks them the same way
every run, so hard-gate them (as advisory flags). "Feels like value-add" or "logical
extension" are judgment calls; hard-gating them manufactures confident-but-wrong FALSEs and
pushes builders to game the gate. Soft-cap those as pairwise signals against a known-good
specimen.
