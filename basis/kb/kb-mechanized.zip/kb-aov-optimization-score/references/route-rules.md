# ROUTE rules — sequencing & selection contract (dictates no wording)

These are named-trigger selection/ordering rules, not quality gates. The scorer checks the
config OBEYS them; it does not grade prose. Each carries its source quote.

## R1 — Order page before upsells (sequencing)
The order-page stack is step one; OTO sequences follow immediately after purchase
confirmation. Stack multiple elements simultaneously rather than relying on a single
mechanism.
- Check: order-page config exists and is optimized before any OTO sequence is defined.
- Quote: "The order page is the primary AOV lever — optimized before upsell sequences begin."

## R2 — Post-purchase order (sequencing)
OTO 1 = highest-margin / most-relevant upsell (typically 1.5-3x core price) → OTO 2 =
complementary product or service → Downsell = reduced version or payment plan of a declined
OTO to recover lost revenue.
- Check: if a post-purchase sequence exists, it follows OTO1 → OTO2 → Downsell ordering.
- Quote: "Downsell: Reduced version or payment plan of a declined OTO to recover otherwise lost revenue"

## R3 — Capture-point preference (trigger)
Prefer order-page order bumps over post-purchase OTOs where possible; bumps convert higher
because the customer has not yet mentally "closed" the transaction.
- Check: a high-relevance add-on is offered as an order-page bump, not deferred to a
  post-purchase OTO, where the offer fits the bump format.
- Quote: "Order bumps captured on the order page convert at higher rates than post-purchase OTOs because the customer has not yet mentally \"closed\" the transaction."

## R5 — Offer-variation anchoring (tier-construction design rule)
When the config presents multiple price points / offer variations on one page, the tiers must
be structured and labelled to anchor selection toward the middle, not merely listed. Present
2-3 tiers with an explicit high anchor (e.g. Starter / Most Popular / Best Value) so the
highest tier makes the mid-tier feel reasonable. The objective is to lift the AVERAGE order
value, not to push every customer to the top tier.
- Check: when "Multiple Offer Variations" is present, tiers are ordered/labelled with a high
  anchor above a mid "most popular" option (not a flat, unanchored list); success metric is
  average-order-value shift, not top-tier take rate.
- Quote: "Presenting multiple price points on the same page (e.g., Starter / Most Popular / Best Value) leverages anchoring: the highest tier makes the mid-tier feel reasonable, increasing mid-tier selection rates. The goal is not to push everyone to the highest tier but to shift the average upward."

## R4 — Relationship constraint (steering, not a gate)
Maximize offers presented in a single session while preserving the customer relationship;
aggressive stacking that damages trust reduces LTV. The felt clause is judged as H4 (a
pairwise signal), never a hard FALSE.
- Quote: "Maximize the number of offers presented to the customer in a single session while preserving the customer relationship."
