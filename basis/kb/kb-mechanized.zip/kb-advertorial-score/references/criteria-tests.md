# Per-criterion membership tests, COUNTABLE gate definitions, and ROUTE contracts

## COUNTABLE gates (script-checkable; each can return FALSE)

**G1 — 50/50 split** *(target: first 50% = education + problem-ID; second 50% = trust-building + selling)*
- Split the page at the midpoint by section count (or word count).
- `pass iff` the first half is dominated by education/problem-identification sections AND the
  second half is dominated by trust-building / selling sections.
- The offer/price reveal must fall in the second half (ties to G2). FALSE if selling starts in half one.

**G2 — No premature reveal** *(target: brand, product name, offer, and price tokens ABSENT until the dedicated offer/solution-reveal section)*
- `reveal_tokens = {brand name, product name, price/$ figure, discount %, offer/CTA}`.
- `pass iff` none of these appear in any section before the offer presentation / solution-discovery section.
- FALSE example (Common Pitfall): "Revealing brand, product name, or price before desire is fully built — kills trust sequence".

**G3 — CTA closing stack** *(target: closing CTA carries a discount %, a free-item count, AND an urgency/scarcity token)*
- `pass iff contains(discount %) AND contains(free-item count) AND contains(urgency token)`.
- Benchmark: "46% off + 3 free items + sell-out urgency as closing stack".

**G4 — Credibility number present** *(target: an authority/credibility figure appears on the offer page)*
- `pass iff` a numeric credibility signal (e.g. studies cited, customer count) appears on the offer page.
- Benchmark: "100,000+ studies cited on offer page (Nubru model)". Advisory — never bands below VIABLE alone.

**G5 — Listicle item count** *(target: list length ∈ {5, 7, 10}; odd preferred)*
- `pass iff item_count ∈ {5, 7, 10}`. Soft-prefer odd (5 or 7) over 10.
- Source enum: "Listicle item count**: 5, 7, or 10 items (odd numbers perform best for list format)".
- Applies ONLY when the page uses the listicle format; mark `n/a` otherwise (n/a never fails).

**G6 — Objection count** *(target: 5–7 named customer objections drive the headline/CTA list)*
- `pass iff 5 <= named_objections <= 7`. Source: "Identify top 5–7 customer objections to build headline list".

**G7 — Production-process integrity** *(target: copy produced in chunks; research + 4 docs precede writing; chiefing performed; swipe from an actively-running ad)*
- `pass iff` all four hold:
  - copy written section-by-section, not one prompt ("Write section by section: headline, lead, body blocks, transition to offer, etc.");
  - research + the four foundational documents precede any copy ("Four documents are constructed from research outputs before any copy is written");
  - a chiefing/review step ran ("apply direct response judgment to tone, authenticity, and sales resistance");
  - swipe target had active paid spend ("active spend indicates proven conversion").
- This is a process gate — score only when the production trace is supplied; else `n/a`.

## FELT signals (pairwise-vs-specimen; NEVER a hard FALSE; return prefer | tie | weaker)

**F1 — Narrator posture** *(target: narrator reads as critical/skeptical/thorough, not instantly enthusiastic)*
- Judge against the narrator-posture reference in `scoring-specimens.md`.
- FALSE-pull foil (Common Pitfall, do not hard-fail): narrator appearing immediately enthusiastic destroys editorial credibility.

**F2 — Skimmability** *(target: headlines alone deliver full education + trust without body copy)*
- Strip the body; read headlines only. Does the skim alone convey education + trust as well as the listicle-title specimen?
- Source rule: "Headlines must be written so skimming alone delivers full education and trust."

**F3 — Chiefing tone judgment** *(target: tone, authenticity, low sales-resistance)*
- Judge against a winning hook/opening specimen; do not auto-fail. Source: Step 5 chiefing reviews "tone, authenticity, and sales resistance".

## ROUTE contracts (named-sequence / selection; structure, not wording — verify order, not prose)

- **8-Stage narrative order:** Hook → Authority signals → Resonant opening → Root-cause education → Solution introduction → Social proof → Mechanism explanation → Offer presentation.
- **5-Section psychological order:** Problem identification → Motivation to solve → Education about causes → Consequences/implications → Solution discovery.
- **10-Section blueprint order:** Above the fold → Listicle block → Unique mechanism → Trust building → Product introduction → Extensive social proof → Risk reversal → Multiple CTAs → Social proof stack → Final close. Final close = **two-option framework with last CTA** (source: "**Final close**: Two-option framework with last CTA") — verify the close presents a two-option choice carrying the last CTA, not a single button.
- **Comparison-framework order:** skeptical question → educate (deficiency/need) → comparison framework → eliminate competitors (outliers/qualifiers/transparency) → price anchoring → authority via ingredient breakdown → in-page purchase.
- **Four-part paragraph beats:** Pain Point → Ripple Effect of Pain → Product Feature → Benefit/Resolution.
- **Listicle item function:** each item serves ≥1 of {USP showcase, desired situation, trust signal}.
- **Hook-image placement:** hook image shows the desired transformation outcome; future-pacing imagery shows the prospect already using the solution.
- **Funnel position:** Cold Ad → Advertorial → Sales Page (never replacing either).
- **Five-step AI production order:** Research → build 4 foundational documents → find active-spend competitor swipe (convert to PDF, extract structure not content) → write in chunks → chief the copy.
- **Vertical query targeting:** in competitive verticals, target lifestyle/educational queries over direct product terms.

## Anchor terms (registry — never redefine here)
UM (Unique Mechanism), Trust signals, Hook, Objection handle, Awareness level,
Angle architecture rule (for long-form), Awareness × angle tier. Use the registry's definitions.

## Why the tiers
Hard-gating a felt criterion (posture, skimmability, tone) produces confident-but-wrong
FALSEs and pushes writers to game the gate. Hard-gating a countable one (a split position,
a token presence, an item count in {5,7,10}) is reproducible and safe.
