# Scoring specimens — the known-good advertorial copy to judge FELT criteria against

Felt criteria (narrator posture, skimmability, chiefing tone) are scored **pairwise
against these**, not on an absolute scale and never by the model that wrote the candidate.
Randomize presentation order; treat any single verdict as a triage signal, not a
certification. Return `prefer | tie | weaker`; `weaker` contributes no pass.

## Hook / opening copy (judge resonance + first-person posture against these)
- "My battle with relentless weight gain had me hopeless until I discovered this"
- "If you find yourself googling 'why can't I lose weight'"
- "Do multivitamins actually work?"
- "They laughed when I sat down at the piano"

## Mechanism-framing copy (judge root-cause / UM education against this)
- "stable weight gain is often just a surface symptom of something much deeper."

## Headline / listicle title (judge skimmability of headlines-alone against this)
- "Six Reasons Americans are Switching to These NASA Inspired Sheets."

## Narrator-posture reference (judge skeptical-vs-enthusiastic against this rule)
- "Narrator must appear critical, skeptical, and thorough — not immediately enthusiastic — to preserve trust."

## How to run the pairwise judge
1. Present candidate + one specimen, order randomized.
2. Ask which better satisfies the named criterion and why (criteria before verdict).
3. Record `prefer|tie|weaker` + the reason. `weaker` contributes no pass for that criterion.
4. Never let the model that generated the candidate be the judge — run on a different model.
