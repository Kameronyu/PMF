---
name: kb-advertorial-score
description: >-
  Score an advertorial pre-sell page for structural soundness before it ships traffic. Use to
  grade a draft advertorial (written by a human, kb-advertorial-write, or any source) and return
  REWORK / VIABLE / SHIP-READY with per-gate evidence. Hard-gates only the countable (50/50 split,
  no-premature-reveal, listicle count, CTA stack, objection count, production integrity); treats
  felt criteria (narrator posture, skimmability, chiefing tone) as pairwise-against-specimen
  signals, never self-graded pass/fail. Run as a SEPARATE pass from the writer. Triggers:
  "score this advertorial", "is this advertorial ready to run", "check this pre-sell page".
---

# Advertorial — score structural soundness before you spend traffic

Grade a draft advertorial against the gates below, then band it. **Do not run this in the same
pass that wrote the page** — a writer grading itself rates its own output higher. Judge felt
criteria against the winning copy in `references/scoring-specimens.md`, ideally on a different model.

Tier discipline: **hard-gate only the countable**; the heuristic stays a signal; **a felt criterion
is judged pairwise against a specimen — never hard-FALSE'd, never self-graded.**

## The gates (each: positive target → how it's judged → tier)

1. **50/50 split** — *target:* first half = education + problem-ID; second half = trust-building + selling.
   *Judge:* **script gate** — selling/reveal absent from half one. Tier: COUNTABLE → hard-gate. (G1)
2. **No premature reveal** — *target:* brand, product name, offer, price tokens ABSENT until the offer/reveal section.
   *Judge:* **script gate** — `not-contains` reveal tokens before that section. Tier: COUNTABLE → hard-gate. (G2)
3. **CTA closing stack** — *target:* closing CTA carries a discount %, a free-item count, AND an urgency token.
   *Judge:* **script gate** — `contains-all` three. Tier: COUNTABLE → hard-gate. (G3)
4. **Credibility number** — *target:* an authority/credibility figure (studies, counts) on the offer page.
   *Judge:* **script gate** — a numeric credibility token present. Tier: COUNTABLE → hard-gate (advisory). (G4)
5. **Listicle item count** — *target:* list length ∈ {5, 7, 10}; odd preferred.
   *Judge:* **script gate** — `item_count ∈ {5,7,10}`; `n/a` if not a listicle. Tier: COUNTABLE → hard-gate. (G5)
6. **Objection count** — *target:* 5–7 named objections drive the headline/CTA list.
   *Judge:* **script gate** — `5 <= count <= 7`. Tier: COUNTABLE → hard-gate. (G6)
7. **Production integrity** — *target:* chunked writing; research + 4 docs precede copy; chiefing ran; swipe from active-spend ad.
   *Judge:* **script gate** over the production trace; `n/a` if no trace supplied. Tier: COUNTABLE → hard-gate. (G7)
8. **Narrator posture** — *target:* critical/skeptical/thorough, not instantly enthusiastic.
   *Judge:* FELT — pairwise vs the posture specimen. Tier: FELT (signal; never a hard FALSE). (F1)
9. **Skimmability** — *target:* headlines alone deliver education + trust.
   *Judge:* FELT — pairwise vs the listicle-title specimen. Tier: FELT (signal). (F2)
10. **Chiefing tone** — *target:* tone, authenticity, low sales-resistance.
    *Judge:* FELT — pairwise vs a winning opening specimen; do not auto-fail. Tier: FELT (signal). (F3)

Membership tests, the COUNTABLE gate definitions, and the ROUTE sequence contracts are in
`references/criteria-tests.md`. Felt specimens are in `references/scoring-specimens.md`.

## Bands (derive from gates that actually passed — not a hollow count)

- **any COUNTABLE hard-gate (G1, G2, G3, G5, G6, G7) FAILED → REWORK** (fix before any spend).
- **all applicable hard-gates pass, ≥1 felt signal is `weaker` → VIABLE** (run, but revise the weak signal).
- **all applicable hard-gates pass AND no felt signal is `weaker` → SHIP-READY.**

`n/a` gates (non-listicle G5, no-trace G7) do not count against the band. G4 is advisory: its
failure caps the band at VIABLE, never REWORK. A felt signal contributes a pass only when the
pairwise judge returns `prefer`; it never manufactures a pass on its own.

## The negatives live here (≤5), each paired with a positive target

Moved out of the writer (where banning a token summons it). Each is a checker rule:

- **Premature brand/product/price reveal** → fails G2; flag REWORK. (positive: hold all reveal tokens until the offer section)
- **Instantly-enthusiastic narrator** → weakens F1. (positive: open critical, skeptical, thorough)
- **Generic testimonials** → flag. (positive: specific, story-driven social proof)
- **Single CTA with no pain specificity** → flag. (positive: each CTA addresses a distinct objection)
- **Whole advertorial written in one AI prompt** → fails G7. (positive: chunk the production, section by section)

## ROUTE rules (contract — named sequence/selection, verified as order not wording)

The named-sequence and selection contracts (8-stage / 5-section / 10-section orders, comparison
framework, four-part paragraph beats, listicle item function, hook-image placement, funnel
position, five-step AI production order, vertical query targeting) are housed in
`references/criteria-tests.md`. Verify a page follows the order; do not grade its prose here.

## Output contract (per advertorial)

```
advertorial: "<id or first headline, verbatim>"
gates: [ {n, target, verdict: pass|fail|signal|n/a, tier, evidence_quote, source} ]
countable_gates: {split, no_reveal, cta_stack, credibility, listicle_count, objection_count, production}  # script, pass|fail|n/a
felt_signals: {narrator_posture, skimmability, chiefing_tone}  # pairwise-vs-specimen, prefer|tie|weaker
route_checks: [ {contract, in_order: true|false} ]   # sequence/selection contracts
band: REWORK | VIABLE | SHIP-READY
flags: [ ... ]   # from the negatives list
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every gate has a verdict; band present; route_checks present.
**SOUNDNESS:** every COUNTABLE verdict came from the script (not eyeballed); every felt verdict
is pairwise-vs-specimen, not self-graded; band derived only from gates that passed their tier's
check; each non-`n/a` `pass`/`fail` carries an `evidence_quote` that is a verbatim substring of
the draft or source. `emit_ready` only if SOUNDNESS holds; else `BLOCKED:<gate>`.

## Self-test (is this grader sound?) — any NO, fix

- Are only the countable gates (G1–G7) hard-gated by script, with F1–F3 as pairwise-vs-specimen signals?
- Is the felt judgment run separately from the writer, against a real specimen, on a different model?
- Does the band come from gates that passed their tier's check, not a raw count (n/a excluded, G4 advisory)?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Are the ROUTE contracts kept as order/selection checks, not re-housed as wording gates?
- Is every quoted specimen a verbatim substring of a source file (no composites)?
