---
name: kb-ads-score
description: >-
  Score a paid-ad creative or campaign config for launch viability before you spend test
  budget. Use to grade an ad (written by a human, kb-ads-write, or any source) against the
  countable gates — hook rate, hold rate, ad-side CPM/CTR/CPC, landing-page CVR floor, kill
  signals, CBO budget floor, Dynamic Creative cap, campaign structure — and return
  KILL / NEEDS-WORK / LAUNCH-READY with per-field evidence. Hard-gates only the countable;
  soft-caps element-presence and pitfalls; treats hook pull as pairwise-vs-specimen, never
  self-graded. Run as a SEPARATE pass from the writer. Triggers: "score this ad",
  "is this creative ready to launch", "check this campaign config", "should I kill this ad".
---

# Ads — score launch viability before you spend test budget

Grade the ad/config against countable gates, then band it. **Do not run this in the same pass
that wrote the ad** — a writer grading itself rates its own output higher. Judge felt hook
pull against the winning lines in `references/copy-specimens.md`, ideally on a different model.

Tier discipline (the rule a fused skill breaks): **hard-gate only the countable** (numbers
from the ad manager or planned config); **soft-cap the heuristic** (element presence, pitfalls);
**compare the felt hook against a specimen — never hard-FALSE it.**

## What gets judged (each: positive target -> how it's judged -> tier)

- **Performance gates G1–G8** — hook rate ≥50%, hold rate ≥25%, website CVR ≥1% (delivery-
  penalty floor), CPM ≤$30, link CTR ≥3%, link CPC ≤$1.50, kill signals, hook ≤5s.
  *Judge:* **script gate** against supplied numbers. Tier: COUNTABLE -> hard-gate.
- **Structure gates S1–S15** — CBO floor (ads×$10 / $50), 3-5×2-5 sets, Dynamic Creative ≤20,
  exactly 5 campaign types, 90/10 split, ASC cap ≤5%, scaling steps, ≥25 concepts/week, etc.
  *Judge:* **script gate** against the planned config. Tier: COUNTABLE -> hard-gate.
- **H1 Eight DR elements** — *target:* all eight present (scarcity optional for premium).
  *Judge:* presence warn per missing element. Tier: HEURISTIC -> soft-cap.
- **H2 Pitfalls** — *target:* none of the ≤5 pitfalls present. *Judge:* soft warn, each paired
  with its positive target. Tier: HEURISTIC -> soft-cap.
- **F1 Hook visceral pull (PIG)** / **F2 Pain-point curiosity gap** — *target:* the hook makes
  the next line necessary / opens a gap the avatar must resolve. *Judge:* FELT — pairwise vs a
  copy specimen, `prefer|tie|weaker`; never a hard FALSE, never self-graded.

- **Infra/config readiness** — *target:* redundant ad accounts/BMs/pages/pixels with a
  same-day relaunch path (shutdowns cost **30-50%**); pixel-obfuscation config (front-end data
  to FB pixel for lower CPAs, server-side e.g. Hyros for full data). *Judge:* presence warn.
  Tier: HEURISTIC -> soft-cap. The FB auction four-step funnel (why action-rate/user-value
  matter) is the mechanism behind G3/G-thresholds. See `references/criteria-tests.md`.

Gate definitions, enums, membership tests, the auction mechanism, infra/config checks,
channel-selection detail, and the pairwise judge live in `references/criteria-tests.md` and
`references/copy-specimens.md`.

## Bands (derive from gates that actually passed — not a hollow count)

- **Any KILL signal (G7) true, OR any G/S hard gate failed -> KILL** (fix before any spend).
- **All hard gates pass, ≥1 heuristic warning OR a felt signal returns `weaker` -> NEEDS-WORK**
  (moderate test budget; address the warning first).
- **All hard gates pass, no warnings, felt signals `prefer|tie` -> LAUNCH-READY** (full budget).

Count only gates that passed their tier's check. A felt signal contributes only when the
pairwise judge prefers/ties the candidate over the specimen; `weaker` never manufactures a pass.

## ROUTE rules stay a contract (named trigger selects the vehicle)

Selection/sequencing rules are not scored as wording — the checker verifies the *selection
matches the trigger*. Full list in `references/route-rules.md`. The load-bearing ones:
cold -> indirect ad (never reveal product/price) / warm -> direct ad; objective always
**Sales/Purchase**, never **Traffic**; cost cap **only after** a winning combo; test **≥3
angles before building a VSL**; dollar decisions follow **MER -> 3rd-party -> Shopify -> Ads
Manager** (Ads Manager soft metrics only). Page selection: **whitelisting** (creator dark
post) preferred over partnership, **10-15 creators** for social-proof saturation. Channel
model: **Google = pull** (compounds 3-10%/mo, no constant refresh) vs **Meta = push**;
**Pinterest** for visual/female products -> route to **PDP, not homepage**.

## The negatives live here (≤5), each paired with a positive target

Moved out of the writer (where banning a token summons it). Each is a checker rule:

- **Traffic objective when goal is purchases** -> select Sales/Purchase. (enum gate)
- **Advantage Plus on a brand-new account** -> disable Advantage+, US-only, single interest.
- **Stacking multiple interests for initial targeting** -> use one relevant interest.
- **Spam-testing variations of one creative** -> ship diverse net-new concepts (≥25/week, S13).
- **Ignoring landing-page CVR** -> keep website CVR ≥1% (G3 floor).

## Output contract (per ad/config)

```
subject: "<verbatim hook line or campaign id>"
performance_gates: {hook_rate, hold_rate, cvr, cpm, link_ctr, link_cpc, kill, hook_seconds}  # G1-G8 pass|fail
structure_gates:   {cbo_floor, cbo_structure, dct_cap, campaign_types, split, asc_cap, ...}   # S1-S15 pass|fail
gate_evidence: [ {gate, target, verdict: pass|fail, supplied_value, source} ]
heuristics: {eight_elements: [missing...], pitfalls: [flag...]}      # H1-H2 warnings
felt_signals: {hook_pull, pain_gap}                                  # F1-F2 prefer|tie|weaker, vs specimen
band: KILL | NEEDS-WORK | LAUNCH-READY
flags: [ ... ]    # from the negatives list
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every applicable gate has a verdict; heuristics + felt signals recorded; band present.
**SOUNDNESS:** every COUNTABLE verdict came from a script against a supplied number (not eyeballed);
every felt verdict is pairwise-vs-specimen, not self-graded; each `pass` carries `supplied_value` +
`source`; each copy quote is a verbatim substring of a source file; band derived only from passed
gates. `emit_ready` only if SOUNDNESS holds; else `BLOCKED:<field>`.

## Self-test (is this grader sound?) — any NO, fix

- Are only the G/S gates hard-gated (by script against numbers), with F1/F2 as pairwise signals?
- Is the felt judgment run separately from the writer, against a real specimen?
- Does the band come from gates that passed their tier's check, not a raw count?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Are ROUTE rules kept as named-trigger selection contracts (not scored as wording)?
- Is every quoted copy specimen a verbatim substring of a source file (no composites)?
