# ROUTE rules — named-trigger selection / sequencing (dictate no wording)

Each rule is a contract: a named trigger selects a vehicle or orders a sequence. The checker
verifies the *selection matches the trigger*, not the copy. Each carries its positive target.

## Selection by trigger
- **Traffic temperature -> ad type.** cold -> indirect ad: never reveal product/price/offer;
  route to advertorial or pre-sell page. warm/retargeting -> direct ad: product shown, clear
  CTA, testimonials, social proof.
- **Awareness stage -> keyword/format.** problem-aware -> cheap upper-funnel keywords +
  authority/press or pain-point format. purchase-intent -> bottom-funnel keywords.
- **Audience type -> framework.** TikTok/younger -> "three reasons why" / "what I ordered vs
  what I got". older (MPC) -> testimonial straight-to-camera. mass market -> VSL + advertorial
  with authority figures.
- **Buyer selection.** end-user pool saturated -> target adjacent / gift buyers.
- **Angle frame.** test desire / pain / offer; double down on the data winner.
- **Targeting mode by account state.** new account -> disable Advantage+, US-only, single
  interest. established -> Advantage Plus / broad. broad-first via pixel, then interest.
- **Campaign objective.** always Sales (optimize Purchase); never Traffic.
- **Cost cap.** only after a winning audience+ad combo is validated.
- **Native placement prerequisite.** advertorial required before Taboola/Outbrain native;
  direct PDP does not fit.
- **PMax zombie fix.** ~80% products get zero spend -> index by ROAS / CM / CVR -> dedicated
  campaigns.
- **Platform roles.** Meta = test + scale creative. Google = capture intent / PMax fed by
  Meta winners. TikTok = split-test angles, then duplicate. (Pull-vs-push model + Pinterest
  playbook below.)
- **Affluent targeting.** lift AOV -> call out high-income professions.
- **Ad-page selection (whitelisting vs partnership).** run prospecting from creator/persona
  page (not brand page) to appear organic. *Whitelisting (preferred):* ads run under the
  creator's page as dark posts — full creative freedom (thumbnails, copy, video), no impact on
  the creator's organic feed; target the creator's existing engager audience first, then scale
  to prospecting. *Partnership ads:* influencer × brand collab with limited creative control.
  *Saturation rule:* 10-15 active creators creates the perception everyone uses the product.
  *White-label persona accounts* (e.g. "Natalie Marie," "Mind and Body") make paid ads read as
  personal recommendations, reducing ad fatigue. Full text: `references/criteria-tests.md`.

## Channel model & playbooks (which channel, why, where to route)

- **Google pull vs Meta push (mental model + cadence).** Google captures *existing* demand
  from users actively searching (pull) — less volatility, higher CVR, higher CTR, compound
  monthly growth of 3-10% **without** constant creative refreshing. Meta is push: requires
  constant creative refreshing and chasing winning ads. Implication for refresh cadence and
  spend confidence: a healthy Google account compounds; a Meta account must keep feeding new
  creative. (Validated across €100M+ ad spend.)
- **Pinterest as a primary traffic channel.** Use when the product is a visual lifestyle
  accessory targeting female demographics. Mobile-first (over 90% of traffic was mobile).
  *Routing rule:* send traffic directly to the product page (PDP), NOT the homepage — PDP
  optimization is higher ROI than homepage design. (Case: drove 50% of all traffic for a €2M
  single-product store over 1.5 years.) Detail in `references/criteria-tests.md`.

## Sequencing by trigger
- **Creative testing order.** test >=3 angles -> pick winner -> iterate -> build VSL ->
  build LP. Never build the VSL before the angle is validated.
- **Decision hierarchy (dollar decisions).** MER -> 3rd-party tracking -> Shopify ->
  Facebook Ads Manager (soft metrics only, never $ decisions).
- **Google expansion order.** search profit first -> Shopping -> PMax -> YouTube -> Display
  -> Demand Gen. Phases: acquire -> scale -> maintain.
- **Retargeting milestone.** 75% video view -> advance to the next asset in the sequence.

## Structure contracts (ordered beat sequences; steering, not wording)
- Three-element: Hook -> Narrative -> CTA (cold: no product/price reveal).
- Viral seven-beat: Hook -> Problem -> Solution -> Product intro -> Social proof ->
  Benefit stacking -> Objection handling + CTA + offer (order flexible; test).
- Holy Grail: Hook -> Body (unique mechanism) -> CTA 1 -> Social Proof -> CTA 2.
- Karen hybrid: seven-element controversy + DR structure.
