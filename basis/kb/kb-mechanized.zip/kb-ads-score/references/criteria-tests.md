# Per-field membership tests + the COUNTABLE gate definitions

All COUNTABLE gates are script checks against numbers the operator supplies (metrics from
the ad manager, or the planned campaign config). All HEURISTIC checks are soft warnings.
FELT signals are pairwise-vs-specimen (`references/copy-specimens.md`), never a hard FALSE.

---

## COUNTABLE gates (script: pass/fail against a supplied number)

Each gate reads a numeric field from the input and returns pass/fail. US-traffic thresholds.

**G1 Hook rate** — `hook_rate = three_second_video_plays / impressions`. PASS iff `>= 0.50`.
**G2 Hold rate** — `hold_rate = plays_to_50pct / impressions`. PASS iff `>= 0.25`.
**G3 Landing-page CVR floor** — PASS iff `website_cvr >= 0.01`. Below 1% triggers a Facebook
  delivery penalty — hard floor, not a warning.
**G4 Ad-side CPM** — PASS iff `cpm <= 30` (USD). `> $30` = ad-side problem.
**G5 Ad-side CTR (link)** — PASS iff `link_ctr >= 0.03`. `< 3%` = ad-side problem.
**G6 Ad-side CPC (link)** — PASS iff `link_cpc <= 1.50` (USD). `> $1.50` = ad-side problem.
**G7 Kill signals (any TRUE → KILL)** — `link_ctr < 0.01` OR `cpc > 3` OR `cpm > 50`.
  (CPC kill band is $2–3; gate uses the upper bound $3.) Any one true → recommend cut.
**G8 Hook delivery window** — for video, core message must land within `<= 5` seconds
  (3–5s); image lands immediately. PASS iff `hook_seconds <= 5` (video) or medium == image.

## COUNTABLE structure gates (script: pass/fail against the planned config)

**S1 CBO budget floor** — `daily_budget >= max(total_ads * 10, 50)` (USD). Floor $50/day.
**S2 CBO structure** — `3 <= ad_sets <= 5` AND `2 <= variations_per_set <= 5`.
**S3 Dynamic Creative cap** — `image_combinations <= 20` (valid: 8×1×1=8 or 4×2×2=16);
  videos must be excluded from Dynamic Creative.
**S4 Campaign-type count** — exactly `5` campaign types in the account enum (below); scaling
  requires `3 <= winning_ads <= 5` validated first.
**S5 Video-test structure** — `2 <= variations_per_set <= 5`, exactly `1` ad copy + `1`
  headline per set, grouped by one variable (angle, creative style, or creator).
**S6 ASC existing-customer cap** — `existing_customer_spend_pct <= 5` or excluded entirely.
**S7 Budget split** — `90` % conversion campaigns / `10` % DPA catalog.
**S8 Structured-testing budget** — `test_budget_per_creative >= 3 * AOV`; run `>= 5` days;
  test `10` creatives/week from a batch of `40`; winner = target KPI + `20`% buffer.
**S9 80/20-method budget** — `budget_per_set = 2 * AOV`; kill window `24`–`48` h.
**S10 Manual bid** — cost cap only after a winning combo; test target CPA, CPA−$5, CPA+$5.
**S11 Scaling step (Meta)** — CBO start `$500`/day; increase `50`–`200`% every `2` days.
**S12 Scaling step (Google)** — min test budget `>= 10 * avg_CPC`; scale `10`–`20`% every
  `3` days.
**S13 Creative diversity (Andromeda)** — post-update `80`% new concepts / `20`% variations;
  `>= 25` net-new concepts/week.
**S14 Product-price budget** — `daily_budget = product_price`; run `>= 3` days; min spend
  `>= 3 * product_price`; expect `10`–`20`% winners (`80`–`90`% fail); one relaunch only.
**S15 Pixel seasoning** — full optimization expects `$50,000`–`$100,000` cumulative spend.

### Closed enums (echo the chosen value verbatim; reject anything off-list)

- **Campaign types (S4):** `Testing | Scaling | Retargeting | Manual Bids | Advantage Shopping Plus`
- **Campaign objective:** `Sales` (optimize `Purchase`) — never `Traffic`.
- **Eight DR elements (H1, below):** `attention-grabbing hook | compelling offer and clear CTA |
  benefits-focused copy | social proof | scarcity/urgency | high-quality visuals |
  educational content | entertainment and curiosity`.

---

## Mechanism: Facebook ad auction four-step delivery funnel

Explains WHY estimated action rates and user value matter (the Total Value formula in G3/S
context only gives the *what*). **Total Value = Advertiser Bid × Estimated Action Rates ×
User Value.**

- Estimated Action Rates include website conversion rate — below 1% CVR triggers a Facebook
  penalty, reducing traffic delivery (this is the G3 floor's mechanism).
- User Value includes relevance scores, thumbnail stop rates, hold rates.
- Auto-bidding handles the bid component; advertisers control action rates and user value via
  creatives and landing pages.

**Facebook processes this across tens of millions of ads in 200 milliseconds using a
four-step funnel: Retrieval (filters 90%+) → Light Ranking → Final Scoring → Auction.**
Because Retrieval filters 90%+ before any auction, a weak ad never reaches the bid step — this
is why action rates / user value, not bid, are the operator's lever.

## Infrastructure & tracking config checks (account-setup readiness)

**Pixel Obfuscation Strategy (CPA-lowering config).** Send only front-end purchase data to
Facebook's browser-side pixel; Facebook then underestimates true customer LTV → lower CPAs.
Use server-side tracking (e.g., Hyros) to maintain full data quality for internal
optimization without exposing upsell revenue. (Decision rule: front-end → Facebook pixel;
full data → server-side, kept private.)

**Infrastructure Risk Management (redundancy readiness).** Maintain multiple ad accounts,
business managers, pages, and pixels. Account shutdowns / shadow bans cause **30-50%**
performance drops. Must be able to relaunch within one day of any component going down.
*Readiness gate:* an account is not launch-ready for scale unless it has redundant
accounts/BMs/pages/pixels and a same-day relaunch path. (Domain verification — Business
Manager → Brand Safety → Domains → Add, ~$20-30 on GoDaddy — is the other infra prerequisite.)

## Channel selection detail (full text behind route-rules.md)

**Whitelisting vs partnership (ad-page selection).** Run prospecting ads from creator or
persona accounts (not the brand account) to appear organic and native. *Partnership ads:*
influencer × brand collaboration with limited creative control. *Whitelisting (preferred):*
ads run under the creator's page as dark posts — full creative freedom (thumbnails, copy,
video), no impact on the creator's organic feed; initial targeting leverages the creator's
existing engager audience, then scales to prospecting. **10-15 active creators** creates the
social-proof perception that everyone uses the product. White-label persona accounts (e.g.
"Natalie Marie," "Mind and Body") make paid ads appear as personal recommendations, reducing
ad fatigue.

**Google pull vs Meta push.** Google captures existing demand from users actively searching
(pull) — less volatility, higher CVR, higher CTR, compound monthly growth of **3-10% without
constant creative refreshing**. Meta requires constant creative refreshing and chasing
winning ads. Google also enables omni-channel synergies: pixels benefit from cross-platform
traffic, winning audiences transfer between platforms.

**Pinterest as primary traffic channel.** Pinterest drove 50% of all traffic for a 2M euro
single-product store over 1.5 years. Performs especially well for visual lifestyle
accessories targeting female demographics. Over 90% of traffic was mobile (1.4M of 1.6M
visitors). Traffic routed directly to product pages, not homepage — product page optimization
is higher ROI than homepage design. (Germany was the primary geographic market; 50,000+ units
sold, 400K profit after VAT.)

---

## HEURISTIC checks (soft-cap / warn — never a hard FALSE)

**H1 Eight-element DR presence** — warn for each missing element from the enum above.
  `scarcity/urgency` may be omitted for premium brands — warn, do not fail.
**H2 Pitfall flags** — each negative below is a soft warning paired with its positive target.

Pitfall → positive target (≤5, the negatives live here):
- Objective is `Traffic` when goal is purchases → select `Sales` / `Purchase`. (S-enum)
- Advantage Plus on a brand-new account → disable Advantage+, US-only, single interest.
- Stacking multiple interests for initial targeting → use one relevant interest.
- Testing variations of one creative (spam testing) → ship diverse net-new concepts (S13).
- Ignoring landing-page CVR → keep `website_cvr >= 1%` (G3, paired positive).

---

## FELT signals (pairwise-vs-specimen — `prefer | tie | weaker`)

**F1 Hook visceral pull (PIG)** — does the hook create an immediate visceral response?
  Judge pairwise against a curiosity/hook specimen. Never a yes/no gate, never self-graded.
**F2 Pain-point curiosity gap** — does the line open a gap a viewer must resolve? Judge
  pairwise against a pain-point specimen. `weaker` contributes no pass.

Run order: present candidate + one specimen, order randomized; ask which better satisfies the
named criterion and why (reason before verdict); record `prefer|tie|weaker`. The model that
generated the candidate may not be the judge.

## Why the tiers
A number is or isn't below its threshold — reproducible, safe to hard-gate. A felt hook's
pull is not; hard-gating it produces confident-but-wrong FALSEs and invites gaming. Soft-cap
the in-between (element presence) because the detectors over-flag.
