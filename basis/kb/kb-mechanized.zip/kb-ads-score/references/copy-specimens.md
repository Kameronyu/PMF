# Copy specimens — the known-good ad lines to judge FELT signals against

FELT signals (F1 visceral hook pull, F2 pain-point curiosity gap) are scored **pairwise
against these**, never on an absolute scale and never by the model that wrote the candidate.
Randomize presentation order; treat any single verdict as a noisy triage signal, not a
certification. Each line below is a verbatim substring of a source KB file.

## Curiosity / open-loop hook reference (judge F1 against these)
- "Dog owners never ignore these three things in your dog's teeth"
- "Not many owners know this, but these are three signs your dog's teeth need support"
- "This coffee is about to go viral"

Ask: does the candidate make the next line as necessary as these do? -> prefer | tie | weaker.

## Pain-point curiosity-gap reference (judge F2 against these)
- "Are you tired of menopause brain?"
- "Do you have this pain point right now?"

Ask: does the candidate open a gap the avatar must resolve? -> prefer | tie | weaker.

## CTA / social-proof reference (sanity-check the closing beat)
- "Join thousands of dog owners seeing amazing results"
- "Efficient and affordable way to help their dental health today"

## Pre-frame reference (outcome-substitution copy)
- "if you buy this, you will get complimented"
- "What if I told you there's an easy way... Introducing Pet Lab Co's dental formula"

## How to run the pairwise judge
1. Present candidate + one specimen, order randomized.
2. Ask which better satisfies the named signal and why (reason before verdict).
3. Record `prefer|tie|weaker` + the reason. `weaker` contributes no pass for that signal.
4. Never let the model that generated the candidate be the judge.
