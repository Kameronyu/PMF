---
name: kb-cro-write
description: >-
  Write the on-page words that convert e-commerce traffic — headlines, CTAs, cart and
  checkout nudges, trust and savings microcopy. Use when generating or rewriting the felt
  copy on a product page, landing page, cart drawer, or checkout. Leads with real winning
  specimens and a few craft targets; routing rules pick which form goes where (awareness
  stage, funnel position). This skill WRITES; it does not grade its own output — score the
  copy with kb-cro-score (a separate pass). Triggers: "write a CRO headline", "rewrite this
  product page copy", "cart nudge copy", "CTA copy for this page".
---

# CRO copy — write the words that move a visitor to buy

Your job is the *wording* a visitor feels on the page — the benefit headline above the fold,
the button they click, the nudge in the cart, the savings line at checkout. Not the layout,
not the test plan, not the benchmark math (that is kb-cro-score). Lead from the specimens
below; reach for a craft target only if it helps; keep it concrete and direct.

## Start here — real winning specimens (study these before writing)

These are preserved verbatim from the source. They steer you harder than any rule. Each is
annotated with WHY it won. More, by funnel position, are in `references/specimen-bank.md`.

- **Benefit headline (above the fold):** *"Your most pleasant period ever"*
  — names the desired end-state, not the product or feature; the visitor feels the outcome
  before reading a single spec. Benefit-led beat feature-led headlines consistently in test.
- **Benefit headline with named product:** *"Say goodbye to painful periods with Maya"*
  — outperformed a generic product-name headline; the relief leads as the hook and the brand
  rides along, instead of opening with a name that means nothing to the visitor yet.
- **Fixed CTA, every button:** *"Get Yours Now"* — the same words on every buy button down
  the page; familiarity removes a tiny decision each time, and "Yours" presumes possession.
- **Emotion-driven cart nudge:** *"Excellent choice! You put products in cart right now"*
  — affirms the action the visitor just took (reduces second-guessing) in the warm moment of
  adding to cart; drove an 18%+ CVR increase. Warm praise of the choice just made carries it.
- **Savings as a dollar amount:** *"You saved $21.87"* — a concrete number the visitor can
  feel as a gain, shown instead of a percentage. Exact dollars read as money in hand.

## Craft targets (steer by these; they are not a rulebook)

- **Benefit over feature.** Lead with the end-state the visitor wants, not the spec that
  produces it. "Your most pleasant period ever" beats "Healthy drug-free relief." But always
  test — very similar headlines produce significantly different CVRs; intuition is unreliable.
- **Concrete over vague.** A specific number, timeframe, or named outcome ("12 hours of
  leak-proof protection," "$21.87") out-pulls "long-lasting" or "great savings."
- **Speak the visitor's words.** Pull the phrasing from customer voice (reviews, surveys) and
  write the element in their language, near the worry it answers — not in marketing-speak.
- **Warm affirmation in cart and checkout.** Affirming the choice already made ("Excellent
  choice!", "Congratulations, your products are waiting for you") is the form that out-converts
  here — the visitor feels backed, and trust holds through the buy decision.
- **Fewest words that keep the pull.** Draft, then cut every word that adds no benefit, no
  number, and no reassurance.

## Optional patterns (reach for the one that fits the funnel slot)

Benefit-end-state headline · Affirmation nudge · Dollar-savings line · Trust-badge microcopy ·
Reassurance timer. Each is a shape to borrow for the right funnel slot, not a required
sequence. Anatomy and a worked example for each is in `references/patterns.md`.

## Contract rules (these DO bind — they pick the form and the slot, not the words)

These come straight from the CRO method; they steer *which* copy goes *where*. They never
grade the wording itself.

- **Awareness / traffic temperature.** Cold paid traffic needs a warm-up (advertorial /
  problem-first) layer before the pitch; warmer traffic can land directly on the benefit
  headline + offer. Match the opening to what the visitor already knows.
- **Message congruency across the funnel.** Keep tone, claim, and imagery consistent from ad
  creative → landing page → cart → checkout → email. The headline should echo the ad that
  earned the click; a mismatch here leaks conversions no on-page polish recovers.
- **Funnel-position form.** Benefit headline above the fold; affirmation nudge at add-to-cart;
  reassurance/reservation copy in the cart drawer and checkout; trust badges and the
  money-back guarantee near the buy decision and at page bottom.
- **Savings shown as dollars, not percentages**, at every stage (this is a SCORE gate too —
  honor it when you write, the scorer enforces it).
- **Objection-mapped placement.** Write each testimonial / FAQ answer to a specific objection
  and place it next to the moment that objection arises, not consolidated at the bottom.

More routing detail (category-specific copy, full-sales-page section order) lives in
`references/routing.md`. The *why* behind savings-as-dollars, palette, and typeface choices
(Pain-Price Perception, Color & Font Psychology) is in `references/psychology.md` — read it to
keep the wording and the visual frame pulling in the same direction.

## How to use this with the grader

Generate several diverse candidates (vary the benefit, the angle, the phrasing — don't iterate
one line toward "safe"). Then hand them to **kb-cro-score** — a separate skill, ideally a
different model — for the hard gates (savings-as-dollars, real social-proof data, funnel
benchmarks) and the benefit-led-vs-specimen judgment. Do not grade your own output here; a
writer that judges itself optimizes toward "looks like CRO copy," not "moves the visitor."

## Before handoff (what kb-cro-score checks)

Awareness only — these are the dimensions the separate scorer grades, so you know what good
looks like while you draft. Generate several diverse drafts; the separate scorer grades — do
not self-grade toward the gate.

- Headline leads with a benefit / end-state the visitor wants, not a feature or a name.
- The copy carries at least one concrete specific (number, timeframe, dollar amount).
- Cart/checkout copy is affirming and trust-building rather than pressure-driven.
- The wording echoes the ad/angle that brought the visitor here (congruency).
