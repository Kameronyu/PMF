# Specimen bank — verbatim winning CRO copy, by funnel position

Preserved verbatim from `cro--carl-weische.md` / `cro--mark-builds-brands.md`. These are the
highest-value asset in the skill — study and adapt, do not abstract into templates. Each
specimen shows the *form* of a good answer; that is what steers a model. Where a tested lift
exists it is noted, because the lift is part of why the wording won.

## Above-the-fold benefit headlines (name the end-state, not the feature)
- "Your most pleasant period ever"
  — pure desired end-state; the outcome is the whole headline.
- "Instantly relieve period cramps"
  — beat the feature-led alternative; verb + benefit + speed, no jargon. (8%+ CVR increase, Nomsk)
- "Instantly stand out from the crowd with affordable and unique Apple Watch bands"
  — beat the bland "New experience with Apple Watch"; specific emotional payoff + qualifiers. (7%+ CVR increase, Solace Bands)
- "Say goodbye to painful periods with Maya"
  — benefit-led headline that outperformed a generic product-name headline; relief leads, brand rides along.

> Craft note from source: "Benefit-led headlines outperform feature headlines consistently."
> But: "very similar headlines produce significantly different CVRs; always test." The
> specimen shows the form; the test decides the winner.

## Buy-button CTA (one consistent string down the page)
- "Get Yours Now"
  — same words on every button; familiarity reduces decision friction; "Yours" presumes possession.

## Cart / add-to-cart nudges (affirm the choice, warmly)
- "Excellent choice! You put products in cart right now"
  — affirms the action just taken in the warm moment. (18%+ CVR increase, $0.20 revenue per user)
- "Congratulations, your products are waiting for you"
  — motivational announcement bar in the cart drawer; possession + gentle pull-forward. (3.6% CVR increase)

## Checkout reassurance (reduce anxiety at the decision)
- "Your cart is reserved for 10 minutes"
  — reservation framing reassures more than a hard countdown; the visitor's choice is being held for them.

## Savings microcopy (concrete dollars, not percentages)
- "You saved $21.87"
  — exact dollar amount reads as money in hand; beat the percentage version. (2.98% CVR improvement)

## Trust & guarantee microcopy (place near the buy decision)
- "12 hours of leak-proof protection"
  — quantified claim; a number the visitor can hold onto.
- "100% secure payment"
- "60-day money-back guarantee"
- "3.5 million+ happy customers"
  — aggregate social-proof anchor at the guarantee section.

> Note: AI can generate this copy at scale but needs the **avatar / customer voice** as input —
> a product brief alone yields generic output. Feed real reviews and survey language, not adjectives.
