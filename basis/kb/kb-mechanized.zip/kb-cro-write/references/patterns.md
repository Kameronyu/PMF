# Optional patterns — anatomy + a worked example each

Reach for one when it fits the funnel slot. None is a required slot order; forcing a fixed
sequence is what produces same-y, low-converting copy. Use these to vary, not to standardize.
Every worked example below is a verbatim winner from the source.

## Benefit-end-state headline (above the fold)
[verb or "say goodbye to"] + [the end-state the visitor wants] (+ optional product / qualifier).
- Lead with the outcome, not the spec or the product name. Add a concrete qualifier only if it
  sharpens the desire ("affordable and unique"), never to pad.
- Example: "Your most pleasant period ever" · "Say goodbye to painful periods with Maya"

## Affirmation nudge (cart / add-to-cart)
[warm affirmation of the action just taken] + [light forward pull].
- Praise the decision the visitor already made; this lowers second-guessing in the warm moment.
  Do not switch to pressure — affirmation out-converts manufactured urgency and protects trust.
- Example: "Excellent choice! You put products in cart right now"

## Dollar-savings line (product page → cart → checkout)
[the exact dollar amount saved], shown instead of a percentage, at every stage.
- A concrete number reads as a gain the visitor can feel; a percentage stays abstract. (This is
  also a SCORE gate — the scorer fails percentage-only savings.)
- Example: "You saved $21.87"

## Trust-badge microcopy (near the buy decision)
[quantified protection / guarantee], stated plainly and specifically.
- A number the visitor can hold ("12 hours," "60-day," "100%") beats a vague reassurance.
- Example: "12 hours of leak-proof protection" · "60-day money-back guarantee"

## Reassurance timer (cart drawer / checkout)
[the visitor's cart / choice is being held FOR them], not [a hostile countdown].
- Reservation framing reduces anxiety; a pure countdown can add it. The visitor's choice is
  protected, not threatened.
- Example: "Your cart is reserved for 10 minutes"
