# Copy-adjacent psychology — the WHY behind the design and savings choices

These are the source rationales that steer the felt copy and the elements around it. They are
craft context (the *why* behind a wording or framing choice), not graders. Restored faithfully
from `cro--carl-weische.md`.

## Pain-Price Perception (the why behind the dollar-savings line)

> Price triggers same brain region as physical pain; spending is perceived as loss. Display
> exact dollar savings (not percentages) to shift perception from loss to gain.

This is the rationale behind writing savings as a concrete dollar amount ("You saved $21.87")
rather than a percentage: the dollar figure reframes the moment from loss to gain. Adding a
savings badge → 3.35% CVR uplift. (The dollar-not-percent format is also enforced as a SCORE
gate; honor it when you write.)

## Color Psychology (steer the palette to match the authority you're claiming)

> - Pastel-only palettes signal innocence/friendliness → reduces authority
> - Dark purple + pastel combination signals luxury/authority
> - Every color choice influences emotional state and judgment

If the copy claims expert authority, a pastel-only palette undercuts it; pair authoritative
copy with a palette that signals authority (e.g., dark purple + pastel for luxury).

## Font Psychology (the typeface must agree with the copy's tone)

> - Rounded/friendly fonts (Nunito) compound credibility loss when paired with weak copy
> - Authoritative sans-serif (Inter) reinforces expert positioning
> - Font and copy tone must be aligned — authority font + assertive copy reinforce each other

Friendly/rounded fonts (Nunito) make weak copy read as even weaker; authoritative sans-serif
(Inter) reinforces expert positioning. Match the typeface to the copy's tone — authority font
+ assertive copy compound; a mismatch undercuts both.
