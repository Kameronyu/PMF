# Routing — which copy form goes where (steering contract, not a grader)

These rules pick the FORM and the SLOT for the copy; they never grade the wording. They are
steering only here — the matching gates live in kb-cro-score. (Sourced from the CRO method.)

## Awareness / traffic temperature → opening
- **Cold paid traffic:** needs a warm-up layer (advertorial / problem-first) before the pitch.
  Open by entering the problem the visitor already feels; earn the right to the offer.
- **Warm / returning traffic:** can land directly on the benefit headline + offer.
- Match the opening line to what the visitor already knows; the Conversion Formula treats
  prospect awareness level as a real input.

## Message congruency across the funnel
- Keep tone, claim, imagery, and offer consistent: ad creative → landing page → cart →
  checkout → email. The headline should echo the ad that earned the click.
- A congruency break leaks conversions that no on-page polish recovers. Copywriting is the
  single biggest lever (the source puts it at 50–60% of e-commerce CRO impact, up to 90% for
  info products) — so the words carrying that congruency matter most.

## Funnel-position form
- **Above the fold:** benefit headline + strong social proof, opened before product detail.
- **Add-to-cart moment:** affirmation nudge.
- **Cart drawer:** motivational announcement bar + reservation/reassurance copy.
- **Checkout:** reservation timer, trust badges, dollar-savings line.
- **Page bottom / guarantee section:** money-back guarantee + aggregate customer-count anchor.

## Objection-mapped placement
- Write each testimonial / FAQ answer to a specific objection and place it next to the moment
  that objection arises — not consolidated in one block at the bottom.

## Full-sales-page section order (when the product page IS the sales page)
benefit headline → value props → product benefits → UGC trust section → testimonials → press →
how it works → comparison → key features → money-back guarantee → more testimonials → FAQ.
- The benefit headline still leads; everything after answers the next question or objection in turn.

## Category routing (tailor the copy emphasis)
- **Baby:** safety certifications above the fold.
- **Fashion:** size guides, lifestyle framing, UGC.
- **High-ticket:** craftsmanship / story-led copy.
- **Technical:** translate features into benefits.
- **Services:** lead with the transformation.
- **SaaS / direct purchase:** write like an info-product / e-commerce funnel (revenue per session).
