# Levers and routing

## Lever enums (the `lever` field must be drawn from the axis's list)

Source: `differentiator--framework.md` → "Levers Within Each Differentiator".

| Axis | Allowed levers |
|---|---|
| **Market** | Avatar flip, transformation change, buyer ≠ user, new sub-avatar, avatar specificity |
| **Mech (UM)** | New product, proprietary naming, new feature, format change, problem UM, solution UM |
| **Angle** | Desire, pain, external blame, care signaling, belonging/identity, curiosity/secret |
| **Offer** | Bundle, price, guarantee, subscription, loss leader |

- **Dual** = a Market lever AND a Mech lever fire simultaneously (True Classic). Name BOTH
  levers: `lever_market` (from the Market list) and `lever_mech` (from the Mech list); a
  single lever is insufficient for Dual.
- **None** = no lever fires on any axis → the DONT-RUN gate.
- Copy/VOC is **not** a lever — it is constant, always execute it regardless of axis.
  Never select it as the differentiator.

## ROUTE rules (kept as contract — order of attack, not wording)

Triggered by a named condition; they bias which axis to try first and what each move
buys. They do NOT dictate copy and do NOT assign a quality verdict.

1. **Try Market first.** Trigger: a market-change option exists. "Market changes are the
   biggest swings." Largest lever → evaluate before Mech/Angle/Offer.
2. **Buyer ≠ user.** Trigger: the buyer is not the end user (Nusk, Maya, Grüns). Opens
   uncontested markets and often allows higher pricing → favor this Market lever when present.
3. **Changing markets decreases sophistication.** Trigger: you move to a new niche ×
   transformation (Nusk, Maya). Lowers the differentiation floor for that combination.
4. **Problem UM + Solution UM compound.** Trigger: both a cause and a solution mechanism are
   available (Shower Head, Hexclad) → state both, they reinforce.
5. **No differentiator on any axis → DONT-RUN.** Trigger: every axis returns None (Hair
   Dryer). This is the hard gate, enforced in SKILL.md, not just a preference.

## Axis decision order (run ALL tests; do NOT stop at the first TRUE)

A product can differentiate on more than one axis (Nusk/Maya are "Market + Angle"; True
Classic is "Market + Mech"). So run every test, record which fire, THEN assign:

1. Run the Market, Mech (UM), Angle, and Offer tests — each FALSE-capable (see
   `axis-membership-tests.md`). Record the full set that return TRUE.
2. If BOTH Market and Mech fire → `differentiator_axis = **Dual**`; name `lever_market`
   + `lever_mech`. (True Classic.)
3. Otherwise `differentiator_axis =` the highest-priority axis that fired, in order
   **Market > Mech > Angle > Offer** ("market changes are the biggest swings," so Market
   is the primary label whenever it fires except the named Market+Mech Dual).
4. If a NON-primary axis also fired (e.g. Market AND Angle — the Nusk/Maya pattern), keep
   the primary label, populate that axis's row (`market`/`mech`/`angle`/`offer`) and its
   lever, and name the co-active axis in `why` (e.g. "Market primary, Angle also active —
   cf. Nusk/Maya"). Do NOT silently drop it.
5. If NO axis fires → `differentiator_axis = **None**` → verdict DONT-RUN. (Hair Dryer.)
