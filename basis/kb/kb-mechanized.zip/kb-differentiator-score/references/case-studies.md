# Case Studies — scoring anchors (verbatim from source)

These are the classification anchors. To score a new product, find the closest case
study and apply the same axis/lever reasoning. Each block is preserved verbatim from
`differentiator--framework.md` so it can be diffed against the source.

## Case Studies

### Blissy
- **Differentiator:** Market
- **Market:** Women's skincare
- **Mech:** Silk pillowcase. Problem UM: Cotton, friction and bacteria.
- **Angle:** —
- **Offer:** —
- **Why:** Customer reviews surfaced UM

### Barefoot Shoes
- **Differentiator:** Market
- **Market:** Neuropathy Relief
- **Mech:** Barefoot/minimalist shoes
- **Angle:** —
- **Offer:** —
- **Why:** Amazon Reviews surfaced neuropathy havers in the reviews of another brand.

### Kinobody
- **Differentiator:** Angle
- **Market:** Young men's dating
- **Mech:** Testosterone supplement. Proprietary system "Mojo Mastery"
- **Angle:** Attract girls effortlessly
- **Offer:** [Bundle] $40→$97 + $69/mo subscription
- **Why:** Tested 3 Markets: dating, fitness, cognitive.

### Nusk / Nomusk
- **Differentiator:** Market + Angle
- **Market:** Boyfriends. Transformation: show her you care.
- **Mech:** Period cramp relief device
- **Angle:** Show that you care. Not personal pain avoidance.
- **Offer:** [Price increase] ~$50→$100. Gift frame justifies higher WTP.
- **Why:** Decreased market sophistication. Offer not pitched to this market.

### Astronaut Projector
- **Differentiator:** —
- **Market:** Parents. Transformation: more aesthetic home.
- **Mech:** Kids toys that match the aesthetic of modern homes
- **Angle:** ex. "dont have to put my kids toys away when I have guests"
- **Offer:** —
- **Why:** New and obviously working UM

### Grüns Gummies
- **Differentiator:** Mech
- **Market:** Parents who want their kids to eat more vegetables.
- **Mech:** Gummy format, kids actually want to eat it.
- **Angle:** ex. don't have to choose between not starting fights at dinner time and having healthy kids
- **Offer:** —
- **Why:** Gummy IS the UM which increases perceived likelihood of achievement (Hormozi value equation)

### Maya Heat Pad
- **Differentiator:** Market + Angle
- **Market:** Boyfriends gift giving and care signaling.
- **Mech:** Heat pad
- **Angle:** perfect gift for your girl
- **Offer:** —
- **Why:** Decreases market sophistication selling to a new market.

### Shower Head
- **Differentiator:** Mech
- **Market:** Skincare
- **Mech:** [Problem UM] Your water has gunk that causes acne. [Solution UM] Our filter removes it.
- **Angle:** —
- **Offer:** —
- **Why:** UM

### Hexclad
- **Differentiator:** Mech
- **Market:** Nonstick pan
- **Mech:** [Problem UM] Traditional coatings degrade over time. [Solution UM] Hex grid pattern — visual proof of permanent non-stick.
- **Angle:** ex. "food slides off and wont wear out" not "tired of doing dishes for so many hours/week?"
- **Offer:** —
- **Why:** UM to nonstick pan

### Performance Golf
- **Differentiator:** Mech
- **Market:** Golf players
- **Mech:** [Solution UM + proprietary naming] "Fear-based feedback system."
- **Angle:** [Desire] Confidence, control, better ball striking.
- **Offer:** —
- **Why:** UM

### True Classic
- **Differentiator:** Dual (Market + Mech)
- **Market:** Men's fitted T shirts 35-40. Look more attractive in your clothes
- **Mech:** [New feature + proprietary naming] Proprietary fit/cut.
- **Angle:** "tight around the arms and chest loose around the gut to hide it"
- **Offer:** —
- **Why:** Dual — new market + new mech simultaneously

### Coconut Beauty
- **Differentiator:** Angle
- **Market:** Women's curly hair products
- **Mech:** —
- **Angle:** [Desire-driven]
- **Offer:** —
- **Why:** Tested desire driven, offer driven, pain driven.

### Riddle Fragrance
- **Differentiator:** Angle
- **Market:** Fragrance - dating
- **Mech:** Fragrance
- **Angle:** Getting complimented. Not "smells good".
- **Offer:** —
- **Why:** Angle found when mining reviews

### Posture Corrector
- **Differentiator:** Market
- **Market:** Mark tested back pain vs posture.
- **Mech:** Posture corrector
- **Angle:** —
- **Offer:** —
- **Why:** Transformation is the variable. Testing 2 different markets.

### Hair Dryer (FAILED)
- **Differentiator:** None — failed
- **Market:** General hair care
- **Mech:** All 7 brands same: "fast dry no heat damage." No differentiation.
- **Angle:** —
- **Offer:** —
- **Why:** No differentiator on any axis. 7 competitors, same mech, same market. Failed regardless of copy quality. No UM + no avatar diff = don't run.
