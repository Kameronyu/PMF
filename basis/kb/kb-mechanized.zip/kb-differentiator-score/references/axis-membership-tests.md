# Axis membership tests (FALSE-capable; registry-anchored)

Each test below can return FALSE → a wrong axis label fails by shape, not by taste.
Meanings are anchored to `term_registry.json` / `definitions.md`; do NOT redefine terms here.

## Market — `differentiator_axis = Market`
- **Test (load-bearing, vs Angle):** Does the transformation OR the core human driver
  change vs competitors? (yes → Market; no → not Market, consider Angle.)
- Anchor (registry, Market): "When the desire changes, does the customer evaluate against
  entirely different alternatives? (yes → market change; no, same alternatives different
  emotional reason → angle change)."
- A `lever` from the Market list must be nameable (Avatar flip / transformation change /
  buyer ≠ user / new sub-avatar / avatar specificity). No Market lever → FALSE.
- Anti-example (registry, Market): Coconut Beauty "switching from a pain-driven to a
  desire-driven frame for the same curly-hair transformation" → FAILS Market (same
  alternatives, different emotional reason) → it is an Angle.

## Mech (UM) — `differentiator_axis = Mech`
- **Test:** Is there a unique way of delivering the transformation vs competitors —
  naming WHY the problem exists (Problem UM) and/or WHAT solves it (Solution/Product UM)?
  (yes → Mech; no → FALSE.)
- Anchor (registry, UM): "The unique way your product delivers the transformation, used to
  differentiate against alternatives." Problem UM = "naming a cause the buyer didn't know
  about"; Product/Solution UM = "the specific product positioned around a mechanism."
- A `lever` from the Mech list must be nameable (New product / proprietary naming / new
  feature / format change / problem UM / solution UM). No Mech lever → FALSE.
- Per-lever supplementary checks (refine the lever choice; NOT additional hard gates):
  **problem UM** → are you naming WHY the problem exists, a cause the buyer didn't know
  about (registry, Problem UM)? **solution/product UM** → must the buyer mentally move the
  product into a new category (registry, Product UM)? Use these to pick the right Mech
  lever; they sharpen the label, they do not gate the axis.
- Disqualifier: raw biological pathway alone ("raised testosterone") is a mechanism, not a
  UM → not Mech on its own.

## Angle — `differentiator_axis = Angle`
- **Test:** Does the transformation stay the SAME and only the emotional frame change?
  (yes → Angle; if the transformation/core driver changes → Market, NOT Angle → FALSE.)
- Anchor (registry, Angle): "the transformation, buyer, and alternatives stay the same and
  only the emotion changes"; trace it to a core human driver + pole (pain/desire).
- A `lever` from the Angle list must be nameable (Desire / pain / external blame / care
  signaling / belonging-identity / curiosity-secret). No Angle lever → FALSE.

## Offer — `differentiator_axis = Offer`
- **Test:** Is the distinction the commercial wrapper (bundle / price / guarantee /
  subscription / loss leader)? (yes → Offer; if it changes who/what/why the buyer wants →
  Market or Angle, not Offer → FALSE.)
- Anchor (registry, Value models): "how the offer is framed commercially ... bundle,
  pricing, discount, guarantee, subscription." Distinct from market/angle change.

## Dual — `differentiator_axis = Dual`
- **Test:** Do BOTH the Market test AND the Mech test return TRUE simultaneously?
  (yes → Dual; only one → that single axis.)
- Anchor (source, True Classic): "Dual (Market + Mech) ... new market + new mech
  simultaneously."
- **SOUNDNESS for Dual:** name TWO levers — `lever_market` (∈ Market list) AND `lever_mech`
  (∈ Mech list). A single lever is insufficient and fails the soundness check.
- Note: Dual is reserved for **Market + Mech**. Other co-active combinations (e.g.
  Market + Angle — Nusk/Maya) are NOT Dual; label the primary axis and record the
  co-active axis per step 4 of the decision order in `levers-and-routing.md`.

## None — `differentiator_axis = None` → verdict DONT-RUN
- **Test (the gate):** Do ALL of Market, Mech, Angle, Offer return FALSE? (yes → None →
  DONT-RUN.) This is the only axis that forces a verdict.
- Anchor (source, Hair Dryer): "No differentiator on any axis. 7 competitors, same mech,
  same market. ... No UM + no avatar diff = don't run."

## Felt criterion (if any) — pairwise, never hard-FALSE
- The "how strong is the differentiator" judgment (e.g. is the UM "obviously working" as
  with the Astronaut Projector) is FELT. Compare the candidate pairwise against the closest
  case study in `case-studies.md`; emit `prefer | tie | weaker`. Never convert it into a
  hard FALSE — axis membership is the gate, strength is only a signal.
