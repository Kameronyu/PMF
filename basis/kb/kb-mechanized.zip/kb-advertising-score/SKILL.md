---
name: kb-advertising-score
description: >-
  Score an advertising plan, campaign, or asset against Hormozi's countable
  advertising gates before spend or send — Rule of 100, the creative-quality→daily-
  spend ladder, LTV:CAC by humans-in-loop, 2x-CAC test budget, conversion benchmarks,
  the <200-word newsletter, channel-count-by-revenue. Returns PASS / WARN / BLOCKED
  per field with an evidence quote. Hard-gates only the countable; soft-caps the
  heuristic (proof strength, tier list, offer quality); routes felt copy to a
  pairwise-vs-specimen signal, never a hard FALSE. Run as a SEPARATE pass from any
  writer. Triggers: "score this campaign", "is this ad plan ready to scale",
  "check my email/funnel against the rules", "grade my LTV:CAC / spend ladder".
---

# Advertising — score the plan against the countable gates before you spend

Grade each applicable field against its target, then band the plan. **Do not run this in the
same pass that wrote the plan or copy** — a producer grading itself rates its own work higher.
Felt copy (hooks, promo names) is judged pairwise against the verbatim winners in
`references/scoring-specimens.md`, ideally on a different model.

Tier discipline: **hard-gate only the countable** (numbers, counts, lengths, enum bands);
**soft-cap the heuristic** (judged rankings — warn, never hard-fail); **a felt criterion is a
pairwise-vs-specimen signal** (`prefer | tie | weaker`), never a hard FALSE or self-graded.

## COUNTABLE gates (each: positive target → membership test → tier: hard-gate)

Only score a field when the plan asserts a value for it. Each test can return FALSE.

1. **Rule of 100 daily floor** — *target:* ≥100 outreaches OR a 100-min post OR ≥$100/day ads,
   AND ≥100 min/day making/improving/researching ads. *Test:* both clauses present and ≥ floor.
2. **Creative-quality → spend ceiling** — *target (enum band):* 5/10≈$100/day · 7/10≈$500/day ·
   8/10≈$5,000/day · 9-10/10=cold worldwide. *Test:* claimed daily spend ≤ the band its
   ad-quality grade allows. Scaling above the band with lower-grade creative → FALSE.
3. **Creative volume floor** — *target:* ≥30 new unique videos/week, permuted to ~100 pieces.
   *Test:* weekly unique-video count ≥ 30.
4. **LTV:CAC by humans-in-loop** — *target (enum):* 0 humans→≥3:1 · 1→≥6:1 · 2→≥9:1 · 3→≥12:1;
   flag arbitrage if >30:1. *Test:* claimed ratio ≥ the floor for its humans-in-loop count.
5. **2x-CAC test budget** — *target:* per-campaign test spend ≤ 2× the 30-day cash collected
   per customer before kill. *Test:* test cap ≤ 2× that cash figure.
6. **70/30 + 3:1 ratios** — *target:* brand:direct-response spend ≈70:30; content:ads ≥3:1
   (never below 2:1). *Test:* split within tolerance AND content:ads not below 2:1.
7. **Channel count by revenue** — *target:* one channel/avatar/product until $1M/yr; add a 2nd
   only ≈$5M (≈$1M/mo). *Test:* channel count ≤ what the stated revenue allows.
8. **Conversion benchmark band** — *target:* result inside its channel band (Meta in-person 10%,
   cold webinar 2-3%, niched webinar 5%, web 1-2%, Amazon ~25%, in-home 35% target).
   *Test:* claimed rate within band, else flag under/over-performance.
9. **Mozy newsletter bound** — *target:* ≤200 words AND slots present: reward quote · one
   tactical nugget · contextual CTA · PS. *Test:* word count ≤200 AND all four slots present.
10. **Hook-variation count** — *target:* ≥5-6 hook variations per offer tested simultaneously.
    *Test:* distinct-hook count ≥ 5.

Per-field membership tests, bands, and tolerances: `references/gate-tests.md`. Email warn-level
diagnostics (18% B2C Mon/Tue, 791% segmentation, plain-text deliverability): `references/email-rules.md`.
To derive what makes winners win, run Common Factors Analysis (top-10% vs bottom-10%): `references/procedures.md`.

## SOFT-CAP gates (HEURISTIC — warn, never hard-fail)

Judged classifications with real false-positive risk: **proof continuum** (in-person > virtual,
live > recorded), **platform tier list**, **offer transformation** (price-driven → value-driven),
**absolute-vs-relative return**, **list-health / unsubscribes**. Emit a `warn` with the rule and
a fix; never BLOCK on these. Definitions in `references/gate-tests.md`.

## FELT signal (pairwise-vs-specimen — never a hard FALSE)

Hook copy and promo-wrapper names are felt; do **not** write a yes/no gate. Judge each against a
winning specimen in `references/scoring-specimens.md`: does it land harder than the specimen for
the named audience? Return `prefer | tie | weaker`. `weaker` routes the copy to
`kb-advertising-write`; it never BLOCKS the score.

## Bands (derive from gates that actually passed — not a hollow count)

- Any COUNTABLE gate the plan asserts and FAILS → **BLOCKED:<gate>** (must fix before spend/send).
- All asserted COUNTABLE gates pass, ≥1 soft-cap warn → **WARN** (ship with noted fixes).
- All asserted COUNTABLE gates pass, no warn → **PASS**.

Count only gates the plan actually asserts a value for; an unscored gate is neither pass nor fail.

## ROUTE rules (contract — selection/sequencing, carried not graded)

- **Awareness → hook type** (registry term `Awareness level`): Unaware → curiosity hook; Problem/
  Solution/Product-aware → progressively direct; Most-aware → direct intro.
- **Creative allocation:** 70% winner permutations / 20% adjacent / 10% wild; execute in reverse
  (10% → 20% → 70%); reuse winners until they fully stop working.
- **Fix order:** earlier funnel stage first; offer before platform; worst-outlier metric first.
- **Optimize target:** cost-per-SALE and LTV:CAC, not cost-per-lead/CPC/cheapest.
- **ROAS dropping as you scale:** pick ONE Five Scaling Lever (lead magnet · creative · CRO ·
  sales efficiency), one at a time; narrow the front end to best-LTV:CAC segment; decentralized
  lead-gen (affiliates/customers) scales beyond management. See `references/diagnostic-frameworks.md`.
- **Agency vs in-house:** 3-phase playbook; Meta/social in-house immediately (21-day creative
  fatigue). See `references/procedures.md`.
- **Channel sequencing:** one channel until $1M; expand proven low-risk before unproven high-risk,
  in parallel, never cliff; control your channel (no one-itis); always run a shadow funnel.
- **Organic vs paid:** organic = give, ads = the ask; convert best organic → paid + 5-sec CTA.
- **Seasonal/promo wrappers** rotate over a fixed sales process — wrapper changes, ops don't.

## The negatives live here (≤5), each paired with a positive target

- **Scaling spend above the creative-grade band** → BLOCK gate 2. (positive: raise creative to the grade the spend needs, e.g. 8/10 before $5k/day)
- **Counting an LTV:CAC that ignores humans-in-loop** → FALSE gate 4. (positive: pick the floor for the actual human count)
- **Newsletter over 200 words / missing a slot** → BLOCK gate 9. (positive: cut to ≤200 with all four slots)
- **A second channel before $1M/yr** → FALSE gate 7. (positive: one channel/avatar/product until $1M)
- **Hard-FALSEing a hook on "felt weak"** → not allowed; route to `weaker` signal. (positive: pairwise-vs-specimen)

## Output contract (per scored plan)

```
plan: "<id or short label>"
gates: [ {n, name, target, value_claimed, verdict: pass|fail|warn|n/a, tier, evidence_quote, source} ]
countable: {rule_of_100, spend_ladder, creative_volume, ltv_cac, test_budget, ratios_70_30, channel_count, conversion, newsletter, hook_count}
soft_caps: {proof, platform_tier, offer, abs_vs_rel, list_health}   # warn|ok, never fail
felt_signals: {hook_copy, promo_names}                               # prefer|tie|weaker
band: PASS | WARN | BLOCKED:<gate>
flags: [ ... ]   # from the negatives list
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every asserted gate has a verdict; band present.
**SOUNDNESS:** every COUNTABLE verdict came from the test against a stated number (not eyeballed);
every soft-cap is `warn|ok` (never fail); every felt verdict is pairwise-vs-specimen (not self-graded);
band derived only from gates the plan asserted; each `pass`/`fail` carries an `evidence_quote` that is
a verbatim substring of the plan. `emit_ready` only if SOUNDNESS holds; else `BLOCKED:<gate>`.

Grader-soundness checklist (is this grader wired correctly?): `references/procedures.md`.
