# Per-gate membership tests + the COUNTABLE band definitions

All YES = the gate passes; any question can return FALSE. Only score a gate when the plan
asserts a value for it (else verdict `n/a`). Topic-local terms (CAC, LTV:CAC, ROAS, CPM, CRO,
core four, shadow funnel) are defined inline here; registry anchor terms (`Awareness level`,
`Hook`, `Angle`) are never redefined.

## COUNTABLE gates (hard-gate — reproducible number/count/length/enum checks)

**1. Rule of 100 daily floor**
- `outreach >= 100` OR `post_minutes >= 100` OR `ad_spend_per_day >= 100` (any one satisfies the reach clause).
- AND `ad_work_minutes_per_day >= 100` (making/improving/researching ads).
- FALSE example: "$50/day, 20 min on ads" → reach clause and work clause both below floor → FAIL.

**2. Creative-quality → spend ceiling** (enum band; pick the row for the claimed ad grade)
- 5/10 → ceiling $100/day (hottest audience only) · 7/10 → $500/day · 8/10 → $5,000/day ·
  9-10/10 → converts cold audiences worldwide (no ceiling).
- PASS iff `claimed_daily_spend <= ceiling(ad_grade)`. Scaling above the band → FALSE.

**3. Creative volume floor**
- `unique_videos_per_week >= 30`, permuted to ~100 creative pieces. PASS iff count ≥ 30.

**4. LTV:CAC by humans-in-loop** (enum floor by human count)
- 0 humans (full automation) → `ratio >= 3:1` · 1 → `>= 6:1` · 2 → `>= 9:1` · 3 → `>= 12:1`.
- PASS iff `claimed_ratio >= floor(humans_in_loop)`. Flag `arbitrage` if `ratio > 30:1`.
- CAC = cost to acquire a customer; LTV = lifetime GROSS PROFIT (never lifetime revenue).

**5. 2x-CAC test budget**
- `per_campaign_test_cap <= 2 * cash_collected_30d_per_customer`. PASS iff cap within 2×.

**6. 70/30 + 3:1 ratios**
- `brand:direct_response ≈ 70:30` (±10pt tolerance) AND `content:ads >= 3:1` and never below 2:1.
- PASS iff split within tolerance AND content:ads not below 2:1.

**7. Channel count by revenue**
- `revenue < $1M/yr` → exactly 1 channel/avatar/product. Add a 2nd only at ≈$5M (≈$1M/mo).
- PASS iff `channel_count <= allowed(revenue)`. A 2nd channel under $1M/yr → FALSE.

**8. Conversion benchmark band** (diagnose under/over-performance; band by channel)
- Meta in-person service 10% · cold webinar 2-3% · niched webinar 5% · web/landing 1-2% ·
  trusted platform page ~4% · Amazon book page ~25% · in-home salesperson 35% target.
- PASS iff `claimed_rate` within band. Below in-home 35% → fix process; above → raise price.

**9. Mozy newsletter bound**
- `word_count <= 200` AND all four slots present: reward quote · one tactical nugget ·
  contextual CTA · PS. PASS iff length and all four slots hold. Missing a slot → FALSE.

**10. Hook-variation count**
- `distinct_hooks_per_offer >= 5` (5-6 target), tested simultaneously, all leading to the same
  benefits/differentiators/CTA. PASS iff count ≥ 5. (80% of viewers decide in the first 3s.)

## SOFT-CAP gates (HEURISTIC — warn, never hard-fail)

These are judged classifications with real false-positive risk; emit `warn` + the rule + a fix.

- **Proof continuum:** rank proof strength — in-person > virtual, live > recorded, customer > founder.
  ~80% of ad content should be proof. Warn if the plan leans on weak proof; never BLOCK.
- **Platform tier list:** judged ranking of platforms by audience/economics. Warn on a poor fit.
- **Offer transformation:** is the offer moving from price-driven to value-driven? Judged; warn only.
- **Absolute-vs-relative return:** is absolute profit growing while the ratio falls (acceptable)?
  A judged classification — warn if the plan optimizes ROAS over absolute profit at scale.
- **List-health / unsubscribes:** unsubscribes are not the enemy (~0.42%/email is benchmark color).
  Warn on alarm over normal churn; never BLOCK.

## Why the tiers
Hard-gating a countable check (a number is or isn't ≥ a floor; a word count is what it is) is
reproducible and safe. Hard-gating a heuristic produces confident-but-wrong FALSEs and pushes
plans toward gaming the gate — so soft-cap it. Felt copy is judged pairwise against a specimen
because shape-grading it would cage the wording (see `scoring-specimens.md`).
