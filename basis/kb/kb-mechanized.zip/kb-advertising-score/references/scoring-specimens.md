# Scoring specimens — the verbatim winners to judge FELT copy against

Felt copy (ad hooks, testimonial hooks, promo-wrapper names) is scored **pairwise against
these known-good winners**, not on an absolute 1-10 and never by the model that wrote the
candidate. Randomize presentation order; treat any single verdict as a noisy triage signal.
Return `prefer | tie | weaker`. `weaker` contributes no pass and routes the copy to
kb-advertising-write; it never BLOCKS the score.

All specimens below are verbatim substrings of the source KB. No composites, no paraphrase.

## Paid-ad hook reference (judge same-offer hook copy against these)
- "Example hooks for same offer: 'Are you backed up in trash?' / 'You smell that smell?' / 'Is this you every trash day?' / 'You missed your child's practice again?' / 'Alex, did you take the trash out?'"

Ask: does the candidate hook open a different emotional entry point — smell, visual mess, social
status, missed events, nagging spouse — as cleanly as these do for one offer? → prefer | tie | weaker.

## Pain-based testimonial hook reference (judge testimonial hook copy against these)
- "Top hooks: 'two months away from shutting our doors', 'barely making enough to survive', 'paid all expenses and finished with $0 of profit'"

Ask: does the candidate open on a specific worst moment with a concrete detail (like the $0-profit
specificity), not a general "how was life before" story? → prefer | tie | weaker.

## Promo-wrapper naming reference (judge seasonal/promo names against these)
- "Examples: 6-week transformation, 42-day detox, belly fat blast, slim by Halloween, Lean by Halloween, slim for Santa, big booty boot camp."

Ask: does the candidate wrap the same core offer in a fresh felt theme that defeats ad fatigue
while the sales process stays fixed? → prefer | tie | weaker.

## How to run the pairwise judge
1. Present the candidate + one specimen, presentation order randomized.
2. Ask which better satisfies the named felt criterion and why (reasoning before verdict).
3. Record `prefer | tie | weaker` + the reason. `weaker` contributes no pass for that copy.
4. Never let the model that generated the candidate be the judge.
