# Execution procedures & playbooks (how to improve creative; agency-to-in-house)

Restored faithfully from `advertising--alex-hormozi.md`. Repeatable methods an executing
agent can run: deriving what makes winning ads win, and the phased agency-to-in-house path.
Reference only.

## Common Factors Analysis — Skill Acquisition Loop (how to improve creative from data)

The repeatable method for deriving what makes winners win. A data-driven skill development
method consumed wherever you need to improve ad creative (or content, sales calls, customer
quality) from performance data.

Procedure:
> "generate high volume of outputs, identify top 10% vs. bottom 10%, extract what the top
> performers share that the bottom lack. Those discrepancies are the learnable skill
> components. Applies to content, ads, sales calls, customer quality."

Steps & rules:
- Requires high volume first to have meaningful data.
- Compare top 10% outputs to bottom 10% outputs in any category.
- The discrepancies between top and bottom are the golden nuggets of skill.
- Applies to: content pieces, ad creatives, sales call recordings, customer quality.
- For customer avatar: What do top 10% customers have in common? Acquire more of those,
  fewer of the bottom 10%.
- Works for skills no course teaches — requires self-generated data.

Source quotes (verbatim):
> "Common factors analysis is fundamentally how I learn everything because a lot of the skills
> I have to learn now are things no one teaches."
> "What are the discrepancies between these two? Those discrepancies are the golden nuggets that
> build together to help you acquire skills."

## Three-Phase Agency-to-In-House Playbook

A systematic approach to using agencies to build internal capability.

- **Phase 1:** hire a basic agency ($3-5K/month) to learn fundamentals and build content cadence.
- **Phase 2:** hire an advanced agency ($15-30K/month) with explicit intent to learn their
  process, document SOPs, and train your team over 6 months.
- **Phase 3:** decouple and transition to a low-cost consulting agreement, then cut entirely.

Execution rules:
- Use agency first for PPC and SEO — faster and easier than building in-house.
- Tell agency upfront: 'I'm taking this over in 6 months'.
- Agency trains internal team member, then transitions to consultant role.
- **Consulting fee: 20–30% of previous delivery fee (~2–3% of ad spend)** (vs. typical 10–15% for full management).
- **Meta/social ads: bring in-house immediately due to 21-day creative fatigue cycle** requiring high creative volume.
- Local Meta ads require constant creative refresh that agencies struggle to deliver at local scale.
- Agency's primary value may be accountability (e.g., committing to 3 videos per week).
- Hire paid ads specialist for $100–200K equity buyout potential to attract talent.

Key metrics: 21-day creative fatigue cycle for Meta/Facebook local ads; consulting transition
fee ~2–3% of ad spend; started with a YouTube agency at $5,000/month; grew from <10,000 to
5 million+ followers in under 24 months.

Source quotes (verbatim):
> "I want to do what you do in my business but I don't know how. I'd like to work with you for
> six months so I can learn how you do it, plus I'll pay extra for you to break down why you make
> the decisions you do and the steps you take to make them"
> "Start with agency. Tell them 'I'm taking this over in 6 months.' Agency trains replacement team
> member. Transition to consulting model once internal person is trained."

Pitfall: the best agencies don't need to run ads — they have more customers than they can handle.

## Agency Learning Method (the magic question)

The companion method for extracting an agency's skill as paid education.

- The **magic question: 'What would it take for you to teach me one-on-one?'**
- Tell the agency: I want to steal everything you have, I'll pay more and stay longer.
- Insist: 'I'm the only one who touches the computer. You tell me what to do.'
- Ask them to explain their decision-making process, not just the steps.
- Talk to at least 10 agencies before buying — ~15 calls to truly understand a space.
- Litmus test: when you stop learning new things on calls = ready to make an informed decision.
- Red flag: agency doesn't provide best practices (funnel, scripts, response times).
- **Hormozi paid $750/hour for weekly sessions; 6 weeks of $750/hour = $6,000 total = one
  month of typical agency fees ($3,000-$5,000/month).**

Source quotes (verbatim):
> "for $6,000 basically the cost of one month of running this agency. I was able to learn the
> skill from one of the best agency owners"
> "What would it take for you to teach me one-on-one?"
> "I go to agencies and say: I want to steal everything that you have but I will do it over a
> longer period of time because it'll take me time to learn, and I will compensate you for the
> difference."

## Grader-soundness checklist (is this grader wired correctly?)

Awareness checks on how the scorer itself is configured — not a writer gate.

- Are only the countable gates hard-gated, with soft-caps warn-only and felt as pairwise signals?
- Is the judgment run separately from any writer, felt copy judged against a real specimen?
- Does the band come from gates the plan actually asserted, not a raw count?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Are ROUTE rules (allocation, fix-order, channel sequencing) carried as contract, not graded?
- Is every quoted specimen a verbatim substring of a source file (no composites)?
