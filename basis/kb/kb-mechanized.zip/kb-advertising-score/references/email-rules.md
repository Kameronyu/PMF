# Email execution rules — timing, segmentation, deliverability (decision rules / thresholds)

Restored faithfully from `advertising--alex-hormozi.md`. Concrete, countable email rules that
live in the advertising source. Treat these as decision rules / benchmark color when scoring or
advising on email, NOT as new hard gates (the only hard email gate is the <200-word newsletter,
gate 9). Use them to diagnose under-optimized email plans and emit `warn` + fix.

## Timing optimization (day and time)

- **B2C: Monday and Tuesday emails see about an 18% lift in open rates.**
- B2B: Wednesday performs best, with a comparable lift.
- **Time of day sweet spots are 10am-noon and 1pm-3pm**, avoiding early morning when real
  business emails dominate the inbox.
- Cross-timezone audiences make timing less critical.
- Data sourced from Neil Patel across millions of emails; ~18% average increase in open rate
  for optimal day selection.

## Segmentation (the 791% rule)

> "HubSpot research showed a 791% increase in email ROI from segmentation alone."

- Segment by revenue level, business stage, or other qualifying data from opt-in.
- Sending advanced tactics to beginners (or beginner content to experts) reduces engagement.
- The quality of the email matters less than whether the right person receives it.
- Use opt-in qualifiers to automatically segment new subscribers.

Source quote (verbatim):
> "It's way less about how good the email is and so much more about who's getting it"

## Plain-text deliverability tactics

- Emails should look like normal person-to-person exchanges: mostly plain text, minimal images,
  one to two links maximum, minimal money language (no "Vegas Strip" design).
- **17% of B2B marketing emails never even reach the inbox** (16.99% precise).
- **Optimize preview text — 24% of people check it before opening.**
- **Use Google-native links** (YouTube, Google Drive) for higher deliverability.
- Remove money language from text to avoid promo-tab classification.
- Get recipients to reply (e.g., reply YES to receive a bonus) to boost domain reputation.

Source quote (verbatim):
> "Don't try and figure out hacks try and simply align what you do with the objective of the platform"

## Email as highest-ROI channel (context)

- Average ROI for email is 35x–45x per dollar spent — highest ROI channel available; cost is
  near zero because you already paid to acquire the contact (email is follow-up).
- Email consumption is uniform across age groups (84-90%+ check daily; 61% multiple times/day).
- Not emailing is the single biggest mistake.

Source quote (verbatim):
> "The average ROI for email depending on the source you look at is between 35 and 45 return"
