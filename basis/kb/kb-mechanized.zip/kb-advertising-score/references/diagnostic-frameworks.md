# Diagnostic & scaling frameworks (what to improve, how lead-gen scales)

Restored faithfully from `advertising--alex-hormozi.md`. These are the named decision
frameworks behind WHAT to fix when spend won't scale and HOW lead generation scales
beyond personal effort. The score skill grades spend ceilings and channel counts; these
tell an agent which lever to pull and which tier to climb. Reference only — not new gates.

## Five Scaling Levers for Paid Acquisition (the WHAT-to-improve framework)

> "The difference between companies spending $5K/day and $100K/day profitably comes down
> to five levers: better lead magnet, better creative, superior CRO on pages, improved
> sales efficiency, or all four combined. ROAS drops as you scale, and improving each
> lever takes time, which is fundamentally why business takes time to grow."

The five levers, in order:

- **Lever 1: Better lead magnet**
- **Lever 2: Better creative/ads**
- **Lever 3: Superior CRO** (conversion rate optimization) on pages
- **Lever 4: Improved sales efficiency**
- **Lever 5: All four combined**

Decision rules:
- ROAS drops as spend increases — these levers compensate for the falling ratio at scale.
- **You can only change one lever at a time, which is why growth takes time.** When ROAS
  drops as you scale, this is the menu of what to improve — pick one lever, not all at once.

Source quote (verbatim):
> "The difference between companies that can spend $100,000 a day and $5,000 a day profitably
> is how good they are. It's literally just making all of these pieces better and that takes time."

## Four-Level Lead Generation Leverage Hierarchy (how lead-gen scales)

A tiered framework for scaling lead generation from personal effort to decentralized
self-sustaining systems. Each level multiplies output while reducing personal time per lead.
This is the centralized-vs-decentralized leverage tier ladder that governs how lead-gen
scales beyond management capacity.

- **Level 1:** You get leads directly — output capped by your hours, fixed throughput.
- **Level 2:** You recruit one lead-getter — they replicate your output; you work once to
  create the node. Adding one per month triples lead flow without additional daily work.
- **Level 3:** Employees (centralized, salaried), agencies (centralized, fee-based),
  affiliates (decentralized, independent), customers (decentralized, existing buyers).
- **Level 4:** Decentralized acquisition through affiliates and customer referrals scales
  exponentially because they promote without management intervention.

Decision rules:
- **Centralized** relationships (employees, agencies) scale **linearly** with management capacity.
- **Decentralized** relationships (affiliates, customers) scale **beyond** management capacity —
  they promote independently and continually.

Key metric: 55% of School customers came from referrals and affiliates.

Source quotes (verbatim):
> "To get mega-rich, you need decentralized acquisition. Employees and agencies scale linearly
> with management. Affiliates and customers scale exponentially because they promote without
> your prodding."
> "Every month you create another lead getter, you triple your lead flow while maintaining your
> personal time investment."

## Narrow the Front End Framework (which segment to keep/cut)

The LTV:CAC-by-segment selection rule for narrowing the front end. Narrowing messaging to
a specific avatar raises response from that segment even though total lead volume drops; the
LTV:CAC ratio often expands because copy gets crisper.

- **Look at LTV-to-CAC by customer segment to find the greatest discrepancy relative to market size.**
- **Cut front ends to the segment with best return on ad spend.**
- **Either bridge to the second avatar or cut them off entirely.**
- Specific callouts in ads (e.g., 'attention salon owners') attract the exact segment you want.

Source quote (verbatim):
> "When they see your ad: 'oh this is just for me' rather than 'I might find some value here' -
> that's the difference."
