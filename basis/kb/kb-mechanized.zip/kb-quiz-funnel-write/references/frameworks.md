# Named frameworks & advanced models (study before writing; choose the shape that fits)

Faithful to the two source files. These are named, teachable models — not slot orders.

## Three Pillars of high-converting quiz funnels (source: Mark Builds Brands)

Every quiz funnel scaling to seven or eight figures per month executes three core mechanisms
**simultaneously**. Knowing the WHY behind each makes the copy seed beliefs better.

1. **Micro-commitments** — each answer (yes/no, slider, multiple choice) creates a "hypnotic
   yes-loop": repeated small agreements prime the prospect into a highly suggestible state
   before the offer appears. (This is why Yes-Street questions are phrased to earn a yes.)
2. **Belief seeding** — subconsciously aligning customer beliefs with beliefs that support
   purchasing the product. *Marketing is fundamentally a belief-change game; seeding removes
   friction between customer and sale.* Write belief-seeding lines to close the gap between
   what the prospect currently believes and what they must believe to buy.
3. **Pre-handling objections** — address likely purchase objections inside the quiz before
   they surface, identical to how top direct-response copywriters structure long-form sales
   copy.

> These three pillars work in sequence to replace the "buy my stuff" cold-traffic experience
> with an emotionally engineered purchase journey.

Every question must serve **exactly one** of these three roles (micro-commitment, objection
pre-handling, or belief seeding); none should exist purely for data collection. The score
skill gates this membership — but as a writer, knowing the pillar a question serves is how you
phrase it.

## Advanced model: Personalized Supplement Formulation — the "Bionic Model" (source: Carl Weische)

The highest-differentiation variant of the quiz funnel. Reach for this framing when the brand
can actually manufacture per-customer.

- **Entry point:** either a long-form quiz OR a blood-test submission; both feed into an
  **individual profile**.
- **Output:** a custom supplement formulation unique to each customer.
- **Value proposition (write toward this):** eliminates over-supplementation and
  under-targeting vs. generic mass-market products.
- **Brand-authority overlay:** celebrity equity (e.g., Ronaldo as shareholder) provides a
  brand-authority overlay device.

> Represents the highest-differentiation version of the quiz funnel model — the quiz data
> doesn't just personalize the sales page, it determines the actual product formulation.

Copy implication: when the formulation is genuinely custom, the diagnosis/result copy can claim
a literally individual product, not just an individualized recommendation — a stronger,
truer verdict than the standard Named-Diagnosis pattern.
