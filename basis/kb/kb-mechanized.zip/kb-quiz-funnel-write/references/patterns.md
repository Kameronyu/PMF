# Optional patterns — anatomy + a worked example each

Reach for one per screen when it fits the moment. None is a required slot order for the
funnel as a whole; forcing a fixed sequence is what produces same-y, un-diagnostic copy.
Use these to vary the wording, not to standardize it.

## Named-Diagnosis
[named stage/grade] + [cause assembled from the prospect's own answers].
- A specific named stage reads as evidence-based; a cause built from *their* answers makes
  the verdict feel measured, not asserted. Only name what the quiz actually collected.
- Example: "Stage 2 Hair Loss — caused by genetic predisposition and high stress levels"

## Yes-Street
[emotional-commitment question] → [practical-commitment question], each answerable "yes".
- Phrase so the honest answer is agreement; escalate emotional → practical so consent
  compounds toward the offer. A reinforcing belief statement can sit between the two.
- Example: "Are you determined to finally stop your hair loss?" then
  "Does a simple hair care routine sound good?"

## Projection/Finality
[projection: "expect results by" + computed future month] + [finality: terminal framing].
- Project a concrete future month from the current date so the multi-month supply reads as
  the time required to reach the promise; finality copy closes comparison-shopping.
- Projection template (fill the bracket): "Based on your answers, we expect you to see
  visible results by [future month]."
- Finality example: "the last plan you'll ever need"

## Result-Frame
[verdict language] + [personalization echo] + [optional live urgency].
- Frame the sales page as the delivery of a result, not the start of an offer; echo a
  collected attribute; urgency adds pressure without a discount.
- Examples: "Hair profile matched" · "Here's your growth plan" ·
  "X people are looking at this right now"

## Objection-Card
[name the just-surfaced barrier] + [answer with the desired identity, not a feature].
- Place immediately after the behavioral question that raised the barrier, before the
  product page; resolve with who the prospect wants to be, not a spec sheet.
- Example: "A busy schedule doesn't have to stop you from looking and feeling years younger."
