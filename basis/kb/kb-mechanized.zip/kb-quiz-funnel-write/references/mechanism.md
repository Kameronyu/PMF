# The real mechanism — why quiz funnels work (steer your copy by this)

This is the load-bearing mental model behind every screen you write. It tells you what to
optimize the wording *for*. Faithful to `quiz-funnel--mark-builds-brands.md`.

## Emotional priming is THE mechanism — not personalization, not AOV (decision rule)

> Quiz funnels do NOT outperform product pages primarily because of personalization, product
> matching, or AOV increases. The core mechanism is **emotional priming** — placing the target
> customer into an emotionally ready-to-purchase state before the offer is shown. Even a
> three-question quiz boosts conversion rates over sending traffic directly to a sales page.

Consequence for the copy you write: the questions, cards, diagnosis, and projection lines are
there to move a cold prospect *progressively* into a purchase-ready emotional state — not to
look personalized for its own sake. The quiz "allows brands to play with emotions progressively,
building readiness to buy rather than demanding it immediately." When choosing between two lines,
prefer the one that advances emotional readiness, not the one that merely sounds more tailored.
Misreading the mechanism (writing for personalization/product-matching instead of priming)
sends the whole funnel toward the wrong target.

## Three revenue levers — why the model is the primary acquisition model (framing)

The quiz funnel is "the most profitable acquisition model currently in use by the largest DTC
and digital brands." It works because it combines three revenue levers:

1. **Higher conversion rate** — emotional priming + micro-commitments.
2. **Higher relevance** — the personalization layer.
3. **Retargeting asset creation** — an email list segmented by quiz responses.

> The quiz replaces the cold-traffic "hope they buy" model with a systematically engineered
> persuasion pathway.

Use this to keep priorities straight: the personalization layer is lever #2, not the engine.
Lever #1 (priming) is the engine; the email-segmentation asset (#3) is why collecting name +
email at quiz end matters even for non-purchasers.
