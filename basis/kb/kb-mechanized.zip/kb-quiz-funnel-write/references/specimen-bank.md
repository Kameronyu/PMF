# Specimen bank — verbatim winning quiz-funnel copy, with the funnel moment each occupies

Preserved verbatim from `quiz-funnel--carl-weische.md`.
These are the highest-value asset in the skill — study and adapt, do not abstract into
templates. Each specimen shows the *form* of a good answer for one screen; that is what
steers a model.

## Objection-card (after a behavioral question surfaces the barrier)
- "A busy schedule doesn't have to stop you from looking and feeling years younger."
  — moment: follows the "how much time do you spend on hair daily?" question; names the
  time objection and answers it with the desired identity, before the product page.

## Named-Diagnosis slide (aggregate prior answers into a named verdict)
- "Stage 2 Hair Loss — caused by genetic predisposition and high stress levels"
  — moment: closes the causation section; combines a named stage with a cause assembled
  from the prospect's own answers (age, severity, timeline, genetic/lifestyle), reading
  as an evidence-based medical result.

## Yes-Street micro-commitments (consistency-bias, answerable "yes", escalating)
- "Are you determined to finally stop your hair loss?"   — emotional commitment.
- "Does a simple hair care routine sound good?"          — practical commitment.
  — moment: final pre-sales section; the pair compounds agreement so the prospect arrives
  at the offer already having said yes multiple times.

## Loading-screen micro-copy (manufacture anticipation + personalization perception)
- "Analyzing your profile…"
  — moment: a loading-screen animation before the sales-page reveal; the simulated
  generation makes a canned result feel individually built.

## Result-Frame sales-page headlines (deliver a result, not an offer)
- "Hair profile matched"
- "Here's your growth plan"
  — moment: above the fold; frame the page as the delivery of a personalized verdict.
- "X people are looking at this right now"
  — moment: above-the-fold urgency; live social pressure without a discount.

## Finality framing (make the multi-month plan feel necessary, not expensive)
- "the last plan you'll ever need"
  — moment: the transformation-plan slide; closes comparison-shopping by framing the plan
  as terminal.

## Personalization callback (echo collected attributes on the sales page)
- "recommended based on your quiz results"
  — moment: the bundle/results page; references attributes the quiz collected, creating
  narrative continuity between funnel and purchase.

> Note: the six-month projection line is a slot-fill template, not a fixed specimen —
> "Based on your answers, we expect you to see visible results by [future month]." Fill the
> bracket with the real projected month computed from the current date. See
> `references/patterns.md` (Projection/Finality).

> Note: AI can generate quiz-funnel copy at scale but needs the real **avatar** and the
> **named outcome** as input — a product brief alone yields generic, un-diagnostic copy.
> Feed real voice-of-customer and the actual quiz answers, not adjectives.
