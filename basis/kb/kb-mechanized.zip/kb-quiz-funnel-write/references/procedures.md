# Execution procedure — the AI-assisted quiz-creation workflow (run this to draft at scale)

Faithful to `quiz-funnel--mark-builds-brands.md`. This is the actual procedure for generating
quiz questions with AI — not just a gate that four docs exist. Complete the four foundational
documents BEFORE prompting; garbage in, garbage out.

## Step 1 — Build the four foundational documents (before writing a single question)

1. **Offer doc** — full breakdown of the product, pricing, mechanisms, and differentiation.
2. **Avatar doc** — detailed customer profile: demographics, psychographics, fears, desires,
   language patterns.
3. **Research doc** — market context, competitive landscape, customer reviews,
   voice-of-customer data.
4. **Beliefs doc** — current beliefs the target customer holds that support or block purchase;
   beliefs that need to be seeded.

## Step 2 — Prompt the AI with the docs as brand context

> Feed all four documents into ChatGPT as a brand context profile. Upload competitor quiz
> examples for pattern analysis. Then prompt ChatGPT to generate questions mapped explicitly
> to the three purposes (micro-commitment, objection handling, belief seeding). Foundational
> documents must be completed before AI prompting — garbage in, garbage out.

So the procedure is: (a) load all four docs as a brand-context profile; (b) upload competitor
quiz examples so the model can do pattern analysis; (c) prompt it to generate questions where
each is explicitly mapped to one of the three purposes. A generated question with no purpose
assigned is a defect — it fails the role-membership requirement.

## Step 3 — Apply the design rules to the generated questions (source: Mark Builds Brands)

- **Gradualization principle:** start with non-invasive, easy questions; build progressively to
  personal or sensitive questions.
- Vary the question format every **2–3 questions** to maintain engagement and dopamine response.
  (The consecutive-format bound is enforced as a gate by kb-quiz-funnel-score.)
- Questions should be dopamine-inducing (sliders, image selects, interactive formats), not just
  text button clicks.
- Insert **intraquiz cards** (non-question screens between questions) to deliver belief-changing
  statements and pre-handle objections mid-flow.
- **Optimal quiz length:** 3–20 questions; sweet spot is 8–12 questions.
- Collect **name and email at quiz end** (before the results reveal) to enable follow-up
  regardless of purchase decision.

## Step 4 — Optimize completion rate post-launch (source: Mark Builds Brands)

**Target KPI: 30% completion rate** — 30% of quiz starters should reach the sales page.

1. Launch with minimal friction to establish baseline completion data.
2. Track drop-off rate at every individual question.
3. Identify spike questions (abnormal drop-off) and revise or remove them.
4. Add qualifying friction progressively based on data — qualifying questions filter low-intent
   prospects but reduce completion volume; balance is data-driven.

## Step 5 — Post-quiz email segmentation (source: Mark Builds Brands)

Trigger a **5–7 email follow-up sequence** delivering personalized results based on quiz answers.

- Build branching email workflows triggered by specific answer combinations (e.g., ingredient
  preferences, speed preferences, problem severity scores).
- Each branch sends a different sequence tailored to that prospect's stated profile.
- Personalized results delivery increases relevance, trust, and downstream conversion likelihood.
- Email collection at quiz end enables retargeting and nurture even for non-purchasers.
