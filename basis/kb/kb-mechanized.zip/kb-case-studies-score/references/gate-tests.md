# Per-gate membership tests + the COUNTABLE definitions

All three gates are COUNTABLE → hard-gate. Each test is yes/no and can return FALSE, so a
wrong call fails by shape. Run the test from the numbers, not from impression.

## Gate 1 — Saturation = failure (registry: 5+ saturation rule for sophistication)

- `same_base = competitors share the same base mechanism / primary claim` (one positioning,
  not merely the same product category).
- `saturated = competitor_count >= 5 AND same_base`.
- **FAIL iff `saturated`** — the undifferentiated entrant cannot be rescued by creative
  quality; require a new mechanism OR a new avatar (see ROUTE: dual-lever / avatar-flip).
- COUNTABLE because the competitor count is a count and "same base mechanism" is observable
  from the competitors' primary claims. Do not soften FAIL because the creative is strong —
  that is the exact failure mode this gate exists to catch.

Verbatim lesson this gate enforces:
> "when 5+ competitors occupy the same mechanism position, no amount of creative quality rescues the undifferentiated entrant — new mechanism or new avatar required"

**Runway window (pairs with this gate, not a separate hard-gate):** the 5+ count tells you
*when* saturation has arrived; a NEW MECHANISM buys runway *before* it does. Treat a new
mechanism as a 6–12+ month head-start for a skilled operator, after which the 5+ count gate
fires as opportunists pile in (Dubai Chocolate, Hexclad — see `case-library.md`).
Verbatim lesson:
> "Skilled marketer + new mechanism product = extended runway (new mechanism buys 6–12+ months before saturation)"

## Gate 2 — On-site vs. ad bottleneck

- `soft_healthy = ctr >= 0.03` (the ad is buying the click).
- `no_conversion = purchases == 0`.
- **Verdict ON-SITE iff `soft_healthy AND no_conversion`** → the bottleneck is the landing
  page, not the ad → action: iterate the LP, not the creative.
- COUNTABLE because CTR is a measured rate against a fixed threshold and purchases is a count.
  Do NOT iterate the ad when this fires — the click already happened.

Verbatim lesson this gate enforces:
> "CTR ≥ 3% + 0 purchases = on-site problem; iterate LP, not ad"

## Gate 3 — Raise spend during LP rebuild

- `soft_healthy = ctr >= 0.03` (soft metrics healthy).
- `hard_broken = purchases broken / not converting at the expected rate`.
- `rebuilding = an LP rebuild is in progress`.
- **Verdict RAISE-SPEND iff `soft_healthy AND hard_broken AND rebuilding`** → the correct
  action is to INCREASE ad spend during the rebuild, because you need volume to measure the fix.
- COUNTABLE on the CTR threshold + the broken-hard-metric condition. Cutting spend here is the
  flagged negative — it starves the rebuild of the data needed to validate the change.

Verbatim lesson this gate enforces:
> "when soft metrics (CTR ≥ 3%) are healthy but hard metrics (purchases) are broken, increasing ad spend DURING the LP rebuild is correct — you need volume to measure the fix"

## Why these are hard-gated and the moves are not

A competitor count, a CTR against 3%, and a purchase count are reproducible — two checkers
reach the same verdict. The positioning/desire/delegation moves depend on which named trigger
is present, so they live as ROUTE selection rules (`route-rules.md`), not pass/fail gates. A
felt fit ("does this case really match my situation?") is judged pairwise against a specimen
and contributes a signal only — never a hard FALSE.
