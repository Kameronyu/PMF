# Case specimens — the known cases each gate / route is judged against

Score a situation by matching it to one of these real cases (verbatim from
`case-studies--spencer-origins.md`). A felt situation-matches-case call is judged
pairwise against the specimen — `prefer | tie | weaker` — never a hard FALSE.

## Gate 1 — Saturation = failure (the canonical FAIL case)

> "7 brands all running "fast drying without heat damage" as primary claim → ads failed regardless of copy quality for all entrants"
> "Undifferentiated mechanism = failure even with high-quality execution"
> "when 5+ competitors occupy the same mechanism position, no amount of creative quality rescues the undifferentiated entrant — new mechanism or new avatar required"

## Gate 2 — On-site vs. ad bottleneck (the LP-congruency unlock case)

> "the unlock was page congruency, not creative quality — the ads were already good; the page was the bottleneck"
> "CTR ≥ 3% + 0 purchases = on-site problem; iterate LP, not ad"

## Gate 3 — Raise spend during LP rebuild (the RatVac rebuild case)

> "During rebuild: doubled ad spend (confident the ad was working; diagnosed LP as bottleneck)"
> "when soft metrics (CTR ≥ 3%) are healthy but hard metrics (purchases) are broken, increasing ad spend DURING the LP rebuild is correct — you need volume to measure the fix"

## R1 — Desire strength → viable channels (wedding vs. cable organizer)

> "Cannot support paid ad spend — desire too weak to carry CAC"
> "desire strength determines which channels and price points are viable — not every product can support paid acquisition"

## R2 — Dual-lever positioning (True Classic)

> "Either axis alone resets sophistication to Stage 1; both axes = maximum reset + rapid scale"
> "the most powerful positioning move is new mechanism + new avatar simultaneously — rare but produces 9-figure businesses when executed well"

## R3 — Avatar-flip lever (Stanley Cup)

> "Identical product (insulated travel cup) — no product change"
> "avatar flip alone can reset market sophistication from Stage 4–5 to Stage 1 — product change unnecessary"

## R4 — Delegation sequence (edit-it-yourself model)

> "self-editing skill → structured delegation brief → trained editor is the correct sequence; skipping to delegation without self-editing first = bad briefs = bad output"

## How to run the pairwise fit judge

1. Present the situation + the candidate case specimen.
2. Ask whether the situation actually matches the case's trigger conditions (counts/CTR for
   gates; named trigger for routes) — criteria before verdict.
3. For a felt fit, record `prefer | tie | weaker`; `weaker` contributes no match.
4. For a COUNTABLE gate, the verdict comes from the numbers, not the fit judge.
