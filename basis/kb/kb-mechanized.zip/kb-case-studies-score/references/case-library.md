# Case library — full restored cases (Spencer / Origins)

The complete set of real cases behind the gates and routes, restored faithfully from
`case-studies--spencer-origins.md`. Each case carries its data and its verbatim lesson so
an executing agent can cite the evidence. Quotes here are verbatim source substrings — do
not paraphrase inside quotes. Organized by the source's sections.

---

## MARKET AWARENESS & SOPHISTICATION

### Norse Organics — Speed-as-Mechanism (Acne) — review-mining heuristic
- Competitive intelligence from review mining: named ingredients (MSM, glucosamine,
  Vitamin C) appeared in reviews → indicated educated buyer base already researching ingredients.
- Mechanism angle discovered: "Acne gone in 4 days" vs. industry standard positioning of 4–6 months.
- Speed became the mechanism differentiator — not ingredients, not formula.
- **Heuristic (mechanism discovery):** mine competitor reviews for the ingredients/claims
  customers themselves name → that reveals what the market already believes works, and where a
  speed-as-mechanism angle is open.
- Verbatim lesson:
> "review mining for competitor-mentioned ingredients reveals what the market believes works (speed-as-mechanism opportunity)"

### Shilajit — Stage 2 positioning (claim enlargement)
- Product correctly positioned at Stage 2 (claim enlargement) given limited market exposure at launch.
- Shilajit had not yet saturated — new benefit claims were still credible and novel to mass audience.
- Verbatim lesson:
> "entering at the right sophistication stage (not over- or under-sophisticated) determines whether creative resonates without education cost"

### Hair Dryer — 7-competitor failure (the saturation FAIL case)
- 7 brands all running "fast drying without heat damage" as primary claim → ads failed
  regardless of copy quality for all entrants.
- Undifferentiated mechanism = failure even with high-quality execution.
- This is the canonical case behind COUNTABLE Gate 1 (saturation = failure).
- Verbatim lesson:
> "when 5+ competitors occupy the same mechanism position, no amount of creative quality rescues the undifferentiated entrant — new mechanism or new avatar required"

### Skate-Cut Gear — Desire spike via external event (36× MER)
- Oct 28: $1,800/day ad spend, $13–15K revenue.
- Oct 29: $5,500/day ad spend, $200,000+ revenue (36× MER).
- Trigger: hockey player death on ice (event created emotional urgency for protective gear).
- Zero product or creative changes between the two days.
- **Decision rule (news-monitoring as demand signal):** watch news in your category for
  desire spikes; the *same* creative at a higher desire intensity produces radically different
  results — so a spike is a buy signal, not a fluke.
- Verbatim lesson:
> "desire can spike overnight due to external events — monitoring news for demand signals in your category is a legitimate strategy; same creative at different desire intensity = radically different results"

---

## CONSUMER PSYCHOLOGY & AVATAR DISCOVERY

### Quadruple-Bypass Surgery Comment — new-avatar discovery procedure
Executable procedure for turning one comment into a validated avatar:
1. Spot the signal: a Facebook ad comment from a bypass surgery recovery patient.
2. **Contacted commenter → recorded call → transcribed → validated pain language.**
3. Define the new avatar: cardiac recovery patients with specific mobility limitations.
4. Build dedicated creative around that avatar.
5. Result: 5.5 ROAS within 48 hours of launch.
- Verbatim lesson:
> "one Facebook comment is enough to justify avatar research if validated — don't ignore outlier comments"

### Hexclad — Desire-first product development ($1B valuation)
- Started with stated customer frustration: food sticking to cookware.
- Product designed around the desire ("food releases perfectly"), not around a manufacturing innovation.
- $1B+ valuation built on desire-first positioning.
- **Framework (desire-first):** the desire already exists in the market; the win is capturing
  it with a mechanism that is visible proof of the benefit.
- Verbatim lesson:
> "the desire was always there (food sticking frustration is decades old) — Hexclad captured it with mechanism (the hex grid pattern = visual proof of non-stick)"

### Ridge Wallet — Avatar-first product development
- Avatar frustration: bulgy wallet discomfort (health + comfort desire).
- Product designed around stated complaint from EDC (everyday carry) community.
- **Framework (avatar-first):** find a community already articulating a frustration, then
  build around their articulation — not around a product vision invented in isolation.
- Verbatim lesson:
> "find a community that articulates a product frustration clearly → build around the articulation, not around a product vision"

### Grüns Gummies — Avatar flip unlocks gift-buyer (format change)
- Adults and children rejecting green juice (taste, texture, preparation effort).
- Gummy format unlocked: (1) children as direct users, (2) gift-buyer avatar (parent buying
  for child) as PRIMARY customer.
- Gift-buyer avatar has different messaging than end-user — the parent's desire (child's
  nutrition) is the driver, not the child's preference.
- **Decision rule (distinct from a same-product avatar flip):** here a *format change* opens a
  buyer who is not the user; the new sell vector can exceed the direct-user market.
- Verbatim lesson:
> "format change can unlock an entirely new sell vector (gift-buyer) that becomes larger than the direct user market"

### Desire Strength Proxy — Wedding weight loss vs. desk cable organizer
- Strong desire example: lose 30 lbs before wedding
  - Supports $5K coaching program
  - Supports $3.5K delivery meal service
  - Supports ~$50 supplement
  - Time-bound urgency + identity stakes
- Weak desire example: desk cable organizer
  - Organic TikTok content can sell it
  - Cannot support paid ad spend — desire too weak to carry CAC
- Verbatim lesson:
> "desire strength determines which channels and price points are viable — not every product can support paid acquisition"

---

## MECHANISM

### AI Mechanism Discovery Prompt — structured template (validated on 2 brands)
**Executable recipe — the prompt inputs are:** product name + product URL + sophistication
PDF. Run it as a *structured* prompt, not a generic ChatGPT question.

- Test 1: Humidifier
  - Spencer ran AI mechanism prompt with product name + URL + sophistication PDF.
  - Claude output: "stainless steel interior" as the differentiating mechanism.
  - Result: correctly identified on first attempt — validated by sales data.
- Test 2: Dog harness
  - Claude output: "convertible D-ring system" as differentiating mechanism.
  - Result: correctly identified on first attempt.
- Verbatim lesson:
> "structured AI prompt (not generic ChatGPT question) can identify mechanisms humans miss — prompt structure matters more than model"

### Dubai Chocolate — Mechanism exploitation boom-bust (runway threshold)
- Novel mechanism: pistachio + kunafa filling = genuinely new texture/flavor combination
  (New Mechanism at Stage 1).
- Unskilled operators entered → viral cycle → peak revenue → rapid saturation (6-month cycle).
- Operators who couldn't sustain mechanistic advantage → revenue collapsed.
- **Threshold / runway rule (pairs with Gate 1's 5+ count):** a new mechanism buys time
  *before* the 5+ saturation point arrives — a skilled operator gets an extended runway window.
- Verbatim lesson:
> "Skilled marketer + new mechanism product = extended runway (new mechanism buys 6–12+ months before saturation)"
- Verbatim lesson (the opportunist dynamic):
> "new mechanism products attract opportunists who extract the boom and accelerate the saturation"

---

## LANDING PAGE & CRO

### Soup Brand — LP congruency unlock (the Gate 2 case)
- Before: generic homepage, no avatar specificity.
- After: congruent LP with doctor call-out, IBS-specific review section, relatable patient story.
- Ad spend: $13K. Revenue following month: $90,000+. Scale: $200,000/month sustained.
- Verbatim lesson:
> "the unlock was page congruency, not creative quality — the ads were already good; the page was the bottleneck"
> "CTR ≥ 3% + 0 purchases = on-site problem; iterate LP, not ad"

### RatVac — LP rebuild (the Gate 3 case) + coupon margin-for-conversion lever
- Pre-rebuild: ROAS 1.18×, RPS $1.04, weekly revenue ~$1,000.
- Post-rebuild: ROAS 3.59×, RPS $6.87.
- During rebuild: doubled ad spend (confident the ad was working; diagnosed LP as bottleneck).
- **Coupon lever (dropped earlier — restored here):** an offer change of a $50 coupon cost 2%
  margin and produced a 6× lift in revenue per visitor. Margin spent on conversion can be a
  high-ROI lever, separate from the raise-spend lesson.
- Verbatim data:
> "Offer change: $50 coupon introduced = 2% margin cost → 6× revenue per visitor lift"
- Verbatim lesson:
> "when soft metrics (CTR ≥ 3%) are healthy but hard metrics (purchases) are broken, increasing ad spend DURING the LP rebuild is correct — you need volume to measure the fix"

### Hollow Socks — Checkout social proof at scale (distinct from PDP)
- $50M+/year revenue, Meta-heavy.
- Social proof implementation: "1 million pairs sold" badge placed AT CHECKOUT (not only PDP).
- Validates: purchase hesitation spikes at checkout → social proof at checkout specifically
  reduces final-moment abandonment.
- **Decision rule (CRO):** checkout placement is not redundant with PDP placement — they target
  different friction moments; place proof at both.
- Verbatim lesson:
> "social proof placement at checkout is not redundant with PDP placement — it addresses a different, higher-friction moment"

---

## EMAIL & RETENTION

### Black Friday 3-send email sequence — send frequency during peak
- Campaign 1: £9,569 revenue.
- Campaign 2 (2 days later): £5,600 revenue.
- Campaign 3 (following day): £3,772 revenue.
- Total: ~£19,000 across a 3-day weekend to engaged segment only.
- **Decision rule + data:** three sends across three days is not over-sending; revenue per send
  falls gradually, not catastrophically — so the marginal send is still strongly positive.
- Verbatim lesson:
> "frequency during peak periods (3 sends across 3 days) is not over-sending — revenue diminishes gradually, not catastrophically"

### Birthday-offer single email
- Single email to engaged segment = £6,000 revenue.
- One of three sends that week — not a special send, a routine cadence send.
- Verbatim lesson:
> "even single targeted sends to engaged lists generate meaningful revenue; under-sending is lost money"

### Early-stage email benchmarks — don't delay email
- Design cost: ~$20/campaign (simple template).
- Revenue: £600–700/campaign during seasonal periods.
- Monthly email revenue: ~£2,000/month from email at low list size.
- **Decision rule + benchmark:** email ROI is strongly positive even at small list sizes;
  starting email early beats waiting for a "big enough" list.
- Verbatim lesson:
> "email ROI justifies investment even at small list sizes — don't delay email until list is "big enough""

### Single UGC Affiliate — seeding procedure + ROI heuristic (£15,000 revenue)
Executable seeding procedure:
1. **One seeded affiliate (Instagram DM → gifted product → tracked via UpPromote).**
2. Affiliate revenue generated: £15,000 brand revenue → £1,500 commission at 10%.
3. Organic referral expansion: affiliate's results attracted network referrals without
   additional seeding cost.
- **Heuristic:** ROI is not proportional to affiliate count — one quality affiliate compounds.
- Verbatim lesson:
> "one quality affiliate compounds; affiliate marketing ROI is not proportional to number of affiliates"

---

## OPERATIONS & SCALING

### Off-Season 3% CTR test — AI hook stack (hook quality vs. seasonal demand)
- Context: testing AI-generated hooks during product's off-season (UK market, wrong time of year).
- Result: achieved 3% CTR — highest CTR ever recorded for that account.
- Significance: validates Andromeda-avoidance B-roll refresh (Nano Banana + Kling 2.6) + AI
  hook generation stack.
- **Diagnostic rule:** you can validate hook resonance via CTR even off-season, because CTR
  (attention) is separable from purchases (suppressed by low seasonal intent).
- Verbatim lesson:
> "hook quality (CTR) is separable from seasonal demand (purchases) — can validate hook resonance off-season even when purchase intent is suppressed"

### UK 3PL — 10,000 units Black Friday (Q4 aggressive stocking with unit economics)
- Order: 10,000 units to UK 3PL.
- Fulfillment cost: £3.10/unit. Charged to customer: £4.95/unit.
- Sold out before Black Friday arrived.
- **Decision rule + data:** stock aggressively for Q4 *with documented unit economics* — here
  charging for shipping kept margin positive even at the highest-cost fulfillment period.
- Verbatim lesson:
> "stocking aggressively for Q4 with documented unit economics (charging for shipping) produced margin-positive outcome even at highest-cost fulfillment period"

### US China-to-US shipping acceptability (disclosed 8-day)
- Volume: 10,000–12,000 US units moved over one year.
- Shipping time: 8 days from China, clearly disclosed at checkout.
- Customer complaints: minimal.
- **Decision rule:** long shipping is acceptable when transparently disclosed; opacity, not
  the delay itself, is what causes complaints.
- Verbatim lesson:
> "disclosed 8-day shipping from China is acceptable to US customers when communicated transparently — opaque long shipping is the problem, not the delay itself"

### Comfort — $50M+/month operating model
Operating model + data (the full model, not just the delegation sequence):
- Revenue: $50M+/month.
- Creative volume: 10,000+ video creatives/week.
- Campaign structure: single CBO at $50K/day.
- Peak: $100K spend on a single Black Friday day.
- Team: $0 → $1M/month achievable with founder + one VA.
- Editor bonus: one editor produced a $13K/day winning ad → received $3,500 bonus.
- **Framework (operating model):** scale is driven by creative volume + a single-CBO structure
  run by a small team, with editors incentivized on winning outputs.
- Verbatim lesson:
> "scale does not require large teams — creative volume + single CBO structure is the operational model; incentivize editors on winning outputs"

---

## POSITIONING

### True Classic — 9-figure dual lever (the R2 case)
- New mechanism (proprietary fit/cut) + new avatar (men who want fitted basics without
  premium brand cost) simultaneously.
- Either axis alone resets sophistication to Stage 1; both axes = maximum reset + rapid scale.
- Verbatim lesson:
> "the most powerful positioning move is new mechanism + new avatar simultaneously — rare but produces 9-figure businesses when executed well"

### Stanley Cup — same product, new avatar (the R3 case)
- Identical product (insulated travel cup) — no product change.
- New avatar: women's hydration/wellness (different from original construction worker/outdoor market).
- Brand revival: near-dead brand became cultural phenomenon.
- Verbatim lesson:
> "avatar flip alone can reset market sophistication from Stage 4–5 to Stage 1 — product change unnecessary"

### Astronaut Projector — $10M year one (avatar specificity = perceived uniqueness)
- Avatar-only differentiation with no mechanism change.
- Existing product category (star projector) repositioned around a specific avatar (children's
  room ambiance) with specific use-case imagery.
- $10M revenue in year one from avatar clarity alone.
- **Decision rule (positioning, adjacent to R3):** specificity of avatar manufactures perceived
  uniqueness; the product need not differ if the avatar positioning is distinct enough.
- Verbatim lesson:
> "avatar specificity creates perceived uniqueness — the product doesn't need to be different if the avatar positioning is distinct enough"

### Edit-It-Yourself model outcomes (the R4 sequence)
- Scale: $0 → $1M/month achievable with founder + VA + editors only (no large team).
- Trained editor: produced $13K/day winning ad after completing structured training doc.
- Verbatim lesson:
> "self-editing skill → structured delegation brief → trained editor is the correct sequence; skipping to delegation without self-editing first = bad briefs = bad output"
