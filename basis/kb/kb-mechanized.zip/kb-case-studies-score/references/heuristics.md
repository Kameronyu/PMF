# Domain heuristics — decision rules drawn from the cases

These are not hard gates and not trigger-routes; they are decision rules the cases establish.
Use them as priors when diagnosing a CRO / email / operations / positioning situation. Each
points to its full case in `case-library.md`. Quotes are verbatim source substrings.

## CRO

- **Social proof at checkout ≠ redundant with PDP** (Hollow Socks, $50M+/yr): place proof at
  both; checkout is a different, higher-friction moment.
> "social proof placement at checkout is not redundant with PDP placement — it addresses a different, higher-friction moment"
- **Coupon as a margin-for-conversion lever** (RatVac): a $50 coupon cost 2% margin and lifted
  revenue/visitor 6×. Spending margin on conversion can outperform spending it elsewhere.
> "Offer change: $50 coupon introduced = 2% margin cost → 6× revenue per visitor lift"

## Email & retention

- **Don't under-send during peaks** (Black Friday 3-send): three sends over three days to an
  engaged segment; revenue tapers gradually (£9,569 → £5,600 → £3,772), so each marginal send
  is still strongly positive.
> "frequency during peak periods (3 sends across 3 days) is not over-sending — revenue diminishes gradually, not catastrophically"
- **Don't delay email for a "big enough" list** (early-stage benchmarks): ~$20/campaign design
  cost, £600–700/campaign, ~£2,000/month at low list size.
> "email ROI justifies investment even at small list sizes — don't delay email until list is "big enough""
- **Affiliate ROI is not proportional to affiliate count** (Single UGC Affiliate): one seeded
  affiliate (Instagram DM → gifted product → tracked via UpPromote) drove £15,000 revenue and
  attracted organic network referrals.
> "one quality affiliate compounds; affiliate marketing ROI is not proportional to number of affiliates"

## Operations & scaling

- **Disclosed long shipping is acceptable; opacity is the problem** (China-to-US 8-day,
  10,000–12,000 units/yr, minimal complaints).
> "disclosed 8-day shipping from China is acceptable to US customers when communicated transparently — opaque long shipping is the problem, not the delay itself"
- **Stock aggressively for Q4 with documented unit economics** (UK 3PL: £3.10/unit cost,
  £4.95/unit charged, sold out pre-Black-Friday).
> "stocking aggressively for Q4 with documented unit economics (charging for shipping) produced margin-positive outcome even at highest-cost fulfillment period"
- **Scale via creative volume + single CBO, not headcount** (Comfort $50M+/mo: 10,000+ creatives/
  week, single CBO at $50K/day; founder + one VA to $1M/mo; editor bonus on winners).
> "scale does not require large teams — creative volume + single CBO structure is the operational model; incentivize editors on winning outputs"
- **Hook quality is separable from seasonal demand** (off-season 3% CTR via AI hook stack):
  validate hook resonance on CTR even when purchases are suppressed by season.
> "hook quality (CTR) is separable from seasonal demand (purchases) — can validate hook resonance off-season even when purchase intent is suppressed"

## Product development & positioning

- **Desire-first** (Hexclad, $1B): the desire pre-exists; capture it with a mechanism that
  visibly proves the benefit.
> "the desire was always there (food sticking frustration is decades old) — Hexclad captured it with mechanism (the hex grid pattern = visual proof of non-stick)"
- **Avatar-first** (Ridge Wallet): build around a community's articulated frustration, not a
  product vision.
> "find a community that articulates a product frustration clearly → build around the articulation, not around a product vision"
- **Format change can unlock a new buyer** (Grüns gift-buyer): the gift-buyer (parent) became
  larger than the direct-user (child) market — distinct from a same-product avatar flip.
> "format change can unlock an entirely new sell vector (gift-buyer) that becomes larger than the direct user market"
- **Avatar specificity manufactures perceived uniqueness** (Astronaut Projector, $10M yr-one):
  the product need not differ if the avatar positioning is distinct enough.
> "avatar specificity creates perceived uniqueness — the product doesn't need to be different if the avatar positioning is distinct enough"
- **Right sophistication stage on entry** (Shilajit Stage 2): enter at the correct stage so
  creative resonates without education cost.
> "entering at the right sophistication stage (not over- or under-sophisticated) determines whether creative resonates without education cost"
