# ROUTE rules — selection / sequencing by named trigger

These are contracts, not verdicts: the named trigger SELECTS a move. They assign no PASS/FAIL
and dictate no wording. If the trigger is absent, the rule does not fire.

## R1 — Desire strength → viable channels / price points

| trigger observed | selected move |
|---|---|
| strong, time-bound, identity-stakes desire (e.g. lose 30 lbs before wedding) | paid ads + high ticket ($5K coaching, $3.5K meal service, ~$50 supplement) |
| weak desire (e.g. desk cable organizer) | organic TikTok only — cannot carry paid CAC |

Verbatim lesson:
> "desire strength determines which channels and price points are viable — not every product can support paid acquisition"

## R2 — Dual-lever positioning (max sophistication reset)

| trigger observed | selected move |
|---|---|
| want the maximum sophistication reset | new mechanism + new avatar simultaneously (either axis alone resets to Stage 1; both = max reset) |

Verbatim lesson:
> "the most powerful positioning move is new mechanism + new avatar simultaneously"

## R3 — Avatar-flip lever (saturated market, no product change)

| trigger observed | selected move |
|---|---|
| Stage 4–5 saturated market, no product change available | avatar flip alone to reset sophistication to Stage 1 |

Verbatim lesson:
> "avatar flip alone can reset market sophistication from Stage 4–5 to Stage 1 — product change unnecessary"

## R4 — Delegation sequence (scaling creative via editors)

| trigger observed | selected sequence |
|---|---|
| scaling creative through editors | self-edit → structured delegation brief → trained editor (skipping to delegation first = bad briefs) |

Verbatim lesson:
> "self-editing skill → structured delegation brief → trained editor is the correct sequence; skipping to delegation without self-editing first = bad briefs = bad output"

## R5 — New-avatar-from-comment (avatar discovery from an outlier signal)

| trigger observed | selected procedure |
|---|---|
| an outlier/validated comment naming a distinct pain (e.g. a bypass-recovery commenter) | contact → recorded call → transcribe → validate pain language → build dedicated creative for the new avatar |

Full procedure + the 5.5-ROAS result: see `case-library.md` (Quadruple-Bypass case).
Verbatim lesson:
> "one Facebook comment is enough to justify avatar research if validated — don't ignore outlier comments"

## R6 — Desire-spike / news-monitoring (external demand signal)

| trigger observed | selected move |
|---|---|
| a category news event spikes desire (e.g. Skate-Cut Gear, 36× MER overnight) | hold creative constant, scale spend into the spike — the same creative converts at the higher desire intensity |

Verbatim lesson:
> "desire can spike overnight due to external events — monitoring news for demand signals in your category is a legitimate strategy; same creative at different desire intensity = radically different results"

## R7 — Mechanism discovery (structured AI prompt + review mining)

| trigger observed | selected move |
|---|---|
| need to find a differentiating mechanism | run the structured AI mechanism prompt (inputs: product name + URL + sophistication PDF), and mine competitor reviews for named ingredients/claims |

Inputs + the two validation tests (humidifier, dog harness) + Norse Organics review-mining:
see `case-library.md`. Verbatim lessons:
> "structured AI prompt (not generic ChatGPT question) can identify mechanisms humans miss — prompt structure matters more than model"
> "review mining for competitor-mentioned ingredients reveals what the market believes works (speed-as-mechanism opportunity)"

## Note on R2 vs. R3

Both reset sophistication, but they fire on different triggers: R2 when both axes are
available and you want maximum reset; R3 when no product change is possible and the avatar
flip alone must carry it. Selecting R3's single lever when both were available is under-using
the reset, not an error to FAIL — it is a ROUTE choice.
