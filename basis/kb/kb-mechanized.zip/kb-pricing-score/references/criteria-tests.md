# Per-field membership tests + the COUNTABLE gate definitions

Each judged field gets a positive target and a test that can return FALSE. COUNTABLE
fields lower to a deterministic script gate; the one FELT field is a pairwise-vs-specimen
signal (`prefer | tie | weaker`), never a hard FALSE, never self-graded.

Anchor terms (do NOT redefine — see `definitions.md`): **value models** (pricing + discount
are its levers), **trust signals** (premium price as a quality signal), **angle** (the frame
that "frames value, not cost"). Pricing here is the value-models pricing+discount lever.

---

## G1 — Price-multiple target (COUNTABLE → hard-gate)

- *Positive target:* the plan sets its premium price target at **2–3x the competitor
  baseline** (i.e. multiple ≥ 2.0), justified by brand equity, not cost reduction.
- `stated_multiple = the numeric "Nx baseline" the plan declares` (FAIL if none stated).
- `in_band = stated_multiple >= 2.0`
- PASS iff `stated_multiple is present AND in_band`.
- FALSE example: a plan whose target is "1.1x baseline / 10% above" → below band → FAIL.
- Evidence: `"2–3x competitor baseline pricing"`.

## G2 — Undercut-free (COUNTABLE → hard-gate)

- *Positive target:* the plan does NOT compete by undercutting scaled retail on price.
- `undercuts = the plan's strategy is to price BELOW competitor baseline to win on price
  (e.g. "undercut by 10–20%", "be cheapest", "beat Walmart/Amazon on price")`.
- PASS iff `NOT undercuts`.
- FALSE example: "undercut competitors by 10–20% to win volume" → `undercuts` true → FAIL.
- Evidence: `"Undercutting by 10–20% = losing strategy against scaled retailers"`.
- *Gate rationale (the WHY):* `"Price is a signal of quality; lower prices attract lower-quality buyers and erode perceived value"`. Undercutting is not just a margin trade — lowering price attracts lower-quality buyers AND erodes the perceived-value asset the premium depends on. See `references/frameworks.md` → "Decision rule — price as a signal of quality".

## G3 — Free of the four named pitfalls (COUNTABLE → enum-membership hard-gate)

- *Positive target:* the plan contains NONE of the four named pricing pitfalls.
- `pitfalls (closed enum)` — flag membership if the plan contains any of:
  1. `price-undercut-competition` — competing on price against scaled retail.
  2. `pixel-seasoning-discount` — temporary price reductions to warm up ad algorithms.
  3. `price-as-traffic-tool` — treating price as a traffic-acquisition tool, not a brand signal.
  4. `launch-low-raise-later` — launching at a discount with plans to raise prices later.
- PASS iff the matched-pitfalls set is empty.
- FALSE example: "drop price at launch to train the Facebook pixel, raise it in week 3"
  → matches `pixel-seasoning-discount` + `launch-low-raise-later` → FAIL.
- Evidence: `"Treating price as a traffic acquisition tool rather than a brand signal"`.

**Why `pixel-seasoning-discount` is gated (the two compounding failure mechanisms):**
Lowering prices temporarily to generate conversions and train ad-platform algorithms (with
intent to raise later) creates two compounding problems —
1. **Conversion rate instability** — `"when prices return to normal, CVR drops because the algorithm was trained on a price-sensitive audience segment"`. The pixel optimized to a price-sensitive segment; normalized prices no longer convert that audience.
2. **Margin destruction during the discount window** — `"the period of low pricing damages profitability and may attract customers who will not repurchase at full price"`.
These two mechanisms are the justification for the gate: the tactic both poisons targeting
and burns margin, with no guaranteed CVR recovery. Positive instead: launch at the intended
premium and build CVR at that price from day one.

## F1 — Positioning conviction (FELT — signal, NEVER a hard gate)

- *Positive target:* the premium is justified by manufactured brand value, not by the product.
- Do **not** write a yes/no gate. Judge the plan's positioning rationale **pairwise against
  a premium-band specimen** in `references/scoring-specimens.md`: does this plan justify the
  premium by brand equity at least as strongly as the specimen? Return `prefer | tie | weaker`.
- `weaker` contributes no pass; it never manufactures a FAIL on its own.

---

## ROUTE rules (contract — named-trigger selection / sequencing)

**R1 — Pricing-strategy selection.** Trigger: the operator is an independent brand owner /
dropshipper who cannot out-scale Walmart/Amazon. Select the **brand-premium** strategy
(price at 2–3x baseline, justified by brand equity). Do NOT select cost-based undercutting.
Evidence: `"building brand perception that justifies 2–3x competitor pricing through superior marketing, positioning, and perceived value"`.

**R2 — Launch-price sequencing.** Trigger: a launch / ad-warm-up pricing decision. Do NOT
discount at launch to train the pixel with intent to raise later. Instead launch at the
intended premium from day one.
Evidence: `"launch at the intended premium price point and build conversion rate at that price from day one."`

## Why the tiers
A number is or isn't ≥2x; an enum pitfall is or isn't present — those are reproducible and
safe to hard-gate. Positioning conviction is felt; hard-gating it produces confident-but-wrong
FALSEs, so it stays a pairwise-vs-specimen signal.
