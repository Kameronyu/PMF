# Scoring specimens — the verbatim source lines to judge pricing plans against

Every quote below is a verbatim substring of `pricing--mark-builds-brands.md`
(Mark Builds Brands). Judge the FELT criterion (positioning conviction) **pairwise
against these**, never on an absolute scale, and never by the agent that wrote the plan.

## Premium-band reference (judge the price-multiple target against this)

- "2–3x competitor baseline pricing"
- "building brand perception that justifies 2–3x competitor pricing through superior marketing, positioning, and perceived value"
- "Price premium is not inherent to the product — it is manufactured through marketing, brand presentation, and positioning."

The premium plan sets its target in this band and justifies it with brand equity, not
cost reduction. A plan that names a multiple **below** this band, or that competes by
undercutting, is weaker than these on the felt positioning-conviction signal.

## Losing-strategy reference (the undercut anti-pattern, stated by source)

- "Undercutting by 10–20% = losing strategy against scaled retailers"
- "Competing on price against Walmart-scale operations — structurally unwinnable"

## Launch-sequencing reference (the day-one premium pattern)

- "launch at the intended premium price point and build conversion rate at that price from day one."

## Execution-levers reference (the HOW the premium is manufactured)

Judge a plan's positioning conviction (F1) against these — a strong plan justifies its
2–3x premium by naming the levers that manufacture brand value, not by the product alone.

- "Brand visual identity and packaging that signals quality"
- "Marketing copy and creative that frames value, not cost"
- "Customer experience (unboxing, post-purchase) that justifies the price in hindsight"
- "Social proof and community that validates the premium"

A plan that asserts a premium with NONE of these levers is `weaker` than this specimen on
the felt signal. Full framework: `references/frameworks.md`.

## Price-as-quality-signal reference (the decision rule)

- "Price is a signal of quality; lower prices attract lower-quality buyers and erode perceived value"

## Pixel-seasoning reference (the named tactical mistake)

- "Treating price as a traffic acquisition tool rather than a brand signal"
- "Launching at a discount with plans to raise prices later — audiences acquired at discount price points do not convert at premium prices at the same rate"

The two compounding failure mechanisms (the WHY the gate exists):

- "when prices return to normal, CVR drops because the algorithm was trained on a price-sensitive audience segment"
- "the period of low pricing damages profitability and may attract customers who will not repurchase at full price"

## How to run the pairwise judge (for the FELT signal only)

1. Present the candidate plan's positioning rationale + one premium-band specimen, order randomized.
2. Ask which better justifies the premium by brand equity rather than cost (criteria before verdict).
3. Record `prefer | tie | weaker` + the reason. `weaker` contributes no pass.
4. Never let the agent that produced the plan be the judge.
