# Pricing frameworks — the HOW behind a premium price (Source: Mark Builds Brands)

The score skill grades *whether* a plan justifies its premium by manufactured brand value
(F1 positioning conviction). This file holds the **execution levers** that actually produce
that value — the four-item HOW a plan should be reaching for. Use it two ways:
(1) as a checklist for what a strong positioning rationale will reference; (2) as the
concrete material the F1 pairwise-vs-specimen judge can test a plan against.

These are levers, NOT gates. Do not hard-fail a plan for omitting one — they inform the
FELT signal only.

---

## Execution levers for premium pricing (the four-item HOW)

> Price premium is not inherent to the product — it is manufactured through marketing,
> brand presentation, and positioning. The same product at 2–3x the price of a generic
> competitor is viable if the brand signals superior quality, trust, and identity to the
> target customer.

**Execution levers for premium pricing:**
- Brand visual identity and packaging that signals quality
- Marketing copy and creative that frames value, not cost
- Customer experience (unboxing, post-purchase) that justifies the price in hindsight
- Social proof and community that validates the premium

Each lever maps to *why a customer accepts the 2–3x multiple*:
- **Visual identity / packaging** — the quality signal at first contact.
- **Copy / creative framing value not cost** — the angle that reframes price as value.
- **Customer experience (unboxing, post-purchase)** — justifies the price *in hindsight*,
  protecting against buyer's remorse and seeding repurchase.
- **Social proof / community** — third-party validation that the premium is warranted.

A plan that claims a 2–3x multiple but names none of these levers is justifying the premium
by the product alone — exactly the weak case F1 is meant to catch.

---

## Decision rule — price as a signal of quality

> Price is a signal of quality; lower prices attract lower-quality buyers and erode
> perceived value

Actionable causal chain (the WHY behind preferring premium over undercutting):
- Price is read by the market as a **signal of quality**.
- **Lowering price** therefore (a) attracts **lower-quality buyers** and (b) **erodes
  perceived value** — a compounding loss, not just a margin trade.
- This is why undercutting (G2) and discount-to-acquire tactics (G3) are losing moves even
  when they appear to "work" short-term: they degrade the asset (perceived value) that the
  premium price depends on.

Use as gate rationale for G2 (undercut-free) and as supporting reasoning for the F1 signal.
