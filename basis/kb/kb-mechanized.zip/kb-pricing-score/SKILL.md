---
name: kb-pricing-score
description: >-
  Score a pricing plan for brand-premium viability before committing to it. Use to grade a
  proposed pricing strategy (written by a human, another skill, or any source) and return
  REJECT / VIABLE / PREMIUM-READY with per-field evidence. Hard-gates only the countable
  (price-multiple target, undercut-free, four named pitfalls); treats positioning conviction
  as a pairwise-against-specimen signal, never self-graded pass/fail. Houses the pricing-strategy
  ROUTE rules (which strategy to select, how to sequence launch price). Run as a SEPARATE pass
  from whoever wrote the plan. Triggers: "score this pricing", "is this price point viable",
  "should we undercut or go premium", "review my launch pricing".
---

# Pricing — score brand-premium viability before you commit

Grade a pricing plan against the gates below, then band it. **Do not run this in the pass
that wrote the plan** — a producer grading itself rates its own output higher. Judge the one
felt field against the source specimens in `references/scoring-specimens.md`.

Tier discipline: **hard-gate only the countable** (price multiple, undercut, named pitfalls);
**the felt field is a pairwise-vs-specimen signal — never a hard FALSE.** Pricing is the
**value models** pricing+discount lever; premium price doubles as a **trust signal**. Do not
redefine anchor terms — see `definitions.md`.

## The fields (each: positive target → how it's judged → tier)

1. **G1 Price-multiple target** — *target:* premium price set at **2–3x competitor baseline**
   (multiple ≥ 2.0), justified by brand equity not cost. *Judge:* **script gate** — a multiple
   is stated AND ≥ 2.0. Tier: COUNTABLE → hard-gate.
2. **G2 Undercut-free** — *target:* the plan does NOT win by pricing below baseline against
   scaled retail. *Judge:* **script gate** — strategy is not "undercut / be cheapest". Tier:
   COUNTABLE → hard-gate.
3. **G3 Pitfall-free** — *target:* none of the four named pitfalls present. *Judge:* **script
   gate / enum membership** — the matched-pitfalls set is empty (enum:
   price-undercut-competition | pixel-seasoning-discount | price-as-traffic-tool |
   launch-low-raise-later). Tier: COUNTABLE → hard-gate.
4. **F1 Positioning conviction** — *target:* the premium is justified by manufactured brand
   value, not the product. *Judge:* FELT — rate pairwise against a premium-band specimen;
   return `prefer | tie | weaker`. Tier: FELT (signal; never a hard FALSE, never self-graded).
   The four execution levers that manufacture that value (the HOW) are in `references/frameworks.md`.

Membership tests and the COUNTABLE gate definitions live in `references/criteria-tests.md`;
the premium-pricing execution levers + the price-as-quality decision rule are in `references/frameworks.md`.

## Bands (derive from gates that actually passed — not a hollow count)

- **Any hard-gate (G1/G2/G3) FAILS → REJECT** (rewrite before any spend).
- **All hard-gates pass, F1 = `weaker` → VIABLE** (premium plausible; positioning thin).
- **All hard-gates pass, F1 = `prefer` or `tie` → PREMIUM-READY** (launch at premium from day one).

F1 contributes only when the pairwise judge does not return `weaker`; it never manufactures a
pass or a fail on its own. The band comes from the hard-gate results plus the F1 signal, never
from a raw tally.

## ROUTE rules (contract — named-trigger selection / sequencing)

- **R1 Pricing-strategy selection.** Trigger: operator is an independent brand owner / dropshipper
  who cannot out-scale Walmart/Amazon → select **brand-premium** (2–3x baseline, justified by
  brand equity). Do NOT select cost-based undercutting.
- **R2 Launch-price sequencing.** Trigger: a launch / ad-warm-up pricing decision → launch at the
  intended premium from day one; do NOT discount to train the pixel with intent to raise later.

Both rules' trigger phrasing and evidence are in `references/criteria-tests.md`.

## The negatives live here (≤5), each paired with a positive target

Moved out of any writer (where naming the trap summons it). Each is a checker rule:

- **Undercutting scaled retail** → fail G2. (positive: price at 2–3x baseline on brand equity)
- **Pixel-seasoning discount** (temporary price drop to warm up ad algorithms) → fail G3. (positive: launch at premium, build CVR at that price)
- **Price as a traffic-acquisition tool** → fail G3. (positive: price as a brand signal)
- **Launch low, raise later** → fail G3. (positive: intended premium from day one)
- **Multiple stated below 2x** → fail G1. (positive: a multiple in the 2–3x band)

## Output contract (per plan)

```
plan: "<verbatim or summarized plan under test>"
fields: [ {id, target, verdict: pass|fail|signal, tier, evidence_quote, source} ]
countable_gates: {G1_price_multiple, G2_undercut_free, G3_pitfall_free}  # script results, pass/fail
matched_pitfalls: [ <subset of the G3 enum> ]                            # empty iff G3 passes
felt_signal: {F1_positioning: prefer|tie|weaker}                         # pairwise-vs-specimen
band: REJECT | VIABLE | PREMIUM-READY
route: {R1_strategy, R2_launch_sequence}                                 # selected per trigger
flags: [ ... ]    # from the negatives list
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** G1/G2/G3 each have a verdict; F1 has a signal; band present.
**SOUNDNESS:** every COUNTABLE verdict came from the script, not eyeballed (G1 numeric, G2/G3
enum); F1 is pairwise-vs-specimen, not self-graded; band derived only from passed hard-gates +
the F1 signal; every `pass`/`fail` carries an `evidence_quote` that is a verbatim substring of
the plan or source. `emit_ready` only if SOUNDNESS holds; else `BLOCKED:<field>`.

## Self-test (is this grader sound?) — any NO, fix

- Are only G1/G2/G3 hard-gated (by script), with F1 a pairwise-vs-specimen signal?
- Is the felt judgment run separately from the writer, against a real source specimen?
- Does the band come from passed hard-gates + the F1 signal, not a raw count?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Are R1/R2 kept as ROUTE rules (named-trigger selection/sequencing)?
- Is every quoted specimen a verbatim substring of a source file (no composites)?
