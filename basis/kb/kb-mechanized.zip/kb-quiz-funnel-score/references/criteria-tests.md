# Per-field membership tests + the COUNTABLE gate definitions

Each judged field below has a positive target and a yes/no membership test that can return
FALSE. COUNTABLE gates lower to a deterministic script check. HEURISTIC gates are soft-caps
(warn, never hard-fail). FELT fields are pairwise-vs-specimen signals — see
`scoring-specimens.md` — and never produce a hard FALSE.

---

## COUNTABLE gates (hard-gate — a script decides; reproducible)

**G1 Question-role membership** (source mbb)
- Positive target: every question maps to exactly one of the closed enum
  `{micro-commitment, objection-pre-handling, belief-seeding}`.
- Test (per question, all YES to pass): Is the question's assigned role one of the three enum
  values? Is the role echoed verbatim from the enum? Does the question exist for that role
  rather than purely for data collection?
- FALSE example: a question tagged `data-collection` or with no role → FAIL that question.
- Gate: any question failing → field FALSE.

**G2 Consecutive-format bound** (source mbb)
- Positive target: no run of more than 3 consecutive questions in the same format.
- Test: `max_consecutive_same_format <= 3`. (Source rule: "Never run more than 2-3
  consecutive questions in the same format.") ≥4 in a row → FALSE.

**G3 Question-count band** (source mbb)
- Positive target: total question count within 3–20; sweet spot 8–12.
- Test: `3 <= count <= 20` to PASS; outside → FALSE. If PASS but outside 8–12, attach a
  warn flag `outside-sweet-spot` (still passes).

**G4 Completion-rate KPI set** (source mbb)
- Positive target: a completion-rate KPI is stated and is `>= 30%` (30% of starters reach the
  sales page).
- Test: a numeric completion-rate target is present AND `>= 30`. Absent or `< 30` → FALSE.

**G5 Email captured before reveal** (source mbb)
- Positive target: name + email collected at quiz end, positioned before the results reveal.
- Test (all YES): is email collection present? is name present? is the capture positioned
  before the results-reveal step? Any NO → FALSE.

**G6 Four foundational docs precede AI generation** (source mbb)
- Positive target: all four docs exist before AI question-generation: closed enum
  `{offer, avatar, research, beliefs}`.
- Test: all four enum members present AND each precedes the AI-prompting step. Missing any, or
  AI step ordered first → FALSE.

**G7 Email-sequence length band** (source mbb)
- Positive target: post-quiz email sequence length within 5–7.
- Test: `5 <= email_count <= 7`. Outside → FALSE.

---

## HEURISTIC soft-cap (warn, never hard-fail — detectors over-flag)

**H1 Dopamine-format presence** (source mbb)
- Positive target: interactive/dopamine formats present (sliders, image selects); not a
  plain text-button-only quiz.
- Test: at least one question uses an interactive format. Count plain-text-button-only
  questions; if the whole quiz is text-button-only, emit warn `text-button-only`. Never a
  hard FALSE — format labels carry real false-positive risk.

---

## FELT fields (pairwise-vs-specimen — `prefer | tie | weaker`, never hard FALSE)

**F1 Diagnosis-slide naming** — does the candidate name a specific stage + cause aggregated
from the prospect's own answers, at least as well as the named-diagnosis specimen?

**F2 Micro-commitment escalation** — do the yes-street questions read as answerable-"yes"
consistency-bias prompts escalating emotional → practical, at least as well as the specimens?

**F3 Projection / finality framing** — does the projection/finality copy make a multi-month
supply feel necessary (not expensive), at least as well as the projection specimens?

**F4 Result-page framing** — does the above-the-fold copy frame the page as the delivery of
an individualized result rather than a product listing, at least as well as the headline
specimens?

Judge each against `scoring-specimens.md` on a different model from the writer. `weaker`
contributes no pass; it is a triage signal, not a hard FALSE.

---

## Why the tiers
Hard-gating a felt field produces confident-but-wrong FALSEs and pushes builders toward
gaming the gate. Hard-gating a countable one (a count is what it is; a number is or isn't
≥30) is reproducible and safe. Soft-cap the in-between (format-detection) because the
detector over-flags.
