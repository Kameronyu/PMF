# ROUTE contract — named-trigger selection & sequencing the scorer checks against

These are structural contracts (which element, in which order, fired by which named trigger).
The scorer references them as presence/ordering checks; they dictate no wording. Anti-pitfall
duals of these rules are the FALSE-capable presence checks in the score contract.

## Funnel sequence contracts (source: Carl Weische)
- **5-question pain-diagnostic opening, ordered by function**: Q1 Visual Identifier → Q2 Pain
  Location → Q3 Pain Specification → Q4 Pain Severity → Q5 Pain Timeline; all five answers
  feed forward to the diagnosis slide + sales-page personalization.
- **Problem→solution pivot, then social proof**: the pivot question surfaces the desired
  outcome FIRST; the first social-proof slide fires immediately AFTER, tied to that stated
  outcome (named trigger: proof fires only once the desired situation is stated).
- **Individualization → sales-page echo**: collect product-relevant attributes, then echo
  them on the sales page for continuity.
- **Objection surface → in-funnel handle**: a behavioral question surfaces an objection; an
  info card neutralizes it before the product page.
- **Causation education before diagnosis**: genetic + lifestyle root-cause questions precede
  the named diagnosis slide.

## Sales-page contracts (source: Carl Weische)
- **Above-the-fold order**: result-framing language → quiz answers shown → bundle-and-save
  leads → social proof + benefits → urgency element.
- **Bundle default-state**: best-value bundle pre-selected + center; subscribe/save
  pre-selected; six-month supply framed as the duration required to hit the promised
  transformation.

## Design / ops contracts (source: Mark Builds Brands)
- **Gradualization ordering**: start non-invasive/easy → escalate to personal/sensitive.
- **Intraquiz cards placement**: insert non-question screens between questions to seed
  beliefs / pre-handle objections mid-flow.
- **Drop-off triage**: launch minimal-friction → track per-question drop-off → spike question
  gets revised/removed → add qualifying friction progressively, data-driven.
- **Email branching**: branch the post-quiz sequence by specific answer combinations; each
  branch a tailored sequence.

## Anti-pitfall presence checks (the FALSE-capable duals — drive the score-contract negatives)
- Entry is a quiz, not cold traffic sent direct to a product page.
- Quiz data is carried through to the sales page (continuity not broken).
- Recommended bundle + subscribe are pre-selected at load.
- Social proof fires only after the desired situation is stated (not too early).
- Objection is handled in-funnel, not only on the product page.
- Transformation-plan framing is present (so six-month supply reads necessary, not expensive).
- Formats vary; first questions are non-invasive; no data-only questions; the four docs are
  not skipped; qualifying friction not added before completion data exists.
- **Optimization target is emotional priming, not personalization/product-matching.** Source
  pitfall: "Attributing quiz funnel performance to personalization/product-matching rather
  than optimizing for emotional priming — leads to wrong optimization priorities." If the
  funnel/spec's stated optimization rationale treats personalization or product-matching as the
  primary lever (rather than priming), flag it — this is the one pitfall that changes WHAT the
  builder optimizes for. Caps band at VIABLE.
