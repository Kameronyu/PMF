# Scoring specimens — known-good quiz-funnel copy to judge FELT criteria against

Felt fields (diagnosis-naming, micro-commitment escalation, projection/finality framing,
result-page framing) are scored **pairwise against these verbatim specimens**, never on an
absolute 1–10 and never by the model that wrote the candidate. Randomize presentation order;
treat any single judgment as a triage signal, not a certification. Return `prefer | tie | weaker`.

All quotes below are verbatim from the two source files. The pairwise judge asks: does the
candidate satisfy the named criterion at least as well as the specimen? `weaker` contributes
no pass for that field.

## Objection info-card (judge in-funnel objection copy against this)
- "A busy schedule doesn't have to stop you from looking and feeling years younger."

## Named-diagnosis result (judge the diagnosis-slide naming against this)
- "Stage 2 Hair Loss — caused by genetic predisposition and high stress levels"
- The named diagnosis aggregates the prospect's own prior answers into a specific stage + cause.

## Six-month projection + finality framing (judge transformation-plan copy against these)
- "Based on your answers, we expect you to see visible results by [future month]."
- "the last plan you'll ever need"

## Yes-street micro-commitments (judge consistency-bias questions against these)
- "Are you determined to finally stop your hair loss?"
- "Does a simple hair care routine sound good?"
- Escalates emotional commitment → practical commitment; each is answerable "yes".

## Loading-screen micro-copy (judge tension-building screen against this)
- "Analyzing your profile…"

## Result-framing sales-page headlines (judge above-the-fold framing against these)
- "Hair profile matched"
- "Here's your growth plan"
- "X people are looking at this right now"
- "recommended based on your quiz results"
- Frames the page as the delivery of an individualized medical-style result, not a product listing.

## How to run the pairwise judge
1. Present candidate + one specimen, order randomized.
2. Ask which better satisfies the named criterion and why (criteria before verdict).
3. Record `prefer | tie | weaker` + the reason. `weaker` contributes no pass.
4. Never let the model that generated the candidate be the judge.
