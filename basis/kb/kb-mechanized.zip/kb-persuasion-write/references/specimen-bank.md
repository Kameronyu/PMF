# Specimen bank — verbatim persuasion fragments, with WHY each works

Preserved verbatim from `persuasion--carl-weische.md` (CW) and
`persuasion--mark-builds-brands.md` (MBB). These are the highest-value asset in the skill
— study and adapt, do NOT abstract into ordered slot templates. Each shows the *form* of a
winning line; that is what steers a model.

> **Concept-heavy source.** The winning fragments are short and load-bearing. There are no
> full long-form persuasion passages in the source — do not invent them. **[BELOW SPECIMEN
> FLOOR for sustained copy: a human should add ≥3 longer real passages when available.]**

## Certainty / risk-reversal (answers "what if it doesn't work for me?")

- "30-day no-questions-asked refund"
  — WHY: a concrete window (the 30-day part) + explicit risk removal (the
  no-questions-asked part). The number makes it falsifiable; the phrase removes the doubt
  the skeptic would otherwise supply. A generic money-back guarantee leaves the doubt
  intact — this closes it.

## Scarcity (credible, oddly-specific count — answers "I'll think about it")

- "Only 47 units left at this price,"
  — WHY (round-number contrast): 47 reads as pulled from real inventory, unlike a
  round-and-fake only-a-few-left line. Specificity is the credibility. Loss aversion does
  the work only if the number is believable; an implausible count tips into the
  manipulation a cold buyer is braced for.

## Authority (borrowed-credibility shorthand — answers "I don't know this brand")

- media logos ("as seen in")
  — WHY: three words move third-party credibility into the headline region with no claim
  the reader must take on faith — the logo carries it. Short-circuits the trust timeline a
  cold audience demands.

## Objection voiced in the buyer's words, then countered (CW objection handling)

The buyer says it; you answer with the mapped element. Voicing the doubt earns the answer.

- Time — "Will this take too long?" → counter: speed claims, ease-of-use proof.
- Effort — "Is this too complicated?" → counter: simplicity framing, done-for-you angles.
- Results — "Will it actually work for me?" → counter: guarantees, before/after proof,
  specificity of claims.
  — WHY: each counter is mapped to one named objection, not placed decoratively. The
  buyer-voice phrasing self-selects the exact doubt to neutralize.

## Buyer-voice objection lines (the doubt a cold reader actually feels)

From the CW objection→element table. Use these as the doubt your copy speaks aloud:

- "I don't know this brand"
- "What if it doesn't work for me?"
- "I'll think about it"
- "Anyone can buy this"
  — WHY: stating the objection in the buyer's own voice before answering it makes the
  answer land; the reader feels heard rather than sold to.

## Ethical bright line (the boundary your copy stays inside)

- Persuasion that helps → ethical. Persuasion that exploits → unethical and long-term
  brand-destructive.
  — WHY: keeps scarcity and urgency honest. Trust compounds over time; manufactured
  pressure converts once and then destroys the relationship. Write to the help side.

## Named worked examples — real offer stacks (CW)

These are the source's named exemplars. Study the element combination each shipped; the Nusk
stack is the explicitly validated baseline for cold-offer conversion.

- **Nusk stack (validated baseline):**
  - "Nusk offer: incorporated guarantees (certainty) + social proof + urgency as core conversion stack."
  - "Stacking social proof + guarantee + urgency (the Nusk stack) is a validated baseline for cold offer conversion"
  — WHY: three elements, each neutralizing a different objection — social proof ("I don't
  know this brand"), guarantee ("what if it doesn't work for me?"), urgency ("I'll think
  about it"). This is the reference floor: stack at least these three on a cold offer.

- **Cogut Beauty (objection-mapped framework):**
  - "Cogut Beauty offer: social proof + guarantees + multi-objection handling (time, effort, results) layered throughout funnel."
  — WHY: demonstrates that persuasion elements must address specific anticipated objections
  (time, effort, results), not just be generically present, and must be layered throughout
  the funnel rather than placed once.
