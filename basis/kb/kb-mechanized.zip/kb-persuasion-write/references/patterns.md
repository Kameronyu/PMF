# Optional patterns — anatomy + a real example each

Reach for one when it fits the objection you are answering. None is a required slot order.
Use these to vary, not to standardize — forced fixed sequences produce same-y, low-pull copy.

## Risk-Reversal Guarantee (answers "what if it doesn't work for me?")
[concrete time window] + [explicit no-friction risk removal]. Lead it as a feature; repeat
it at the moment of action, not buried in fine print.
- Example: "30-day no-questions-asked refund"
- Why it works: the number makes the promise falsifiable; the phrase removes the doubt the
  skeptic would otherwise supply.

## Credible-Scarcity Line (answers "I'll think about it")
[oddly-specific real count] + [the constraint reason]. Must be credible and real — an
implausible or round number reads as the manipulation the buyer is braced for.
- Example: "Only 47 units left at this price,"
- Why it works: specificity is the credibility; loss aversion only fires on a believable
  number.

## Authority-Shorthand (answers "I don't know this brand")
[borrowed third-party credibility marker] placed in the headline region. Show the proof;
let it carry the claim. A bare "we're experts" backfires with a skeptic.
- Example: media logos ("as seen in")
- Why it works: transfers credibility without a claim the reader must take on faith.

## Objection-Voiced Counter (the core move for cold copy)
[buyer's doubt in their own words] → [the element mapped to exactly that doubt].
- Example: "Will it actually work for me?" → guarantees, before/after proof, specificity.
- Why it works: voicing the doubt earns the right to answer it; the answer is mapped, not
  decorative. This is the difference between persuasion that converts and persuasion
  decoratively placed on a page.

## Element execution menus (the concrete tactics for each element)

Each element below names its objection and its implementation menu — the actual mechanics
to draft the line. Social-proof, certainty, authority, and scarcity already have specimens
above; urgency and exclusivity carry no specimen, so their menu is what you draft from.

### Urgency (answers "I'll think about it" — time-based pressure)
Time constraints drive immediate action and prevent decision paralysis. Cold traffic without
urgency defers the purchase indefinitely ("I'll come back later" = never).
- Implementation menu: **countdown timers, flash sale windows, price-increase deadlines, or
  limited-time bonuses.**
- Urgency operates on time; scarcity operates on quantity — both can be layered simultaneously.
- Honest only: apply urgency with a legitimate reason — "sale ends soon" with no explanation
  reads as manipulation. A reset/recycling timer is fatal.

### Exclusivity (answers "Anyone can buy this" — perceived privilege)
Password access, referral requirements, or invite-only framing makes offers feel special and
desirable. Exclusivity converts commodity products into perceived privileges.
- Implementation menu: **waitlists, member-only pricing, referral-unlock mechanics, or
  limited enrollment language.**

### Scarcity (answers "I'll think about it" — quantity-based loss aversion)
Limited quantity framing creates urgency through loss aversion. Must be credible and real to
avoid eroding trust.
- Implementation menu: **"Only 47 units left at this price," batch releases, or
  production-limited runs.**

### Social Proof (answers "I don't know this brand")
- Implementation menu: **embed review counts, star ratings, before/after results, and named
  testimonials directly into ad creative and landing pages.**

### Authority (answers "I don't know this brand")
- Implementation menu: **feature expert endorsements, credentials, media logos ("as seen
  in"), or practitioner recommendations in headlines and opening copy.**

### Certainty / risk reversal (answers "what if it doesn't work for me?")
Source (CW): "Money-back guarantees and try-before-you-buy options reduce perceived purchase
risk." Both are valid Certainty implementations — reach for either.
- Implementation menu: **make the guarantee prominent, specific (e.g., "30-day
  no-questions-asked refund"), and repeat it at checkout; or a try-before-you-buy option
  that lets the buyer experience the product before committing money.**

### Reciprocity (give first — top-of-funnel obligation)
The MBB source names social proof and reciprocity as "the highest-leverage laws in online
selling." Reciprocity: humans are hardwired to return favors — when you give first, the
recipient feels obligated to give back. Lead with value before asking for the purchase.
- Implementation menu: **free content (blogs, videos, lead magnets, tools) that creates
  obligation at scale — the more specific and valuable the free asset, the stronger the
  felt reciprocity.**
- Sequence note: reciprocity is the "give first" step in the Cialdini sequence
  (see `routing.md`); skipping it — asking for purchase before delivering value — reduces
  compliance.
