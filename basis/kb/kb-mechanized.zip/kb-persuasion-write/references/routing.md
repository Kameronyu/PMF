# Routing — which element answers which objection (contract; no wording, no verdict)

These rules pick the *element*, not the *words*. They dictate no copy and grade nothing.

## Objection → element selection (CW)

| Buyer objection | Element that neutralizes it |
|---|---|
| "I don't know this brand" | Authority + Social Proof |
| "What if it doesn't work for me?" | Certainty (guarantee) |
| "I'll think about it" | Urgency + Scarcity |
| "Anyone can buy this" | Exclusivity |

## Universal cold-traffic objections → counter (CW)

| Objection (buyer voice) | Counter to deploy |
|---|---|
| Time — "Will this take too long?" | speed claims, ease-of-use proof |
| Effort — "Is this too complicated?" | simplicity framing, done-for-you angles |
| Results — "Will it actually work for me?" | guarantees, before/after proof, specificity of claims |

## Stack priority for cold offers (CW)

1. Social Proof + Certainty first — establish trust and remove risk.
2. Urgency / Scarcity to close — the action triggers, deployed last.
3. Authority amplifies all other elements when present.

Cold audiences have zero prior trust — elements must compensate for the absent brand
relationship. Map elements to specific objections explicitly in copy; do not place them
decoratively.

## Cialdini sequencing (MBB — when building a full sequence)

1. Establish liking and similarity before presenting any offer.
2. Demonstrate authority via credentials, case studies, or third-party validation.
3. Deploy social proof matched to the target audience's identity.
4. Give first (reciprocity trigger) — free value, insight, or tool.
5. Secure micro-commitment — a small agreement that creates consistency pressure.
6. Introduce scarcity only when genuine; never manufacture false deadlines.
7. Make the ask — it lands after all six laws have been primed.

Laws compound when sequenced; isolated tactics (e.g. scarcity alone) underperform.

## Channel selection (MBB — digital / e-commerce)

- Online, social proof + reciprocity are the highest-leverage laws — trust signals must
  substitute for in-person relationship-building.
- Prefer video testimonials over text when credibility cues matter (real person, real
  voice raise perceived authenticity).
- Authority online proxies via media mentions, certifications, and demonstrated expertise.

## Ethical knowledge application framework (MBB — dual-use meta-framework)

Persuasion knowledge is dual-use: it can protect or exploit. This meta-framework governs how
to deploy psychological knowledge responsibly. The source names the DEFENSIVE side as the
highest-priority use.

- **Defensive Application (Primary Use):** Knowledge of persuasion laws allows recognition of
  manipulation attempts directed at you — by advertisers, salespeople, politicians, and bad
  actors. This is the highest-priority use of the knowledge. Recognizing reciprocity traps,
  false scarcity, and manufactured social proof prevents exploitation.
- **Offensive Application (Secondary Use, Constrained):** Persuasion techniques are ethical
  when used to help others reach decisions that genuinely serve their interests. The
  constraint: never use psychological leverage to extract compliance against the target's
  actual interest.
- **The Bright Line:** Persuasion that helps → ethical. Persuasion that exploits → unethical
  and long-term brand-destructive. Trust compounds over time; manipulation erodes it faster
  than it builds.

## Ethical gate (MBB — when NOT to deploy)

- Never use psychological leverage to extract compliance against the target's actual
  interest.
- Introduce scarcity only when genuine; never manufacture false deadlines or reset timers.

## Anchor registry terms (use, never redefine)

- **Trust signals** — the umbrella for these mechanics (social proof, authority,
  certainty/risk-reversal); they reduce perceived risk and substitute for in-person
  credibility. All six CW elements + Cialdini laws map under this.
- **Objection handle** — a specific copy or structural element that neutralizes a known
  buyer objection, living throughout the funnel (ad → LP → checkout).
- **Awareness level** — the buyer's recognition state; governs which elements must
  establish trust before persuading. Cold = lowest awareness/trust.
- **Extraordinary identifier** — the saturated upper bound of trust signals (named
  celebrity, major press, credentialed authority); the identity-level, uncopyable signal.
