# Seasonal Spending Cycle + Desire Calendar — the data feeding R9

R9 names "route by Desire Calendar month" but the month-by-month data and thresholds were never
emitted, making the rule unactionable. Restored faithfully from Spencer Origins. No line budget.

---

## Seasonal Spending Cycle Awareness (month-by-month decision data)
Monthly calendar tied to dopamine cycles, financial reality, and social context:
- Late Aug / Sep: 15–30% resistance increase (financial tightening after summer — not a creative problem)
- October: Halloween/fall spending spike
- November/December: gifting-mode requires full messaging frame shift
- January: 35–40% health supplement surge
- February: Valentine's Day — $27.5B 2025 record
- July (not September): Back-to-school — 67% of purchases by end of July

Implication: poor performance in late Aug/Sep = seasonal effect, not necessarily funnel failure —
**do not make permanent decisions from seasonal data.**

## Desire Calendar by Month (the routing table R9 selects on)
- Full month-by-month table: dominant desire + biological driver + cultural event + spend data.
- **Inverse use** (the actionable rule): if primary market is in-season, competitors are flooding
  that desire → target the opposite desire.
  - Example: January health surge = opportunity for comfort/indulgence brands targeting "recovery
    from restriction".
- Key pitfalls: never pull December health brand spend as benchmark; run back-to-school ads in July
  not September.

## Decision rule (how R9 consumes this)
- Permanent desire = product category & brand positioning; trending desire = ad-campaign sprint.
- When your market is in-season (competitors flooding), target the opposite desire.
- Desire evaluation order before commitment: **Scope → Urgency → Staying Power**
  (Scope = how many feel it / market size; Urgency = how badly now / conversion speed;
  Staying Power = will they want it again / LTV).
- Two-axis viability filter (Intensity × Scope): high×small = niche (ceiling); low×large = commodity
  (needs massive reach); high×large = scaling product.
