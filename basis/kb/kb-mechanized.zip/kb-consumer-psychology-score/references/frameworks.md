# Frameworks restored from source — the WHY behind the gates

These are the named models, decision rules, and engineered-bias stacks the gates classify against.
They were dropped in the lean pass; restored here faithfully so an executing agent can reason about
*why* a field is gated, and so the route-rules have their mechanism. No line budget here — be faithful.
All quoted lines are verbatim substrings of the source KB files.

---

## Dual-System Emotional Decision-Making Model (Carl Weische)
The rationale behind the 95/5 copy split (field 7) and the "appeal to System 1, not specs" routing.

Human decisions are governed by System 1 (fast, intuitive, emotional — requires less cognitive
energy) and System 2 (slow, conscious, logical). The reptilian complex and limbic system make
emotional decisions below conscious awareness; the prefrontal cortex rationalizes these decisions
after the fact.

> "99% of decisions are emotional/intuitive. Only 1% are truly logical."

Marketing must appeal to System 1 to be effective. Logical features and product specs serve as
**post-purchase rationalization fuel, not primary purchase drivers**. This is the model under field 7:
≥95% of copy on outcomes/results because the buy is emotional; ≤5% on specs because specs only
rationalize a decision already made.

---

## Pain Threshold Crossing Framework + loss-aversion 2x multiplier (Carl Weische, Tony Robbins)
A named lever set feeding angle discipline (R4) and current→desired-state framing (R5).

Every person has an internal pain threshold. Below it, they endure discomfort without acting. Once
cumulative emotional pain exceeds the threshold, motivation to change activates and buying behavior is
triggered. Each person's threshold is individual — there is no universal level.

**Three levers to exceed the threshold:**
1. **Timing**: Priming someone's identity before asking ("do you consider yourself a caring person?") increases follow-through
2. **Priming**: Attach labels that reshape identity and expected behavior
3. **Focus**: People judge something as more important simply because they are paying attention to it

**Loss-aversion decision rule:** the pain of losing something is **2x as powerful** as the pleasure
of gaining an equivalent thing. Pain-based marketing outperforms aspirational/pleasure-based
messaging. Strategy: test multiple angles, identify the winning pain angle, then "beat it to death"
by exploring multiple sub-pain-points within that angle rather than rotating to new angles prematurely.

---

## Two Forces That Create Desire + Mass Education mechanism (Spencer Origins)
The full force model behind R9's permanent-vs-trending split (only the split survived the lean pass).

- 2 permanent forces (always present):
  1. Mass Instincts — hardwired biological drives
  2. Mass Technological Problems — friction created by technology adoption
- 2 forces of change (time-dependent):
  1. Style Trends — social/cultural shifts in what's desirable
  2. Mass Education — information that changes what people want or fear
- Mass Education example: a published GLP-1 risk report would collapse Ozempic demand overnight —
  information is the mechanism, not the product

This sits beside the *Four core human drivers* / Six Mass Instincts registry entry. Routing
consequence: permanent desire = product category & brand positioning; trending desire = ad-campaign
sprint. The Mass-Education lever is the one that can move a market without touching the product.

---

## Cognitive Bias Stack for CRO (Carl Weische)
The three biases deliberately engineered into page design — feeds R6 trust-signal deployment.

1. **Cognitive Fluency Bias**: Simpler, clearer offers generate more trust and higher conversion.
   Complexity kills conversion by increasing cognitive load and reducing perceived credibility.
2. **Loss Aversion / Risk Avoidance**: People prefer certain outcomes over uncertain ones even at
   lower potential reward. Counter with: explain why competitors fail, show exactly how your solution
   works, provide money-back guarantees and trust badges.
3. **Authority Bias**: Triggered through confident messaging and professional design. Position brand
   as market leader through design and copy. Authority reduces the cognitive effort required to trust.

---

## Social Proof as Tribal Survival Instinct + validated conversion lifts (Carl Weische)
The mechanism and the numbers behind R6/R7 placement ordering (the lean pass stripped every number).

Social proof evolved as a tribal survival heuristic — following group behavior was a life-or-death
signal. This instinct operates via System 1 and remains fully active in modern consumers. Social
proof placement must be strategic (tied to customer journey stages, not generic).

Validated conversion lifts from social proof placement:
- Team section on homepage: **+5.4% conversion rate**
- Testimonial stars on collection pages: **+8.71% revenue per user**
- Reviews in navigation menu: **+6.75% revenue per user**
- Happy customer count shown in cart: **+6.88% revenue per user**

Trust layers for e-commerce: press mentions (Vogue, Vanity Fair, Glamour) → aggregate social proof
("50,000 happy customers") → individual testimonials with names/photos → detailed transformation
reviews.

---

## Mere Exposure Effect + full-funnel retargeting architecture (Carl Weische)
The principle name and worked CPA result behind R7's hero→view-retarget→UGC→still ladder.

Repeated brand exposure increases willingness to pay purely through familiarity — the **mere exposure
effect** (e.g., Heinz ketchup premium over identical no-name product). Applied to retargeting
architecture:
- **Hero ad** (top of funnel) → retarget 95%, 75%, 50% video view audiences
- **UGC retargeting videos**: Creators reference the hero ad by name ("I saw the 'prepare to be
  complimented' ad") and address specific objections
- **Still image ads**: Final-stage retargeting reinforcing brand familiarity

Creates perception: "everyone is watching these ads, everyone is buying this product."

**Result**: Riddle Fragrance — Meta new customer CPA cut from **$122 to $55 in one week**.

---

## Psychological Trigger Implementation: FOMO, Scarcity, Urgency, Reinforcement (Carl Weische)
The named moments and the numbers/placement rules R7 fires but had stripped.

- **FOMO timers**: Create urgency through time-limited availability
- **Stock counters + social proof combined**: Scarcity + tribal validation simultaneously →
  **12–16% conversion increase**
- **Cart drawer reinforcement copy** ("Excellent choice"): Positive reinforcement at peak intent
  moment → **+18% conversion**
- **Announcement bars with store benefits**: Persistent trust signal → **+3% conversion**
- **Mirror neuron image strategy**: Visibly happy model image near top of landing page triggers
  mirror neurons, inducing positive emotional state that primes for purchase. Model should match
  customer avatar shown in ad creative for congruency.
- **Payment provider logos** (Visa, Mastercard, PayPal, Apple Pay): Trust transfer via associative
  credibility — consumer already trusts these brands; co-display transfers that trust passively.
- **Future pacing**: Copy that helps customers vividly envision positive outcomes post-purchase,
  combined with guarantees and transparent shipping/returns info, neutralizes purchase anxiety.

---

## Self-Efficacy as Primary Entrepreneurial Trait (Carl Weische)
A named concept + counterintuitive finding; pairs with the "Overconfidence/optimism" pitfall.

Meta-analysis of hundreds of studies on entrepreneurial success: **self-efficacy** (belief that one's
own actions can achieve any goal) has the single largest direct effect on venture growth among all
psychological traits. Persistence and active risk management are positive predictors. Overconfidence
and excessive optimism are **negative** predictors of entrepreneurial success.

Decision rule for grading an operator/founder asset: treat overconfidence and excessive optimism as a
RED flag (HEURISTIC warn), not a green one; self-efficacy + persistence + active risk management are
the positive signals.
