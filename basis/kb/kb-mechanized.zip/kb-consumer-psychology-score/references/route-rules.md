# ROUTE rules — named-trigger selection & sequencing (contract, not wording)

These select WHICH strategy/lever/venue fires for a classified field. They dictate no actual copy
(generation lives in the copywriting / hooks / VSL WRITE skills that consume these classifications).
Anchor to *Stage → required levers matrix*, *Awareness × angle tier matrix*, *Extraordinary
identifier*, *Source venues by tier* in the registry.

## R0 — Assess BOTH before any strategy (sequencing gate)
Awareness stage AND sophistication stage are assessed simultaneously before selecting messaging.
Neither alone is sufficient.

## R1 — Sophistication stage → required lever (*Stage → required levers matrix*)
- `New` → basic direct claim; be indirect.
- `Early` → scale up with specifics.
- `Growing` → introduce a new mechanism (a *UM*).
- `Established` → amplify benefits of the mechanism.
- `Saturated` → add an *Extraordinary identifier*: authority figures, hyper-specific audience callouts, unique mechanism.

**Saturation override (feeds the SKILL verdict):** Sophistication = `Saturated` AND routed lever
lacks an Extraordinary identifier → `BLOCKED:sophistication`.

## R2 — Awareness stage → funnel step
- Cold (problem/solution-unaware) → VSL leading with the problem; expand awareness before product.
- Product-aware → skip emotional storytelling; go straight to objection handling.

## R3 — UM → belief it shifts (field 6/8 input)
- Problem-UM shifts the belief "my previous solutions should have worked".
- Product-UM (Solution-UM) shifts the belief "nothing will work for me".

## R4 — Angle discipline (field 5 input)
Map angles to mass desires → pick the most base universal desire for the avatar → validate on cheap
ads → exhaust sub-pain-points within the winner ("beat it to death") before rotating.

## R5 — Selling structure
Current state → desired state → position the offer as the bridge.
Alchemy of Sales order: rapport/frame → current situation → desired situation → product positioning
→ trust building → pitch with urgency → objection handling.

## R6 — Trust-signal deployment (*Trust signals*)
Counter the relevant bias / answer "has someone like me achieved this result?" with matching proof.
Trust-layer order: press mentions → aggregate social proof → individual testimonials → transformation reviews.

## R7 — Placement & retargeting
Place social proof by journey stage; fire FOMO/scarcity/reinforcement mechanics at their named
moments; hero ad → 95%/75%/50% view retargets → UGC → still-image final stage.
Mechanism = *mere exposure effect*; named-moment numbers (cart "Excellent choice" +18%, stock+social
12–16%, social-proof placement lifts, mirror-neuron image rule, future pacing, Riddle $122→$55) live
in `references/frameworks.md` (Mere Exposure + Psychological Trigger + Social Proof sections).

## R8 — Buyer-state → framing
- Happiness-motivated → frame functional/specific, not aspirational (avoids post-purchase dissonance).
- External-locus → shift locus first via education/narrative OR use done-for-you framing.
- Externally-validated → belonging/status/identity offers; always pre-frame authority before the claim.

## R9 — Desire timing
Permanent desire = product category & brand positioning; trending desire = ad-campaign sprint.
Route by Desire Calendar month; when your market is in-season (competitors flooding), target the
opposite desire. Evaluation order: Scope → Urgency → Staying Power.
The four-force desire model + Mass-Education lever is in `references/frameworks.md`; the month-by-month
calendar data + seasonal thresholds (15–30% Aug/Sep, 35–40% Jan, July 67% back-to-school) is in
`references/data-calendar.md`.

## R10 — VOC venue routing (*Source venues by tier*)
Reddit / YouTube / Amazon reviews / Facebook groups / surveys / TikTok organic / forums. Per-category
Reddit search after desire is set; Amazon export → LLM theme clustering; comment-mining closed loop:
contact → record → transcribe → extract → validate verbatim back with the customer (non-negotiable).
The 5-category Reddit search-string templates, the Amazon review-mining steps + worked angle examples
(Blissy/barefoot/posture), and the comment-mining loop are in `references/procedures.md`.

## R11 — Audience-as-pricing-lever
Target higher-value archetypes to lift perceived value without changing COGS.
