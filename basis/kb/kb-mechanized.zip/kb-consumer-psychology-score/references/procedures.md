# Execution procedures / SOPs restored from source

The upstream processes that PRODUCE the artifacts the gates check (the Necessary Beliefs Document,
the 5-category sub-avatar, the ≥3 angles). The lean pass kept the gate but dropped the procedure that
fills it, leaving the rules unactionable. Restored verbatim-faithfully here. No line budget.

---

## Foundational Docs SOP for Copy Architecture (Mark Builds Brands)
The four-document parent process that produces the Necessary Beliefs Document field 6 gates.

> Before any copy is written for a new product, run the product through the Foundational Docs SOP.
> This process generates deep psychological research on the target customer and produces exactly four
> output documents that serve as the structural foundation for all landing page copy. The SOP feeds
> the AI copywriting step—it is not replaced by AI. No copy is written until these four documents
> exist.

This is the upstream contract: the Necessary Beliefs Document (the artifact field 6 counts 3–7
beliefs in) is one of the outputs of this SOP. The companion Belief-Change architecture says: create a
Necessary Beliefs Document before writing any copy — list the 3–7 specific beliefs a prospect must
hold to purchase; map each VSL or ad component to shifting one or more of those beliefs; use the
Unique Mechanism of the Problem to shift "my previous solutions should have worked"; use the Unique
Mechanism of the Solution to shift "nothing will work for me"; allocate 95% of copy to outcomes, 5%
or less to features. **No copy / no AI tool is applied until this document exists.**

Gate consequence: "Copy before the Beliefs Doc" → fails field 6. The SOP is what makes the gate
satisfiable.

---

## Five-Category Reddit Research Protocol for Sub-Avatars (Spencer Origins)
The search-string templates that fill the 5-category avatar gated by field 10.

After desire is identified, search four remaining categories independently on Reddit:
1. Emotion — "feeling [emotion] about [category]"
2. Behavior — "people who [specific behavior]"
3. Demographic — "[demographic] struggling with [category]"
4. Product experience — "[product category] results" / "did [product] work for you"

- Capture self-identifying labels from each category.
- Feed raw Reddit quotes into Claude for headline generation.
- Worked output: "Magnesium got you sleeping longer. This gets you sleeping deeper." — arose from
  emotion + product experience combo mining.

(The five categories are: Desires [the required start-here core] + the four searched above =
Desires | Demographics | Emotions | Behaviors | Product-Experiences — the exact keys field 10
requires non-empty.)

### Customer Comment Mining for Avatar Discovery (the closed loop behind R10)
5-step closed-loop process for turning a Facebook comment into a validated sub-avatar:
1. Contact commenter (DM or email from comment thread)
2. Record call
3. Transcribe call
4. Feed transcript to Claude for pain language extraction
5. Validate AI-generated pain language directly back with customer before using in copy

Warning: AI may guess "throbbing pain" when real language is "pins and needles and stabbing pains" —
the validation step is non-negotiable. One validated comment spawned a new avatar → dedicated
creative → 5.5 ROAS within 48 hours.

---

## Amazon Review Mining for Angle Discovery (Mark Builds Brands)
The procedure + named worked examples that teach what an uncovered angle looks like (R10 named the
export→cluster step but dropped these examples).

Systematic process for surfacing untapped marketing angles from existing customer language:
1. Search Amazon for the validated product category; filter for high review-count listings.
2. Export reviews in bulk using the Amazon Review Export Chrome extension.
3. Feed exported reviews into ChatGPT; prompt for recurring themes, pain points, and unaddressed use cases.
4. Each cluster of unaddressed pain = a potential new marketing angle targeting a distinct buyer segment.

**Worked examples (what an uncovered, uncontested angle looks like):**
- Barefoot shoes: primary angle = minimalist lifestyle; review mining revealed neuropathy relief as a
  completely untapped, uncontested angle.
- Posture corrector: angle 1 = posture improvement; angle 2 = back pain relief. Same product, two
  distinct desire channels, different audiences.
- Blissy pillowcases scaled to multi-eight figures by repositioning as acne prevention—a use case
  buried in customer reviews, not in any competitor's messaging.

Marketing goal: channel existing desire through new angles, not create new desire. Product is fixed;
messaging is the variable.

---

## Desire Hunting Research Protocol (Spencer Origins) — the verbatim discipline behind field 4
- 1-hour time cap per research session — prevents over-studying without action.
- Three-column spreadsheet: Desires/Wants/Needs | Customer Language Snippets | Rejected Ideas (what
  didn't pass Command+F verification).
- "Do not paraphrase" as operational rule — verbatim only.
- Desired state must be captured in their words: "smoother and less dry" not "hydrated".
