# Per-field membership tests + enum definitions + COUNTABLE gate thresholds

Enum labels defer to `term_registry.json` (Awareness level, Market sophistication, Four core human
drivers, Angle, UM, Command+F verbatim rule, etc.) — never redefine a registry term here. Each test
is all-YES = field passes; any line can return FALSE so a wrong value fails by shape.

## Field 1 — Mass-market drive (COUNTABLE → hard-gate)
- ALLOWED: `Reproduction | Social-Comparison | Social-Belonging | Safety-Security`
  (or the 6 Mass-Instinct enum: `Health/Survival | Status | Sex/Relationships | Comfort | Control | Belonging`).
- Run Mass Desire Identification first: feature → benefit → root driver, then echo the chosen value verbatim from the list.
- TEST: value ∈ list? evidence_quote names the feature/benefit that chains to it?
- The 6-instinct list AUGMENTS *Four core human drivers* (Spencer's own note); it does not replace the registry term.

## Field 2 — Awareness stage (COUNTABLE → hard-gate)
- ALLOWED: `Unaware | Problem-Aware | Solution-Aware | Product-Aware | Most-Aware`.
- TEST: value ∈ list? evidence quotes the asset's own words placing it (e.g. educating-about-the-problem ⇒ Unaware)?

## Field 3 — Sophistication stage (COUNTABLE → hard-gate)
- ALLOWED: `New | Early | Growing | Established | Saturated` (defers to *5+ saturation rule*).
- TEST: value ∈ list? evidence cites how many competing offers have already been pitched?

## Field 4 — VOC verbatim (COUNTABLE → hard-gate)
- `verbatim = the stored phrase is a Command+F substring of the research doc` (no paraphrase).
- Cluster enum: `pains | objections | excuses`.
- TEST: each phrase passes Command+F? each is tagged to exactly one cluster? FALSE example: paraphrasing "smoother and less dry" as "hydrated" → not in source → FAIL.

## Field 5 — Angle count (COUNTABLE → hard-gate)
- `count = distinct angles validated on cheap ads BEFORE any VSL/funnel build`.
- TEST: count ≥ 3? each angle distinct (different root mass desire, not a reworded twin)?

## Field 6 — Necessary-Beliefs count (COUNTABLE → hard-gate)
- `count = blocking beliefs listed in the Necessary Beliefs Document, written before copy`.
- TEST: 3 ≤ count ≤ 7? each row a specific belief a prospect must hold (not a vague theme)?

## Field 7 — 95/5 copy split (COUNTABLE → hard-gate, advisory cap)
- `feature_share = words on product features/specs ÷ total copy words`.
- TEST: feature_share ≤ 0.05 (≥95% on outcomes/results)?

## Field 8 — Testimonial mapping (COUNTABLE + FELT edge)
- Function enum: `pre-handle | seed`. Each testimonial maps to ONE function AND to a named belief from the Beliefs Doc.
- TEST (script): function ∈ enum? a Beliefs-Doc belief id is named? FALSE: a generic "This product is great!" with no pain and no belief → FAIL.
- FELT edge ("specific enough?") → pairwise-vs-specimen, never a hard FALSE.

## Field 9 — Desire quadrant (COUNTABLE → hard-gate)
- ALLOWED (Intensity × Scope): `niche` (high×small) | `commodity` (low×large) | `scaling` (high×large) | `low-low`.
- TEST: value ∈ list? evidence cites the intensity read and the scope read?

## Field 10 — Sub-avatar completeness (COUNTABLE → hard-gate)
- Required keys: `Desires | Demographics | Emotions | Behaviors | Product-Experiences` (Desires is the start-here core).
- Avatar-count bands: `$0–100K = 1` · `$100K–$1M = 2–3` · `$1M+ = several`.
- TEST: all 5 keys non-empty? avatar count matches the revenue band?

## Field 11 — Emotion unpack (COUNTABLE → hard-gate)
- Primary enum: `joy | sadness | fear | disgust | anger | surprise`. Secondary (reported): `anxious | frustrated | overwhelmed | defeated`.
- TEST: each reported secondary maps to a primary cluster (e.g. overwhelmed → fear+disgust; frustrated → anger)?

## Field 12 — Audience criteria (COUNTABLE → hard-gate)
- Four criteria: `growing | can-pay | easy-to-target | in-pain`.
- TEST: all 4 carry a verdict? candidate prioritized by scoring highest across all four?

## Field 13 — WIIFM read (FELT — pairwise only, NEVER a membership gate)
- Do NOT write a yes/no test. Compare the copy to a winning specimen in `scoring-specimens.md`:
  does it answer "What's in it for me?" as well as the specimen? Return `prefer | tie | weaker`.
- `weaker` contributes no pass; it downgrades READY → REVISE-COPY. Never a hard FALSE.

## Why the tiers
Hard-gating a felt field (WIIFM) produces confident-but-wrong FALSEs and pushes writers to game the
gate. Hard-gating a countable one (an enum membership; a 3–7 count; a Command+F substring; a 5-key
completeness check) is reproducible and safe. Soft-cap the heuristics (high-discount welcome flows,
vanity-metric optimization, surface demographics) — those detectors over-flag, so warn, don't fail.
