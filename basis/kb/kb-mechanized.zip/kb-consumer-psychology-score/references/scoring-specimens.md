# Scoring specimens — the known-good lines to judge the FELT field against

Field 13 (WIIFM) is scored **pairwise against these**, not on an absolute scale and never by the
model that wrote the candidate. Randomize order; treat any single read as a triage signal, not a
certification. Every line below is a verbatim substring of a source KB file (the anti-rot gate
confirms this).

## Verbatim VOC reference (the standard field 4 / Command+F enforces)
Customer-lifted, found-in-research language outperforms internally generated copy. Judge candidate
research phrases against these real mined specimens:

- "smoother and less dry"
- "pins and needles and stabbing pains"
- "walking on clouds"

How to use: a research phrase must be a Command+F hit like these — not a paraphrase. The paraphrase
foil "hydrated" (NOT a specimen) is what these defeat.

## WIIFM / functional-results reference (judge field 13 against these)
The buyer-facing standard is functional, specific, self-interested benefit language:

- "Magnesium got you sleeping longer. This gets you sleeping deeper."

Ask: does the candidate answer "What's in it for me?" as concretely as this line does? Return
`prefer | tie | weaker`. `weaker` downgrades READY → REVISE-COPY; it never produces a hard FALSE.

## Stage-calibration reference (sanity-check fields 2 & 3 routing, not graded)
The source's own stage examples, useful to confirm a routed lever matches its stage:

- "increase testosterone by 10% in 3 weeks"
- "feeling tired and unable to progress in the gym may signal low testosterone"

## How to run the pairwise judge
1. Present candidate + one specimen, order randomized.
2. Ask which better answers "What's in it for me?" and why (criteria before verdict).
3. Record `prefer | tie | weaker` + the reason. `weaker` contributes no pass for that field.
4. Never let the model that generated the candidate be the judge.
