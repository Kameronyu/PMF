# Scoring specimens — verbatim source figures the gates check against

Every line below is a verbatim substring of `upsells-and-monetization--alex-hormozi.md`. The
anti-rot checker confirms this. Use these as the known-good numbers when judging a move; never
stitch fragments into a composite.

## Gate 1 — upsell sizing (5X base)
- "Price upsell at 5X base offer to achieve meaningful conversion and revenue impact"
- "Undersized upsell ($100 on $1,000 base): 20% conversion adds only $20 to ticket — not worth effort"
- "Correctly sized upsell ($5,000 on $1,000 base): 20% conversion adds $1,000 to ticket — doubles LTV"

## Gate 2 — 10% uptake on 10x doubles revenue
- "Even 10% uptake on 10x price doubles revenue"

## Gate 3 — buy-X-get-Y front-load
- "$100/month service -> $200/month premium with buy 6 get 6 free = $1,200 upfront"

## Gate 4 — 5-5-5 price climb
- "5-5-5 model: Every 5 sales, raise price by 20% ($5 → $6 → $7.20 → $8.64)"

## Gate 5 — four-element product
- "Air: Low incremental cost to deliver = high gross profit"
- "The most scalable businesses have nearly zero cost to add another customer."
- "Expensive products make more money per unit."
- "Unique, expensive, sticky air, managed by an owner — that was their breakdown of the perfect business."

## Gate 6 — fractal 80/20 take-rates
- "80% of challenge buyers bought supplements (~$200)"
- "70% took rollover to annual membership (double the 35% industry average)"
- "20-30% of annual members took paid-in-full discount"
- "Customers tend to be fractal 80/20. About one out of five will buy something significantly more expensive."

## Gate 7 — Med-Spa blended value
- "Math: (Upsell conversion % x Upsell gross profit) + Front-end gross profit = Blended value per customer"
- "Example: (40% x $1,300) + $58 = $578 blended value vs $202 CAC = ~3:1 ratio"

## Gate 8 — PIF 5x commission
- "Paid in full: closer earns $1K per transaction"
- "PIF commission 5x higher than payment plan commission"

## Gate 9 — peak-hour surge math
- "10% price increase on 50% of weekly volume (Thu-Sat) = ~5% total revenue increase"
- "5% revenue increase on 28% margin business = ~20% profit increase"

## Gate 10 — prepay take-rate bands
- "Minimum 10% discount for paid-in-full; money today is worth at least 10% more than money in a year"
- "Buy-10-get-2 deal (pay 10 months, receive 12): 15-20% take rate"
- "Moderate discount + ancillary benefits (faster delivery, extended guarantee, priority access, concierge): 30-40% take rate"
- "Third-party financing increases overall sales ~35% by converting previously unable-to-buy prospects"

## Gate 11 — ROIC reinvest
- "If a location costs $50K and generates $250K net profit in 12 months = 5x ROIC"
- "If I reinvest the $250,000 profit to open 5 new locations at $50,000 each, the next year I make $1.25 million. This is how compounding occurs."

## Gate 12 — IP success / failed metric
- "Failed metric: IP investment → no audience growth → no sales lift = broken model"

## Gate 13 — affiliate threshold
- "Anyone bringing 10+ people received two unreleased bonus chapters"

## Gate 14 — guarantee-as-upsell claim rate
- "Only 1 in 10 guarantee buyers actually claimed it"
- "Guarantees can be sold as an upsell -- zero cost if not claimed, 90% of buyers never claim"

## Frameworks / decision rules — Dollars Per Box (unit-economics obsession)
- "Build your entire business DNA around a single unit economic metric that everyone in the company understands. ButcherBox used 'dollars per box' as their North Star metric - fully loaded profit per box shipped, including all costs down to the tape on the box."
- "Negotiate every single line item obsessively"
- "$129 box price targeting $20 fully loaded profit per box at start"
- "All we care about at Omaha Steaks is dollars per box"

## Frameworks / decision rules — LTV as the advertising arms race
- "Most businesses fail not from lack of leads but from lack of profitable leads—solve the business back to front"
- "CAC variation across competitors in same market is typically only 1-2x"
- "LTV is the primary differentiator between successful and unsuccessful businesses"
- "Don't chase 'cheaper leads'—the first campaign always performs best, it degrades from there"
- "Google '[your industry] average customer acquisition cost' to benchmark against competitors"
- "LTV is the arms race of advertising. Most businesses will identify one or two key things that must happen."

## Frameworks / decision rules — Partner for your deficiencies
- "Identify your core deficiencies (distribution, manufacturing, online sales) and partner with someone who has a lifetime of learning in those areas rather than trying to learn everything yourself. Businesses are limited by the collective brainpower inside the organization."
- "Businesses are limited by the collective brainpower in the organization"
- "There are few things more valuable than building distribution"

## Frameworks / decision rules — Solve for zero (hobby business)
- "Start by solving for zero time and profit rather than trying to build a grand vision."
- "Build with the premise of minimal time investment and profitability from day one"
- "Outsource everything you are not uniquely good at"
- "ButcherBox went from hobby targeting $20K/month to $550M/year"

## ROUTE — In-Person Event Renewal System
- "Day 1: Intro, teaching sessions, pitch, buyer dinner"
- "Day 2: 15-30 min re-pitch framed as value + objection handling, then more teaching, final close"
- "Greet everyone by name with 2 specific facts about their business/marriage"
- "Assign attendees to staff rosters with colored lanyards for personalized attention"
- "If you're going to pitch, pitch. If you're not, don't. Don't go soft."

## ROUTE — Med-Spa menu close
- "Menu close: present the ideal package (everything they need to look like a goddess), let them cross off items"
- "Start at ideal and work down to budget rather than starting small and upselling"
- "You sell the vacation: if you were to look like a goddess these are all the things you need, and then everything they cross off they just look uglier and older."

## ROUTE — Post-diagnostic habit stacking
- "Habit stacking: coffee → supplements next to coffee; gym trips → pre/post-workout in car"
