# Business-DNA / decision frameworks (steering context, not graded gates)

These are decision rules and execution disciplines that frame WHICH monetization move is even
worth scoring — unit-economics obsession, the LTV arms race, partnering for deficiencies, and
the hobby-business "solve for zero" premise. None is a pass/fail gate (the countable gates do
that); they are the strategic contract that tells a scoring agent how to read a move. Verbatim
source figures live in `references/specimens.md`.

## Dollars Per Box — unit-economics obsession (decision discipline)

Build your entire business DNA around a single fully-loaded unit-economic metric that everyone
in the company understands and rallies around. Choose ONE metric, load ALL costs into it, and
negotiate every line item.

- Choose one unit economic metric the entire company rallies around.
- Fully load all costs into that metric including shipping, packaging, processing fees —
  "down to the tape on the box."
- Negotiate every single line item obsessively.
- This keeps focus on profitability from day one.
- Benchmarks: $129 box price targeting $20 fully loaded profit per box at start; ~30% gross
  margin; ~6.5% net margin at $550M revenue (ButcherBox / "dollars per box").

Use when scoring a move: a move that ignores fully-loaded cost-per-unit (counts only headline
price or CAC) is structurally suspect — push it back to the single loaded metric first.

## LTV as the Advertising Arms Race (decision rules / thresholds)

Advertising costs increase permanently; the offsetting force is rising LTV. The competitor who
can spend the most to acquire a customer while staying profitable wins the market. The decision
rules:

- **Solve the business back to front.** Most businesses fail not from lack of leads but from
  lack of *profitable* leads — solve the business back to front.
- **CAC variation across competitors in the same market is typically only 1-2x.**
- **LTV is the primary differentiator** between successful and unsuccessful businesses (CAC is
  nearly fixed across the market; LTV is where you win or lose).
- **Don't chase "cheaper leads"** — the first campaign always performs best, it degrades from
  there.
- Advertising costs only increase over time — CPM, CPC all trend up permanently; you need LTV
  to grow concurrently to remain competitive.
- Raising prices is one of the strongest LTV levers; most owners are terrified to do it.
- **Benchmark step:** Google "[your industry] average customer acquisition cost" to benchmark
  against competitors.
- Benchmark: Starbucks LTV $14,000 per customer, built over 40-50 years.

Decision-rule use: when a move is framed as "get cheaper leads / lower CAC," redirect — CAC is
only 1-2x movable; the real lever is LTV. Score the move for whether it raises LTV, not CAC.

## Partner for Your Deficiencies (decision rule)

Identify your core deficiencies (distribution, manufacturing, online sales) and partner with
someone who has a lifetime of learning in those areas rather than trying to learn everything
yourself. Businesses are limited by the collective brainpower inside the organization.

- Partner-vs-self-learn: on a CORE deficiency, partner rather than try to learn it from scratch.
- The best people in the world don't work for free — pay for complementary expertise.
- **Distribution is one of the most valuable partnership assets** — to bring or to get.
- Example: Rihanna brought media distribution + brand; LVMH brought supply chain and retail
  (118 factories, 6,000+ retail stores). Prestige Labs did $1.7M in month one off a gym
  distribution base.

Decision-rule use: a monetization move that depends on a capability the org lacks (distribution,
manufacturing, online sales) should route to a partnership, not an internal build.

## Solve for Zero (Hobby Business Framework)

Start by solving for zero time and profit rather than trying to build a grand vision. Build
something designed to run without you and be profitable from day one; it paradoxically scales
easier because the premise already handles the hardest constraints.

- Build with the premise of minimal time investment and profitability from day one.
- Outsource everything you are not uniquely good at.
- If you build something to be a hobby, it can remain a hobby.
- Romantic big visions tend to fail; pragmatic profit-seeking tends to succeed.
- Trajectory example: ButcherBox went from a hobby targeting $20K/month to $550M/year.

Decision-rule use: when a move adds owner time or delays profitability for a "grand vision,"
flag it against this premise — prefer the minimal-time, profitable-from-day-one structure.
