# Per-gate membership tests + the arithmetic each compiles to

All gates here are COUNTABLE → script-gated. Each test can return FALSE. Run the arithmetic in
a step SEPARATE from whoever designed the move; record the computed value as `evidence`, then
the verdict. Source figures to anchor against are in `references/specimens.md`.

## Gate 1 — Upsell sizing (5X)
- `multiple = upsell_price / base_offer`
- PASS iff `4 ≤ multiple ≤ 6` (≈5X). FAIL if undersized (multiple ≪ 5) — undersized upsell
  adds negligible ticket at ~20% conversion. FAIL → REJECT (the override; see SKILL band rule).
- Worked: $5,000 on $1,000 → 5.0 → PASS. $100 on $1,000 → 0.1 → FAIL.

## Gate 2 — 10%-on-10x doubles revenue
- `added_revenue = uptake_rate × tier_multiple × base`
- PASS iff `added_revenue ≈ base` (revenue roughly doubles). Worked: 0.10 × 10 × base = base → PASS.

## Gate 3 — Buy-X-get-Y front-load
- `upfront = paid_period_price × periods_paid`; compare to single-period price.
- PASS iff price is raised (≈3x) AND `upfront` exceeds one normal period's cash by a large
  multiple. Worked: $200/mo prepay-6 = $1,200 upfront vs $100/mo single period → PASS.

## Gate 4 — 5-5-5 climb
- For each 5-sale step: `step_n = step_(n-1) × 1.20`.
- PASS iff every step equals prior × 1.20. Worked: $5 → $6 → $7.20 → $8.64 → PASS.

## Gate 5 — Four-element product (enum membership)
- ALLOWED criteria (closed set): {Unique, Expensive, Sticky, Air}. Buffett variant adds
  {owner-minded operator}.
- MEMBERSHIP TEST (all YES or the product is not "great" by this gate):
  - Unique — proprietary / moat competitors can't copy directly?
  - Expensive — high revenue per unit?
  - Sticky — customers return / recurring or reoccurring purchase?
  - Air — low incremental delivery cost / high gross margin?
- PASS iff all 4 (5 for the Buffett variant) are YES. Any one NO → FAIL. This is enum
  membership, not a count — three of four does not pass.

## Gate 6 — Fractal 80/20 take-rates
- Successive-tier step-down: tier1 ~80%, tier2 ~70%, tier3 ~20-30%; ~1 in 5 ascends each tier.
- PASS iff each observed tier rate falls within its band. A rate far outside band → FAIL (the
  funnel isn't behaving fractally; re-check pricing gaps).

## Gate 7 — Med-Spa blended value
- `blended = (upsell_conv_pct × upsell_GP) + frontend_GP`; `ratio = blended / CAC`.
- PASS iff the formula computes from supplied inputs AND `ratio ≥ ~3`.
- Worked: (0.40 × $1,300) + $58 = $578; $578 / $202 ≈ 3:1 → PASS.

## Gate 8 — PIF 5x commission
- `ratio = pif_commission / payment_plan_commission_total`
- PASS iff `ratio ≈ 5`. Worked: $1,000 PIF vs $1,000 over 5 plan payments — confirm the PIF
  per-transaction commission is 5x the per-payment commission ($1K vs $200/payment) → PASS.

## Gate 9 — Peak-hour surge math
- `rev_lift = price_increase × share_of_volume`; `profit_lift = rev_lift / net_margin`.
- PASS iff the chain computes. Worked: 0.10 × 0.50 = ~5% revenue; 5% / 0.28 ≈ ~20% profit → PASS.

## Gate 10 — Prepay take-rate bands (structure → band)
- Map the offer structure to its band; PASS iff the claimed/expected take rate is in band:
  - PIF discount: minimum 10% discount (the floor, not a take rate).
  - Buy-10-get-2: 15-20% take rate.
  - Moderate discount + ancillary benefits: 30-40% take rate.
  - Third-party financing: ~+35% overall sales.
- FAIL if a structure is paired with an out-of-band number.

## Gate 11 — ROIC reinvest
- `ROIC = net_profit_12mo / fully_loaded_capital_per_unit` (buildout, licenses, tech,
  recruiting — not just CAC).
- PASS iff `ROIC ≥ ~5x` in 12 months for a bootstrap-viable unit. Worked: $250K / $50K = 5x → PASS.

## Gate 12 — IP success metric (both-observables)
- PASS iff IP spend produced audience growth AND sales lift (both present).
- FAIL if either is absent — "IP investment → no audience growth → no sales lift = broken model."

## Gate 13 — Affiliate threshold
- PASS iff `referrals ≥ named_threshold` (the bonus fires at the count). Worked: 10+ referrals
  → two unreleased bonus chapters → threshold met.

## Gate 14 — Guarantee-as-upsell claim rate
- `claim_rate ≈ unclaimed_complement`; PASS iff `claim_rate ≈ 10%` (≈90% never claim), making
  the guarantee a near-zero-cost upsell.

## Why all gates are hard-gated (no FELT tier here)
Every gate is arithmetic or closed-enum membership — reproducible and safe to hard-gate. This
topic carries no "would a buyer feel X" judgment, so there is no FELT/pairwise signal and no
soft-cap heuristic. Do not invent one; a structural choice belongs in `route-rules.md` as
contract, not as a graded gate.
