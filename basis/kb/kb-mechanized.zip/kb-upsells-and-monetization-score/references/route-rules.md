# ROUTE rules — selection / sequencing by named trigger (contract, not graded)

These dictate which lever, what sequence, or what order — never the wording. A move that
matches one of these is structurally on-pattern; record `route_match: {rule, trigger}`. None of
these is a pass/fail gate (that's the countable gates' job); they are the steering contract.

## Continuation / timing
- **Always have a continuation offer ready before the front-end program ends.** Trigger:
  front-end program nearing its end with no second offer staged.
- **Milestone-moment upsell sequence:** ask at the milestone moment → next week → last chance
  (3 shots). Trigger: customer first experiences ROI from the front-end.
- **Post-diagnostic supplement sequence:** 48h after diagnostic → nutrition consult → assumed
  close ("charge to card on file"). Uses **habit stacking** to anchor supplement use to existing
  daily routines (coffee → supplements next to coffee; gym trips → pre/post-workout in car).
  Trigger: diagnostic call completed.
- **In-Person Event Renewal System:** structure a multi-day event for renewals.
  - Day 1: Intro, teaching sessions, pitch, buyer dinner.
  - Day 2: 15-30 min re-pitch framed as value + objection handling, then more teaching, final close.
  - Greet everyone by name with 2 specific facts about their business/marriage.
  - Assign attendees to staff rosters with colored lanyards for personalized attention.
  - Immediate renewal incentive: first-class tickets to next events, or spread a discount across
    quarters.
  - Discipline: "If you're going to pitch, pitch. If you're not, don't. Don't go soft." (Soft
    pitching closed only 1 of 50.) Trigger: live multi-day event aiming to maximize renewals.

## Offer-structure menus
- **Value/LTV lever menu** (Eight-ways / Seven-ways): pick among raise price · cut delivery
  cost · cross-sell · upsell · quantity · down-sell · economy/budget tier · purchase frequency
  · financing · change collection terms. Trigger: need more revenue from existing customers.
- **Buy-1-get-2 (give more free than charged) by raising the unit price.** Trigger: recurring
  service where upfront cash is wanted.
- **High-ticket high-scarcity tier:** 10-50x price, limited to top ~5%; countdown
  4→3→2→1→sold out. Trigger: a promotion targeting the fractal top 5%.
- **One-time vs consumable split:** high one-time fee + lower recurring fee, by value type.
  Trigger: offer mixes one-time (knowledge/course) and consumable (community/hosting) value.
- **Tiered offer:** pair low-ticket (volume/trust) with high-ticket (profit) for one niche.
  Trigger: a single hyper-relevant audience served at multiple price points.
- **Two universal upsells:** after purchase offer "more of it" OR "more help with it."
  Trigger: immediately after a first purchase.
- **Waved-fee AB close:** wave the setup fee for a year commitment, else pay fee +
  quarter-to-quarter. Trigger: ascending from front-end to a recurring back-end.

## Pricing / anchoring
- **Peak-hour surge framing:** frame as "peak-hour pricing" not "weekday discount"; offer
  membership as the escape valve. Trigger: demand concentrated in high-demand periods.
- **Three pricing fixes:** add a premium anchor; make continuity opt-out (default); push price
  until total profit drops. Trigger: standard price undervalued / continuity under-taken.
- **Profit-maximizer decoy:** place a 10x/100x item you never plan to sell, to anchor. Trigger:
  menu lacks a high anchor.
- **Med-Spa "menu close":** present the ideal package (everything they need "to look like a
  goddess") and let the customer cross items off; start at the ideal and work DOWN to budget
  rather than starting small and upselling. Pairs with Gate 7 (blended value) — it lifts the
  upsell ticket, which is the usual constraint, not CAC. Trigger: high-margin upsell where the
  bottleneck is upsell average ticket.

## Prepay / capital
- **Prepay bundling & timing:** bundle ancillary benefits (faster delivery / guarantee /
  concierge / skip-the-line); align payment dates to customer income patterns (wage earners:
  paydays; business owners: high-deposit days). Trigger: converting customers to upfront cash.
- **Pre-sales over VC** when validation + capital are both needed. Trigger: pre-launch product
  needing demand proof and capital without dilution.

## Affiliates / reviews / restaurant
- **Two-tier affiliate routing:** super affiliates → status incentives; regular → threshold
  bonuses. Trigger: affiliates segment by audience size / motivation.
- **Unlockable digital bonus for B2B/digital:** trade a higher-tier trial for a review.
  Trigger: no physical goods to give, review generation wanted.
- **Restaurant lever menu:** push alcohol; weekly high-margin table tent; first-timer visual
  marker + surprise dessert (peak-end); weekday repeat incentives. Trigger: brick-and-mortar
  restaurant growing average ticket and repeat visits.

## Value-stack order (sequencing contract)
- **Value-stack ORDER:** core product → social proof → scarcity → access → tangible bonuses →
  expert services → network → one-on-one → exposure → guarantee → extreme scarcity. Trigger:
  layering enhancements onto a core offer. (Anchor Guarantee/risk-reversal layers to the shared
  Objection-handle and Value-model registry terms; do not redefine.)

## Zero-cost upsell selection
- **Zero-cost upsell selection:** pick a complementary zero-time product whose margin covers
  the ad bill (guarantees qualify — ~90% never claim; see Gate 14). Trigger: want to liquidate
  ad spend so core revenue becomes profit.
