# Frameworks, theses & execution procedures (restored detail)

The score skill keeps only the COUNTABLE floor and the ROUTE contract. The conceptual
theses, decision rules, and manual procedures behind those checks live here so an executing
agent has the WHY and the HOW, not just the threshold. Quotes are verbatim source substrings.

---

## Custom-CRM differentiator thesis (CW)

The score skill's Check 1 keeps only the FLOOR (the four baseline flows are table stakes).
The differentiator — the thing ABOVE the floor that actually wins — is:

> "The differentiator is a custom CRM strategy with die-hard fan flows, community loops, and referral mechanics that reduce CAC toward zero."

Contrast it anchors against (verbatim, floor side):
> "Basic email flows (welcome series, abandoned checkout, sunset, engagement re-activation) are minimum requirements — table stakes — not competitive differentiators."

Referral-loop logic that the differentiator activates (verbatim):
> "Community building generates organic UGC and activates viral referral effects. When referral loops are functioning, new customer CAC can approach zero, fully funded by existing customer LTV."

Use: a setup that has only the four baseline flows passes Check 1 but is NOT differentiated —
band narrative should note the absence of die-hard fan flows / community loops / referral
mechanics, not certify the setup as competitive.

---

## Cross-channel MER mechanic — Omni-Channel Retention Stack (SP)

The score skill keeps the negative ("measuring email in isolation"). The positive mechanic
that motivates running channels SIMULTANEOUSLY is the Marketing Efficiency Ratio insight:

> "Email MER (Marketing Efficiency Ratio) improves when all channels run simultaneously — lift is cross-channel, not additive."

The coordinated stack (verbatim):
> "Coordinated stack: Email + SMS + WhatsApp + Google remarketing + Meta remarketing"

Region-segmentation rule (verbatim):
> "Build region-based segments for channel-specific sends (US vs. UK timing/content)"

Decision rule: because lift is cross-channel and NOT additive, do not evaluate or budget any
single channel in isolation — measure the combined email + SMS + retargeting ecosystem
(this is the positive behind the "measuring email in isolation" negative).

---

## Manual affiliate-seeding procedure (SP)

The UGC-affiliate ROUTE rule keeps only the Klaviyo trigger + two binary questions + Drive
link. The manual seeding execution procedure that bootstraps the affiliate network is:

> "Manual seeding process: Instagram DM → gift product → track in spreadsheet (Instagram handle / TikTok / email)"

Step sequence:
1. Instagram DM the prospect.
2. Gift product (free, no purchase required).
3. Track in a spreadsheet — columns: Instagram handle / TikTok / email.

Network expansion (verbatim):
> "Organic referrals expand network after seeded affiliates produce visible results."

Supporting parameters already captured elsewhere (kept here for the full procedure):
- Platform (SP): "Platform: UpPromote (Shopify) for affiliate management and tracking"
- Commission floor (SP): "Commission: 10% minimum viable floor"
- Single-affiliate ceiling (SP): "Single affiliate ceiling documented: £15,000 brand revenue → £1,500 commission at 10%"
