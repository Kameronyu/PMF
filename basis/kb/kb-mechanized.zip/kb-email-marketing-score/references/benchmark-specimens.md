# Diagnostic benchmark bands (NOT pass/fail gates)

These figures position a setup within a narrative band. They are membership-testable as
whether the claimed figure sits inside the documented range, but they NEVER manufacture a
pass for the band count — only the 8 countable checks do that. Use them to explain WHERE a
setup sits, not to certify it.

## Revenue-contribution bands
- Email + SMS contribution to daily revenue (MB) — verbatim source:
  "Email + SMS contribution to daily revenue: **15–20%** (conservative) to **20–30%** (optimized)"
- Abandoned cart flow contribution (MB): "Abandoned cart flow revenue contribution: **~15% of daily revenue**"
- Worked figure (MB): "At $10,000/day revenue, 15% automation contribution = $1,500/day incremental."

## CAC-headroom band
- Retention refinances acquisition (CW): "brands can spend 2x on customer acquisition at the same effective cost"
- Referral-loop floor (CW): "When referral loops are functioning, new customer CAC can approach zero, fully funded by existing customer LTV."
- Backend bid advantage (MB): "the email-equipped operator can afford $37.50 CAC and still maintain equivalent net margins — a structural bid advantage in paid acquisition."

## Infrastructure-gap band
- Market baseline (CW): "Nine out of ten brands lack the retention foundation needed to scale acquisition spend."

## Social-proof outcome band
- Review-routing result (SP): "Result: 780 Trustpilot reviews at 4.8 rating"
- Affiliate ceiling (SP): "Single affiliate ceiling documented: £15,000 brand revenue → £1,500 commission at 10%"

## How to use a band
1. Read the setup's claimed figure for the dimension.
2. Report which band it falls in (conservative / optimized / below-floor) and the verbatim source range.
3. Do NOT convert this to a check pass. The band is context for the GAP/VIABLE/OPTIMIZED narrative only.
