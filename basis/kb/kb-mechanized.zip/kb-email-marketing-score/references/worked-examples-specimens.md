# Worked examples & felt-copy specimens (verbatim source)

These are the generative reference patterns the score pass should recognize but NEVER
self-grade as copy. They were authored as worked examples / felt copy in source; an
executing builder reaches for them, a scorer only checks they are present and faithful.
Every quote below is a verbatim substring of a source file. Do not paraphrase inside quotes.

---

## Personalized Abandoned Cart Recovery Sequence — worked example (CW)

A two-email abandoned-cart sequence where the differentiation lives in the SECOND email.
This is a generative/build pattern (the mechanizer dropped it when it emitted no write skill).

**Two-email structure (verbatim source substrings):**

- Email 1 — verbatim:
> Standard cart reminder (baseline recovery)

- Email 2 — verbatim:
> Sent from a named persona ("Natalie"), includes a custom video message addressed to the prospect, links to a personalized landing page replicating a 1:1 chat conversation interface

**Why it converts (verbatim rationale):**
> "The chat-like landing page experience creates a feeling of individual attention, not mass automation — this perception of personalization is the primary conversion driver."

**Who it recovers (verbatim):**
> "The sequence recovers high-intent prospects who abandoned for non-price reasons (distraction, comparison shopping) by reactivating the personal connection to the brand."

**Coherence mechanic (verbatim):**
> "Key mechanic: the named persona + video + chat-style page creates a coherent personalization narrative across the entire touchpoint sequence."

Each element (named persona "Natalie" + custom video + chat-style 1:1 landing page)
reinforces the same narrative: the prospect is being individually addressed, not batch-mailed.
The personalization layer in Email 2 — not Email 1's baseline reminder — is where recovery
rates materially improve (see the matching pitfall in `check-tests-specimens.md` / negatives).

---

## Post-purchase "family" / identity-based framing — felt copy (CW)

The post-purchase sequence frames the purchase as MEMBERSHIP, not order fulfillment.
The framing tokens are felt copy — preserve verbatim, never harden into a gate.

**Framing copy (verbatim source substrings):**
- Shipping confirmation: "you've joined the family"
- Welcome email frames customer as a member of a branded community, e.g. "Coconut family"

**Why the framing (verbatim rationale):**
> The "family" framing is intentional: it shifts the psychological relationship from transactional to identity-based. Customers who identify with the brand generate organic content, refer others, and exhibit higher repeat purchase rates.

This sequence directly feeds the referral loop in the Retention-Financed Acquisition Model
(see `frameworks.md`).
