# ROUTE contract — named-trigger selection / sequencing

These are structural rules, not scores. A setup that violates or omits a route emits a
`route_flag` naming the route; it never produces a hard FALSE on copy and is never self-graded.
Each rule: TRIGGER → required selection/sequence. Specimens are verbatim source substrings.

## Capture placement (TRIGGER: non-converting paid visitor)
- Newsletter capture sits at the bottom of the LP, after conversion sections.
  - Verbatim (CW): "a newsletter signup section positioned at the bottom of the landing page — after all conversion-focused sections"
- Contact captured pre-checkout, not at checkout.
  - Verbatim (MB): "Capture contact information on the sales page or advertorial stage **before** checkout, not after."

## Flow priority order (TRIGGER: build/optimize order by ROI)
- Verbatim sequence (SP): "1. Abandoned checkout (highest ROI — purchase intent already established)" → "2. Abandoned cart" → "3. Browse abandonment" → "4. Welcome sequence" → "5. Post-purchase".

## Channel roles (TRIGGER: stacking email + SMS on a recovery flow)
- Verbatim (MB): "email handles long-form recovery messaging, SMS handles immediate urgency triggers"

## Post-purchase sequence — CW (TRIGGER: shipping confirmation onward)
- Verbatim steps (CW): "Shipping confirmation" → "Welcome email" → "Discount code delivery" → "Community invitation" → "Brand ambassador CTA".

## Post-purchase must-includes — SP (TRIGGER: post-purchase flow)
- Verbatim spans (SP): "Shipping address confirmation"; "Shipping timeline expectation (sets expectation, reduces"; "Refund-incentivized survey".

## Platform migration (TRIGGER: list size / monthly revenue)
- Verbatim (SP): "Shopify native email: sufficient at early stage (sub-$10K/month)" then "Migrate to Klaviyo as list scales"; "Do not migrate prematurely — Klaviyo's value compounds with list size".

## Tool stack (TRIGGER: named function need)
- Verbatim (MB): "Omnisend recommended for operators who want a single platform managing both channels. Klaviyo + SMSBump recommended for operators prioritizing depth of segmentation and deliverability."
- Affiliates (SP): "Platform: UpPromote (Shopify) for affiliate management and tracking"

## Retargeting activation threshold (TRIGGER: daily ad spend)
- Verbatim (MB): "Paid retargeting (separate from owned-channel email/SMS remarketing) should only be activated at **minimum $500–$1,000/day in ad spend**."
- Owned channel from day one (MB): "Email and SMS remarketing should be activated from day one regardless of spend level".

## Frequency-decision metric (TRIGGER: cadence anxiety)
- Verbatim (SP): "track revenue per send, not unsubscribe rate"

## Review routing by star rating (TRIGGER: submitted rating)
- Verbatim (SP): "1–3 stars → Judge.me (private resolution — captures complaints before they go public)" and "4–5 stars → Trustpilot (public — builds review count where it matters for acquisition)".

## UGC affiliate trigger (TRIGGER: post-delivery enthusiasm window)
- Verbatim (SP): "Klaviyo trigger: 2–3 weeks post-delivery (after product experience, before enthusiasm fades)"
- Two binary questions (SP): "Do you love it?" and "Do you want to earn money?"
- Verbatim (SP): "Google Drive UGC upload link in same email (remove friction from submission)"

## Peak-period cadence (TRIGGER: peak season / geography)
- Verbatim (SP): "During Black Friday weekend: 9+ campaigns across channels (email + SMS + WhatsApp)"
- Geography (SP): "Thanksgiving sends go to US only, exclude UK — geographic relevance increases engagement"

## Value-withheld voucher CTA (TRIGGER: review-request CTA)
- The CTA omits the numeric voucher value.
  - Verbatim (SP): "get a gift voucher" not "get £10 voucher"
  - Verbatim rationale (SP): "withholding the value increases click-through without anchoring expectations"
