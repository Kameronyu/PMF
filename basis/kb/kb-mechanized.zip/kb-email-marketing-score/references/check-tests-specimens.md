# Per-check membership tests + the COUNTABLE gate definitions

All 8 checks are COUNTABLE → script gates. Each test is all-YES to pass; any can return FALSE.
Each `pass` must carry an `evidence_quote` that is a verbatim substring of the setup being scored.

## Check 1 — Baseline-flow floor (enum, contains-all)
- `flow_set ⊇ {welcome series, abandoned checkout, sunset/re-engagement, engagement}`
- PASS iff all four enum members are present. FAIL → cap band at GAP (floor override).
- Source floor (CW): "Minimum viable email flows: welcome series, abandoned checkout, sunset/re-engagement, engagement flows — these are floor, not ceiling"
- Anchor (CW): "Basic email flows (welcome series, abandoned checkout, sunset, engagement re-activation) are minimum requirements — table stakes — not competitive differentiators."

## Check 2 — Flow length (count bound)
- `flow_email_count >= 15`
- PASS iff count ≥ 15. Source (MB): "Overall flows should be 15–20 emails minimum."
- Pitfall foil (MB): "Making abandoned cart sequences too short; counterintuitively, longer sequences recover more revenue"

## Check 3 — Broadcast cadence + ratio (equals + threshold)
- `email_per_week == 3` AND `promo_share <= 0.20` AND `sms_per_week <= 0.5`
- PASS iff all three hold. Sources (MB): "3 broadcast emails per week"; "80% value content / 20% promotional/selling content"; "1 message every two weeks (avoid SMS fatigue)".
- Over-send foil (MB): "Over-sending SMS (more than 1–2/month) causes list fatigue and opt-out spikes"

## Check 4 — LTV:AOV ratio (numeric threshold)
- `ltv / aov >= 3.0`
- PASS iff ratio ≥ 3.0; below → flag underperformance. Source (MB): "A sub-3:1 ratio signals underperformance in one or more of: email flows, SMS flows, upsell processes, or retargeting ads."

## Check 5 — Engaged-segment window (equals + exclusion)
- `engaged_window_days == 180` AND `send_audience excludes >180-day-unengaged`
- PASS iff both hold. Source spans (SP, verbatim): "opened OR clicked in last 180 days"; "Never send campaigns to your full list — only to engaged segment".
- Risk foil (SP): "30K unengaged + 30K engaged in same send = spam classification risk for ALL future sends"

## Check 6 — Day-one discount pop-up (presence + threshold)
- `popup_live_at_launch == true` AND `discount_pct >= 10`
- PASS iff both hold. Source (SP): "10%+ discount offer on pop-up, live from day one — do not delay".

## Check 7 — Refund-survey (count bound)
- `survey_question_count >= 2`
- PASS iff ≥ 2 questions. Source (SP): "Two-question minimum structure". Target context (SP): "Refund-incentivized survey (target: 5 refunds/month → reduces disputes and captures honest feedback)".

## Check 8 — Affiliate commission floor (numeric threshold)
- `commission_pct >= 10`
- PASS iff rate ≥ 10. Source (SP): "Commission: 10% minimum viable floor".

## Why the tiers
Hard-gating these is reproducible and safe: a flow is or is not in the enum; a count, a
ratio, a window, a percentage is what it is. The revenue-contribution figures are kept as
bands (see `benchmark-specimens.md`) because they are diagnostic context, not a pass/fail the
setup controls; forcing them into a gate produces confident-but-wrong FALSEs.
