# Per-field membership tests + the COUNTABLE gate definitions

All YES = the field passes; any can return FALSE. Countable fields lower to a script; the
felt field lowers to a pairwise comparison against `voice-specimens.md`.

## Field 1 — Function-fit (COUNTABLE — script gate)
- `function ∈ {overcome_objection, install_belief}` — exactly one value, echoed verbatim
  from the enum.
- PASS iff exactly one function is selected. Two functions or none → FAIL.
  Rationale: each testimonial placed in comments should serve exactly one of two functions.

## Field 2 — Target-named (COUNTABLE — script gate)
- `names_objection = has(objection token)` where token ∈ {price, skepticism, complexity,
  and other named buyer objections} — see registry **Objection handle**.
- `states_belief = has(a "they think X is true" purchase belief)` — see registry **Belief**.
- PASS iff `names_objection OR states_belief`. Neither present → FAIL.

## Field 3 — Not-generic (COUNTABLE — script gate)
- PASS iff `names_objection OR states_belief` (the inverse of generic praise).
- FAIL iff it addresses no objection AND installs no belief — a wasted social-proof slot.

## Field 4 — Reply-to-all-planned (COUNTABLE — script gate)
- `reply_to_all = the deployment plan replies to every ad comment, not only planted ones`.
- PASS iff present. Selective reply (only testimonials answered) → FAIL → flag inauthentic.
- Mirrors ROUTE R3.

## Field 6 — Specific-outcome (HEURISTIC — soft-cap/warn, not a hard gate)
- `has_specific = a named outcome OR a concrete detail is present` (not generic adjectives).
- WARN if absent; do NOT hard-fail — specificity-of-language judgment over-flags.

## Field 7 — Slot-not-overloaded (HEURISTIC — soft-cap/warn, not a hard gate)
- Count of testimonials in the comment slot reads organic, not manufactured.
- WARN if the slot looks overloaded; source gives NO numeric threshold, so never hard-fail.

## Field 5 — Customer-voice (FELT — pairwise only, NEVER a membership gate)
Do **not** write a yes/no test for Field 5. Judge voice by comparing the testimonial to a
customer-voice specimen (`voice-specimens.md`): does this read more like a real customer
than the specimen does? Return `prefer | tie | weaker`. This is the field the triage flagged
as FELT — keep it a signal, never a hard FALSE.

## Why the tiers
Hard-gating a felt field produces confident-but-wrong FALSEs and pushes selectors toward
gaming the gate. Hard-gating a countable one (a function is or isn't one of two; an objection
token is or isn't present) is reproducible and safe. Soft-cap the in-between (specificity of
language, testimonial volume) because the detectors over-flag.
