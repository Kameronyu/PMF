# Voice specimens — what to judge Field 5 (customer-voice) against

Field 5 is scored **pairwise against these**, not on an absolute scale and never by the
model that wrote or selected the candidate. The source ships no full customer-voiced
testimonial, so the positive reference here is the one belief-bearing copy fragment the
source does carry, plus the criterion language. Ask: does the candidate read more like a
real customer than this reference does? → prefer | tie | weaker.

## Customer-voice / belief reference (judge Field 5 against this)
- The source's own belief-function fragment, reinforcing a core purchase belief:
  "this worked even when X didn't"
- The target shape, stated by the source: written in natural customer language, specific
  and outcome-oriented — not polished marketing copy.

Ask: does the candidate make a prospect in a verification mindset read it as a peer, the way
this fragment does? → prefer | tie | weaker. `weaker` contributes no DEPLOY-lift.

## Brand-voice anti-patterns (deliberately NOT customer-voice — do not score as wins)
These are the foils the source names; a candidate that reads like these loses Field 5 and
trips the generic-praise gate (Fields 1–3).
- anti-pattern (generic praise, no objection, no belief): "great product!"
- anti-pattern (generic praise, brand-voiced, wasted slot): "Love this brand!"

## How to run the pairwise judge
1. Present candidate + the customer-voice reference, order randomized.
2. Ask which reads more like a real customer and why (criteria before verdict).
3. Record `prefer | tie | weaker` + the reason. `weaker` contributes no DEPLOY-lift.
4. Never let the model that generated or selected the candidate be the judge.
