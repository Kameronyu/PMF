# Specimen bank — verbatim winning funnel copy, with the angle each executes

Preserved verbatim from `funnel-architecture--mark-builds-brands.md`,
`funnel-architecture--carl-weische.md`, and
`funnel-architecture-quiz-funnel-landing-pages-advertorial--mark-builds-brands.md`.
These are the highest-value asset in the skill — study and adapt, do not abstract into
templates. Each specimen shows the *form* of a good answer; that is what steers a model.

## Advertorial hero (outcome / threat framing)
- "Save your skin, hair and health from disaster with this disruptive shower head"
  — angle: outcome + threat ("save," "disaster"); the product is the rescue, never the subject.
  Strong enough to carry a shortened funnel (advertorial straight to order page).

## Congruent landing-page headline (ad → page message-match)
- "anywhere all weather shoes made for adventuring"
  — angle: travel/adventure, mirroring a travel-photographer ad of waterproof shoes in Iceland.
  The page repeats the ad's exact promise in desire-language; congruency, not features, converts.

## First-person transformation lead (POV-story advertorial)
- "From foot pain victim to pain-free in 30 days"
  — angle: before-state, then after-state, then a concrete timeframe; told as a relatable
  consumer's story (paired in source with a persona like Maria, 58), not an expert pitch.
  Disarms because it reads as someone like the reader.

## Quiz hook question (low-friction, self-identifying)
- "What's your biggest challenge with X?"
  — angle: costs nothing to answer and is about the prospect's own problem, not the product;
  the answer is the segmentation signal for the tailored offer that follows.

## Quiz question strategy — how to structure the questions after the hook
The hook question (above) only opens the quiz. The questions that follow are a deliberate
micro-commitment sequence; write them to carry these three mechanics (verbatim from source,
funnel-architecture--mark-builds-brands.md):
- **Gradualization:** Avoids abrupt ad-to-purchase transition; low-barrier questions build momentum
- **Micro-agreements:** Each quiz question increases commitment and reduces purchase friction
- **Seeding:** Installs empowering beliefs that pre-overcome product objections before sales page

So: keep early questions low-barrier so the reader keeps answering; let each successive answer
extract a slightly larger agreement; and phrase questions to plant the empowering beliefs the
sales page will later harvest, so objections are pre-overcome before the pitch. The whole quiz
"uses micro-commitment psychology to make purchase feel inevitable."

## Bottom-of-funnel scarcity (offer-aware only)
- "only seven pairs left"
  — angle: concrete, countable scarcity on a BOGO / offer page; specific number beats
  "limited time." Use only when the reader is already offer-aware.

## High-AOV VSL CTA wording (reduces commitment anxiety)
- "Check Availability"
  — angle: on a high-ticket VSL CTA (source: $200+ price threshold), this wording reduces
  commitment anxiety. Verbatim source rule: 'CTA text: "Check Availability" (not "Buy Now") —
  reduces commitment anxiety.' Reach for it instead of a hard "Buy Now" on education-first,
  no-price-shown VSL pages.

## Listicle format label (skimmable, generic-angle / younger / TikTok traffic)
- "Seven Reasons Why"
- "Top 5 Reasons"
- "10 Benefits"
  — angle: faster to consume than long-form advertorial; reach for these on broad introductions
  and short-attention traffic. Format is a compelling headline + key benefits with images + CTA.

> Note: every specimen here was lifted as a real substring from the source. When you adapt one,
> keep its angle and its concreteness; replace the noun, not the structure of the feeling.
