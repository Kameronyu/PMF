# Optional page patterns — anatomy + a note each

Reach for one when it fits the awareness stage and the angle. None is a required slot order;
forcing a fixed sequence produces same-y, compliant copy — the opposite of what a page that has
to stop a reader needs. Use these to vary, not to standardize.

## POV-story advertorial (problem-aware / unaware)
First-person narrative from a relatable consumer persona (lifestyle blogger, not an expert).
Open on the before-state, walk the lived journey, land on the after-state. The author being
"someone like me" is what disarms.
- Example lead: "From foot pain victim to pain-free in 30 days" (persona e.g. "Maria, 58").

## Authority advertorial (skeptical / educated)
Expert- or doctor-authored; mechanism-focused. Educate on the problem, the cost of inaction, and
the solution, then close. The ad should already be mechanism-focused so the page stays congruent
(e.g. a "recommended by a doctor" badge on the product page).

## Listicle ("Seven Reasons Why")
Skimmable numbered format for generic angles, broad introductions, younger audiences, and
short-attention traffic (e.g. TikTok). Faster to consume than long-form advertorial.
Shape: compelling headline + key benefits with images + CTA with an exclusive offer.

## Congruent LP headline
Mirror the winning ad's angle, language, and visual promise in the page headline so the page
proves the ad was true. Carry the same visuals through to checkout.
- Example: "anywhere all weather shoes made for adventuring" (mirrors a travel/adventure ad).

## Quiz hook question
The first question must be low-friction and immediately relevant to the prospect's
self-identified problem — never the product. The answer segments the reader toward a tailored offer.
- Example: "What's your biggest challenge with X?"

## Pre-sale warming lead
Open by articulating the problem better than the prospect can themselves, congruent with the ad,
showing both the pain and the aspirational goal above the fold — before any pitch. The CTA comes
later in the page, not at the top.
