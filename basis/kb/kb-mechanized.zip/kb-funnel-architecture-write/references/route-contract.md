# Route contract — funnel-type selection and page-section sequences

These are STRUCTURAL contracts. They route which page you write and set the ORDER of beats.
They never dictate the wording inside a beat — that is the writer's felt job (see SKILL.md and
specimen-bank.md). Use this to pick the form; do not let it cage the words.

## Funnel-type selection by awareness stage

- Advertorial funnels (Types 1 & 2) target top and middle of funnel; direct product and BOGO
  funnels (Types 3 & 4) target the bottom.
- Funnel 1 (POV-story advertorial) = problem-aware / unaware.
- Funnel 2 (authority advertorial) = skeptical / educated.
- Funnel 3 (direct product / BOGO) = offer-aware only.
- Funnel 4 (BOGO, bottom-of-funnel) = high-awareness only.
- Quiz-funnel stage matching: Unaware → problem-aware uses ad or advertorial content and does
  NOT mention the product; solution-aware → product-aware uses a sales page or VSL.
- Quiz funnel form spec (source: funnel-architecture--carl-weische.md): when you choose the quiz
  form, the expected shape is an 18-slide structure — "11 diagnostic questions + 2 info/trust
  slides + summary and solution framing slides" (full sequence: Ad → 18-slide diagnostic quiz →
  personalized sales page; every answer collected feeds personalization on the product page).
- Default to a PDP for standard-complexity traffic; extend the funnel only for $2,000+
  high-ticket, heavy-education problem-aware traffic, or post-VSL traffic.
- Influencer-sourced traffic (source-keyed congruency route): write to a dedicated offer page
  co-branded to that specific influencer (their color scheme/branding + a dedicated about-them
  section), with standard conversion sections retained below. The angle is audience-to-page
  message match — mirror the influencer's content, not the generic ad. (Full rule + verbatim
  source: kb-funnel-architecture-score/references/ecosystem-and-expansion.md.)

### Conflict to escalate (do not negotiate in copy)
Spencer "default to PDP for cold" vs. Weische/Mark "always pre-sell for cold." Resolve by
operator stage + product complexity: early-stage unit-economics testing → PDP; scaling /
brand-funded → advertorial. Keep as a branch keyed on stage; flag for human-review consistency.

## Page-section sequences (ordered beats; wording is the writer's)

- Pre-sale warming sequence (1–6): pain → why past attempts failed → consequences → desire →
  mechanism → CTA.
- 8-step advertorial structure: desired state → current state → other options → introduce →
  explain → why now → objections/guarantee → CTA.
- Pre-sale 4-part: Introduction → Education → Transition → Pitch.
- Six mandatory sales-page sections: Hero → Storytelling → Trust → Objection → Offer → Security.
  - Hero anatomy (source: funnel-architecture--carl-weische.md). The hero "must answer 8 questions
    via product images: what they buy, what's in it for them, is it for them, what they get, can
    they trust the product, who is it from, can they trust the brand, is it worth it." Hero
    must-include list: "product images, title, reviews, one-sentence value prop, variant
    selection, discount pricing, scarcity indicator, CTA, express delivery info, trust badges."
- LP conversion sequence: Hook → Problem → Solution/mechanism → Proof → Offer → Objection →
  CTA + risk reversal.

## Placement triggers

- Introduce the CTA 50–75% through the page, not at the top.
- Cold traffic → full funnel (Ad → Advertorial → Sales → Order → OTO → Thank You).
  Warm traffic (prior exposure) → Shopify PDP or sales page directly, to avoid funnel fatigue.
- Place a units-sold badge at CHECKOUT (not only the PDP) because hesitation spikes there.
- CRO trust-signal priority order: photo reviews → UGC → units-sold at checkout →
  checkout badges → niche PDP copy.
