# Per-criterion membership tests + the COUNTABLE gate definitions

## Membership tests (all YES = the criterion passes; any can return FALSE)

**C1 Guarantee specificity (COUNTABLE — script gate)**
- `has_timeframe = matches a window token ("30-day", "60 day", "for 90 days", "N-day")`.
- `has_risk_reversal = contains-any("refund", "money-back", "money back", "no-questions",
  "no questions asked", "guarantee")`.
- PASS iff `has_timeframe AND has_risk_reversal`. A guarantee CLAIM present but missing either
  → FAIL → caps band at REWORK (guarantee override).
  FALSE example: "satisfaction guaranteed" → no timeframe → FAIL.
  PASS example: the guarantee specimen in `scoring-specimens.md` (timeframe + no-questions refund).

**C2 No reset/recycling timer (COUNTABLE — script gate)**
- `reset_timer = a countdown/urgency device whose deadline recomputes per visit/reload`
  (e.g. evergreen timer keyed to first-view, a timer that restarts on refresh).
- PASS iff no reset timer present. A detected reset timer = FAIL → caps band at REWORK
  (reset-timer override). This is the deterministic tell of manufactured scarcity.

**C3 Scarcity credibility (HEURISTIC — soft-cap, never hard-fail)**
- Is the scarcity/urgency claim plausible (an oddly specific real count, not a round
  placeholder) AND substantiated (a stated reason: batch release, production-limited run)?
- Soft-cap (record + drop one band) on: round/implausible counts, "limited stock" with no
  number, urgency with no explained reason. Never a hard FALSE on judgment alone.

**C4 Guarantee prominence (HEURISTIC — soft-cap)**
- Does risk reversal appear as a lead/headline feature AND repeat at checkout (not fine print)?
- Soft-cap on burial — risk reversal present only in footer/terms. Names the burial location.

**C5 Authority substance (HEURISTIC — soft-cap)**
- Does the authority claim SHOW evidence — a credential, media logo, demonstrated proof, or an
  Extraordinary identifier (named celebrity / major press / credentialed authority)?
- Soft-cap on bare claim ("expert-formulated") with nothing shown. Never a hard FALSE.

## FELT criteria (pairwise only, NEVER a membership gate)

**C6 Social-proof specificity (FELT — signal)**
Do **not** write a yes/no test. Judge against a proof specimen in `scoring-specimens.md`: is
this proof more specific, named, and relatable than a bare star rating? Return
`prefer | tie | weaker`. `weaker` contributes no pass. This is the criterion not to launder
into "is it generic? → FALSE"; keep it a signal.

**C7 Proof-audience match (FELT — signal)**
Judge pairwise: does the testimonial match the prospect's identity/aspiration (Awareness level
and avatar) better than the specimen does? Return `prefer | tie | weaker`. Never a hard FALSE.

## Why the tiers
Hard-gating a felt criterion ("is this proof generic?", "does it match the audience?") produces
confident-but-wrong FALSEs and pushes writers to game the gate. Hard-gating a countable one
(a timeframe token is or isn't present; a timer does or doesn't reset) is reproducible and safe.
Soft-cap the in-between (scarcity credibility, prominence, authority substance) because those
detectors over-flag — a warn that drops a band, not a kill.
