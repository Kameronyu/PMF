# Scoring specimens — the known-good fragments to judge against

Preserved VERBATIM from the source KB files. FELT criteria (C6 proof specificity, C7
audience match) are scored **pairwise against these**, never on an absolute scale and never
by the model that wrote the candidate. Randomize order; penalize vagueness; treat any single
score as a triage signal, not a certification. The COUNTABLE gates (C1, C2) are scored by the
script, not against these — these are sanity references for what passing looks like.

## Guarantee specimen (sanity-check C1 winners — timeframe + risk-reversal)
- "30-day no-questions-asked refund"

Ask of a candidate guarantee: does it carry BOTH a concrete window AND money-back language
the way this does? The script (C1) decides PASS/FAIL; this is the shape of a pass.

## Scarcity specimen (sanity-check C3 — oddly-specific, credible count)
- "Only 47 units left at this price,"

A real, oddly-specific number reads as credible. A round placeholder or "limited stock" with
no number soft-caps C3.

## Authority specimen (sanity-check C5 — shown, not claimed)
- The source's media-logo cue: media logos ("as seen in")

Authority that SHOWS a third-party signal (credential, media, demonstrated proof) beats a bare
claim of expertise.

## Buyer-voice objection specimens (judge C7 proof-audience match against these)
The objections proof must answer in the prospect's own voice:
- "I don't know this brand"
- "What if it doesn't work for me?"
- "Will it actually work for me?"
- "Is this too complicated?"

Ask: does the candidate's proof speak to the prospect that voices these, in their identity and
aspiration? → prefer | tie | weaker.

## Ethical bright-line (governs deployment, not a score)
- "Persuasion that helps → ethical. Persuasion that exploits → unethical and long-term brand-destructive."

## Named worked-example stacks (reference baselines for stack completeness)
These are the source's named offer exemplars. Use them to judge whether a candidate stack
reaches the validated baseline of element coverage — not as a per-criterion gate.
- Nusk (validated baseline): "Nusk offer: incorporated guarantees (certainty) + social proof + urgency as core conversion stack."
  - "Stacking social proof + guarantee + urgency (the Nusk stack) is a validated baseline for cold offer conversion"
- Cogut Beauty (objection-mapped): "Cogut Beauty offer: social proof + guarantees + multi-objection handling (time, effort, results) layered throughout funnel."

A stack that covers fewer objection categories than the Nusk baseline (social proof +
guarantee + urgency) is under-stacked — note it; do not hard-fail on it.

## How to run the pairwise judge (C6, C7)
1. Present candidate + one specimen, order randomized.
2. Ask which better satisfies the named criterion and why (criteria before verdict).
3. Record `prefer|tie|weaker` + the reason. `weaker` contributes no pass for that criterion.
4. Never let the model that generated the candidate be the judge.
