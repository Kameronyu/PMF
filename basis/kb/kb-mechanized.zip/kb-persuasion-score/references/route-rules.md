# ROUTE rules — selection / sequencing contract (no wording, no quality verdict)

These choose and order persuasion elements by a NAMED trigger. They dictate no copy and
assign no pass/fail — they are the contract the scorer respects, not a graded criterion.

## 1. Objection → element selection (Objection handle)
| Buyer objection (named trigger) | Element(s) that neutralize it |
|---|---|
| "I don't know this brand" | Authority + Social Proof |
| "What if it doesn't work for me?" | Certainty (guarantee) |
| "I'll think about it" | Urgency + Scarcity |
| "Anyone can buy this" | Exclusivity |

## 2. Universal cold-traffic objections → counter
- **Time** ("Will this take too long?") → speed claims, ease-of-use proof.
- **Effort** ("Is this too complicated?") → simplicity framing, done-for-you angles.
- **Results** ("Will it actually work for me?") → guarantees, before/after proof, specificity.

## 3. Stack priority (cold offers)
Social Proof + Certainty first (trust + risk removal) → then Urgency/Scarcity to close
(action triggers). Authority amplifies all other elements when present.

## 4. Placement
Social-proof artifacts (review counts, star ratings, before/after, named testimonials) embed
in ad creative AND landing pages — not one or the other.

## 5. Cialdini sequencing (the canonical order)
liking/similarity → demonstrate authority → deploy social proof → give first (reciprocity)
→ secure micro-commitment → introduce scarcity (genuine only) → make the ask.
Laws compound when sequenced; isolated tactics underperform.

## 6. Ethical gate (when NOT to deploy) + dual-use meta-framework
Persuasion knowledge is dual-use: it can protect or exploit. The source names a two-part
ethical application framework, with the DEFENSIVE half as the highest-priority use:
- **Defensive Application (Primary Use):** Knowledge of persuasion laws allows recognition of
  manipulation attempts directed at you — by advertisers, salespeople, politicians, and bad
  actors. This is the highest-priority use of the knowledge. Recognizing reciprocity traps,
  false scarcity, and manufactured social proof prevents exploitation.
- **Offensive Application (Secondary Use, Constrained):** Persuasion techniques are ethical
  when used to help others reach decisions that genuinely serve their interests. The
  constraint: never deploy psychological leverage against the target's actual interest.
- **The Bright Line:** Persuasion that helps → ethical. Persuasion that exploits → unethical
  and long-term brand-destructive. Trust compounds over time; manipulation erodes it faster
  than it builds.

Introduce scarcity only when genuine; never manufacture false deadlines. (This is the
boundary the C2 reset-timer gate and the C3 credibility soft-cap mechanically enforce.)

## 7. Channel selection
Online, social proof + reciprocity lead — Trust signals must substitute for in-person
relationship-building. Prefer video testimonials over text when credibility cues matter
(real person, real voice). Authority online proxies via media mentions, certifications,
follower counts, and demonstrated expertise in content.
