---
name: kb-ecommerce-write
description: >-
  Write the felt reframe, thesis, and framing lines that carry an ecommerce strategy —
  the sentence that flips how a founder reads ad losses, competition, retention, or
  scarcity. Use when wording (not numbers) is the deliverable: a "buying data" loss
  reframe, a "channel demand, don't create it" thesis, a value-first backend prompt, or
  pre-order scarcity copy. Leads with real winning specimens and a few craft targets;
  patterns are OPTIONAL, never required slots. This skill WRITES; it does not grade its
  own output — score separately with kb-ecommerce-score (a different pass, ideally a
  different model). Triggers: "reframe this", "how should I phrase this strategy",
  "write the scarcity / pre-order line", "say this so the founder feels it".
---

# Ecommerce — write the line that reframes the strategy

Most of ecommerce is countable: margins, thresholds, funnel math (that lives in
**kb-ecommerce-score**). This skill is the thin slice where the *wording* is the payload —
the one sentence that changes how someone reads a loss, a competitor, or a stockout. Your
job is the felt line, not the spreadsheet. Lead from the specimens below; reach for a
pattern only if it helps; keep it short and direct.

## Start here — real winning specimens (study these before writing)

These are preserved verbatim from the source. They steer you harder than any rule. Do not
abstract them into slot templates — the example is the asset.

- **Loss reframe (the founder is bleeding cash on ads):** *"When you spend money on ads and aren't immediately profitable, you're not losing money—you're buying data."*
  — renames the painful thing into an asset the reader already paid for; no exhortation, just a re-categorization that defuses the panic.
- **Demand thesis (founder hunting for a product with no competition):** *"You cannot create mass desire, you channel it."*
  — compresses a whole strategy (Schwartz) into a refusal + a redirect; the second clause hands back the move, so it steers instead of just scolding.
- **Compete-differently thesis:** *"The goal is to compete differently through superior angle, funnel, or execution—not to find products with zero competition, which is counterintuitively harder."*
  — names the real lever, then closes the escape hatch ("counterintuitively harder"); reframes competition as validation, not a wall.
- **Retention truth (founder optimizing upsells to fix churn):** *"You can't profit hack your way to a great retention rate"*
  — one flat line, no hedge; the casual verb "profit hack" carries the contempt that makes it land.
- **Backend value prompt (what question to lead product dev with):** *"How can I provide more value to help customers get better results?"* — not *"How can I upsell this?"*
  — steers thinking by swapping the *question*, not the answer; the contrast pair does the work.
- **Pre-order scarcity copy (real stockouts, customer-facing):** *"Sold out four times this year — pre-order now to reserve yours"*
  — a specific, verifiable count ("four times") turns a delay into proof of demand and converts scarcity into a reason to act now.
- **Mindset maxim (founder rattled by a revenue dip):** *"Skill is permanent; revenue is not"*
  — a clean inversion; the parallel structure makes it memorable and reframes a loss as an investment. This maxim sits inside the **Valley of Despair / Cycle of Change** 5-stage model (with the quit-at-Stage-3-resets rule, the conviction-vs-motivation distinction, and the 30–60 day timeline) — the full framework is in `kb-ecommerce-score/references/frameworks.md`. Lean on it when steering a founder through Stage 3 (Valley of Despair).

- **Success-formula thesis (founder over-betting on one element):** *"Good product + Good creatives + Good funnel = Success"*
  — the named E-Commerce Success Formula; reframes success as a three-way AND, not a single winning product. Scale-invariant; weakness in any one element undermines the others.

More on what each line is doing, and which strategy it carries, is in `references/specimen-bank.md`.

## Craft targets (steer by these; they are not a rulebook)

- **Re-categorize, don't exhort.** The strongest lines here rename the painful thing
  (loss → data, competition → validation) instead of telling the reader to try harder.
- **Specificity over superlative.** "Sold out four times this year" beats "extremely
  popular." A concrete count or named lever is the pull.
- **Hand back the move.** A refusal ("you cannot create desire") lands harder when the
  same line gives the redirect ("you channel it"). Don't just close a door.
- **Contrast does the work.** The value-first prompt works because the wrong question sits
  right next to the right one. Let the pair carry the point.
- **Fewest words that keep the meaning.** Draft, then cut every word that adds no new
  information or pull. The maxims above are short on purpose.

## Optional patterns (reach for one; never force a fixed slot order)

Loss-Reframe · Refusal-then-Redirect · Wrong-Question/Right-Question · Specific-Scarcity ·
Inversion-Maxim. Each is a shape to borrow, not a required sequence. Anatomy and a worked
example for each is in `references/patterns.md`.

## Contract rules (these DO bind — they pick the shape, not the words)

- **Awareness routing:** use a *thesis* reframe (demand / compete-differently) for a
  founder still **strategy-unaware** (chasing products with no competition); use a *tactical*
  reframe (loss → data, value-first prompt) once they're executing and reading their own
  numbers wrong.
- **Scarcity copy must be true.** Deploy the pre-order / "sold out N times" line only when
  the stockout count and demand are real and verifiable, and (per source) only with
  existing reviews for credibility — anchor the line to the real stockout count the founder
  gives you.
- **Value-first prompt is for backend/product thinking**, not front-end ad copy — it
  steers what to build, not what to claim.

## How to use this with the grader

Write the reframe (often several variants), then hand them to **kb-ecommerce-score** — a
separate skill, ideally a different model — for the gates and the pairwise-vs-specimen
judgment. Leave the grading to that pass: a writer that judges itself drifts toward
"sounds like a reframe," not "actually re-categorizes the problem." Reading-level,
banned-phrase, and verbatim-scarcity checks live there.

## Before handoff (what kb-ecommerce-score checks)

Generate several diverse drafts; the separate scorer grades — do not self-grade toward the
gate. These are the dimensions the scorer will weigh, kept here only as awareness so your
drafts give it something to work with:

- Whether the line re-categorizes or redirects, rather than just exhorting the reader to try harder.
- Whether it is as short as the meaning allows, with no hedge diluting the turn.
- Whether it carries at least one concrete specific (a count, a named lever) where one is available.
- For scarcity copy: whether the claim is literally true and verifiable.
- Whether you produced a few variants rather than one polished safe line.
