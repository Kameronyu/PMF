# Optional patterns — anatomy + a worked example each

Reach for one when it fits the situation. None is a required slot order; forcing a fixed
sequence is what produces same-y, compliant lines. Use these to vary, not to standardize.

## Loss-Reframe
[name the painful number] + [re-categorize it as an asset the reader already paid for].
- Renames the thing rather than arguing against the feeling. No exhortation.
- Example: "When you spend money on ads and aren't immediately profitable, you're not losing money—you're buying data."

## Refusal-then-Redirect
[refuse the reader's instinct] + [hand back the actual move in the same breath].
- The redirect is what turns a scold into steering; never close a door without opening one.
- Example: "You cannot create mass desire, you channel it."

## Wrong-Question / Right-Question
[the extraction question] set against [the value question].
- The contrast pair carries the point — keep both halves; the wrong one makes the right
  one legible.
- Example: "How can I provide more value to help customers get better results?" not "How can I upsell this?"

## Specific-Scarcity
[a concrete, verifiable count] + [the action that reserves supply].
- A real number turns a delay into proof of demand. Must be literally true.
- Example: "Sold out four times this year — pre-order now to reserve yours"

## Inversion-Maxim
[X is permanent] + [Y is not] — or any tight parallel that flips a loss into an investment.
- Parallel structure makes it memorable; brevity makes it land.
- Example: "Skill is permanent; revenue is not"
