# Specimen bank — verbatim winning lines, with the strategy each carries

Preserved verbatim from `ecommerce--carl-weische.md` / `ecommerce--mark-builds-brands.md` /
`ecommerce--spencer-origins.md`. These are the highest-value asset in the skill — study and
adapt the *form*, do not abstract them into slot templates. The numbers and thresholds these
lines reference belong to **kb-ecommerce-score**; here only the wording matters.

## Loss / cost reframe (turn a painful number into an asset)
- "When you spend money on ads and aren't immediately profitable, you're not losing money—you're buying data."
  — strategy: early ad spend is a paid-learning investment, not a failure. Renames "loss"
  as "data" the reader already bought. Use when a founder is panicking at break-even or
  negative early ROAS.

## Demand thesis (channel demand, don't manufacture it)
- "You cannot create mass desire, you channel it."
  — strategy: validate proven market demand instead of inventing a new one (Schwartz,
  *Breakthrough Advertising*). Refusal + redirect in seven words.
- "The goal is to compete differently through superior angle, funnel, or execution—not to find products with zero competition, which is counterintuitively harder."
  — strategy: competition is validation; differentiate on angle/funnel/execution rather
  than hunting an empty market. Names the lever, then closes the escape hatch.

## Retention truth (product quality > upsell hacking)
- "You can't profit hack your way to a great retention rate"
  — strategy: retention is driven by product results and enjoyment; upsell/SMS tooling is
  secondary. Flat, contemptuous of the shortcut. Use when a founder treats churn as a
  funnel problem.

## Value-first backend prompt (the question to lead product dev with)
- "How can I provide more value to help customers get better results?"  — contrasted against the wrong question, "How can I upsell this?"
  — strategy: lead backend/product development with the value question, not the extraction
  question. The contrast pair is the device; keep both halves.

## Specific scarcity copy (customer-facing; must be true)
- "Sold out four times this year — pre-order now to reserve yours"
  — strategy: convert real stockouts into proof of demand and a reason to act now. Deploy
  only with a true, verifiable count and existing reviews for credibility (per source).

## Success-formula thesis (the whole game in one line)
- "Good product + Good creatives + Good funnel = Success"
  — strategy: the named E-Commerce Success Formula (Mark Builds Brands). It is
  "Scale-invariant from $1,000/day to $100,000/day" and "Weakness in any single element
  undermines the others." Use when a founder is over-indexing on one element (usually the
  product) — the line reframes success as a three-way AND, not a single winning bet. The
  full framework (and its multiplicative logic) lives in
  kb-ecommerce-score/references/restored-frameworks.md.

## Mindset / inversion maxim (reframe a revenue dip)
- "Skill is permanent; revenue is not"
  — strategy: ROAS drops, accounts get banned, products die, but skill compounds; early
  losses are skill-building investments. A clean parallel inversion.

> Note: these lines are felt steering, not generative copy templates. The ecommerce writer
> is a thin reframe/voice skill — most of the topic's payload is countable and lives in
> kb-ecommerce-score. Feed real founder context (the actual number they're misreading, the
> real stockout count) so the reframe lands on the truth, not a generic version of it.
