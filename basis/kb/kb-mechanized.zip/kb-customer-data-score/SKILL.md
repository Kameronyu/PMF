---
name: kb-customer-data-score
description: >-
  Score a qualitative-customer-data (VOC) research plan and its analyst synthesis for
  soundness before optimization decisions are committed. Use to grade a survey/mining plan
  plus the analyst's prioritized findings and return BLOCKED / VIABLE per the contract, with
  per-field evidence. Hard-gates only the countable (both cohorts present, mining-before-
  surveys, qual cross-referenced with quant); soft-caps the heuristic (every finding tagged
  with one fix-type); never self-grades. Run as a SEPARATE pass from the researcher.
  Triggers: "score this research plan", "is this VOC synthesis sound", "check cohort coverage",
  "validate these qualitative findings".
---

# Customer data — score a VOC plan + synthesis before you commit dev resources

Grade a research plan and its analyst output against the gates below, then emit the contract.
**Do not run this in the same pass that designed the plan or wrote the synthesis** — a producer
grading itself certifies its own gaps. Judge fix-type tagging pairwise against the specimens in
`references/synthesis-specimens.md`, ideally on a different model.

Tier discipline: **hard-gate only the countable** (cohort set, sequencing, convergence);
**soft-cap the heuristic** (fix-type enum coverage); **never hard-FALSE a felt judgment.**

## The judged fields (each: positive target → how it's judged → tier)

1. **Cohort coverage** — *target:* the plan surveys BOTH converted customers AND
   near-converters/churned customers. *Judge:* **script gate** — both cohort tokens present.
   Tier: COUNTABLE → **hard-gate** (missing either → FAIL).
2. **Mining-before-surveys** — *target:* message mining of existing communications precedes
   survey deployment. *Judge:* **script gate** — plan orders mining before surveys.
   Tier: COUNTABLE → **hard-gate**.
3. **Quant convergence** — *target:* each qual finding is cross-referenced against a named
   quantitative signal before dev resources are committed. *Judge:* **script gate** — every
   finding carries a `quant_signal`. Tier: COUNTABLE → **hard-gate**.
4. **Fix-type tagging** — *target:* every synthesized finding is tagged with exactly one
   fix-type from the enum {technical, messaging, offer}; output is a prioritized list, not
   vague suggestions. *Judge:* HEURISTIC — enum membership is checkable, but the assignment
   is a fuzzy boundary call with real false positives. Tier: HEURISTIC → **soft-cap / warn**,
   never hard-fail.
5. **Analyst pass present** — *target:* findings come from an analyst synthesis step
   (clustered by theme, prioritized), not raw responses acted on directly. *Judge:* **script
   gate** — synthesis step declared. Tier: COUNTABLE → **hard-gate**.
6. **Sufficient volume before analysis** — *target:* enough responses are accumulated before
   clustering / drawing conclusions (insufficient samples produce misleading clusters).
   *Judge:* **script gate** — adequate volume declared before the analyst pass. Tier:
   COUNTABLE → **hard-gate**. See `references/field-tests.md` Field 6.

Per-field membership tests and the enum/gate definitions are in `references/field-tests.md`.
These fields anchor on registry terms (PMBD, objection handle) without redefining them; see
`references/field-tests.md` for the cross-references.

## Verdict (derive from the gates that actually passed — not a hollow count)

- Any COUNTABLE hard-gate FAILs → **BLOCKED** (name the field; fix before acting).
- All hard-gates pass, fix-type tagging clean → **VIABLE** (findings may feed testing).
- All hard-gates pass but fix-type soft-cap warns → **VIABLE-WITH-WARN** (tag the untagged
  items before prioritizing).

A finding contributes to "prioritized list" only when it carries a fix-type tag AND a
`quant_signal`; an untagged or unreferenced finding never manufactures a pass on its own.

**Hypothesis override (structural):** findings are treated as hypotheses to validate with
quant testing, never as final decisions — a plan that commits dev resources before convergence
(field 3) FAILs regardless of other gates.

## The negatives live here (≤5), each paired with a positive target

Held in the checker, not the producer (where banning a pattern summons it):

- **Quant-only, no qual** → flag. (positive: pair quant "where/how much" with qual "why")
- **Surveys before message mining** → flag, fails field 2. (positive: mine first, then design
  questions from real customer language)
- **Skipping the analyst synthesis** → flag, fails field 5. (positive: require the analyst pass)
- **Single-cohort surveying** → flag, fails field 1. (positive: require both cohorts)
- **Treating findings as final** → flag, fails field 3. (positive: treat as hypotheses to
  validate with quant testing)

## Routing (ROUTE — what passing findings feed)

Open-ended survey responses, captured in the customer's own vocabulary, route to specific
consumers: headline testing, FAQ structuring, and objection-handling sections on PDPs and
landing pages. Convergence between a qual finding and a quant signal justifies an A/B test;
misalignment indicates a segment mismatch or sampling issue to investigate before acting.
See `references/synthesis-specimens.md` for the worked convergence example (shipping cost +
68% cart abandonment → free-shipping A/B test) and the technical-first prioritization rule.

## Output contract (per plan)

```
plan_id: "<id>"
fields: [ {n, target, verdict: pass|fail|warn, tier, evidence_quote, source} ]
countable_gates: {cohort_coverage, mining_before_surveys, quant_convergence, analyst_pass, sufficient_volume}  # script, pass/fail
heuristic_caps: {fix_type_tagging}                 # soft-cap, clean|warn
findings: [ {text: <verbatim quote of the analyst finding being scored, not generated prose>, fix_type: technical|messaging|offer, quant_signal, source} ]
verdict: BLOCKED | VIABLE | VIABLE-WITH-WARN
flags: [ ... ]    # from the negatives list
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every field has a verdict; verdict present; findings list non-empty.
**SOUNDNESS:** every COUNTABLE verdict came from the script (not eyeballed); fix-type tagging
is pairwise-vs-specimen, not self-graded; every fix_type is one of {technical,messaging,offer};
each `pass` carries a verbatim `evidence_quote`; verdict derived only from passed gates.
`emit_ready` only if SOUNDNESS holds; else `BLOCKED:<field>`.

## Self-test (is this grader sound?) — any NO, fix

- Are only the countable fields (1,2,3,5,6) hard-gated by script, with fix-type tagging (4) a soft-cap?
- Is the grading run separately from the plan-designer / synthesis-writer, against a real specimen?
- Does the verdict come from gates that passed their tier's check, not a raw count?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Is the hypothesis-override kept as a structural gate, and routing kept as a ROUTE rule?
- Is every quoted specimen a verbatim substring of a source file (no composites)?
