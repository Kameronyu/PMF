# Scoring specimens — the known-good wording to judge FELT/heuristic fields against

The heuristic field (fix-type tagging) is judged **pairwise against these**, not on an
absolute scale and never by the model that produced the synthesis. Treat any single tag as a
triage signal, not a certification.

## Open-ended survey-question specimens (what sound qual collection looks like)
These four question types capture customer vocabulary verbatim and feed the consumers in the
ROUTE rule. Judge whether a plan's questions are this open-ended and single-clause.

- "What was the primary reason you decided to purchase today?"
- "What almost stopped you from buying?"
- "What other solutions did you consider before choosing us?"
- "What result were you hoping to achieve?"

Ask: does the candidate's question elicit the customer's own words as directly as these do?

## Fix-type tagging reference (judge field 4 against these source anchors)
The two-tier output taxonomy that fix-type tags must map onto:

- Low-hanging fruit (→ `technical`): "immediately fixable technical/UX issues (site speed, bugs, broken flows)"
- High-leverage opportunities (→ `messaging` / `offer`): "deeper optimization targets informed by recurring language, objections, and motivations"

The analyst target the prioritized list must satisfy:

- "Output a prioritized recommendation list segmented by fix type (technical vs. messaging vs. offer)"

A finding that converts raw language into a roadmap, not vague suggestions:

- "This structured synthesis step is what converts raw customer language into a testing roadmap rather than a list of vague suggestions."

## Convergence reference (judge field 3 against this)
What a sound qual+quant cross-reference looks like:

- "Qualitative findings must be cross-referenced against quantitative signals to validate hypotheses before development resources are committed"

### Worked example — qual finding + named quant signal → justified A/B test
This is the only concrete demonstration of how a qualitative finding, a specific quantitative
signal, and a number combine into a justified test. A finding passes field 3 when it follows
this shape: a qual objection AND a named quant signal converge, and the convergence (not the
qual alone) is what justifies committing the test.

- "Example: if surveys reveal shipping cost as a top objection AND quantitative data shows 68% cart abandonment at checkout where shipping is first displayed, that convergence justifies immediate A/B testing of free shipping thresholds or shipping cost reveal earlier in the funnel."

Judge a candidate finding against this: does it carry BOTH a qual objection (e.g. shipping
cost) AND a named quant signal (e.g. 68% cart abandonment at the point shipping is shown), and
does the proposed test follow from their convergence? Misalignment between the qual and quant
signals is not a pass — it indicates a segment mismatch or survey sampling issue worth
investigating before acting.

## Prioritization reference (judge fix ordering against this)
When findings are tagged by fix-type, the technical tier is sequenced first — not by generic
impact/effort weighting but because technical/site-speed issues gate everything downstream.

- "Site speed and technical bugs are highest-priority immediate fixes surfaced by this process — they block all downstream conversion improvements"

A prioritized list that places a messaging/offer fix ahead of an open technical/site-speed
fix is mis-ordered: the technical fix blocks the downstream conversion gains the others depend
on, so it ranks first regardless of its own estimated revenue impact.

## How to run the pairwise judge
1. Present candidate finding + one specimen, order randomized.
2. Ask which better satisfies the named field and why (criteria before verdict).
3. Record `prefer|tie|weaker` + the reason. `weaker` contributes no pass for that field.
4. Never let the model that generated the synthesis be the judge.
