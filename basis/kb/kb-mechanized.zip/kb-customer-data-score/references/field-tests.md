# Per-field membership tests + the gate / enum definitions

## Membership tests (all YES = the field passes; any can return FALSE)

**Field 1 — Cohort coverage (COUNTABLE — script gate)**
- Does the plan survey converted customers (purchase-driver data)?
- Does the plan also survey near-converters or churned customers (abandonment-reason data)?
- PASS iff BOTH cohorts present. Missing either → FAIL. Both cohorts are required for full
  funnel insight: surveying only prospects misses purchase-driver data; surveying only
  customers misses abandonment-reason data.

**Field 2 — Mining-before-surveys (COUNTABLE — script gate)**
- Does message mining of existing communications (support inboxes, reply emails, reviews,
  social comments, community threads) occur BEFORE survey deployment?
- PASS iff mining precedes surveys. FAIL → flag: surveys-before-mining risks designing
  questions around internal assumptions rather than actual customer language.

**Field 3 — Quant convergence (COUNTABLE — script gate)**
- Does every qual finding carry a named `quant_signal` it is cross-referenced against?
- Are dev resources committed only AFTER that cross-reference?
- PASS iff every finding has a `quant_signal` AND no commitment precedes it. Convergence
  (qual + quant agree) justifies an A/B test; misalignment flags a segment/sampling issue.

**Field 4 — Fix-type tagging (HEURISTIC — soft-cap, judged pairwise vs. specimen)**
- `fix_type ∈ {technical, messaging, offer}` — exactly one per finding.
- ALLOWED VALUES (echo verbatim; WARN on any value not in this list, never hard-fail):
  - `technical` — immediately fixable technical/UX issues (site speed, bugs, broken flows).
  - `messaging` — copy insights from recurring language, objections, motivations.
  - `offer` — offer/flow opportunities (pricing, thresholds, funnel structure).
- Is the output a prioritized recommendation list, not a list of vague suggestions?
- Soft-cap: WARN on any untagged or off-enum finding; never hard-fail (boundary calls between
  messaging and offer have real false positives). Judge ambiguous tags pairwise against
  `references/synthesis-specimens.md`.
- Interpretation aid for typing a mined pattern: a high-frequency phrase / repeated objection
  signals either unaddressed friction (conversion killer → typically `technical` or an
  `offer`/messaging objection handle) or an underemphasized value prop (copy opportunity →
  `messaging`). Source: "High-frequency phrases and repeated objections in this corpus indicate
  either unaddressed friction (conversion killers) or underemphasized value propositions (copy
  opportunities)."

**Field 5 — Analyst pass present (COUNTABLE — script gate)**
- Is there a declared analyst synthesis step that clusters responses by theme/frequency and
  prioritizes by impact/effort, rather than acting on raw responses directly?
- PASS iff the synthesis step is declared. FAIL → flag: skipping it introduces confirmation
  bias and misses cross-theme patterns.

**Field 6 — Sufficient volume before analysis (COUNTABLE — script gate)**
- Does the plan accumulate a sufficient volume of responses BEFORE clustering / drawing
  optimization conclusions? (Source step 2: "Accumulate sufficient volume of responses before
  analysis"; reinforced in Key Metrics.)
- PASS iff the plan declares that adequate response volume is reached before the analyst pass
  clusters or before optimization conclusions are drawn. FAIL → flag: insufficient sample
  sizes produce misleading clusters.
- Source anchor (verbatim): "Collect qualitative data before drawing optimization conclusions
  — insufficient sample sizes produce misleading clusters"

### Prioritization rule (applies to field 4 ordering, not a separate gate)
When findings are tagged by fix-type, the technical tier ranks first because it gates the rest:
"Site speed and technical bugs are highest-priority immediate fixes surfaced by this process —
they block all downstream conversion improvements". A list that orders a messaging/offer fix
ahead of an open technical/site-speed fix is mis-ordered. See `synthesis-specimens.md`
(Prioritization reference) for the pairwise judge anchor.

## Why the tiers
Hard-gating a countable field (a cohort token is or isn't present; mining is or isn't ordered
before surveys; a `quant_signal` is or isn't attached) is reproducible and safe. Hard-gating
the heuristic fix-type assignment would produce confident-but-wrong FALSEs on genuine
messaging-vs-offer boundary cases, so it is a soft-cap warn instead.

## Registry anchor terms (cross-reference; never redefined here)
- **PMBD** — the customer-side data mined in VOC research (Pain, Belief, Motif, Desire); the
  "language, objections, decision drivers" this plan surfaces is PMBD output.
- **Objection handle** — the copy/structural element mined objections feed (PDP / landing-page
  / checkout). Field-4 `messaging` findings often become objection handles.
See `definitions.md` / `term_registry.json` for the canonical entries.
