# ROUTE rules — selection/sequencing contracts (check shape, do not grade copy)

These are named-trigger selection and sequence contracts the offer plan must obey. The scorer
checks the shape (right option for the trigger, right order); it does not grade wording — that
is the writer's job. Anchor terms (Awareness level, UM, Value models) are in the registry.

## Sequencing contracts (ordered — wrong order is a shape failure)

- **NTPMA dependency order** (also gate 8): Niche → Transformation → Price → Mechanism → Access
  Channel. Never build the mechanism before validating N-T-P; validate with committed money first.
- **Offer Testing Hierarchy (priority order):** Bundle & Save → Price test (higher = quality
  signal first) → MOQ → BOGO → %-off on quantity breaks → free-shipping threshold → free gift
  (test and remove).
- **Offer Construction Hierarchy (priority):** avatar-specific bonus → quantity breaks → free gift
  (test/remove) → higher price as quality signal vs discounting to match Amazon.
- **BOGO iteration sequence:** Buy 1 get 1 → Buy 2 get 1 → Buy 2 get 3 free; set MOQ to protect
  the 52% margin floor.
- **Charging-for-shipping isolation:** remove free gifts first; if sales hold, gifts weren't
  driving conversion → then test charging shipping.
- **Lever priority below $100K/mo:** creative > offer > landing page > advertorials (irrelevant
  before $100K/mo); architect offers BACKWARD from required margin.

## Selection contracts (right option for the named trigger)

- **Audience temperature → offer structure:** cold-friendly offers target Unaware + Problem-Aware
  (disruptive angle + UM + precise avatar); use FOMO/fear framing for problem-aware. Organic-
  validated offers do NOT transfer unchanged to paid cold traffic — different awareness needs
  different structure.
- **Funnel type → front-end model:** high-AOV bundle front-end (cover CAC on first sale) vs
  low-price entry ($5/$9) + backend upsell stack (→ 5–9× front-end AOV). Consumable LTV-negative
  front-end allowed only if subscription is built in at point of purchase.
- **Discount display by AOV:** low AOV → % off; high AOV → $ amount; always display whichever
  number appears larger.
- **Guarantee type by stage/risk:** unconditional (starting out, max lift/exposure) / conditional
  (filters uncommitted) / implied-performance / anti-guarantee (reputation strong enough none
  needed). The *wording* of the chosen guarantee is WRITE, not scored here.
- **Default-bias architecture:** pre-select highest-AOV / subscription tier as "best deal/
  bestseller" default; visual cues guide toward the higher-value choice.

## Precondition gates (run before the above)

- **Desire-saturation gate:** a desire already met by existing products cannot be claimed again
  without a new mechanism — run before angle selection.
- **Offer-addiction guard:** prefer conditional second-unit unlock over baseline discounts so
  customers don't train to the discounted price as the baseline.

## Validation procedure — HOW to test a new offer before banding it

The Offer Testing Hierarchy (above) tells you WHAT to test, in what order. This procedure is
HOW to run any one of those tests cleanly so the result is trustworthy. A new offer must clear
this protocol before it earns a band; an offer measured against the live page during active
campaigns produces dirty numbers and should be flagged, not scored.

**Offer-to-Landing-Page Testing Protocol (5-Step)**
1. Duplicate the product page
2. Apply new offer to duplicate only (original stays live)
3. Create new ad set pointing to duplicate URL
4. Run 7+ days inside Meta — let algorithm stabilize
5. Compare Meta-level CVR and AOV (not Shopify — attribution differs)
- URL-embedded discount codes for shareable links (e.g., ?discount=CODE in URL)
- Never test offer changes against the live page during active campaigns

Read rules for the scorer: measure CVR/AOV at the Meta level (Shopify attribution differs and
will mislead a band decision); require ≥7 days of run time before trusting a comparison; treat
a test run against the live page during an active campaign as invalid (flag, do not band).
