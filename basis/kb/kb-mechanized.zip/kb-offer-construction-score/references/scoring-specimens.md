# Scoring specimens — the known-good offers to judge FELT gates against

Felt gates (13 irrational-not-to-buy, 14 must-have framing) are scored **pairwise against
these**, not on an absolute scale and never by the model that built the candidate. Randomize
presentation order; treat any single score as noisy (a triage signal, not a certification).

## Irrational-not-to-buy reference (judge gate 13 against these)

- "Best case scenario, you change your life forever... Worst case scenario, you work out for 6 weeks basically for free. You tell me I suck and I give you your money back."
- "When you pay $4,500, you can count that weight gone. You can put it out of your mind. We're going to get there one way or another as long as you follow the steps."

Ask: does the candidate make refusal feel as irrational as these do? → prefer | tie | weaker.

## Must-have framing reference (judge gate 14 against these)

**Offer exemplars (judge pairwise against these actual offers, not against the principle):**
- Narrative-repositioning move that frames a category buy as a transformation: "30-Day Mojo Mastery Challenge" (a named challenge reframing of "testosterone booster").
- All-in-one bundle reframing of a single product into a named perceived-value offer: "AG1 = $126 perceived value sold at $79".

**Framing principle (carl-weische, context: "Must-have vs. nice-to-have positioning") — orients the judge, NOT the pairwise specimen:**
- "All-in-one solution framing for painful problems tied to deep desires converts at dramatically higher rates than isolated product framing."

Ask: does the candidate read as a must-have all-in-one (like the offer exemplars above), or a nice-to-have add-on? → prefer | tie | weaker. Judge against an offer exemplar, not the principle.

## Promise-specificity reference (sanity-check gate 11 winners)

- Specific target shape: "lose 20 lbs in 90 days".
- Niche-language signal: "for e-commerce founders doing $1M–$5M".
- Generic anti-pattern (NOT a specimen — deliberately not a winner): "get in shape".

## Unique-mechanism naming reference (felt naming the offer may carry)

- "P90X: 'muscle confusion.' Weight Watchers: 'point system.' These are unique mechanisms."

## How to run the pairwise judge

1. Present candidate + one specimen, order randomized.
2. Ask which better satisfies the named gate and why (criteria before verdict).
3. Record `prefer|tie|weaker` + the reason. `weaker`/`tie` contributes no band-lift for that gate.
4. Never let the model that built the candidate be the judge.
