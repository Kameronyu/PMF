# Per-gate membership tests + COUNTABLE gate definitions

Each test: all YES = the gate passes; any can return FALSE. All gates 1–12 are script-checked.
Anchor terms (Niche, Transformation, UM, Awareness level, Value models) are in the registry —
not redefined here.

## Gate 1 — Compare-at ratio (COUNTABLE)
- `ratio = compare_at_price / selling_price`
- PASS iff `ratio == 2.0` exactly (a clean 50% off).
- FALSE example: compare-at 1.7× selling price → non-round discount, no clean anchor → FAIL.
- Source line (mark-builds-brands): "Compare-at price: $79.95 (exactly 2x selling price)".

## Gate 2 — Margin floor (COUNTABLE)
- `floor = {standard_discount: 0.60, BOGO: 0.52, ad_funded_growth: 0.60, absolute: 0.50}`
- PASS iff `gross_margin% >= floor[offer_type]` AND `>= 0.50` always.
- Floors (spencer-origins): "50% absolute floor; 52%+ for BOGO; 60%+ for standard discounts";
  "60%+ minimum margin for ad-funded growth"; "Never test offers below 50%".

## Gate 3 — RPS band (COUNTABLE)
- `RPS = CVR × AOV` using Meta-measured CVR (not Shopify).
- Route to band: `<1.00 → intervene` / `1.00–2.00 → bundle` / `>2.00 → media-buy`.
- PASS iff RPS computed from Meta CVR AND routed to the correct band.
- FALSE example: RPS computed from Shopify CVR → wrong attribution → FAIL.
- Bands (spencer-origins): "Below $1.00: dramatic intervention"; "$1.00–$2.00: bundles are the lever".

## Gate 4 — Break-even ROAS (COUNTABLE)
- 5-step: sale price − COGS − shipping = GP; GP ÷ sale price = gross-margin%; `BE-ROAS = 1 ÷ gross-margin%` (round up).
- PASS iff BE-ROAS computed by this method AND modeled before launch.
- FALSE example: offer launched with no BE-ROAS modeled → FAIL.

## Gate 5 — Value-equation direction (COUNTABLE)
- `Value = (Dream Outcome × Perceived Likelihood) / (Time Delay × Effort & Sacrifice)`.
- PASS iff the offer addresses all four: Dream Outcome ↑, Perceived Likelihood ↑, Time Delay ↓, Effort/Sacrifice ↓.
- FALSE example: offer raises Dream Outcome but leaves Time Delay long and Effort high → 2 of 4 → FAIL.

## Gate 6 — Three-tier pricing (COUNTABLE)
- PASS iff exactly 3 tiers present AND middle visually highlighted AND highest-AOV/bestseller pre-selected as default.
- FALSE example: 2 tiers, or 4 tiers, or no default pre-selected → FAIL.

## Gate 7 — Bonus-stack sum (COUNTABLE)
- `Σ(stated bonus values) >= core_offer_price`.
- PASS iff the sum of credible stated bonus dollar-values meets or exceeds the core price.
- Source line (mark-builds-brands pricing/bonuses): "Total bonus value should exceed or match the core offer price".

## Gate 8 — NTPMA order (COUNTABLE)
- PASS iff plan solves Niche → Transformation → Price → Mechanism → Access Channel in that order
  AND market validated by committed money before the mechanism was built.
- FALSE example: mechanism (product) built before niche/transformation/price validated → out-of-order → FAIL.
- Order line (carl-weische): "Niche → Transformation → Price → Mechanism → Access Channel".

## Gate 9 — 30-day cash (COUNTABLE)
- PASS iff `30-day cash collected >= 2×CAC + COGS` (self-funding).
- FALSE example: 30-day cash < 2×CAC + COGS → front-end not self-funding → FAIL → caps band at REWORK.
- Source line (alex-hormozi, Client Financed Acquisition): "Want 2x CAC plus COGS to equal 30-day cash collected".

## Gate 10 — Seven-component section (COUNTABLE)
- PASS iff all 7 named slots present: countdown timer · social proof · one-sentence value prop ·
  price+anchor · 4 benefit bullets · repeated urgency · payment provider logos.
- FALSE example: 6 of 7 slots (no payment logos) → FAIL.

## Gate 11 — Promise specificity (COUNTABLE)
- `contains_specific = has(number) OR has(named_outcome) OR has(timeframe)`; niche named, not generic.
- PASS iff `contains_specific` AND the niche is named.
- FALSE example: "get in shape" → no number/outcome/timeframe → FAIL. Target shape: "lose 20 lbs in 90 days".

## Gate 12 — Close-rate band (COUNTABLE, advisory; service offers)
- Map close rate to underpricing multiple: 80%+ → 3–4× under · 60–80% → 2–3× · 50–60% → 1.5–2× ·
  40–50% → 1.25–1.5× · 30–40% → appropriately priced · <30% → avatar/sales-motion problem.
- PASS iff close rate mapped to the correct band. A `<30%` result emits a "fix avatar/sales-motion, not price" flag.
- Advisory: a failed mapping routes to a flag, never to REWORK on its own.

## Gate 2b — Revenue Illusion check (COUNTABLE, advisory flag; paired with gate 2)

A margin floor (gate 2) can PASS while net profit still collapses if a discount is expanded to
chase revenue. The source names this and prescribes a mandatory decision rule.

- Source (spencer-origins): "Revenue increase + maintained ROAS + reduced margin = net profit
  collapse"; named pattern to recognize and avoid: **"Revenue Illusion"**.
- Source decision rule (spencer-origins): "always run the margin-adjusted net profit calculation
  before expanding offer discounts".
- Worked scenario (spencer-origins, verbatim model):
  - Baseline: $100K spend, 2× ROAS, 70% margin = $40K net profit
  - New: $150K spend, 2× ROAS, 55% margin = $15K net profit → Revenue +50%, profit −62.5%.
- CHECK: when an offer lowers margin to expand a discount, compute margin-adjusted net profit
  (`gross revenue × new margin`) against the current baseline — do NOT band on ROAS or gross
  revenue alone.
- FALSE example: offer passes gate 2's margin floor and holds ROAS, but margin-adjusted net
  profit falls below baseline → **emit a "Revenue Illusion" flag**.
- Advisory: this never forces REWORK on its own — it emits a flag so a gate-2 PASS is not read
  as net-profit-safe.

## Why the tiers
Hard-gating a felt gate (irrational-not-to-buy, must-have framing) produces confident-but-wrong
FALSEs and pushes builders toward gaming the gate. Hard-gating a countable one (a ratio, a margin
floor, a tier count, an ordered sequence) is reproducible and safe. The felt gates stay pairwise
signals in `scoring-specimens.md`.
