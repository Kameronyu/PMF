---
name: kb-copywriting-score
description: >-
  Score a piece of copy (ad, hook, headline, advertorial, feed post) for production viability
  before spending media budget, and return DISCARD / VIABLE / SHIP with per-gate evidence.
  Use to grade copy written by a human, kb-copywriting-write, or any source. Hard-gates only
  the countable (reading grade level, Facebook compliance, valence quadrant, give-to-ask
  ratio, Command+F verbatim, checklist tallies); treats the felt criteria (pain articulation,
  curiosity) as pairwise-vs-specimen signals, never self-graded pass/fail. Run as a SEPARATE
  pass from the writer. Triggers: "score this copy", "is this ad worth running", "will this
  pass Facebook", "grade this headline", "rank these ads".
---

# Copywriting — score viability before you spend media budget

Grade each piece against the gates below, then band it. **Do not run this in the same pass
that wrote the copy** — a writer grading itself rates its own output higher. Score the felt
criteria against the winning specimens in `references/scoring-specimens.md`, ideally on a
different model. Anchor terms (Hook, Angle, UM, PMBD, Awareness, Trust signals) to the
registry; never redefine them here.

Tier discipline (the rule a fused skill breaks): **hard-gate only the countable**;
**soft-cap the heuristic**; **compare the felt against a specimen — never hard-FALSE it.**

## COUNTABLE gates (script-checkable; each: positive target → tier)

1. **Reading grade level** — *target:* copy scores at/below the target grade band (3rd–6th).
   *Judge:* script gate (grade ≤ 6). HARD-GATE — fail caps band at DISCARD.
2. **Facebook compliance** — *target:* no all-caps body, no unbleeped profanity, no aggressive
   transformation claim. *Judge:* regex/membership gate. HARD-GATE — any hit = DISCARD.
3. **Valence × Intensity quadrant** — *target:* copy sits in the acceptable quadrant (high
   enough intensity to motivate, positive enough to avoid fear-mongering). *Judge:* enum
   membership vs. the two specimens in references. HARD-GATE — extreme-negative = DISCARD.
4. **Command+F verbatim** — *target:* every assumed customer word appears in the research docs.
   *Judge:* contains-check against research. HARD-GATE — an unfound word = DISCARD pending fix.
5. **Pain/desire cap** — *target:* ≤5 core pains AND ≤5 core desires carried. *Judge:* count. SOFT-CAP.
6. **Give-to-ask ratio** *(content/feed only)* — *target:* ≥3:1 give-to-ask in long-form;
   ≤3% promotional (~1 ask per 10) in feed. *Judge:* ratio gate. HARD-GATE for feed copy.

Checklist tallies (countable presence, no element mandatory — a tally, never a single FALSE):

7. **7-Point Hook Checklist** — count of {curiosity, pain, solution, specificity, credibility,
   timeframe, simplicity} present. More = stronger.
8. **4-Element Advertorial Headline** — headline contains all of {self-interest, news appeal,
   curiosity trigger-word, quick & easy}. Presence gate (4/4 to ship a headline).
9. **6-Factor Ad Score** — ad answers yes to {attention, care, dream, urgency, social proof, CTA}.

Gate definitions, regexes, token lists, and the per-element tests are in
`references/gate-tests.md`.

## FELT signals (pairwise-vs-specimen; `prefer | tie | weaker`; NEVER a hard FALSE)

- **Pain articulation** — does the call-out name the prospect's pain more accurately than they
  could themselves? Judge pairwise against the pain specimen, not a gate.
- **Curiosity / open loop** — does the line make the next line more necessary than the
  open-loop specimen does?

A felt signal contributes a point only when the pairwise judge returns `prefer`; `weaker`
manufactures no pass. See `references/scoring-specimens.md`.

## Bands (derive from gates/signals that actually passed — not a hollow count)

- **DISCARD** — any HARD-GATE failed (grade > 6, FB hit, extreme-negative valence, Command+F
  miss, feed give-to-ask < 3:1), OR checklist tally ≤ 3. Rewrite before any spend.
- **VIABLE** — all hard-gates pass AND checklist tally 4–5. Moderate test budget.
- **SHIP** — all hard-gates pass AND checklist tally 6–7. Top budget.
- **type=headline** uses its own thresholds (the only checklist is Gate 8, max 4/4):
  DISCARD ≤ 3/4; no intermediate VIABLE band; SHIP = 4/4 (a headline ships only at 4/4).

**Override (structural, ROUTE):** route the copy by registry **Awareness level** before
banding — copy aimed at an unaware buyer that leads with a bare transformation claim drops one
band (mismatched specificity scrolls past). The awareness→approach map is in
`references/route-rules.md`.

## The negatives live here (≤5), each paired with a positive target

Moved out of the writer (where banning a token summons it). Each is a checker rule:

- **All-caps body** → flag, fails gate 2. (positive: sentence case; emphasis via word choice)
- **Aggressive transformation claim** ("lose 20 lbs in 2 days without diet or exercise") → flag, fails gate 2. (positive: a credible, qualified claim)
- **Extreme-negative valence** ("Brain health emergency — protect yourself now") → flag, fails gate 3. (positive: motivating-but-positive framing)
- **Inferred customer word** (a word absent from research) → flag, fails gate 4. (positive: the buyer's verbatim word)
- **Round-number specificity** ("$10,000") → flag, weakens checklist specificity. (positive: an odd, precise figure)

## Output contract (per piece)

```
copy: "<verbatim>"
type: hook | headline | ad | advertorial | feed_post   # selects which gates apply
countable_gates: [ {gate, target, verdict: pass|fail, tier, evidence_quote, source} ]
checklist_tally: {hook_7: n/7, headline_4: n/4, ad_6: n/6}   # script counts
felt_signals: {pain_articulation, curiosity}   # pairwise-vs-specimen: prefer|tie|weaker
awareness_level: unaware|problem-aware|solution-aware|product-aware|most-aware
band: DISCARD | VIABLE | SHIP
flags: [ ... ]   # from the negatives list
```
Every `pass`/`fail` orders evidence before verdict; every `evidence_quote` is a verbatim
substring of the copy or research being judged. `source` ∈ {traces_to:copy | traces_to:research | kb:<cite>}.

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every applicable gate has a verdict; checklist tallies present; band present.
**SOUNDNESS:** every COUNTABLE verdict came from the script (not eyeballed); every felt verdict
is pairwise-vs-specimen, not self-graded; band derived only from gates/signals that passed
their tier's check; each gate carries an `evidence_quote`; awareness override applied.
`emit_ready` only if SOUNDNESS holds; else `BLOCKED:<gate>`.

## Self-test (is this grader sound?) — any NO, fix

- Are only the countable gates hard-gated (by script), with pain/curiosity as pairwise-vs-specimen signals?
- Is the felt judgment run separately from the writer, against a real specimen?
- Does the band come from gates/signals that passed their tier's check, not a raw count?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Is the awareness-level override kept as a ROUTE rule, not a hard FALSE?
- Is every quoted specimen a verbatim substring of a source file (no composites)?
