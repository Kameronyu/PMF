# Scoring specimens — the known-good copy to judge FELT criteria against

Felt criteria (pain articulation, curiosity) are scored **pairwise against these**, not on an
absolute scale and never by the model that wrote the candidate. Randomize presentation order;
penalize verbosity; treat any single score as a noisy triage signal, not a certification.
Every line below is a verbatim substring of a source KB file.

## Pain-articulation reference (judge the pain call-out against these)
- "Do you have trouble getting upstairs or going on a walk for a long period of time without a rash forming between your legs?"
- "tired of taking all these calls yourself?"

Ask: does the candidate name the prospect's pain more accurately to themselves than these do?
→ prefer | tie | weaker. The principle behind the test: "If you can articulate the pain of a
prospect more accurately to themselves than they can articulate it, they will believe that you
can help them almost better than any promise that you can make them."

## Curiosity / open-loop reference (judge the hook's pull against these)
- "What happens to your body when you eat beef organs for 30 days"
- "As a vet for 10 years, here's the only supplement I give my dogs"
- "Is that a gray hair?"

Ask: does the candidate make the next line as necessary as these do? → prefer | tie | weaker.

## Valence quadrant reference (sanity-check Gate 3)
- Acceptable (pass): "Complete darkness may support long-term memory health"
- Unacceptable (fail): "Brain health emergency — protect yourself now"
- Supplementary felt heuristic (guidance, not a hard gate): "Family member test: would you
  show this ad to a family member you care about?"

## Specificity reference (sanity-check the Gate 7 specificity element)
- High-specificity winner: "What happens to your body when you eat beef organs for 30 days" (named timeframe: 30 days).
- Round-number anti-pattern (deliberately NOT a source winner): "$10,000".

## How to run the pairwise judge
1. Present candidate + one specimen, order randomized.
2. Ask which better satisfies the named criterion and why (criteria before verdict).
3. Record `prefer | tie | weaker` + the reason. `weaker` contributes no pass for that criterion.
4. Never let the model that generated the candidate be the judge.
