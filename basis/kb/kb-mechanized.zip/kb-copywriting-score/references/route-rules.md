# ROUTE rules — named-trigger selection / sequencing (contract, dictate no wording)

These are structural overrides the scorer applies before banding. They select WHICH gates
apply and can drop a band; they never become a hard FALSE on copy quality. Anchor
**Awareness level** to the term registry; do not redefine it.

## Awareness level → copy approach (canonical; the band override)
Locate the buyer, then check the copy's specificity matches:
- **Unaware** → curiosity hook that creates problem awareness first; leading with a bare
  transformation claim is a mismatch → drop one band.
- **Problem-aware** → describe their specific problem in their language.
- **Solution-aware** → reference failed prior solutions + UM education.
- **Product-aware** → objection handles, social proof, guarantees; compare variants.
- **Most-aware** → direct offer; value model (urgency/scarcity/discount) leads.
Specificity rises with awareness. A piece whose specificity outruns the buyer's awareness
drops one band regardless of gate count.

## Type → which gates apply
- **hook** → Gate 7 (7-point tally) + felt curiosity/pain; grade-level, valence, FB compliance.
- **headline** → Gate 8 (4/4) + grade-level + valence.
- **ad** → Gate 9 (6-factor) + grade-level + valence + FB compliance.
- **advertorial** → grade-level + valence + pain/desire cap + headline gate on its headline.
- **feed_post** → Gate 6 (give-to-ask) + grade-level + FB compliance.

Email copy is not a distinct structural type (the source treats email as a channel where the
same grade-level/copy principles apply, not a gate set of its own). Score an email under the
applicable structural type above — its subject line as a **headline**, its body as an **ad** or
**advertorial** — and emit that type label.

## Six objection categories (enum membership — for objection-handle copy)
An objection-handle's target objection must classify into exactly one of: Time, Money,
Authority, Fit, Past Experience, Stall. A handle that maps to none (or is the leading
emotional reason to buy) is an angle, not an objection handle — re-label, do not score it.
