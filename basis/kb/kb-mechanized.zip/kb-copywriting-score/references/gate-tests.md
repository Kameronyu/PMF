# Per-gate membership tests + the COUNTABLE definitions

Each test is yes/no and can return FALSE. Countable gates lower to a script (`contains`,
`regex`, a count, or a numeric threshold) so they run identically every time. Felt criteria
are NOT here — they live in `scoring-specimens.md` and are judged pairwise.

## Gate 1 — Reading grade level (COUNTABLE → hard-gate)
- Run the copy through a reading-grade grader (Hemingway App or equivalent).
- `pass iff grade <= 6`. Target band is 3rd–6th grade.
  - Hormozi: "Reducing reading grade level from 7th to 3rd on email follow-ups resulted in
    50% conversion increases without changing message content."
  - Hormozi: "Ninth grade reading level disqualifies two-thirds of readers."
  - Spencer: "Target: Grade 6 reading level for all direct response copy."
- FAIL → DISCARD.

## Gate 2 — Facebook compliance (COUNTABLE → hard-gate)
Three deterministic checks; ANY hit = fail = DISCARD:
- **All-caps body:** `regex` for runs of ≥3 consecutive all-caps words in body copy →
  "All-caps writing → not rejected but triggers artificially inflated CPM/ad costs as punishment."
- **Profanity:** unbleeped curse word present → "Profanity → rejected; bleeped curse words are acceptable."
- **Aggressive transformation claim:** a claim of an extreme outcome in an implausible window,
  e.g. "lose 20 lbs in 2 days without diet or exercise" → "Aggressive transformation claims …
  → ad rejection."

## Gate 3 — Valence × Intensity quadrant (classified pairwise-vs-specimen)
Two axes: valence (positive↔negative), intensity (mild↔extreme).
- BAN quadrant: high intensity + low valence (extreme negative) = fear-mongering →
  "Meta ban + Shopify removal + brand destruction."
- Classify by pairwise comparison against the two specimens (analogous to the felt signals —
  this requires judgment, it is not a deterministic script FALSE):
  - Acceptable (pass): "Complete darkness may support long-term memory health"
  - Unacceptable (fail): "Brain health emergency — protect yourself now"
- Rule: high enough intensity to motivate, positive enough to avoid compliance flags.
- Supplementary felt heuristic (guidance, not the gate): see the family-member test in
  `scoring-specimens.md`.

## Gate 4 — Command+F verbatim (COUNTABLE → hard-gate, contains-check)
- For every assumed customer word in the copy, `contains`-check it against the research docs.
- `fail` if any kept customer word does not appear in research.
  - Spencer: "Before publishing any copy, run Command+F on all research documents for every
    assumed customer word"; "If a word doesn't appear in research, remove it from copy."
  - Worked example: "hydrated" appears zero times in research; the buyer says "smoother and less dry."

## Gate 5 — Pain/desire cap (COUNTABLE → soft-cap)
- Count distinct core pains and core desires carried by the piece.
- `warn` if pains > 5 OR desires > 5 (Weische: carry only 3–5 core pains and 3–5 core desires).
  Soft — over-loading is a warn, not a DISCARD.

## Gate 6 — Give-to-ask ratio (COUNTABLE → hard-gate for feed copy)
- Long-form: "Integrated asks must maintain minimum 3:1 give-to-ask ratio within the content piece itself."
- Feed: "no more than 3% of posts"; "1 promotional post per 10 organic posts for short-form."
- `pass iff` ratio ≥ 3:1 (long-form) AND ask-share ≤ 3% (feed). Applies only to content/feed types.

## Gate 7 — 7-Point Hook Checklist (COUNTABLE tally; no element mandatory)
"Score any hook against seven elements; more checkmarks = higher performance. No single
element is mandatory." Count presence of each:
1. Curiosity — open loops
2. Pain point callout
3. Solution promise
4. Specificity — exact numbers and timeframes
5. Credibility/authority
6. Clear timeframe for results
7. Simplicity
Per-element presence is membership-testable (e.g. specificity = has a non-round number/timeframe).
Tally drives the band; it is a count, never one hard FALSE.

## Gate 8 — 4-Element Advertorial Headline (COUNTABLE presence gate)
"Four simultaneous elements required" — a headline ships only at 4/4:
1. Self-Interest — "what's in it for me," addressed to the target audience
2. News Appeal — framed like breaking news
3. Curiosity — trigger words: "this," "why," "new"
4. Quick & Easy — solution presented as fast and effortless

## Gate 9 — 6-Factor Ad Score (COUNTABLE presence tally)
"Evaluate any advertisement across six key factors": (1) grab attention, (2) make you care,
(3) sell the dream, (4) create urgency, (5) show social proof, (6) tell you what to do next (CTA).
Score each yes/no; tally feeds the band.

## Round-number test (for the specificity element of Gate 7)
- `round(n) = n ends in one or more zeros OR is a common milestone (10, 25, 50, 100, 1000)`.
- A specificity claim whose only number is round does not count toward the tally; flag it.
