---
name: kb-funnel-architecture-score
description: >-
  Score a D2C funnel build for production viability against the architecture benchmarks
  before scaling spend. Use to grade a funnel (its metrics, page sequence, and funnel-type
  choice) and return BROKEN / WORKING / SCALE-READY with per-check evidence. Hard-gates only
  the countable benchmarks (CPM, CTR, CVR, ATC, AOV thresholds; the CTR-ATC-purchase
  diagnostic node); treats felt criteria (congruency, "doesn't feel sold to") as
  pairwise-against-specimen signals, never self-graded pass/fail; keeps funnel-type selection
  and page-sequence rules as ROUTE contract. Run as a SEPARATE pass from any builder.
  Triggers: "score this funnel", "diagnose my funnel metrics", "is this funnel ready to scale",
  "which funnel layer is broken".
---

# Funnel architecture — score viability before you scale spend

Grade a funnel against the benchmark table, the diagnostic tree, and the congruency signals,
then band it. **Do not run this in the same pass that built the funnel** — a builder grading
itself rates its own output higher. Judge felt criteria against the specimens in
`references/scoring-specimens.md`, ideally on a different model.

Tier discipline: **hard-gate only the countable** (numeric benchmark thresholds, the
diagnostic-node enum); **soft-cap the heuristic** (directional uplift / completion bands);
**compare the felt against a specimen — never hard-FALSE it.**

## The checks (each: positive target → how it's judged → tier)

1. **Benchmark thresholds** — *target:* each reported metric clears its bound (CPM < $30; ad
   CTR > 3%, advertorial 7–10%; CPC < $1.50; CVR > 3%; ATC > 10% of visitors; ATC-to-purchase
   > 30%; AOV > $100). *Judge:* **script gate** — numeric comparison per metric. COUNTABLE → hard-gate.
2. **Diagnostic-node classification** — *target:* given (CTR, ATC, purchases), map to exactly
   one node of the 4-node tree. *Judge:* **script gate** — deterministic enum lookup against
   fixed thresholds (3%, 10%, 1%). COUNTABLE → hard-gate.
3. **Funnel-side layer attribution** — *target:* a missed Layer-2 metric names its failure
   layer (low ATC → landing-page/benefits; low ATC-to-purchase → checkout). *Judge:* **script
   gate** — threshold + named-layer lookup. COUNTABLE → hard-gate.
4. **Directional uplift / completion** — *target:* adding a pre-sell layer moves CVR/AOV
   upward; a quiz sequence completes in the 40–60% band. *Judge:* SOFT-CAP — directional band,
   real-world variance; warn, do not hard-fail. HEURISTIC.
5. **Narrative congruency** — *target:* ad angle, language, and visuals match the pre-sale /
   product page. *Judge:* FELT — signal pairwise against the Vessi congruency specimen; never
   a hard FALSE.
6. **"Doesn't feel sold to"** — *target:* the advertorial reads as editorial / organic, not as
   an ad. *Judge:* FELT — signal pairwise against the advertorial specimen; never a hard FALSE.

Benchmark bounds, the 4-node tree, layer-attribution map, and the soft-cap bands are in
`references/benchmark-tests.md`. ROUTE contract (funnel-type selection + page sequencing) is in
`references/route-contract.md` — selection/sequence violations are checker FLAGS, not score gates.
Ecosystem (cold/warm/hot + $100K/day rule), Dark-Funnel platform expansion order, the
architecture trend cycle, the build-order branch, and influencer co-branded pages are in
`references/ecosystem-and-expansion.md` — these are ROUTE/decision-rule FLAGS, not benchmarks.

## Bands (derive from checks that actually passed — not a hollow count)

- **BROKEN** — any COUNTABLE benchmark fails OR the diagnostic node is a non-purchasing node.
- **WORKING** — all COUNTABLE benchmarks pass; felt signals tie-or-better; soft-caps may warn.
- **SCALE-READY** — all COUNTABLE benchmarks pass AND AOV > $100 (auction headroom) AND both
  felt signals `prefer` over their specimens.

A felt criterion contributes only when the pairwise judge `prefer`s it over the specimen; it
never manufactures a pass on its own. **Congruency override (structural):** if any ROUTE
congruency rule is violated (ad angle ≠ LP), cap the band at WORKING regardless of benchmarks —
congruency break is the conversion leak the numbers haven't caught yet.

## The negatives live here (≤5), each paired with a positive target

Kept in the checker, not the builder. Each is a checker FLAG:

- **Cold traffic sent straight to product page** → flag. (positive: warm via staged pre-sell first)
- **AOV left equal to product price** → flag; below auction-headroom target. (positive: AOV > $100 via order page / OTO)
- **CTA at top of advertorial** → flag. (positive: CTA at 50–75% through the page)
- **Iterating the ad when CTR ≥ 3% + 0 purchases** → flag; it's an on-site problem. (positive: fix LP/checkout, not creative)
- **Units-sold badge only on PDP** → flag. (positive: also place at checkout where hesitation spikes)

## Output contract (per funnel)

```
funnel_id: "<id>"
checks: [ {n, target, verdict: pass|fail|signal, tier, evidence_quote, source} ]
countable_gates: {benchmarks, diagnostic_node, layer_attribution}  # script results, pass/fail
felt_signals: {congruency, doesnt_feel_sold_to}                     # pairwise-vs-specimen, prefer|tie|weaker
diagnostic_node: "<one of the 4 nodes>"                             # enum
band: BROKEN | WORKING | SCALE-READY
flags: [ ... ]   # from the negatives list + any ROUTE violation
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every check has a verdict; diagnostic_node present; band present.
**SOUNDNESS:** every COUNTABLE verdict came from the script (not eyeballed); diagnostic_node is
one of the 4 enum nodes; every felt verdict is pairwise-vs-specimen, not self-graded; band
derived only from passed checks (BROKEN if any benchmark fails); each `pass` carries an
`evidence_quote` that is a verbatim substring of its source. `emit_ready` only if SOUNDNESS
holds; else `BLOCKED:<check>`.

## Self-test (is this grader sound?) — any NO, fix

- Are only checks 1–3 hard-gated (by script), with checks 5–6 as pairwise-vs-specimen signals?
- Is the felt judgment run separately from the builder, against a real specimen?
- Does the band come from checks that passed their tier's check, not a raw count?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Are structural rules (funnel-type selection, sequencing, congruency cap) kept as ROUTE contract?
- Is every quoted specimen a verbatim substring of a source file (no composites)?
