# Ecosystem architecture, platform expansion, and build-order decision rules

These are STRUCTURAL / decision-rule contracts that sit alongside the funnel-type selection
and page-sequencing rules in `route-contract.md`. They route WHAT to build across awareness
levels and platforms, and WHEN to adopt or expand. They are not benchmark gates; a violation is
a checker FLAG (and the "$100K/day ceiling" rule below can justify a band-cap when whole
awareness layers are missing). Restored faithfully from source.

## Marketing awareness ecosystem architecture (cold / warm / hot) — Mark Builds Brands

The cold→full-funnel and warm→PDP branches already live in `route-contract.md`. This adds the
HOT (email/SMS) layer and the ecosystem decision rule that ties all three together.

> Running only top-of-funnel cold traffic ads is insufficient to scale to $100K/day. Every awareness level (cold, warm, hot) requires dedicated campaigns and touchpoints.
>
> - Cold: Chad Funnel with advertorial
> - Warm: Retargeting ads to Shopify or sales page
> - Hot: Email/SMS sequences (Klaviyo + SMS Bump)
> - The full ecosystem creates self-sustaining revenue; isolated campaigns create revenue fragility
> - $100K/day cited as the scale ceiling that cannot be broken without the full ecosystem

**Decision rule:** isolated campaigns = revenue fragility and cannot break the $100K/day ceiling;
self-sustaining revenue requires all three awareness layers running dedicated campaigns at once.

**Hot-layer tooling (Omnipresent Retargeting System):** three-channel retargeting against
visitors who did not convert at any funnel stage — paid retargeting ads (against visitors to
sales page, order page, upsell pages); email automation via Klaviyo (triggered by email popup
for non-buyers on sales page); SMS remarketing via SMS Bump (triggered by SMS popup). Adds
10–20% to top-line revenue daily; higher recovered revenue lowers effective CAC and improves
profitability thresholds.

## Dark Funnel / multi-platform expansion sequence (Meta → Google → YouTube) — Carl Weische

An ordered, named-trigger expansion ROUTE. Do NOT advance a platform until the prior one is done.

> Modern buying behavior is non-linear: Meta ad → Google search → review sites → other platforms → purchase. Failing to cover the full path causes customer loss in the "dark funnel."
>
> Expansion sequence: Optimize Meta fully first → Google (shopping campaigns, retargeting, Performance Max) → YouTube (adapt winning Facebook angles to landscape video format; target intent audiences with brand and competitor keywords).

**Pitfall flag:** "Expanding to Google/YouTube before Meta is fully optimized" — premature
expansion before Meta is fully optimized is a checker FLAG.

## Funnel architecture trend cycle — adopt the current architecture early — Mark Builds Brands

A decision rule for WHICH top-of-funnel architecture to adopt now (not a parallel menu).

> Funnel architectures follow a limited-window opportunity cycle before saturation. Sequential dominance: **advertorials → VSLs → quiz funnels**.
>
> - Early adopters capture disproportionate returns before commoditization
> - **Quiz funnels are the current high-performing architecture**
> - Weight loss brand validation: 5M+ visits/month using quiz funnel principles
> - 85% of attendees at an Elite Mastermind ($1B+ annual sales) were running advertorials or VSLs — confirms strategy is institutional-grade

**Decision rule:** pick the current early-adopter architecture (presently quiz funnels) before
it commoditizes; advertorial / VSL / quiz are NOT interchangeable parallel options — they are a
temporal sequence with diminishing returns as each saturates.

**Pitfall flag:** "Missing the early-adopter window on current architecture trend (currently:
quiz funnels)" — staying on a saturated architecture is a checker FLAG.

## Build-order branch: simultaneous full-funnel launch vs. bottom-up sequencing — Carl Weische

This directly tensions with Weische's own "start simple, scale before adding layers" complexity
sequencing and Spencer's KISS / default-to-PDP guidance (both in `route-contract.md`). The
teachable is the CHOICE between the two build orders.

> Instead of sequentially building funnel types from bottom to top, launch all funnel stages simultaneously at brand inception: bottom-of-funnel product pages + top-of-funnel VSL pages across Meta, Google, and native ads. Enables new brands to compete at 8-figure scale immediately (used in IM8 supplement launch with David Beckham).

**Decision rule (branch by operator situation, do not auto-resolve):**
- Bottom-up sequencing (default / KISS): start simple, validate unit economics, add funnel
  layers only as you scale — the conservative path for unit-economics testing.
- Simultaneous full-funnel launch: brand-funded inception with the capital to launch all stages
  (product pages + VSL pages across Meta, Google, native) at once, to compete at 8-figure scale
  immediately. Justified when backed (e.g., IM8 supplement launch with David Beckham).
- Flag for human-review consistency rather than auto-resolving; keep as a ROUTE branch keyed on
  funding / brand stage.

## Influencer co-branded offer pages (congruency routing keyed on traffic SOURCE) — Carl Weische

A source→page routing pattern: a sibling of awareness-keyed funnel-type selection, but the
trigger is the traffic SOURCE (a specific influencer), not the awareness level.

> Create dedicated offer pages co-branded with specific influencers featuring their color scheme, branding, and a dedicated section about them. Traffic from that influencer's organic or paid content routes to this congruent page. Produces "crazy conversion rates" due to audience-to-page message match. Standard conversion sections retained below the influencer section.

**Routing rule:** traffic from a specific influencer's organic or paid content → a dedicated
offer page co-branded to that influencer (their color scheme, branding, dedicated about-them
section), with standard conversion sections retained below. The mechanism is audience-to-page
message match (the same congruency principle as ad→LP, keyed on source instead of awareness).
