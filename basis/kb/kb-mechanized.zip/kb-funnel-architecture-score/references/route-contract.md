# ROUTE contract — funnel-type selection + page sequencing

These are named-trigger selection / sequencing rules. They dictate STRUCTURE, never wording.
A violation is a checker FLAG (and can trigger the congruency band-cap), not a benchmark gate.
Anchor terms (awareness level, angle, hook, trust signals, objection handle) are defined in the
term registry — never redefined here.

## Funnel-type selection (keyed on awareness level)

- Advertorial funnels (Types 1 & 2) target top and middle of funnel; direct product and BOGO
  funnels (Types 3 & 4) target the bottom.
- Funnel 1 = problem-aware/unaware; Funnel 2 = skeptical/educated; Funnel 3 = offer-aware only;
  Funnel 4 = bottom-of-funnel high-awareness only.
- Awareness-stage matching: Unaware → Problem-aware = ad/advertorial, don't mention product;
  Problem-aware → Solution-aware = pre-sell page or quiz; Solution-aware → Product-aware =
  sales page or VSL.
- Dual-funnel: low-awareness → Ad → Pre-sale → Product → Checkout; high-awareness → Ad →
  Offer/product → Checkout.
- Spencer default: PDP for standard-complexity traffic; extend the funnel only for $2,000+
  high-ticket, heavy-education problem-aware, or post-VSL traffic.

## Ordered-step sequence contracts (must be in order)

- Pre-sale warming sequence 1–6: pain → why past attempts failed → consequences → desire →
  mechanism → CTA.
- 8-step advertorial: desired state → current state → other options → introduce → explain →
  why now → objections/guarantee → CTA.
- Pre-sale 4-part: Introduction → Education → Transition → Pitch.
- Six mandatory sales-page sections: Hero → Storytelling → Trust → Objection → Offer → Security.
- 6-step DR funnel SOP: research → offer → ad → pre-sale → sales → CRO.
- Chad Funnel: Ad → Advertorial → Sales → Order → OTO → Thank You.
- LP conversion sequence: Hook → Problem → Solution/mechanism → Proof → Offer → Objection →
  CTA + risk reversal.
- Cascading-constraint diagnosis: Layer 1 ad-side → Layer 2 funnel-side → Layer 3 AOV; only
  advance if the prior layer passes.

## Conditional / placement triggers

- CTA introduced at 50–75% through the page, not at the top.
- Cold → full Chad Funnel; warm (prior exposure) → Shopify PDP or sales page directly (avoid
  funnel fatigue).
- Units-sold badge placed at CHECKOUT (not only PDP) — hesitation spikes there.
- CRO trust-signal priority 1–5: photo reviews → UGC → units-sold at checkout → checkout badges
  → niche PDP copy.

## Ecosystem / expansion / build-order rules (see ecosystem-and-expansion.md for detail + verbatim source)

- **Awareness ecosystem (cold/warm/hot):** all three layers need dedicated campaigns. Cold →
  Chad Funnel + advertorial; warm → retargeting to Shopify/sales page; hot → email/SMS (Klaviyo
  + SMS Bump). Isolated campaigns = revenue fragility; cannot break the $100K/day ceiling.
- **Dark Funnel expansion (ordered, do not skip):** optimize Meta fully first → Google (shopping,
  retargeting, Performance Max) → YouTube (winning FB angles in landscape; intent + competitor
  keywords). Expanding before Meta is fully optimized = FLAG.
- **Architecture trend cycle (decision rule):** adopt the current early-adopter architecture
  before it saturates — advertorials → VSLs → quiz funnels; quiz funnels current. Staying on a
  saturated architecture = FLAG.
- **Build-order branch:** bottom-up sequencing (default/KISS) vs. simultaneous full-funnel
  launch at inception (brand-funded, all stages at once). Branch by funding/brand stage; flag
  for human review, do not auto-resolve.
- **Influencer co-branded offer page (source-keyed congruency route):** traffic from a specific
  influencer → a dedicated page co-branded to that influencer, standard conversion sections below.

## CONFLICT (branch by stage, do not negotiate)

Spencer "default to PDP" vs Weische/Mark "always pre-sell for cold." Resolution: choose by
operator stage + product complexity — sub-$100K/mo unit-economics testing → PDP; scaling /
brand-funded → advertorial. Keep as a ROUTE branch keyed on stage; flag for human-review
consistency rather than auto-resolving.
