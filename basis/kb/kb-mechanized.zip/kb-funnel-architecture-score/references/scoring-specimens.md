# Scoring specimens — the known-good lines to judge FELT criteria against

Felt criteria (Check 5 congruency, Check 6 editorial-feel) are scored **pairwise
against these**, not on an absolute scale, and never by the model that built the candidate.
Present candidate + one specimen in randomized order; ask which better satisfies the named
criterion and why (reason before verdict); record `prefer | tie | weaker`. `weaker`
contributes no pass for that criterion. Treat any single judgment as a triage signal, not a
certification.

## Narrative congruency reference (judge Check 5 against this)

The Vessi landing-page headline mirrors the winning travel/adventure ad angle — message-match
from ad to LP, not feature copy:

- "anywhere all weather shoes made for adventuring"

Ask: does the candidate's LP headline match its ad's angle/language/visual as tightly as this
does? → prefer | tie | weaker.

## Editorial-feel reference (Check 6 — does it read as editorial, not an ad) (judge against this)

The shower-head advertorial headline reads as an outcome/threat-framed editorial hook, not a
feature ad — emotionally charged, outcome-first:

- "Save your skin, hair and health from disaster with this disruptive shower head"

Ask: does the candidate's advertorial hero read as editorial (value/story framing) at least as
much as this does, rather than as a direct product pitch? → prefer | tie | weaker.

## How to run the pairwise judge

1. Present candidate + one specimen, order randomized.
2. Ask which better satisfies the named criterion and why (criteria/reason before verdict).
3. Record `prefer | tie | weaker` + the reason. `weaker` contributes no pass for that criterion.
4. Never let the model that generated/built the candidate be the judge.
