# Benchmark gates + diagnostic tree + soft-cap bands

All thresholds below are COUNTABLE → a script compares the reported number to the bound.
A felt judgment never overrides a benchmark fail; it only caps an otherwise-passing band.

## Check 1 — Benchmark thresholds (hard-gate, per metric)

PASS iff the reported metric clears its bound. Any single fail → contributes BROKEN.

| Metric | Bound (PASS iff) |
|---|---|
| CPM | < $30 |
| CTR (ad) | > 3%  (advertorial-driven: 7–10%) |
| CPC | < $1.50 |
| Conversion Rate | > 3%  (< 3% = funnel problem) |
| Add-to-Cart Rate | > 10% of page visitors |
| ATC-to-Purchase | > 30% of add-to-carts |
| AOV | > $100  (2–3x front-end product price) |
| Brand Impressions to Convert | ~6–7 (cold traffic) — context, not a fail gate |

Advertorial-route CTR band: a funnel routed through an advertorial should clear the higher
7–10% band, not merely 3%; below 7% on an advertorial route is a SOFT-WARN, not a hard fail.

## Check 2 — CTR-ATC-Purchase 4-node diagnostic (hard-gate, enum lookup)

Given `(CTR, ATC%, purchases)`, classify to exactly one node. Fixed thresholds: 3%, 10%, 1%.
A non-purchasing node (any node whose remedy is not "scale") → contributes BROKEN.

| Condition | Node (enum) | Remedy |
|---|---|---|
| CTR < 1% | Creative problem | Kill ad, iterate creative |
| CTR ≥ 3% + 0 purchases | On-site problem (LP or checkout) | Do not iterate on ad |
| CTR ≥ 3% + ATC < 10% | PDP problem | Fix PDP copy/offer/congruency |
| CTR ≥ 3% + ATC ≥ 10% + 0 purchases | Checkout friction or pricing issue | Fix checkout or test price |

Script note: evaluate most-specific conditions first (the ATC sub-cases before the bare
"CTR ≥ 3% + 0 purchases" parent). The chosen node string must be echoed verbatim from this list.

## Check 3 — Funnel-side layer attribution (hard-gate, threshold + named layer)

When a Layer-2 metric is below bound, the failure layer is fixed (not a guess):

| Below-bound metric | Named failure layer |
|---|---|
| Low add-to-cart rate | landing page copy or benefits presentation failure |
| Low ATC-to-purchase ratio | checkout friction |

Cascading-constraint order is a ROUTE rule (diagnose Layer 1 ad-side → Layer 2 funnel-side →
Layer 3 AOV; only advance if the prior layer passes) — see `route-contract.md`.

## Check 4 — Directional uplift / completion (SOFT-CAP, warn only)

These have real-world variance; warn if missing, never hard-fail the band:
- Adding a pre-sell layer should move CVR and AOV **upward** (directional). Reference magnitude
  from one case: CVR 1.97% → 3.44% (+75%), AOV $135 → $191 (+41%). Missing the exact figure is
  not a fail; a flat or downward move after adding a layer is a SOFT-WARN.
- Quiz funnels: completion in the **40–60%** band on well-structured sequences. Outside the
  band → SOFT-WARN (sequence may be too long / friction too high), not a hard fail.

## Checks 5–6 — felt criteria (NOT here)

Congruency and "doesn't feel sold to" are FELT. Do not write a numeric gate for them. Judge
pairwise against the specimens in `scoring-specimens.md`; return `prefer | tie | weaker`.
`weaker` contributes no pass and triggers the congruency band-cap when it is a ROUTE violation.

## Why the tiers

Hard-gating a number (a metric is or isn't above its bound; a diagnostic node is a deterministic
lookup) is reproducible and safe. Hard-gating a felt judgment (congruency, editorial feel)
produces confident-but-wrong FALSEs and pushes builders toward gaming the gate. Soft-cap the
in-between (uplift magnitude, completion rate) because real funnels vary run-to-run.
