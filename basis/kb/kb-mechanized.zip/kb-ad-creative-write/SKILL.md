---
name: kb-ad-creative-write
description: >-
  Write the felt copy inside a cold-traffic ad creative — the qualification hook, the
  POV opener, the landing-page outcome line, the FOMO / novelty phrase. Use when
  generating or rewriting the wording a viewer actually reads or hears in a static,
  UGC, or VSL ad. Leads with real winning specimens and a few craft targets; offers
  named patterns (Qualification-Question, POV, Direct-Outcome, FOMO/Novelty) as
  OPTIONAL shapes, never required slots. This skill WRITES; it does not grade its own
  output — score ad copy with kb-ad-creative-score (a separate pass). Triggers:
  "write ad creative", "write the hook for this ad", "rewrite this ad copy",
  "landing page headline", "UGC script copy".
---

# Ad creative — write the wording cold traffic feels

A creative executes an **angle** (the emotion you invoke) for a buyer at a known
**awareness level**. Your job here is the *wording* — the line that makes a cold viewer
self-qualify, keep watching, and click. Lead from the specimens below; reach for a named
pattern only if it helps; keep it direct.

## Start here — real winning specimens (study these before writing)

Preserved verbatim from the source. They steer you harder than any rule. More, with the
job each does, are in `references/specimen-bank.md`.

- **Qualification question (viewer self-qualifies silently):** *"Going traveling abroad?"*
  — a yes/no question the right buyer answers in their head; it filters the audience before
  any claim, and the algorithm self-selects who leans in.
- **Qualification opener (filter the ideal buyer):** *"If you're like me..."*
  — opens by addressing one person, not a market; the wrong buyer scrolls, the right one
  feels seen and stays for the demonstration.
- **Direct outcome headline (landing page):** *"Don't dream of perfect curls, get them"*
  — names the exact desired outcome and flips wishing into having; direct beats clever,
  and it keeps ad-to-page congruency because it states the same promise the ad sold.
- **Spoken hook that carries the claim in text:** *"This device cured my bad posture in less than one week."*
  — concrete result + concrete timeframe in the first line; most viewers watch with sound
  off, so the claim has to land as on-screen text.
- **POV format line:** *"I experienced problem XYZ and found this solution"*
  — first-person discovery framing that reads as organic, not as an ad; fill XYZ with a
  real, visceral problem in the buyer's own words.

## Craft targets (steer by these; not a rulebook)

- **Qualify, don't broadcast.** The strongest cold openers let the right buyer
  self-select — a question they answer silently, a "if you're like me" that the wrong
  person skips. Speak to one person.
- **Direct over clever.** State the angle plainly. Wit that hides the promise is a leak,
  especially at scale.
- **Specificity over superlative.** A named outcome, a number, a timeframe ("perfect
  curls," "less than one week") beats "amazing" / "fast."
- **Carry the claim in text.** Sound-off is the default; the hook's promise must survive
  with the audio muted.
- **Congruent with the destination.** The line a viewer clicks on should be the same
  promise the landing page opens with — write the ad and the page outcome line together.

## Optional patterns (reach for one; never force a fixed order)

Qualification-Question · POV · Direct-Outcome · FOMO/Novelty. Each is a shape to borrow,
not a required sequence — forcing slots produces same-y creative, the one thing a
cold-traffic ad cannot afford. Anatomy and a worked example for each is in
`references/patterns.md`. A bank of FOMO and novelty phrases lifted verbatim from the
source is in `references/specimen-bank.md`.

## Contract rules (these DO bind — they pick the shape, not the words)

- **Awareness routing.** Unaware / problem-aware: lead with a qualification question or
  POV problem framing to create recognition first. Solution-aware: lead with the outcome
  and the unique mechanism. Most-aware: lead with the FOMO / novelty / value lever.
- **Format follows angle.** POV / first-person discovery for relatable problem-aware
  copy; direct-outcome statements for solution-aware and on the landing page; FOMO and
  novelty phrasing native to the feed for most-aware. Group the wording you write to the
  angle it serves.
- **Hide the attack.** Cold creative reads as organic; write so the line never announces
  itself as a paid advertisement.

## How to use this with the grader

Generate several diverse creatives (vary the pattern and the angle; do not iterate one
toward "safe"). Then hand them to **kb-ad-creative-score** — a separate skill, ideally a
different model — for the gates and the pairwise-vs-specimen judgment. Do not grade your
own output here; a writer that judges itself optimizes toward "looks like an ad," not
"stops cold traffic." Banned-phrase, congruency, and combination-count checks live there.

## Before handoff (what kb-ad-creative-score checks)

Awareness, not a writer gate: the separate scorer judges drafts against these. Generate
several diverse drafts; the separate scorer grades — do not self-grade toward the gate.

- Whether the opener lets the right buyer self-qualify before any product claim.
- Whether it is direct — the promise legible in one read — and congruent with the landing page.
- Whether it carries at least one concrete specific (named outcome, number, or timeframe).
- Whether the claim survives with the sound off (text-driven).
- Whether several diverse candidates exist rather than one polished safe line.
