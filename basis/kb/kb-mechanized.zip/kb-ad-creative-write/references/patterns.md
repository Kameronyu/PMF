# Optional patterns — anatomy + a worked example each

Reach for one when it fits the angle and the awareness level. None is a required slot
order; forcing a fixed sequence is what produces same-y creative. Use these to vary, not
to standardize.

## Qualification-Question
[a yes/no question only the qualified buyer answers "yes" to].
- The viewer self-qualifies silently; the wrong audience scrolls, the algorithm learns who
  leans in. Best for unaware / problem-aware cold traffic.
- Example: "Going traveling abroad?"

## POV (Point-of-View)
[first-person discovery] = "I experienced [problem] and found [this solution]".
- Reads as organic lived experience, not as an ad. Emotionally relatable; mirrors the feed.
  Fill the problem with the buyer's own visceral language. Best for problem-aware.
- Example shape: "I experienced problem XYZ and found this solution"

## Direct-Outcome
[name the exact desired outcome] + [flip wishing into having].
- States the promise plainly — direct beats clever, especially at scale and on the landing
  page where congruency with the ad matters most. Best for solution-aware and the LP headline.
- Example: "Don't dream of perfect curls, get them"

## Text-Driven Claim Hook
[concrete result] + [concrete timeframe], written to land as on-screen text.
- Most viewers watch sound-off, so the claim has to survive muted. Specific result + specific
  time beats any superlative.
- Example: "This device cured my bad posture in less than one week."

## FOMO / Novelty
[scarcity or newness phrasing, native to the feed].
- For most-aware buyers who need a reason to act now; phrase it as the feed phrases it, not
  as ad-speak. Pull from the verbatim phrase bank in `specimen-bank.md`.
- Examples: "almost always sold out," / "game changer,"

> The numeric test structures these patterns get deployed inside (combination caps, batch
> sizes, spend bands) are NOT patterns — they are gates, and they live in kb-ad-creative-score.
