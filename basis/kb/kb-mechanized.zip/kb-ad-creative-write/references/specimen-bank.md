# Specimen bank — verbatim winning ad copy, with the job each does

Preserved verbatim from `ad-creative--carl-weische.md` / `ad-creative--mark-builds-brands.md`.
These are the highest-value asset in the skill — study and adapt, do not abstract into
templates. Each shows the *form* of a line that works on cold traffic; that is what
steers a model harder than any adjective list.

## Qualification openers (the right buyer self-selects)
- "Going traveling abroad?"
  — a yes/no question the qualified viewer answers silently; filters audience before any claim.
- "If you're like me..."
  — addresses one person, not a market; the wrong buyer scrolls, the right one stays.

## Direct-outcome lines (state the promise plainly; great on the landing page)
- "Don't dream of perfect curls, get them"
  — names the exact outcome and flips wishing into having; keeps ad-to-page congruency.

## Spoken / text hooks (carry the claim in on-screen text for sound-off viewing)
- "This device cured my bad posture in less than one week."
  — concrete result + concrete timeframe; lands even with the audio muted.

## POV format line (first-person discovery; reads as organic, not as an ad)
- "I experienced problem XYZ and found this solution"
  — fill XYZ with a real, visceral problem in the buyer's own words.

## FOMO phrase bank (scarcity; native to the feed, for most-aware buyers)
- "almost always sold out,"
- "only X left"

## Novelty / revolution phrase bank (curiosity + newness)
- "game changer,"
- "discover the secret of,"
- "experts are amazed"

## Native production directive (not copy, but governs how the copy reads)
- "Always hide your attack"
  — the wording must never announce itself as a paid advertisement.

> Note: these steer the *wording*. The membership/threshold rules (combination caps,
> spend bands, test structures) are NOT here — they live in kb-ad-creative-score.
