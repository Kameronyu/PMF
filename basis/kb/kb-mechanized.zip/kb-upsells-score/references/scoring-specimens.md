# Scoring specimens — the known-good plans to judge FELT signals against

Felt signals (Signal 6 offer relevance, Signal 7 OTO1 problem-fit) are scored **pairwise
against these**, not on an absolute scale and never by the model that wrote the plan.
Randomize presentation order; treat any single judgment as a triage signal, not a
certification. Each line below is a verbatim substring of a source KB file.

## Offer-relevance reference (judge Signal 6 against these)

- "The offer must be logically connected to the item just added — not random."
- "OTO must be logically connected to the just-purchased item"
- "Each upsell solves a different problem within the same laundry routine."

Ask: is the candidate's upsell as logically connected to the just-purchased item as these are?
→ prefer | tie | weaker. A random or category-mismatched offer returns `weaker`.

## OTO1 problem-fit reference (judge Signal 7 against these)

- "Must either solve the original problem better/faster/easier OR solve a new problem created by achieving the initial product's results."
- "Each product in the funnel sequence solves the problem created by the previous product."
- "Identify a contextual limitation of the front-end product and design a subscription upsell that fills that specific gap."

Ask: does the candidate OTO1 resolve the original problem better/faster, OR a new problem the
first purchase created, as cleanly as these? → prefer | tie | weaker.

## How to run the pairwise judge

1. Present candidate + one specimen, order randomized.
2. Ask which better satisfies the named signal and why (reasoning before verdict).
3. Record `prefer|tie|weaker` + the reason. `weaker` contributes no pass for that signal.
4. Never let the model that generated the plan be the judge.
