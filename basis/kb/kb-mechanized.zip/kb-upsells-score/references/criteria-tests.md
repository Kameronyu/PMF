# Per-field membership tests + the COUNTABLE gate definitions

All countable gates lower to a deterministic script check. Felt signals are pairwise-vs-
specimen (see `scoring-specimens.md`) and never compile to a yes/no FALSE.

## Countable gates (script — each returns pass|fail by shape)

**Gate 1 — AOV:front-end ratio**
- `ratio = planned_AOV / front_end_price`
- PASS iff `ratio >= 2`. Target band is `2 <= ratio <= 3`. `ratio == 1` (1:1) → FAIL.
- Anchor: minimum AOV:front-end price ratio = 2:1; a $40 product needs a minimum $80 AOV.

**Gate 2 — OTO1 max price**
- PASS iff `oto1_price <= 10 * front_end_price`.
- Anchor: OTO1 can be priced up to 10x the front-end product price. Practical OTO1 range
  $200–$300; typical take rate 5–10%.

**Gate 3 — Post-purchase upsell count**
- PASS iff `2 <= post_purchase_oto_count <= 4` (one-time offers in the dopamine window).

**Gate 4 — Price-tier → format match (deterministic table)**

| Front-end tier | Threshold | Required format |
|---|---|---|
| Low-ticket | Under $50 | Simple one-section offer with urgency/scarcity |
| Mid-tier | $50–$150 | Detailed five-section text sales letter (TSL) |
| High-ticket | $150+ | Video sales letter (VSL) with authority figure |

- Resolve the tier from front-end price, then PASS iff `chosen_format == tier_required_format`.
- Mismatch examples that FAIL: a simple one-section offer on a $200 upsell; a VSL on a $10 upsell.

**Gate 5 — Downsell on OTO1 rejection**
- PASS iff `downsell_discount == 50%` AND `downsell_channel == popup`.
- A separate downsell page (not a popup) → FAIL (split-tested inferior to popup format).

## Felt signals (pairwise only — NEVER a membership FALSE)

**Signal 6 — Offer relevance / logical connection**
- Is every upsell logically connected to the just-purchased item, not random?
- Judge pairwise against the relevance specimen in `scoring-specimens.md`. Return
  `prefer | tie | weaker`. `weaker` (a disconnected/random offer) contributes no pass and
  triggers the relevance band-drop. Do NOT write a yes/no gate for this — fit is felt.

**Signal 7 — OTO1 problem-fit**
- Does OTO1 solve the original problem better/faster/easier, OR a new problem the first
  purchase created? Judge pairwise against the problem-fit specimen. Return `prefer|tie|weaker`.

## Benchmark reference numbers (context for grading, not pass/fail gates)

- Post-purchase upsell AOV lift: 10–30% additional.
- In-cart upsell: ~50% take rate; adds ~$20 to AOV.
- Pre-selecting higher-value bundles: ~20% AOV increase.
- Cross-sell margin math: 20% margin front-end + $20 profit cross-sell ≈ 3x total profit.
- Downsell: 10% take rate on a $300 upsell = ~$30 added to AOV.

## Why the tiers

Hard-gating a felt field (is an offer "relevant"?) produces confident-but-wrong FALSEs and
pushes builders toward gaming the gate. Hard-gating a countable one (a ratio is or isn't ≥2,
a count is what it is, a format matches the table or doesn't) is reproducible and safe.
