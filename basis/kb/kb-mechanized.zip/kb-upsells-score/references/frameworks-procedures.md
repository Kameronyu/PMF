# Full-funnel upsell frameworks, execution procedures, and decision rules

The countable gates and felt signals (`criteria-tests.md`, `scoring-specimens.md`) decide
whether a plan ships. This file restores the *why* behind the AOV lever and the *how* of the
stage-by-stage execution that the ROUTE contract in SKILL.md references — the strategic
frameworks, execution instructions, and decision rules an agent applies when building or
grading the funnel. Restored faithfully from `upsells--carl-weische.md` and
`upsells--mark-builds-brands.md`; no line budget here, so it is comprehensive.

---

## The strategic WHY: AOV as competitive acquisition advantage (Source: Mark Builds Brands / Dan Kennedy)

This is the framework that decides *when AOV is the lever to pull*. AOV is not a vanity
metric — it is the mechanism for advertising dominance.

Core principle (Dan Kennedy): **"The business owner who can spend the most to acquire a new
customer wins."**

Higher backend AOV directly funds higher customer acquisition cost (CAC) bids, enabling
outcompeting rivals for the same ad audience while remaining profitable. In-cart upsells
adding $20 AOV enable spending $10–$15 more per customer acquisition than competitors. This
is the primary mechanism for advertising dominance — not better creatives or lower CPMs.

Carl Weische states the same mechanism: "Higher AOV directly enables higher customer
acquisition cost tolerance, unlocking more aggressive and profitable media buying."

**Decision rule (diagnostic):** treat AOV as the lever ONLY after ad-side (CPM/CTR/CPC) and
funnel-side (landing page, checkout conversion) problems are ruled out. The AOV issue is
diagnosed last, not first. Once it IS the lever, the AOV:front-end ratio gate (Gate 1) and
OTO1 elasticity (Gate 2) become the operative targets.

---

## Execution: product / collection page stage

### AOV framing through lifestyle imagery (Source: Carl Weische)

Increase perceived multi-unit purchasing norms through imagery alone.

> Always show multiple people (4: full family or friend group) using the product
> simultaneously in all product imagery. This normalizes gifting and multi-unit purchasing
> without explicit upsell language.

Combine with data-driven "frequently bought together" sliders for compounding AOV lift.
Framing and copywriting around upsells is as important as the offer mechanics themselves.

### Data-driven "frequently bought together" cross-sell integration (Source: Carl Weische)

> Analyze backend order data to identify most commonly co-purchased products, then
> dynamically surface those combinations in a "frequently bought together" slider on the
> product page. Dynamic, data-backed recommendations outperform static/manual upsell lists.

Decision rule: prefer dynamic, data-backed recommendations over static/manual upsell lists.

### Collection-page bundle pre-selection (Source: Carl Weische)

> Feature bundles first on collection pages and pre-select the higher-value bundle option by
> default. Price anchoring effect makes single units appear cheaper by comparison. Removing
> the manual upgrade friction drives customers toward higher-AOV options passively.

- Execution: feature bundles first; pre-select the higher-value bundle by default.
- Anchoring rationale: the pre-selected higher bundle anchors price so single units appear
  cheaper by comparison; removing the manual-upgrade friction drives buyers to higher AOV
  passively.
- Data: pre-selecting higher-value bundles increased AOV by 20%.

---

## Execution: cart stage — gamification with spend-threshold progress bar (Source: Carl Weische)

The mechanic (not just the copy line):

> Embed a visual progress bar in the cart drawer tied to a spend threshold that unlocks a
> free gift. Gamification makes additional spending feel rewarding rather than costly.
> Accompany the progress bar with a low-friction one-click product-add mechanism.

- Mechanic = progress bar in cart drawer + spend threshold that unlocks a free gift +
  one-click product-add.
- Shipping-threshold variant: "Spend $X more for free shipping" triggers the same
  psychological mechanic. (The copy line itself lives in the writer's specimen bank; the
  mechanic lives here.)

---

## Cross-sell strategy: margin multiplication + demographic expansion (Source: Carl Weische)

Cross-sells on low-margin front-end products can multiply total profit per transaction by 3x
or more. A $20 profit cross-sell added to a 20% margin front-end product triples overall
profit.

> Cross-sells also enable demographic expansion while retaining core audience overlap,
> effectively widening the addressable market without changing front-end targeting.

- Margin math: 20% margin front-end + $20 profit cross-sell = 3x total profit margin.
- Strategic half (decision rule): cross-sells widen the addressable market via demographic
  expansion while retaining core audience overlap — without changing front-end targeting.

---

## Post-purchase window: the 24-hour anxiety window + recapture-on-exit (Source: Mark Builds Brands)

The moment immediately after payment submission is the highest emotional state a customer
will ever be in within a company's history.

> Post-purchase anxiety takes ~24 hours to subside, creating a sustained window of price
> elasticity.

Price elasticity at OTO1 is maximized — upsells can be priced up to 10x the front-end product
price at this stage. Credit card info is already saved; CPA was paid at initial purchase, so
all post-purchase revenue is pure profit.

> Mechanism: Exploit the 24-hour post-purchase anxiety window via email/SMS sequences if the
> customer exits the funnel before completing upsell steps.

- Framework: ~24h sustained price-elasticity window after purchase.
- Execution: if the customer exits the funnel before completing the upsell steps, recapture
  via email/SMS sequences within that window.

---

## Post-purchase email/SMS sequence: repurpose OTO content + retarget (Source: Carl Weische)

The final stage of the full-funnel architecture is not a bare "email/SMS" node — it carries a
specific instruction:

> Post-purchase email sequence: Repurpose OTO content as nurture/education; retargeting ads
> to past buyers with special offers

- Execution: repurpose the OTO content as nurture/education in the email/SMS sequence.
- Execution: run retargeting ads to past buyers with special offers.

---

## The full-funnel architecture this stage map enumerates (Source: Carl Weische)

Deploy upsell opportunities at every stage of the customer journey simultaneously:

1. **Product/collection page:** Lifestyle imagery, bundle pre-selection, "frequently bought together" slider
2. **Add-to-cart:** Logic-gated popup upsell
3. **Cart:** Progress bar gamification, cross-sell recommendations
4. **Checkout:** Upsells framed as "today's top deals" (native Shopify)
5. **Post-purchase (pre-thank you):** 2–4 one-time offers in the dopamine window
6. **Thank-you page:** Soft product recommendations
7. **Post-purchase email sequence:** Repurpose OTO content as nurture/education; retargeting ads to past buyers with special offers

Case data: street fashion brand: $930K/month at 12% margin → $1.57M/month at 20% margin in
2 months via full-funnel upsell implementation.

---

## The five-section mid-tier text sales letter (TSL) structure (Source: Carl Weische — Collagen Peptides Model)

Gate 4 mandates a "five-section text sales letter (TSL)" for the mid-tier ($50–$150) front-end
band but does not say what the five sections are. This is the structural contract Gate 4
checks against — the format the agent must actually build (and the grader must verify is
present) for a mid-tier OTO.

> Mid-tier post-purchase upsells use a structured five-section text sales letter:

The five named sections, in order:

1. **Authority figure introduction**
2. **Offer introduction**
3. **Detailed offer explanation**
4. **Benefits breakdown**
5. **Special deal with CTA**

When grading a mid-tier TSL for Gate 4, "format match" means all five of these sections are
present in this sequence — an authority-figure intro, the offer introduction, a detailed offer
explanation, a benefits breakdown, and a closing special-deal-plus-CTA. A mid-tier OTO missing
the authority intro or the structured benefits/special-deal close is not a TSL by this spec and
fails the format match even if the dollar tier is correct.

---

## Worked example: Collagen Peptides mid-tier funnel (Source: Carl Weische — Collagen Peptides Model)

The grounding worked example for both the five-section TSL structure above AND the adaptive
upsell logic rule ("smaller front-end purchase → upsell to larger quantity; larger → downsell
to incremental addition"). The adaptive rule is abstract without this case; restore it here.

The full case verbatim:

> **Collagen peptides funnel example:**
> - Front-end pricing: $42.99–$132 depending on bundle
> - Frame: doctor explaining a facility "mistake" customers can exploit for better value
> - Adaptive logic: 1-jar or 3-jar buyers → upsell to 3 additional jars; 6-jar buyers → downsell to 1 additional jar
> - Upsell 2: Collagen Care Plus as necessary for long-term results and faster absorption

How it grounds the rules:
- **Tier → format:** the front-end at $42.99–$132 spans into the mid-tier band, so the OTO is
  built as the five-section TSL (authority-doctor intro → offer → explanation → benefits →
  special deal/CTA), led by the "facility mistake" authority frame.
- **Adaptive logic (Gate-adjacent ROUTE rule):** the sequence is NOT static. A 1-jar or 3-jar
  buyer (small front-end purchase) is **upsold to 3 additional jars**; a 6-jar buyer (large
  front-end purchase) is **downsold to 1 additional jar**. This is the concrete instantiation
  of "smaller front-end purchase → upsell to larger quantity; larger → downsell to incremental
  addition." A flat sequence that offered every buyer the same 3 jars would ignore the 6-jar
  buyer's existing quantity and underperform.
- **OTO2:** Collagen Care Plus, positioned as necessary for long-term results and faster
  absorption — a "longer-term results" / "faster results" type, not more-of-the-same.

---

## Worked example: Truly Free Home laundry funnel — complementary-problem sequence (Source: Carl Weische — Truly Free Home Model)

The grounding worked example for the complementary-problem upsell type (Type 4: solve a
distinct-but-related problem within the same activity context, rather than selling more of the
same). The scoring relevance specimen quotes the principle ("Each upsell solves a different
problem within the same laundry routine.") but not the three named products or the 8x metric —
restored here.

> For low-ticket front-ends, upsell sequences solve distinct but related problems within the
> same activity context rather than selling more of the same product.

The full Truly Free Home funnel verbatim:

> **Truly Free Home laundry funnel:**
> - Front-end: laundry wash products at $5–$20 (health-conscious mothers avoiding toxins)
> - Upsell 1: Oxy Boost bleach alternative at $5 (positioned as 80% savings) — brighter clothes without chemicals
> - Upsell 2: Non-toxic stain stick — removes impossible stains
> - Upsell 3: Non-toxic laundry machine cleaner — maintains washing machine without toxins

The three named upsell products and what each solves:
1. **Oxy Boost** bleach alternative at **$5** (positioned as 80% savings) — brighter clothes
   without chemicals.
2. **Non-toxic stain stick** — removes impossible stains.
3. **Non-toxic laundry machine cleaner** — maintains the washing machine without toxins.

Each upsell solves a *different* problem within the *same* laundry routine — not more wash
product. Result datum:

> The full sequence lifted AOV from $5 to approximately $40 (8x lift).

So: **$5 front-end → ~$40 blended AOV = 8x lift.** This is the canonical low-ticket
complementary-problem outcome; cite it when grading whether a low-ticket sequence is solving
related problems (relevant, high-lift) versus stacking duplicates.

---

## Worked example: Nuru knee massager high-ticket CLV-maximization funnel (Source: Carl Weische — Nuru Knee Massager Model)

The named grounding case for the high-ticket three-upsell CLV-maximization sequence. The
high-ticket CLV framework is otherwise abstract; this case supplies the specific prices and the
AOV/CLV figures.

> High-ticket front-ends support a three-step upsell sequence combining one-time purchases with
> subscription products to maximize immediate AOV and long-term CLV.

The full Nuru funnel verbatim:

> **Nuru knee massager funnel:**
> - Front-end: knee massager at $179
> - Upsell 1: Second knee massager at $139.95 via VSL with Dr. Jeremy Campbell — framed as a gift for friends/family
> - Upsell 2: Knee pain patches at $59/month subscription — solves the gap where the device only works at home
> - Upsell 3: VIP health club membership at $97/month — addresses broader health concerns, builds community

The named structure:
- **Front-end:** knee massager at **$179** (high-ticket; $150+ tier → VSL with authority).
- **Upsell 1:** a **second knee massager at $139.95**, delivered via VSL with the authority
  figure **Dr. Jeremy Campbell**, framed as a gift for friends/family (gift/exclusivity reframe
  dissolving the "I already have one" objection).
- **Upsell 2:** **knee pain patches at $59/month** subscription — fills the solution gap where
  the device only works at home (a contextual limitation of the front-end product).
- **Upsell 3:** **VIP health club membership at $97/month** — addresses broader health concerns
  and builds community.

Results datum:

> **Results:** $400+ AOV; $500–$1,000+ potential CLV through subscription components.

So: **$179 front-end → $400+ AOV; $500–$1,000+ potential CLV.** The two subscription components
($59/month + $97/month) are what convert a high AOV into multi-hundred-to-thousand-dollar CLV;
cite this case when grading whether a high-ticket plan is leaving CLV on the table by using
only one-time OTOs.
