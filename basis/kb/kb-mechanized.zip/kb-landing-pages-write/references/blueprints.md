# Optional blueprints — section order + the job of each section

Reach for one when it fits the traffic temperature and product type. None is a required slot
order for your *sentences* — they order the *page*. Write each section from the specimens and
craft targets in SKILL.md; the source's value is the sequence and the psychological job of each
block, not a fixed wording.

## Hero element order (above-the-fold)
The hero is the highest-leverage element — prospects decide to stay or leave within seconds; all
critical purchase information must be visible without scrolling.
1. Positive-tone announcement bar (set the emotional frame before product content)
2. High-quality images of happy customers *using* the product (not bare product shots)
3. Desire-led headline (see specimen "Reveal Your Most Radiant Glow")
4. 2–3 sentence product explanation + one-sentence value proposition
5. Social-proof element (star rating / review count) visible above fold
6. Trust badges: free shipping, free returns, payment-provider logos
7. Clear singular CTA button (sticky); pre-select Subscribe & Save to lift LTV

Right-side order (product pages): social proof → product title → value proposition → badges →
3–4 sentence extended benefit description.

## Eight-section psychological sequence
Each section performs a distinct psychological function:
countdown timer (urgency) → happy model image (priming) → product benefits (not features) →
social proof (3,000+ five-star reviews) → before-and-after (visual proof) → pain-point
identification (problem awareness) → product mechanism breakdown (how it works) → money-back
guarantee (neutralize final objection). Multiple sections reinforce the same key messages for
different reading styles and scroll depths.

## Long-form 5–8 section architecture
Most brands ship 1–2 sections (product + reviews); high-converting pages use 5–8:
above-fold (value prop, avatars, social proof, CTA) → what's inside (ingredient-to-benefit) →
before/after + press/authority → testimonials each solving a *specific* objection →
"5 reasons why" listicle → offer section (urgency, limited-time deal, pricing, social proof).
Technical/novel products add objection-handling sections. Structured around psychology, not aesthetics.

## Four-section benefits sequence (below the hero)
Moves the prospect from doubt to desire; each section addresses a different barrier:
competitive differentiator / USP comparison (see specimen "...not comparable") → emotional value
proposition (tie product to pre-existing positive associations) → materials/craftsmanship with
storytelling (analogy + narrative make quality tangible) → future pacing (vivid life-after-owning).

## Sales-conversation mirror
Maps offline sales stages onto page structure:
open with frame (position as revolutionary) → present desired state with copy + imagery → embed
press/trust early → hero story (character with the prospect's problems) → amplify pain + address
failed alternatives → first CTA → stack testimonials + press after first CTA → handle major
objections by name → certifications (vegan, cruelty-free, derm-approved) → distribute testimonials
*throughout* → close with urgency/scarcity + final CTA + source-credibility markers.

## Trojan homepage
Convert the homepage from passive navigation into a full sales page:
hero with clear value prop → press mentions → best-seller showcases → competitor comparison →
unboxing content → repeated trust/differentiation across multiple sections.

## Listicle bridge page (cold / top-of-funnel)
A trust-building bridge, NOT a conversion page:
curiosity headline with social proof (see specimen "...3 million+ people...") → 5–7 benefit points,
each with a supporting image → CTA directing to the product page.

## Eight questions product images must answer
what they're buying · what's in it for them · is it for them (avatar match) · what they get
(contents) · can they trust it · who it's from · is it worth it · how it works (mechanism).

## Traffic-temperature / product-type playbooks (pick the model that fits the product)
Two opposed models for the page's *spine*. Choose by product type, then write the sections from
the specimens. These carry execution detail the SKILL.md one-liners omit.

### Desire-based products — Coconut Beauty model
Lead with aspirational identity outcomes, not problem elimination.
- Hero headline names the identity/desire outcome (specimen: "Reveal Your Most Radiant Glow").
- Frame the product as an insider "secret weapon."
- Show multiple customer avatars (diverse skin tones, hair colors) so a broad audience identifies.
- Tie benefits to specific ingredients for credibility.
- End with a how-to guide to reduce post-purchase anxiety.
- Distribute social proof across ALL sections, not just a dedicated block.
- Include urgency elements in the offer section.

### Novel / complex products — FEMA education-first model
Category-creating products must prioritize education over persuasion.
- Lead with a curiosity hook (specimen: "Discover the panties the internet goes crazy about").
- Dedicate significant real estate to product-mechanism explanation and demos.
- Name the dominant objection directly and neutralize it (e.g., the "diaper" comparison for
  period underwear).
- Use a founder story for human trust + brand authenticity.
- Incorporate UGC / community content as adoption proof.
- WARNING: over-persuading without educating increases refund rates — teach before you sell.

Technical or novel products require additional objection-handling sections (e.g., a fabric
breakdown for period underwear). Long-form serves different buyer types at different scroll
depths — structure around psychology, not aesthetics.

## Why happy-customer imagery (rationale behind hero/eight-section image choices)
High-quality images of happy customers *using* the product (not bare product shots) activate
mirror neurons for subconscious emotional transfer — the prospect feels the satisfaction before
reading a word. The "happy model image" in the eight-section sequence does the same priming job.
