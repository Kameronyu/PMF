# Specimen bank — verbatim winning landing-page copy, with the job each does

Preserved verbatim from `landing-pages--carl-weische.md` / `landing-pages--mark-builds-brands.md`.
These are the highest-value asset in the skill — study and adapt, do not abstract into ordered
slot templates. Each specimen shows the *form* of a good answer; that is what steers a model.

## Hero headlines (desire / identity outcome — not feature-led)
- "Reveal Your Most Radiant Glow"
  — job: hero headline for a **desire-based** product. Names the identity the buyer wants to step
  into; carries no ingredient or spec. Used twice in the source (generic hero example AND the
  Coconut desire-based model) — the canonical desire-led headline to beat.

## Urgency / offer copy (concrete number + concrete deadline)
- "Limited time 30% off – ends in 5 minutes"
  — job: countdown timer / offer-section urgency anchor. The discount number and the clock carry
  the pressure; the deadline is what converts "limited time" from wallpaper into action.

## Differentiator / USP (reframe the category, don't out-argue on features)
- "You don't need to compare because it's not comparable"
  — job: the first benefit section's competitive-differentiator line. Preempts the Google/Amazon
  comparison shop by moving the product out of the comparison set entirely. Disarms a sophisticated
  market's price-checking reflex.

## Listicle bridge hooks (sell the click, not the product — for cold traffic)
- "Discover what 3 million+ people are going crazy over"
  — job: curiosity-driven headline for a **cold / top-of-funnel** listicle bridge page. An open
  loop on *what* it is, fused to a FOMO social-proof number. Builds curiosity + trust before any hard sell.

## Education-first hooks (open a loop on a novel product so the reader stays to be taught)
- "Discover the panties the internet goes crazy about"
  — job: lead hook for a **novel / category-creating** product (FEMA education-first model). Buys
  the attention to *teach* the mechanism; over-persuading here without educating drives refunds up.

## Clarity (the test for every line)
- "Confused minds do not buy."
  — job: the single spine across copy, media, and design. Apply it as a pass/fail to every line
  you write — does it reduce cognitive load, or add it?

> Note: items "Reveal Your Most Radiant Glow" appears as one underlying copy specimen used in two
> places (generic hero + Coconut model) — count it once. Net distinct copy specimens: 6 — above
> the ≥3 floor. All are verbatim substrings of the source.
