# Anchor terms — defined in the registry, never redefined here

This topic uses these registry terms with their canonical meanings. Anchor to
`/tmp/kb-ref/term_registry.json` and `definitions.md`; do not invent local definitions.

- **Trust signals** — persuasion mechanics that reduce perceived risk and substitute for
  in-person credibility ("can I believe these people will deliver?"). On a page: trust badges,
  press mentions, certifications, displayed review counts.
- **Social proof** — surfaced via the Trust-signals family; on the page it is the displayed
  five-star review count and the "X million people" FOMO number.
- **Objection handle** — a specific copy or structural element that neutralizes a known buyer
  objection, living throughout the funnel (ad → LP → checkout). Here: objection-specific
  testimonials, named-objection sections, the money-back guarantee, education-first neutralization.
- **Awareness level** — where the buyer is on the chain from unaware to ready-to-buy; drives
  archetype selection (cold → listicle bridge; product-aware → full product/offer page).
- **Hook** — a scroll-stopping strategy; here the curiosity/desire headline that earns the stay.
- **Differentiator** — umbrella for the levers that distinguish the offer (market, UM, angle,
  value models, trust signals); on the page, the USP / competitor-comparison section.
- **UM (Unique Mechanism)** — the unique way the product delivers the transformation; on the
  page, the "product mechanism breakdown" / how-it-works section.
- **Value models** — how the offer is framed commercially (bundle, pricing, discount, guarantee,
  subscription); on the page, the discount anchor, guarantee, and Subscribe & Save.
- **Market sophistication** — what's required to differentiate where competitors already are;
  drives the "not comparable" / competitor-comparison framing.
