---
name: kb-advertising-write
description: >-
  Write the felt copy in an ad campaign — paid-ad hook variations off one offer,
  pain-based testimonial hooks, and rotating promotional-wrapper names for the same
  core offer. Use when generating or rewriting ad hook lines, eliciting testimonial
  hooks, naming a seasonal/promo wrapper, or reframing seasonal messaging. Leads with
  real winning specimens lifted verbatim from the source and a few craft targets;
  offers named angles as OPTIONAL patterns, never required slots. This skill WRITES;
  it does not grade its own output — score copy with kb-advertising-score (a separate
  pass, ideally a different model). Triggers: "write ad hooks", "hook variations for
  this offer", "testimonial hook", "name this promo", "seasonal messaging".
---

# Advertising copy — write the words a viewer feels

Your job is the *wording* inside an ad: the hook that survives the first three seconds,
the testimonial line that lands because of one concrete detail, the promo name that
rebundles the same offer so it stops feeling stale. The strategy around it (allocation,
ratios, channel order) is decided elsewhere — here you write what the reader actually
reads. Lead from the specimens below; reach for an angle only if it helps; keep it short
and concrete.

## Start here — real winning specimens (study before writing)

Preserved verbatim from the source. They steer harder than any rule. Study the *form* and
write fresh in the same spirit; treat them as live examples to echo, not ordered slots to fill.

**Paid-ad hook bank — one offer (trash-pickup service), five hooks:**
- *'Are you backed up in trash?'* · *'You smell that smell?'* · *'Is this you every trash day?'* · *'You missed your child's practice again?'* · *'Alex, did you take the trash out?'*
  — WHY it works: one offer, five different *emotional entry points* — physical (smell),
  visual (mess), social status, missed family moments, the nagging-spouse voice. None
  pitches the product; each enters a desire or pain the viewer already lives. This is hook
  *multiplication*: same benefits and CTA underneath, the opening line is the variable.

**Pain-based testimonial hooks (top performers out of 2,500+ reviewed):**
- *'two months away from shutting our doors'* · *'barely making enough to survive'* · *'paid all expenses and finished with $0 of profit'*
  — WHY it works: each opens on a single worst *moment* with a concrete detail. The
  "$0 of profit" specificity is what makes it land — two of the top four hooks named zero
  dollars. The prospect relates because it matches where they currently are, not where
  they ended up.

**The eliciting move (how to get copy like the above out of a customer):**
- *"The moments are what makes hooks. The details are what make them powerful"*
  — WHY it works: it tells you what to ask FOR. Ask for the single worst moment, not a
  general "how was life before" story; the specific detail of that moment becomes the hook.

**Promo-wrapper name bank — same gym offer, rotating names that defeat ad fatigue:**
- *6-week transformation, 42-day detox, belly fat blast, slim by Halloween, Lean by Halloween, slim for Santa, big booty boot camp*
  — WHY it works: the core offer (nutrition + workouts) never changes; only the wrapper
  name rotates — by season (slim for Santa), by outcome (belly fat blast), by timeframe
  (42-day detox). Same economics, fresh creative, so the market re-engages.

**Seasonal reframe — forbid one word, lead with benefits:**
- *"If you're in a seasonal business don't call it the offseason because then everyone's gonna treat it like the offseason."*
- *Indoor golf summer messaging: air conditioning, 18 holes in under 30 minutes, drink in hand*
  — WHY it works: naming the slow period "offseason" is a self-fulfilling prophecy. Reframe
  around what makes the off-peak version *better* — concrete benefits, not a defense of the season.

More specimens, with what each executes, are in `references/specimen-bank.md`. Named OPTIONAL
ad-build structures and copy-independent levers (pain-demo 15s build, behavior-change structure,
visual casting, avatar alignment, **the Proof Continuum** — what TYPE of proof to write) are in
`references/ad-structures.md` — reach for one, never forced. When writing testimonial or
social-proof copy, the Proof Continuum says which proof is worth the words: proof, not promise,
is the differentiator.

## Craft targets (steer by these; they are not a rulebook)

- **Buy attention before you pitch.** The opening line earns the next three seconds on
  pain, curiosity, or recognition — keep the product name out of it until attention is bought.
  80% of viewers decide not to watch in the first three seconds; the hook is the highest-leverage
  word you write.
- **One concrete detail beats a superlative.** "$0 of profit" / "18 holes in under 30
  minutes" outpull "struggling" / "fast." Specificity is what makes a moment relatable.
- **Multiply, then choose.** For a hook, produce many variations off ONE offer, each
  entering a different emotion (smell, status, missed moment, the voice in their head); spend
  the effort on spread across emotions rather than polishing a single line.
- **Enter the desire they already have.** Write what the avatar is living right now; the
  benefits and CTA stay constant underneath while the entry point varies.
- **Same offer, fresh wrapper.** A promo name rotates the felt framing — season, outcome,
  timeframe — over an unchanged sales process. Change the words, not the operations.
- **Fewest words that keep the pull.** Draft, then cut anything that adds no new pull.

## Optional angles (reach for one; never force a fixed order)

Pain-question · Physical-sensation · Social-status · Missed-moment · Inner-voice ·
Worst-moment-testimonial · Season-wrapper · Outcome-wrapper · Timeframe-wrapper.
Each is an entry point to borrow, not a required sequence. Vary the angle across your
batch so the set covers different emotions rather than restating one.

Whole-ad OPTIONAL build templates (when you write more than a hook): **pain-demo 15s** (pain
hook → demo → on-screen CTA) and **behavior-change** (tons of attention + uncomfortable fact +
testimonial + CTA; show what they MISS OUT ON). Full builds in `references/ad-structures.md`.

## Contract rules (these DO bind — they pick the shape, not the words)

- **Awareness routing** (Eugene Schwartz `Awareness level`): Unaware → a curiosity hook
  unrelated to the solution. Problem-aware / Solution-aware / Product-aware → progressively
  more direct, naming the pain or mechanism. Most-aware → direct introduction of the offer.
  Match the hook's directness to where the viewer already is.
- **Hook multiplication is per-offer:** all variations lead to the *same* benefits,
  differentiators, and CTA; only the opening line changes.
- **Testimonial elicitation:** ask for the single worst *moment*, not a "how was life
  before" summary; the concrete detail of that moment is the hook.
- **Wrapper, not offer:** when naming a promo, the core offer and sales process stay fixed;
  only the wrapper name rotates.
- **Avatar alignment (three move together):** ad messaging, lead magnet, and price point must
  match the same avatar; changing the copy without the other two breaks the funnel. The wording
  you write must speak the targeted avatar's language. Detail in `references/ad-structures.md`.
- **Visual casting is a targeting lever, not copy:** who/what appears in the ad (people, setting,
  clothing) targets the audience harder than words — flag it when relevant. See `references/ad-structures.md`.

## How to use this with the grader

Generate several diverse candidates — vary the angle and the emotional entry point, spreading
effort across many openers. Then hand them to **kb-advertising-score** — a separate skill,
ideally a different model — for the counts and the pairwise-vs-specimen judgment (hook count
per offer, the 3-second / length checks, banned wording like "offseason"). Grading lives in
that separate pass; keep this pass focused on producing varied drafts.

## Before handoff (what kb-advertising-score checks)

Generate several diverse drafts; the separate scorer grades — do not self-grade toward the gate.
These are awareness of what that pass looks at, not a writer loop:

- The opening line buys attention on pain/curiosity/recognition before any product mention.
- Several diverse variations off one offer, each a different emotion.
- Each carries at least one concrete detail (number, named moment, timeframe).
- For a promo name: the core offer stays fixed while only the wrapper changes.
- For a testimonial hook: a single worst moment with a specific detail.
