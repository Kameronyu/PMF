# Specimen bank — verbatim winning advertising copy

Preserved verbatim from `advertising--alex-hormozi.md`. These are the highest-value asset
in the skill — study and adapt, do not abstract into templates. Each specimen shows the
*form* of a good answer; that form is what steers a model.

## Paid-ad hook multiplication (one offer, many emotional entry points)

One trash-pickup offer, five hooks — same benefits, differentiators, and CTA underneath;
only the opening line changes. 80% of viewers disengage in the first 3 seconds, so the
hook is the highest-leverage variable. Test 5-6+ variations simultaneously.

- "Are you backed up in trash?"        — angle: physical/visual pain, question form.
- "You smell that smell?"              — angle: sensory recognition (smell).
- "Is this you every trash day?"       — angle: recurring-pain recognition.
- "You missed your child's practice again?" — angle: missed family moment / cost of the problem.
- "Alex, did you take the trash out?"  — angle: the nagging-spouse inner voice.

Each enters a different emotion: smell, visual mess, social status, missed events, nagging
spouse. Write fresh ones in this spirit — do not reuse these literally.

## Pain-based testimonial hooks (top performers from 2,500+ reviewed)

Each opens on a single worst MOMENT with a concrete detail. Ask the customer for their
single worst moment, not "how was life before" — the detail is what makes it land. Two of
the top four named zero dollars of profit; specificity wins.

- "two months away from shutting our doors"   — angle: imminent-failure moment, timeframe detail.
- "barely making enough to survive"           — angle: survival pressure.
- "paid all expenses and finished with $0 of profit" — angle: the $0 specificity that makes it relatable.

The eliciting principle, verbatim:
- "The moments are what makes hooks. The details are what make them powerful"

## Promotional-wrapper name bank (same offer, rotating names that defeat ad fatigue)

The core gym offer (nutrition + workouts) and the sales process never change; only the
wrapper name rotates — by season, outcome, or timeframe — so the market re-engages.

- 6-week transformation   — timeframe wrapper.
- 42-day detox            — timeframe + outcome wrapper.
- belly fat blast         — outcome wrapper.
- slim by Halloween       — season + outcome wrapper.
- Lean by Halloween       — season + outcome wrapper (variant).
- slim for Santa          — season wrapper.
- big booty boot camp     — outcome + format wrapper.

## Seasonal messaging reframe (forbid one word; lead with benefits)

- "If you're in a seasonal business don't call it the offseason because then everyone's gonna treat it like the offseason."
  — principle: naming the slow period "offseason" is a self-fulfilling prophecy.
- Indoor golf summer messaging: air conditioning, 18 holes in under 30 minutes, drink in hand
  — reframe: lead on concrete benefits of the off-peak version, not a defense of the season.

## Contextual CTA (bridge the ask to the content that preceded it)

- "If that's the most important part shortterm then why wouldn't you take the extra minute to just make it contextual"
  — principle: a CTA should connect to the specific content before it (if the email is
  about testimonials, the CTA relates to testimonials), not a generic copy-paste link.

## Bring-a-friend woven copy

- "bring a friend"
  — woven into every ad, post, email, and piece of content across a campaign; framed as
  faster/better results with a friend. Drove 25-30% of customers from unattributed
  word of mouth at scale.
