# Ad structures & copy-independent levers (OPTIONAL build templates)

Restored faithfully from `advertising--alex-hormozi.md`. These are named, executable creative
patterns and steering levers that sit alongside the hook/specimen craft. They are OPTIONAL
structures to reach for — never required slots. Reference for the writer.

## Pain-Based Demonstration Ad Structure (the 15-second short-form build)

The most efficient ad structure for short-form (15-second) spots.

> "Start with a pain-based hook showing what it's like NOT to have the product, then immediately
> solve it by demonstrating the product. This is the most efficient ad structure for short-form
> (15-second) spots... Prefer text on screen over audio-only for CTA -- many viewers don't have sound."

Build:
- **Hook** with contextual pain the audience is currently experiencing (question-based pain hooks
  are fundamentally effective).
- **Immediately solve** the pain with a product demonstration.
- **On-screen CTA:** prefer text on screen over audio-only — many viewers don't have sound.
- 15 seconds is enough to get the point across with this structure.
- Reference example: the Ramp.com ad — show the pain of not having expense management, then show
  the instant solution.

Source quote (verbatim):
> "It's demonstration. They start with a pain-based hook of what it's like to not have the product
> and then they just immediately solve it with having the product through demonstration."

## Attention-to-Behavior Conversion Gap (the behavior-change structure)

Grabbing attention and changing behavior are two different things. An ad can score 10/10 on
attention and still fail to change behavior if it leaves the viewer feeling good rather than
compelled to act. The hook/attention side is only half — this is the structure that actually moves
behavior.

Build:
> "Ad structure for behavior change: tons of attention + fact that makes uncomfortable +
> testimonial + CTA. Showing what people will MISS OUT ON (loss aversion) is often more compelling."

- Attention and behavior change are separate objectives.
- If an ad leaves you feeling good, it may not create urgency to act.
- Showing what people will MISS OUT ON (loss aversion) is often more compelling.
- Testimonials of someone who avoided disaster using the service drive more action.

Source quote (verbatim):
> "The point of advertising is to let people know about your stuff, but the point of persuasion is
> to change behavior."

## Visual Casting for Ad Audience Targeting (copy-independent lever)

A targeting lever that operates independently of the copy — the people, setting, and clothing in
the ad attract the corresponding demographic more powerfully than words.

> "The setting, clothing, and people in your ad do more to attract the right audience than the copy.
> If you want to reach more women, put women in the ad. If your clients are all men, it's probably
> because you're in the ad."

- Setting, clothing, and people in the ad attract the right audience more than copy does.
- If you want to reach more women, put women in the ad.
- If all clients are men, it's probably because only the founder appears in the ad.
- Using multiple different people across different ad creatives can double or triple lead flow.
- Diagnose audience skew by examining who is actually in your ads, then diversify ad talent to
  expand reach.

## Avatar Alignment System (ads + lead magnet + price must change together)

The three-way alignment decision rule that governs the messaging this skill produces. To attract
the right customer, three things must move together; changing one without the others breaks the funnel.

> "To attract the right customer, you must align three things simultaneously: your ad messaging
> (speak their language), your lead magnet (match their identity), and your price point (match the
> economics of acquiring that avatar). Changing one without the others creates a broken funnel."

- **Ads** — message the right prospect: 'tired of your job' attracts employees; 'frustrated with
  your business' attracts business owners.
- **Lead magnet** — must match the desired avatar: a book about quitting your job attracts
  job-quitters, not business owners.
- **Price** — must match the economics: acquiring a business owner may cost 5-10x more than a
  consumer, so price accordingly.
- All three must change together or the economics won't work (one case: 80% of revenue came from
  the wrong customer segment).

Source quote (verbatim):
> "If you can't say 'hey tired of your job' - that's going to attract people with jobs who are tired
> of their jobs. If you say 'frustrated with your business' then you're going to have different concerns"

## Proof Continuum for Ad Creative (what TYPE of proof to write, and why)

Proof exists on a continuum from least to most compelling. This governs the testimonial and
social-proof copy this skill produces: it tells you not just WHAT to ask for (the worst moment),
but WHAT KIND of proof is worth writing up and why proof — not promise — is the differentiation lever.

> "Proof exists on a continuum from least to most compelling. 80% of winning ads are about proof,
> not promises. The most compelling proof is in-person, live, unrecorded, from someone who looks
> like the prospect, with the specific result they want. Your promise is not unique, your proof is."

- Worst proof: faceless, anonymous, 10-year-old, text-based testimonial.
- Best proof: in-person, live, looks like prospect, specific desired result, hard to fake.
- Factors: in-person > virtual, live > recorded, looks like me > doesn't, exact result I want > close to what I want.
- 80% of ad creative resources should go toward proof.
- Your promise is not unique. Your proof is. Everyone promises the same thing — the differentiator is whether they can back it up.

Source quotes (verbatim):
> "Your promise is not unique, your proof is. Everyone in the marketplace promises the same thing. The question is whether they can back it up and that is unique to you"
> "When I look at all the ads we've done over the years, 80% of them are about proof"
