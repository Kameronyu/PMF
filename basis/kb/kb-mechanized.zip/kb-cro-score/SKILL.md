---
name: kb-cro-score
description: >-
  Score a CRO change, test, or engagement against the e-commerce funnel benchmark
  system before shipping or trusting it. Use to grade a proposed split test, a funnel
  diagnosis, an order-bump/savings/social-proof tactic, or a client's readiness, and
  return BLOCK / REVISE / SHIP with per-gate evidence. Hard-gates only the countable
  (funnel benchmarks, significance thresholds, revenue stages, order-bump band, savings
  format); soft-caps the heuristic pitfalls; treats benefit-vs-feature headline as a
  pairwise-against-specimen signal, never a self-graded pass/fail. Run as a SEPARATE
  pass from the writer. Triggers: "is this test valid", "score this funnel", "can we
  call this A/B test", "is this CRO client ready", "grade this checkout change".
---

# CRO — score a change/test against the funnel benchmark system

Grade each input against its gates, then band it. **Do not run this in the same pass that
proposed the change** — a writer grading its own tactic rates it higher. Judge the one felt
gate against the winning specimens in `references/scoring-specimens.md`.

Tier discipline (the rule a fused skill breaks): **hard-gate only the countable**;
**soft-cap the heuristic**; **compare the felt against a specimen — never hard-FALSE it.**

## The judged gates (each: positive target → how it's judged → tier)

1. **Funnel health** — *target:* CVR ≥ 3% AND Add-to-Cart Rate ≥ 10% of LP visitors AND
   Add-to-Cart→Purchase ≥ 30%. *Judge:* **script gate**, three numeric thresholds. COUNTABLE.
2. **Stage diagnosis** — *target:* attribute the failing stage deterministically — ATR < 10%
   → landing page; ATP < 30% → order page/checkout. *Judge:* **script gate**. COUNTABLE.
3. **Test callability** — *target:* a test is callable only if ≥ 2,000 conversions AND
   ≥ 20,000 sessions AND ≥ 3 weeks AND ≥ 90% significance. *Judge:* **script gate**. COUNTABLE.
4. **Early-stop validity** — *target:* an early kill is valid only when a 20%+ decrease is
   sustained 3–5 consecutive days; otherwise the early stop FAILS. *Judge:* **script gate**. COUNTABLE.
5. **Program viability** — *target:* a monthly A/B program needs ≥ 1,500 orders/month; a CRO
   client needs ≥ $500K/month; granular tests need ≥ $200K/month. *Judge:* **script gate**. COUNTABLE.
6. **Test design** — *target:* AA-test validated tracking first; split is 50/50 simultaneous
   (not sequential); one test per page. *Judge:* **script gate**, present/absent. COUNTABLE.
7. **Order-bump band** — *target:* an order bump is priced $10–$20. *Judge:* **script gate**,
   numeric band. COUNTABLE.
8. **Savings format** — *target:* savings shown as an exact dollar amount, not a percentage,
   at every stage. *Judge:* **script gate**, contains-dollar / not-percent. COUNTABLE.
9. **Social-proof honesty** — *target:* counts/timers use real live data, never fake or
   hard-coded numbers. *Judge:* **script gate**, present/absent of a fabricated count. COUNTABLE.
10. **Benefit-led headline** — *target:* the headline leads with a buyer benefit, not a
    feature/product name. *Judge:* FELT — signal pairwise against a benefit-led specimen;
    never a hard FALSE. FELT (triage signal: prefer | tie | weaker).

Per-gate membership tests and the COUNTABLE threshold definitions are in
`references/criteria-tests.md` (incl. EPC/ROAS math and the creative-side Hook/Hold/CTR
benchmarks for the diagnose-before-kill split). The ROUTE contract (optimization sequence,
testing hierarchy, diagnose-before-kill, placement, category routing, payment-processor and
pixel-enrichment/EMQ selection) is in `references/route-contract.md` — gating context, not a
judged field. The diagnostic & prioritization models behind the gates (Conversion Formula,
Two-State research, Diagnostic Failure Analysis metric split, Impact Grading 0-15, Accelerated
Growth Model, CRO Maturity by revenue stage, 80/20 split) are in `references/frameworks.md`.
Research/survey/upsell-test protocols and the cart/checkout AOV stack are in
`references/procedures.md`.

## Bands (derive from gates that actually passed — not a hollow count)

- **Any COUNTABLE gate FAILS → BLOCK** (do not ship; name the failed gate).
- **All COUNTABLE pass, heuristic pitfall(s) flagged → REVISE** (fix the warned anti-pattern).
- **All COUNTABLE pass, no pitfall flagged → SHIP.**

The felt gate (#10) never blocks: a `weaker` headline downgrades SHIP→REVISE with note
"test a benefit-led variant," never below REVISE on its own.
**Readiness override (structural):** if monthly revenue < $200K, cap the band at BLOCK for any
granular split test regardless of other gates — insufficient volume voids significance (#5).

## Heuristic pitfalls (soft-cap — warn, do not hard-fail)

Match against `references/criteria-tests.md` pitfall list (tests <3 days, sequential testing,
wrong segmentation, modifying live tests, CTA only top/bottom, single payment processor,
skipped AA test, effort spread across stages, aesthetics over copy). On match → flag REVISE
with the named fix; real false-positive rate, so never an auto-BLOCK.

## The negatives live here (≤5), each paired with a positive target

- **Calling a test under threshold** → BLOCK. (positive: ≥2,000 conv AND ≥20,000 sess AND ≥3 wks AND ≥90%)
- **Early-killing without a sustained 20% drop** → BLOCK the early stop. (positive: 20%+ for 3–5 days)
- **Savings shown as a percentage** → flag REVISE. (positive: exact dollar amount at every stage)
- **Fake / hard-coded social-proof counts** → flag REVISE. (positive: real live data only)
- **Sequential A/B instead of 50/50 simultaneous** → flag REVISE. (positive: simultaneous 50/50 split)

## Output contract (per input)

```
input: "<verbatim change/test/tactic under review>"
gates: [ {n, target, verdict: pass|fail|signal, tier, evidence_quote, source} ]
countable_gates: {funnel, diagnosis, callability, early_stop, viability,
                  design, bump_band, savings_format, social_proof}  # script results, pass/fail
felt_signals: {benefit_headline}                                    # pairwise-vs-specimen: prefer|tie|weaker
band: BLOCK | REVISE | SHIP
flags: [ ... ]   # from the negatives + heuristic-pitfall list, each with its fix
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every applicable gate has a verdict; band present.
**SOUNDNESS:** every COUNTABLE verdict came from the script (not eyeballed); the felt verdict
is pairwise-vs-specimen, not self-graded; band derived only from gates that passed their
tier's check; each `pass`/`fail` carries an `evidence_quote` that is a verbatim substring of
the input or the source benchmark. `emit_ready` only if SOUNDNESS holds; else `BLOCKED:<gate>`.

## Self-test (is this grader sound?) — any NO, fix

- Are only gates 1–9 hard-gated (by script), with gate 10 as a pairwise-vs-specimen signal?
- Is the felt judgment run separately from the writer, against a real specimen?
- Does the band come from gates that passed their tier's check, not a raw count?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Are structural rules (readiness override, ROUTE contract) kept out of the hard gates?
- Is every quoted specimen a verbatim substring of a source file (no composites)?
