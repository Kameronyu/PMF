# ROUTE contract — named-trigger selection & sequencing (gating context, not a judged gate)

These are structural contracts the scorer uses as context when judging whether a change is
sequenced and routed correctly. They are NOT hard gates and NOT self-graded — they tell the
grader what "in the right order / in the right place" means. A change that violates a contract
is flagged REVISE with the named fix, never auto-BLOCKED (except the readiness override in SKILL.md).

## Sequencing contracts
1. **Optimization sequence (Conversion Priority Hierarchy):** Offer → Angle → Funnel →
   Copywriting → UX/UI Design. Validate each level before the next; never polish design first.
2. **High-Impact Testing Hierarchy:** offer/price → ad-to-LP copy alignment → customer-journey
   routing → traffic-source segmentation → structural funnel changes → minor tweaks last.
3. **Diagnose-before-kill:** diagnose root cause → fix the weak variable → relaunch → only kill
   after relaunch also fails. "Do not kill unprofitable campaigns immediately."
4. **Continuous iteration loop:** Research → Hypothesis → Split Test → Validate → Roll Out →
   Repeat; never implement page changes without a split test.
5. **Data-to-iteration loop:** behavioral signal → diagnose cause → pull customer voice →
   rewrite element in verbatim customer language → deploy → measure → iterate.
6. **1% weakest-link rule:** map every funnel stage; fix the single weakest link for ≥1 week;
   do not spread effort across stages simultaneously.
7. **Full-sales-page section order:** benefit headline → value props → product benefits → UGC
   trust section → testimonials → press → how it works → comparison → key features →
   money-back guarantee → more testimonials → FAQ.

## Selection contracts (by named trigger)
8. **Traffic-source routing:** cold paid traffic needs a warm-up/advertorial layer before the
   pitch; organic social converts differently than paid; route accordingly.
9. **Event-driven method switch:** during high-traffic sale events, replace standard A/B with
   multi-arm bandit, 3–4 variations, shift traffic dynamically/manually every 30–60 minutes.
10. **Payment-processor selection:** test Stripe / Checkout.com / EasyPayDirect / PayPal; pick
    the highest approval rate.
10b. **Pixel enrichment / EMQ optimization:** "Pixel enrichment sends additional customer data
    identifiers back to the Facebook pixel beyond standard event data." Higher Event Match
    Quality (EMQ) score → better algorithmic targeting → reduced cost per acquisition. A direct
    lever for lowering CPA without changing creative or funnel structure — sibling to
    payment-processor selection (both raise effective performance without touching the page).
11. **Category routing:** baby → safety certs above fold; fashion → size guides / lifestyle / UGC;
    high-ticket → craftsmanship storytelling; technical → features-as-benefits; services → lead
    with transformation; demo-required SaaS → optimize like info-product funnels.

## Placement & alignment contracts
12. **Hypothesis format:** "If [change], then [expected result], because [reasoning]."
13. **Message congruency:** consistent ad creative → landing page → cart → checkout → email
    (tone, imagery, color, variant shown, models featured).
14. **Placement contracts:** CTA at every section break (≤1 screen without a buy button); social
    proof distributed throughout, not consolidated; testimonials positioned near the objection
    they answer; guarantee section at page bottom.

## Registry-anchored terms used as context (anchor to term_registry.json; never redefined here)
Pain (P), Belief (B), Desire (D), Objection handle, Trust signals, Value models, Awareness
level, Hook, Market sophistication. These are the buyer-side and differentiator levers the
copy and trust contracts above operate on; their definitions live in the registry.
