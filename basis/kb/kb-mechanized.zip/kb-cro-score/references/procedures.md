# CRO execution procedures — research, survey, and upsell-test protocols

Concrete procedures the scorer uses as context when judging whether research and AOV work was
done the right way. These are how-to protocols, not hard gates. Restored verbatim-faithfully
from the source files.

## Three-Step Audience Research System

The concrete research protocol behind the data-to-iteration loop.

> 1. Create 30 high-quality questions for a questionnaire (quality of questions determines quality of answers)
> 2. Conduct conversations with 20-40 target audience members; use gift cards or dinners as incentives
> 3. Research YouTube comments, Reddit, and specialized forums where the audience openly discusses problems

Pair with the Two-State framework (see `frameworks.md`): the 30 questions should surface both
the Current Situation (pains, beliefs, anxieties) and the Desired Situation (dreams, wishes).

## Sprint-Based Survey Strategy

Cadence and survey types for ongoing customer-voice collection.

> - Run surveys every 3-6 months or triggered by: new product launches, economic shifts, major market events
> - Two types: on-page pop-ups (after 30-60 seconds on homepage/product pages) and post-purchase surveys on thank-you pages
> - Sprint model minimizes friction while gathering quality data

## Upsell Variation A/B Testing Methodology (Cocunat case study)

The named upsell-test methodology and its result.

> Test three upsell mechanics simultaneously: (1) same product in different quantities,
> (2) one different complementary product, (3) carousel of multiple different products. All
> three variations outperformed the control. Variation 2 (single different product)
> outperformed all others by far → 15% revenue lift. Run for ~30 days for significance.

## Cart and Checkout AOV Stack

The AOV-lever stack for cart/checkout (the order-bump $10-20 band is hard-gated separately as
gate 7; these are the sibling levers).

> - Free shipping progress bar (micro-commitment to threshold)
> - One upsell in cart
> - Pre-selected bundle options
> - Pre-selected expedited shipping upsell
> - Subscription toggle for LTV

Checkout-specific stack (Weische Framework): limited-inventory urgency at top; "Your cart is
reserved for 10 minutes" timer; money-back guarantee doubled (90 → 180 days) on checkout page
only; six-month supply pre-selected; expedited shipping upsell pre-selected; specific coupon
code for added perceived value; trust elements and testimonials on the checkout page.
