# CRO frameworks — the diagnostic & prioritization models behind the gates

These are the source frameworks the scorer leans on as the *reasoning* behind its gates. They
are gating context (how to diagnose, prioritize, and stage), not new hard gates. Restored
faithfully from `cro--carl-weische.md`, `cro--mark-builds-brands.md`, and
`cro-conversion-optimization-split-testing--carl-weische.md`.

## Conversion Formula (the core diagnostic model)

The model behind funnel scoring — every gate maps to one of its terms.

> Formula: Conversion = (Customer Motivation × Value Proposition × Incentive) / (Friction + Anxiety)
> - Motivation: prospect awareness level and core desire
> - Value Proposition: appeal, exclusivity, credibility, clarity
> - Incentive: reason to act now
> - Friction: navigational confusion, cognitive load, checkout complexity
> - Anxiety: unresolved objections, missing trust signals

Use it to *locate* a failing funnel: a low add-to-cart rate is usually a Value-Proposition or
Friction problem on the landing page; a low add-to-cart→purchase ratio is usually Friction or
Anxiety at the order page/checkout. The numerator levers (motivation, value prop, incentive)
multiply — a zero on any one zeros the whole; the denominator (friction, anxiety) must be
driven down, not just the numerator up.

## Two-State Target Audience Research Framework

The gap-between-states model is the core lever for all conversion messaging.

> - Current Situation: pain points, beliefs, motives, anxieties, emotions
> - Desired Situation: dreams, wishes, how they want to look and feel
> - The gap between these states is the core lever for all conversion messaging

Wrong pain points or wrong desired state = no resonance = no conversion, independent of
technical optimization. For non-obvious pain-point products (luxury, fashion), focus on the
desired emotional state and status expression.

## Diagnostic Failure Analysis Framework (creative vs funnel metric split)

Do not kill unprofitable campaigns immediately. First diagnose the root cause, fix the
identified weakness, and relaunch before making a final kill decision. Without diagnosis,
testing is random gambling. The instrument is a split of metrics:

> Creative diagnostic metrics: Hook rate, hold rate, CPC, CPM
> Funnel diagnostic metrics: AOV, conversion rate, EPC (earnings per click)

Process:
1. Campaign underperforms → run diagnostic across creative and funnel metrics
2. Identify the specific weak variable
3. Adjust that variable and relaunch
4. Only kill after relaunch also fails

This converts failure into structured learning and compounding iteration. Map the failing
metric to its side: weak hook/hold/CPC/CPM → fix the creative; weak AOV/CVR/EPC → fix the
funnel. (Creative-side benchmarks live in `criteria-tests.md`.)

## Impact Grading System for Hypothesis Prioritization

The 0-15 prioritization scheme that ranks hypotheses before testing. (Only the "one test per
page" clause is a hard gate — gate 6; the grading scale itself is prioritization context.)

> All CRO hypotheses scored against 10 KPIs (e.g., Is the change above the fold? Was it
> discovered via user testing? Is it supported by quantitative data?). Scale: 0-15 points.
> Higher score = higher priority. Only one test per page at a time.

Use it to sequence the backlog: score each hypothesis 0-15 against the 10 KPIs, test the
highest scorers first. Higher score = higher priority.

## Accelerated Growth Model (4 stages)

The compound-growth operating model; stage 1 names the full tool stack (Limbic Map and Motif
Compass are the psychology-mapping tools beyond the analytics stack).

> 1. Holistic Data Mastery: Google Tag Manager + Google Analytics + Hotjar + Limbic Map + Motif Compass
> 2. Full-Funnel Conversion Optimization: identify bottlenecks, apply consumer psychology frameworks
> 3. Rapid Testing Machine: maximize test quantity AND quality; every third test outperforms control
> 4. Iterate Growth Strategy: apply compounded learnings across all business decisions

## CRO Maturity Model by Revenue Stage

The staged priorities behind the viability gate (gate 5 keeps the $200K/$500K cutoffs; these
are the per-stage priorities).

> - $1-5M/year: product-market fit, offer optimization, trust foundations (social proof, reviews)
> - $5-10M/year: build systematic data gathering, analysis, and testing processes
> - $50-60M+/year: full in-house CRO team (6+ specialists) becomes financially viable
> - $50-100M+/year: conversion optimization takes explicit priority over pure aesthetics below this threshold

Match CRO effort to business stage — premature granular testing wastes resources before
sufficient volume exists. Monthly thresholds (from the split-testing source): $0-200K → no
split tests yet (product-market fit); $200K-500K → landing pages/advertorials/structural
changes; $500K+ → granular split testing on smaller details.

## 80/20 Growth Split

The prioritization rule behind "fix the foundation before iterating."

> - 80% of growth from foundational offer/funnel/angle setup
> - 20% from iterative A/B testing
> - High-leverage tests can shift revenue 10-30% overnight

## EPC / ROAS business-case formula

The business-case math that turns a CVR/AOV lift into a ROAS lift.

EPC (Earnings Per Click) Formula: "Conversion Rate × AOV = EPC. ROAS = EPC / CPC."

- Improving CVR 4%→5% AND AOV $50→$60 increases ROAS from 2x to 3x with zero additional ad spend.
- Revenue per user and profit per user are the most critical daily website metrics.
- Use EPC as the funnel-side health metric in the diagnostic split above; ROAS = EPC / CPC ties
  funnel performance back to media cost.
