# Per-gate membership tests + the COUNTABLE threshold definitions

All COUNTABLE gates are script-checkable. Each test is YES = pass; any can return FALSE.
Local domain metrics (not registry terms): **CVR** conversion rate · **AOV** average order
value · **ATR** add-to-cart rate (carts ÷ LP visitors) · **ATP** add-to-cart→purchase ratio
(purchases ÷ carts) · **EPC** earnings per click (CVR × AOV).

**EPC / ROAS business-case math (context for the funnel-side diagnosis):**
EPC (Earnings Per Click) Formula: "Conversion Rate × AOV = EPC. ROAS = EPC / CPC." Use EPC as
the funnel-side health metric and ROAS = EPC / CPC to tie funnel performance to media cost.

## Creative-side diagnostic benchmarks (context for the diagnose-before-kill split)
When the diagnostic split (see `frameworks.md`) points at the creative, judge it against these
benchmark thresholds (context, not a hard funnel gate):
- Hook rate benchmark | >30%
- Hold rate benchmark | >15%
- CTR benchmark | >1%
A creative under any of these is the weak variable to fix before killing the campaign; AOV /
conversion rate / EPC under their floors point at the funnel instead.

## Gate 1 — Funnel health (COUNTABLE — script gate)
- `cvr >= 0.03` AND `atr >= 0.10` AND `atp >= 0.30`.
- PASS iff all three hold. Source benchmark: "Minimum 3% for most e-commerce"; "Minimum 10%
  of landing page visitors"; "Minimum 30% (3 of every 10 add-to-carts must convert)".

## Gate 2 — Stage diagnosis (COUNTABLE — script gate)
- If `atr < 0.10` → attribute failure to **landing page**.
- If `atp < 0.30` → attribute failure to **order page / checkout**.
- PASS iff the diagnosis names the stage the failing metric implicates. Deterministic, no taste.

## Gate 3 — Test callability (COUNTABLE — script gate)
- `conversions >= 2000` AND `sessions >= 20000` AND `runtime_weeks >= 3` AND `significance >= 0.90`.
- PASS iff all four hold. A test called below any threshold → FAIL → BLOCK.
- Benchmark ranges (call at the floor): conversions 1,000–3,000 (use ≥2,000), users 20,000–50,000,
  runtime 3–4 weeks, significance 90–95%.

## Gate 4 — Early-stop validity (COUNTABLE — script gate)
- An early termination is valid ONLY if `decrease_pct >= 0.20` AND `consecutive_days in [3,5]`.
- PASS iff the early stop meets both; any other early stop → FAIL the early stop.

## Gate 5 — Program / client viability (COUNTABLE — script gate)
- Monthly A/B program: `orders_per_month >= 1500`.
- CRO client viable: `monthly_revenue >= 500000`.
- Granular split tests: `monthly_revenue >= 200000` (below → readiness override caps at BLOCK).
- In-house team viable: `annual_revenue >= 50000000` (requires min 5x ROI).
- PASS iff the relevant threshold for the input's claim is met.

## Gate 6 — Test design (COUNTABLE — script gate, present/absent)
- `aa_test_ran == true` (tracking validated before any live split).
- `split == "50/50 simultaneous"` (NOT sequential).
- `tests_on_page <= 1` (one test per page at a time).
- PASS iff all three present. Any absent → FAIL.

## Gate 7 — Order-bump band (COUNTABLE — script gate)
- `10 <= bump_price <= 20`. PASS iff in band. Expected take rate ~50% (context, not gated).
- Margin context (decision rule, not gated): "Digital products are ideal order bumps — zero
  additional fulfillment cost, 100% margin on the bump." Prefer a digital bump when one fits
  the offer; it carries the band's take rate with no fulfillment cost.

## Gate 8 — Savings format (COUNTABLE — script gate)
- `contains_dollar_amount AND NOT shows_percentage` for the savings display.
- PASS iff savings rendered as an exact dollar figure at every stage, not a percentage.

## Gate 9 — Social-proof honesty (COUNTABLE — script gate, present/absent)
- `count_source in {real_backend, real_analytics}` AND `NOT hard_coded`.
- PASS iff every stock count, visitor count, or timer is real live data. Any fabricated /
  hard-coded number → FAIL.

## Gate 10 — Benefit-led headline (FELT — pairwise only, NEVER a membership gate)
Do **not** write a yes/no test for #10. Judge whether the candidate headline leads with a
buyer benefit (vs. a feature or product name) by comparing it to a benefit-led winner in
`references/scoring-specimens.md`. Return `prefer | tie | weaker`. A `weaker` result downgrades
SHIP→REVISE with "test a benefit-led variant"; it never blocks. This is the gate the fused
skill would wrongly launder into "is this headline good? → FALSE"; keep it a signal.

## Heuristic pitfalls (soft-cap — warn-on-match, never auto-BLOCK)
Flag REVISE with the named fix; these detectors over-flag, so they are not hard gates:
- Tests ended after 2–3 days (false positives) → run to threshold.
- Sequential testing (version A then B) → run 50/50 simultaneous.
- Wrong segmentation (all visitors instead of those who hit the element) → segment to the interaction.
- Modifying live tests → freeze the site during the test.
- CTAs only at page top or bottom (scroll deserts) → CTA at every section break.
- Single payment processor untested → test Stripe / Checkout.com / EasyPayDirect / PayPal.
- Skipped AA test → validate tracking first.
- Effort spread across stages → fix the single weakest link first.
- Aesthetics prioritized over copy/speed → clarity and copy drive purchases.

## Why the tiers
Hard-gating a felt judgment (benefit vs. feature) produces confident-but-wrong FALSEs and
pushes operators toward gaming the gate; "very similar headlines produce significantly
different CVRs," so it must always be tested, not gated. Hard-gating a countable one (a number
is or isn't ≥3%; a runtime is what it is) is reproducible and safe. Soft-cap the in-between
pitfalls because the detectors over-flag.
