# Scoring specimens — the known-good headlines to judge the FELT gate against

Gate 10 (benefit-led vs. feature-led headline) is scored **pairwise against these**, never on
an absolute scale and never by the writer that produced the candidate. Randomize presentation
order; treat any single judgment as a triage signal, not a certification.

## Benefit-led headline winners (judge gate 10 against these)
- "Your most pleasant period ever"
- "Instantly relieve period cramps"
- "Instantly stand out from the crowd with affordable and unique Apple Watch bands"
- "Say goodbye to painful periods with Maya"

Ask: does the candidate lead with a buyer benefit as cleanly as these do, rather than a feature
or product name? → prefer | tie | weaker. A `weaker` result contributes no SHIP for the headline.

## Quantified-claim / trust microcopy references (sanity-check supporting copy)
- "12 hours of leak-proof protection"
- "100% secure payment"
- "60-day money-back guarantee"

## Emotion-driven cart-nudge references (the winning lift specimens)
- "Excellent choice! You put products in cart right now"
- "Congratulations, your products are waiting for you"

## Savings-display reference (the dollar-not-percent winner)
- "You saved $21.87"

## How to run the pairwise judge
1. Present candidate + one specimen, order randomized.
2. Ask which better leads with a buyer benefit and why (criteria before verdict).
3. Record `prefer | tie | weaker` + the reason. `weaker` contributes no pass for the headline.
4. Never let the model that generated the candidate be the judge.
