# Specimen bank — verbatim winning research questions, with what each surfaces and feeds

Preserved verbatim from `customer-data--carl-weische.md`. These are the highest-value asset
in the skill — study and adapt them, do not abstract them into a fixed questionnaire. Each
question shows the *form* of a good prompt: open-ended, single-clause, anchored to a real
decision, returning the customer's own words. That form is what steers a model.

Each maps to a slice of **PMBD** (Pain, Belief, Motif, Desire) and routes to a specific
downstream consumer (headline testing, FAQ, objection handling on PDPs/landing pages).

## Motivation — surfaces purchase drivers
- "What was the primary reason you decided to purchase today?"
  — PMBD: Desire/Motif. Asks for the *one* driver, past tense, anchored to a real purchase.
    Feeds: headline testing (lead with the driver customers name most).

## Hesitation — surfaces objections (Belief)
- "What almost stopped you from buying?"
  — PMBD: Belief/Pain. "Almost stopped" names friction without leading the witness.
    Feeds: objection handles on PDPs, checkout, and landing-page objection sections.

## Alternatives considered — surfaces the competitive set
- "What other solutions did you consider before choosing us?"
  — PMBD: Belief/Motif. Maps the buyer's real consideration set in their own framing.
    Feeds: differentiation copy, comparison sections, FAQ.

## Outcome expectation — surfaces Desire in the buyer's words
- "What result were you hoping to achieve?"
  — PMBD: Desire. The wanted outcome as the customer phrases it — Desire copy you mirror
    directly under the Command+F verbatim rule (keep only words that appear in research).
    Feeds: headline testing, hero copy, FAQ framing.

## Cohorts to ask (the contract behind the questions)
- **Converted customers** — to understand purchase drivers (Motivation, Outcome).
- **Near-converters / churned customers**, where accessible — to map abandonment reasons
  (Hesitation, Alternatives). Both cohorts are required for full funnel insight.

> Note: mine existing communications (support inboxes, reviews, social comments, community
> threads) BEFORE deploying these questions. Real unprompted language surfaces the actual
> mental model customers use — feed that into the wording, don't ask cold from assumptions.
