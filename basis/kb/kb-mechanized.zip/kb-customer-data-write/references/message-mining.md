# Message mining — where to mine, and what a recurring pattern means

Mine existing communications BEFORE drafting survey questions. Mining prioritizes zero-cost
data already inside the business: customer support inboxes, post-purchase reply emails, product
reviews (on-site and third-party), social media comments, and community threads. Surfacing real
unprompted language first is what keeps the survey from being designed around internal
assumptions — the actual mental model customers use should be mirrored in ad copy and landing
page headlines.

## Interpretation rule — what a high-frequency pattern signals (and how to act)

When you cluster the mined corpus by frequency, a recurring phrase or repeated objection means
one of two things, and each routes to a different action:

> "High-frequency phrases and repeated objections in this corpus indicate either unaddressed
> friction (conversion killers) or underemphasized value propositions (copy opportunities)."

- **Unaddressed friction (conversion killers)** — a recurring objection or complaint that names
  a barrier. Action: treat as a friction/conversion problem; it becomes an objection handle on
  the PDP, checkout, or landing-page objection section, or a technical/offer fix.
- **Underemphasized value proposition (copy opportunity)** — a recurring benefit or reason
  customers volunteer that the current copy under-states. Action: surface it harder — lead with
  it in headline testing and hero copy.

Mining existing communications before deploying surveys reduces survey design bias: real
unprompted language surfaces the actual mental model customers use, which should be mirrored in
ad copy and landing page headlines.

## Cohorts and sequencing (the contract behind mining)
- Mine first, then design questions from the language the corpus surfaces.
- Both cohorts still apply downstream: converted customers (purchase drivers) AND
  near-converters / churned customers (abandonment reasons).
