# Optional question shapes — anatomy + the cohort each fits

Reach for one when it fits the funnel stage and cohort. None is a required slot in a fixed
questionnaire; forcing all four on every respondent produces a survey that returns tidy,
same-y answers instead of live language. Use these to vary, not to standardize.

## Motivation
[ask for the single primary reason] + [anchor to the real purchase moment].
- Surfaces: purchase drivers (Desire/Motif). Best cohort: converted customers.
- Example: "What was the primary reason you decided to purchase today?"

## Hesitation
[name the friction] + [without suggesting what it was].
- Surfaces: live objections (Belief/Pain). Best cohort: converted customers (what they
  overcame) and near-converters/churned (what they didn't).
- Example: "What almost stopped you from buying?"

## Alternatives considered
[ask what else they weighed] + [anchor to the decision: "before choosing us"].
- Surfaces: the real competitive/consideration set in the buyer's framing.
- Example: "What other solutions did you consider before choosing us?"

## Outcome expectation
[ask for the hoped-for result] + [let them phrase the outcome themselves].
- Surfaces: Desire in verbatim customer words — the highest-value copy input.
- Example: "What result were you hoping to achieve?"

> All four are open-ended by design. The moment a shape tempts you toward a multiple-choice
> list, you've stopped capturing the customer's vocabulary and started imposing your own.
