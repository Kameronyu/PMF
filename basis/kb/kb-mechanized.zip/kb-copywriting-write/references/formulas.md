# Optional formulas — anatomy + a worked example each

Reach for one when it fits the angle. None is a required slot order; forcing a fixed
sequence is exactly what produces same-y copy. Use these to vary, not to standardize. The
worked examples are verbatim from source — study them, then build your own line.

## Money Mad Lib (positioning in one sentence)
[I help] + [WHO, specifically] + [get GOOD STUFF, concrete] + [without BAD STUFF they fear].
- The power is in the specificity of each slot; vague slots produce a forgettable line.
- Example: "I help 45-year-old women who just had kids get back into their high school jeans without giving up time with their family."

## Feature→HOW→Outcome (translate a spec into a felt benefit)
[feature] → [the mechanism by which it works] → [the concrete outcome the buyer feels].
- Never ship the bare feature; always carry it through to the outcome.
- Worked chain: "Stainless steel interior" → resists bacterial biofilm → water stays fresh for 72 hours.

## Push-Pull (alarming negative → fast resolution)
[push: alarming negative] + [pull: immediate positive turn]. Don't drag the negative.
- Example: "I think I just got scammed" — then turn it: "...until I found this."

## Damaging Admission (concede, then pivot)
[a real, damaging truth] + BUT + [the belief you want them to hold].
- The conceded flaw buys credibility; the pivot redirects it.
- Example: "Our websites are ugly as hell, but they convert."

## Contrast Headline (make the hard outcome feel easy)
[hard / desired outcome] + is now as easy as + [one small, concrete action].
- Example: "Losing 30 lbs is now as easy as making one swap in your morning routine"

## Status-Benefit (sell how others will see them)
[the feature] → [the moment someone whose opinion matters notices].
- Ask: who gives them status, when, and what status means in their subgroup?
- Example: "a cookbook so fast and easy that all your friends will wonder how you found the time to be fit and cook for your family."

## "How to X without Y, even if Z" (objection-pre-empting headline)
[How to] + [good outcome] + [without bad outcome] + [even if biggest fear/objection].
- Names the dream, removes the dreaded cost, and disarms the top objection in one line.

## MAGIC / Lead-magnet naming
- MAGIC: Magnetic reason why + Avatar + Goal + Interval + Container word.
  Example: "Busy Mom's 30-Day Relaxation Getaway for the Holidays"
- Lead-magnet naming conventions (Source: Alex Hormozi) — the name determines engagement rate
  more than anything else; advertise the result to the target audience, not the vehicle:
  - Convention 1: Number + Outcome + Time Frame — "3 Emails That Turn Cold Leads Into Clients in 24 Hours"
  - Convention 2: How To + X Without Y — "How to Build a Funnel Without Hiring a Copywriter"
  - Convention 3: Adjective + Thing + Outcome — "The Lazy Funnel Template That Converts Like Crazy"
  - Convention 4: X Mistakes — "4 Mistakes Keeping Your Business Under a Million Dollars"

## Hook–Pain–Bridge–Outcome (Source: Carl Weische — 4-part ad formula)
A four-part formula used across all ad creatives; apply consistently for brand congruency.
1. **Hook:** Contains value proposition (e.g., "In just 10 minutes you will get flexible curves with movement")
2. **Pain:** "No more X" framing (no more frizz, no more dryness, no more undefined curls)
3. **Bridge:** Connects pain to product solution
4. **Outcome:** Closes the copy loop with the customer's desired end state
- Brand using this formula (Coconut): $100M+ lifetime revenue. Creatives: 20–25 seconds.
- Distinct from the 7-element Creative Script Framework (Hook→Pain→Pitch→Mechanism→Desire→Proof→CTA) in `frameworks.md`.

## Four Elements of High-Converting Advertorial Headlines (Source: Mark Builds Brands)
Headline accounts for ~90% of advertorial performance in split testing. All four elements
required simultaneously:
1. **Self-Interest** — address "what's in it for me" directly to the target audience
2. **News Appeal** — frame like breaking news or a news article
3. **Curiosity** — use trigger words: "this," "why," "new"
4. **Quick & Easy** — present solution as fast and effortless (humans seek the laziest path)

## Externalize-Blame (lift shame off the prospect)
[It's not your fault.] + [the external system / environment that caused the problem].
- Makes the pain feel solvable rather than a personal failing.
- Example: "It's not your fault. The modern world around you is literally designed to destroy your testosterone levels."

## Desire-to-Headline 12×2 Matrix (generative scaffold — exhaust angles before selecting)

Source: Spencer Origins. A copy-GENERATION method, not a gate. Cross every desire source
against each force of change to enumerate distinct headline angles for one product, then pick.

- **12 desire sources** = 6 mass instincts (Health/Survival, Status, Sex/Relationships,
  Comfort, Control, Belonging) + 6 technological problem categories (complexity, overwhelm,
  fragility, maintenance, incompatibility, obsolescence).
- **2 forces of change:** Style Trend OR Mass Education.
- **12 × 2 = 24 total headline combinations per product.** Worked dog-harness examples: each
  instinct × each force = a distinct angle.
- Use as a generative scaffold to exhaust all angles systematically before selecting — do not
  ship all 24; generate broadly, then choose the strongest.

## Power-word substitution (raise the temperature of a flat word)
Swap a neutral word for a charged one that's still true in the prospect's frame:
"issue" → "scammed" · "popular" → "viral" · "misleading" → "chronically lying".
- Then repeat the core claim across the piece (say it more than once; show it several times).
