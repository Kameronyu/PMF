# Named source frameworks — anatomy + verbatim specimens

Restored faithfully from `/tmp/kb-src/copywriting/`. These are the full step sequences,
element lists, decision rules, and procedures behind frameworks named (but not enumerated)
elsewhere in this skill. None is a gate — they are shapes, scaffolds, and procedures the
writer borrows. Examples in quotes are verbatim substrings of the source.

---

## Sequential CTA Closing Stack — 6-step order (Source: Spencer Origins)

Augments the Closing/CTA section. An ordering contract for the close: write fresh wording
inside each slot, but keep the sequence — each step must logically flow from the previous.

Step order:
1. **Transformation vision** (paint the after-state)
2. **Mechanism distinction** (why this, not others)
3. **Social proof bridge** (others like them succeeded)
4. **Guarantee** (de-risk the decision)
5. **Price anchor** (reframe cost against alternative)
6. **Brand tagline** (identity stamp)

- Third-person framing for guarantee copy: "Thousands of customers have..." vs. "We
  guarantee..." — reduces pitch perception.
- Each step must logically flow from the previous — don't reorder.

---

## Epiphany Bridge Testimonial Framework (Source: Alex Hormozi)

A six-quadrant interview structure (Internal/External × Before/During/After) that maps a real
customer's decision journey. Captures fears, objections, and the reasoning that overcame them,
producing both persuasive content and ad creative. One interview generates three distinct
marketing assets.

Six-quadrant matrix: **Internal/External × Before/During/After**
- **Before Internal:** emotional/psychological state (e.g., 'My wife didn't respect me because
  I couldn't make money')
- **Before External:** observable facts (e.g., $33K/month income, behind on payments, almost
  lost house)
- **Decision Point External:** trigger event (saw ad, testimonials from similar businesses)
- **Decision Point Internal:** initial objection (wasn't sure if it was legit)
- Why they moved forward: saw social proof from similar profiles
- **After Internal:** emotional outcome (restored dignity, better about myself)
- **After External:** observable results (got car back, upgraded neighborhood, kids in better
  school)
- *(+2 additional points)*

Key metrics & benchmarks:
- One interview generates three distinct marketing assets
- 60-90 second ad with highlight points

Verbatim rationale (specimens):
> "This framework is valuable because it shows the prospect's own internal dialogue—their fears, concerns, and the reasoning that overcame those fears. This is more persuasive than the founder explaining why someone should buy."
> "Seeing people similar to oneself winning is the strongest motivator for taking action."

---

## Six Types of Sales Message Leads (Source: Michael Masterson, Great Leads)

Six distinct lead types cover the full range of sales message openings, each matched to a
different awareness level and offer type. Pairs directly with Schwartz's awareness levels for
maximum effectiveness. Mastery of these lead structures is prerequisite to writing
high-converting long-form copy.

- From the recommended-resource list: **Great Leads** — Michael Masterson; six lead types for
  any sales message.

> Source note: the source file names this framework and its function (six lead types matched
> to awareness levels, prerequisite to long-form copy) but does NOT enumerate the six
> individual lead types. Do not fabricate the six names; consult *Great Leads* directly to
> obtain them. Use awareness level (see `route-rules.md`) to select which lead fits.

---

## Gary Halbert's Hypothetical Maximum (Source: Alex Hormozi)

Start by imagining the absolute most effective, highest-touch version of your outreach as if
your life depended on a single attempt. Execute that unscalable version, then systematically
identify which 20% of elements drove 80% of results, and scale those elements while cutting
the rest. A concrete scale-from-unscalable execution method.

- Imagine you can only send one letter or you die — what would you do?
- Start with handwritten envelope, handwritten name, licked stamp, handwritten letter, lumpy
  mail.
- If you only have budget for 100 letters, handwrite all of them.
- Use revenue from the first 100 to scale to 500.
- Identify which 20% of the unscalable elements drove 80% of the results.
- Use cash from earlier less-scalable operations to create leverage in more-scalable operations.
- You always lose efficiency at scale, so start with the absolute most efficient process.

Verbatim (specimens):
> "You can use cash from your earlier less scalable thing to create more leverage in the more scalable thing and get 80% of the effect with 10 times the output."
> "Whenever I want to write a sales letter, I imagine I can only write one letter for my life or I'm going to die."

---

## Eight-Element Sales Page Framework (Source: Mark Builds Brands)

The "sales page (8 elements)" ordering contract named in `route-rules.md`, enumerated:

1. **Headline** — benefit-driven, must include 3–4 of 7 checklist elements
2. **Urgency** — time-limited offers create buying pressure
3. **Scarcity** — limited availability increases perceived value
4. **Guarantee/Risk Reversal** — eliminate customer risk
5. **Unique Mechanism** — explains why this solution works when others failed
6. **Social Proof** — testimonials that overcome objections or install empowering beliefs
7. **FAQ Section** — handles remaining objections
8. **Credibility Markers** — market-specific signals (not always doctors or celebrities)

---

## Problem Amplification Cascade / Downstream Consequences (Source: Carl Weische)

After identifying the core problem, systematically educate on downstream consequences to
amplify urgency before introducing the solution:

1. **Educate on the core problem** with data and external causes (e.g., "Men's testosterone
   levels have dropped almost 50% in the last four decades")
2. **List downstream consequences** of the unresolved problem (anxiety, depression, low energy,
   low sex drive, low ambition)
3. **Externalize blame** — attribute problem to modern environment, not the prospect ("It's not
   your fault. The modern world around you is literally designed to destroy your testosterone
   levels.")
4. **Transition to hope/solution** with "good news" framing after fully establishing pain

External blame reframe removes the shame barrier to purchasing. Social proof (before/after
cases) placed after problem education, before solution reveal.

---

## Strategic Objection-Resolving Testimonial Placement (Source: Carl Weische)

Each testimonial should be selected to neutralize one specific customer objection identified
through research — not displayed randomly. Testimonials are positioned as sections two, three,
or four. The testimonial block is introduced with a social proof scale framing ("hundreds of
thousands of happy customers").

- **Example objection-mapped testimonial:** "I'm so happy I'm finally using an all-natural
  skincare that actually works as advertised" → resolves objection that brand claims are
  exaggerated.
- Position testimonials addressing the most critical objections near the bottom, close to the
  CTA.
- Each testimonial should be specific and technical, not generic.

---

## Two-Option Close Framework (Source: Carl Weische)

Present the prospect with two explicit paths at close:
- **Option 1:** Leave and continue with old methods — buy expensive flawed alternatives or
  cheap knockoffs with the same problems.
- **Option 2:** Try the product risk-free like thousands who already made this choice.

Reinforce page-exclusive pricing: leaving means paying full price on the main website. Re-state
guarantee to make Option 2 feel completely without risk. Position brand as partner in the
customer's journey, not a seller.

---

## New Information as Mechanism (Source: Spencer Origins)

Augments the New Information section. Use deep, non-obvious research as the mechanism that
reframes the problem.

- Deep research (not AI-generated) to find non-obvious factual education that reframes the
  problem.
- Verified-fact requirement — surface-level education fails; must be genuinely non-obvious.
- **AG1 benchmark:** $5M clinical investment → positioned as clinically-backed → $600M business.
- **30–67% partial awareness rationale:** use counterintuitive hooks because 30–67% of audience
  has heard a concept but doesn't fully understand it.
- **Credibility-destruction test:** if 67%+ of audience already knows it, don't claim it's a
  discovery.
- Worked example: REM sleep — most know the term, few understand architecture → education
  opportunity.
- Soup brand: IBS-specific information → $13K spend → $90K revenue following month.

---

## Vague Discount Messaging Over Specific Amounts (Source: Carl Weische)

"Save up to 50%" consistently outperforms stating specific dollar or percentage discounts in
ad copy or on-site messaging. Vague maximum savings language creates a higher perceived value
ceiling. Applied during sales events to evergreen ad creative while offer details live on the
website. (A concrete copy decision rule.)

---

## Price-Per-Unit Value Reframe (Source: Spencer Origins)

- Break total price into smallest meaningful unit.
- $X for 17 meals = $2.65/meal vs. the typical $10 meal.
- Pair with quality justifier in the same sentence: "$2.65/meal AND 40 grams of protein".
- Applies to subscriptions, multi-unit products, and recurring-use items.
- Rule: always pair the low unit price with a quality signal — low price alone reads as low
  value.

---

## Avatar Revenue Scale Thresholds (Source: Spencer Origins)

A decision rule for when to expand the number of avatars copy targets. Avatar-building priority
order: (1) Desires, (2) Experiences, (3) Emotions, (4) Behaviors/Habits, (5) Demographics
(last — demographics are a byproduct of the above).

Scale guidance:
- **$0–100K:** 1 core avatar, go deep.
- **$100K–500K:** same avatar, better execution — don't expand yet.
- **$500K+:** 2–3 avatars.
- **$1M+:** expand surface area further.

Comfort (hoodie brand) benchmark: 10,000+ videos/week at $500M+ attributed to desire/behavior
targeting, not demographics.

---

## YouTube Transcript Research + ChatGPT Analysis Process (Source: Carl Weische)

Systematic content aggregation process:
1. Document 10 headlines from top-performing short and long-form videos in the niche.
2. Watch 1–2 long-form videos for full audience pain-point context.
3. Select five videos, copy transcripts via YouTube's transcript feature, feed into ChatGPT
   with structured research prompts.
4. Note high-engagement "oversharing" comments from those five videos for deeper analysis.

YouTube creators compress blog/article knowledge and provide opinions — making them efficient
research proxies for audience insight.

---

## Casual Referral Language Extraction (Source: Spencer Origins)

A distinct VoC mode — capture how customers describe the product to a friend, a different
linguistic register than complaint/review language.

- Elicit how customers describe the product to a friend — not in complaint/review language.
- Prompt to customers: "Make this less salesy and more like you're just telling a friend about
  it".
- Indicators of authentic referral language: triggering problem, uncertainty, specific time
  references, social proof framing.
- Example: "I've had it for 8 months, everyone stops and asks me about it" — natural social
  proof with specificity, no pain framing.
- Tactic: text actual customers unprompted and capture their response.
- Capture this register separately from Amazon/Reddit reviews — it's a different linguistic
  mode.

---

## Congruence Chain: Ad-to-Onboarding Alignment (Source: Alex Hormozi)

Every step of the funnel should feel like a baton pass, with each touchpoint's language and
promise matching the next. Full alignment across ad → webinar headline → webinar intro →
webinar content → sales call → onboarding → execution produces significantly more revenue.
Breaks in congruence cause drop-off and distrust.

- Ad language must match webinar headline.
- Webinar headline must match first lines of webinar.
- Webinar content must match sales call framing.
- Sales call must match onboarding and success delivery.
- Simple to understand, hard to execute — requires coordination across multiple parties.
- Complete alignment makes significantly more revenue.

Verbatim (specimen):
> "Every step should feel like a baton pass. Simple to understand, hard to execute because it requires coordination across multiple parties. Complete alignment makes significantly more revenue."

---

## Disney-Like Hero Story Advertorial Structure — 6-section order (Source: Carl Weische)

The "Disney 6-section" advertorial ordering contract named in `route-rules.md`, enumerated. The
customer is always the hero. Keep the section order; write fresh wording inside each.

1. **Section 1:** Desired situation image + headline framing the problem as solvable ("facial redness is no longer an obstacle for me")
2. **Section 2:** Introduce relatable hero character with specific, emotionally resonant pain point (personal story)
3. **Section 3:** Hero takes action, decides to find a solution, dives into root cause
4. **Section 4:** Turning point — hero discovers the product as the "magical solution"
5. **Section 5:** Explain the solution in detail — ingredients, features, benefits, unique mechanism
6. **Section 6:** Risk reversal (30-day free trial), testimonials, CTA

Product not shown until after five full paragraphs of story. PhD Beauty sustained $1M+/month
using this advertorial structure for over two years.

---

## PHC Beauty 6-Paragraph POV Advertorial Framework (Source: Carl Weische)

The "PHC 6-paragraph" advertorial ordering contract named in `route-rules.md`, enumerated.
First-person customer POV story structure (6 stages):

- **Hook:** Before/after image + emotionally resonant headline
- **Para 1:** Relatable situational storytelling (redness in the office)
- **Para 2:** Motivation and desired outcome state
- **Para 3:** Problem education and root cause explanation (temperature, stress, UV); mention fragrances in skincare cause inflammation to subtly lead toward fragrance-free solution
- **Para 4:** Consequences of the problem including emotional/mental health implications
- **Para 5:** Discovery of solution through social proof vehicle (e.g., Facebook group post)
- **Para 6+:** Product with three value pillars (immediate effect, long-term effect, unique differentiator) + risk reversal with testimonials

---

## Creative Script Framework: Hook → Pain → Pitch → Mechanism → Desire → Proof → CTA (Source: Carl Weische)

A named, seven-element ad-script structure applicable to any product. Distinct from the
Hook–Pain–Bridge–Outcome 4-part formula (see `formulas.md`). A shape to borrow, not a gate.

1. **Hook:** Interrupt and capture attention
2. **Pain:** Articulate current problem
3. **Pitch:** Introduce the product as the better way
4. **Mechanism:** Explain exactly how the product works
5. **Desire:** Paint the desired end state
6. **Proof:** Show social proof of others achieving the result
7. **CTA:** Direct action instruction

Worked template (verbatim):
> "Hey [name], do you want [desired situation]? There's a problem — [what they've been doing wrong]. But today there's a better way — [product/mechanism]. This helps you [desired situation]. It already helped [social proof], so click here now."

---

## Three Hook Archetypes for Video Ads (Source: Mark Builds Brands)

Three named hook types to vary ad openers. All focus on the problem being solved, never the
product itself. Examples are verbatim.

1. **Problem-Solution:** "Here's how I fixed my dog's health problem in just [time]" / "If your dog has this symptom, stop giving them XYZ and try this instead"
2. **Surprise/Discovery:** "I can't believe what the vet said about this supplement" / "The shocking ingredient in most supplements that's harming your pet"
3. **Expert Authority:** "As a vet for 10 years, here's the only supplement I give my dogs"

---

## Mechanism Villain Framework (Source: Spencer Origins)

Name a specific villain as the root cause; competitors only fix symptoms; the product blocks
the source. Frames product as defender/guardian, not just a better version.

- Name the specific biological/chemical/structural villain as root cause
- Structure: Name villain → competitors only fix symptoms → product blocks source
- Rule: re-explain the mechanism each time it's mentioned — never assume carry-through
- Worked example: DPP4 enzyme destroys GLP-1 ("fullness hormone") — product blocks DPP4
- Supporting data: 58% GLP-1 increase, 25% fewer calories in 7 days, 90 women 12-week study
- Frames product as defender/guardian, not just a better version of existing solutions

---

## Deep Pain Copy Structure for Landing Pages (Source: Carl Weische)

Above-the-fold copy should focus entirely on pain, not the product. Use scene-setting openers
that put the reader in a specific moment they recognize. Layer multiple pain dimensions:
physical, emotional, relational, self-esteem. Hook is achieved when the reader feels deeply
seen in their pain before any solution is offered.

Verbatim rationale (specimen):
> "It doesn't even talk about the product. The only thing it does is create pain and go deep into the pain."

---

## Message Resonance Framework (Source: Carl Weische)

Why message resonance matters — the strategic framing behind VOC research. Two scenarios exist
when broadcasting a message:

- **No Resonance:** Gap between market desire and brand message → initial traction but capped below 8 figures, poor profitability
- **Full Resonance:** Message aligns with the market's emotional wavelength → massive pull, word of mouth, seemingly infinite scale while profitable

The goal is to artificially create a "blue ocean" that attracts ideal customers and makes the
brand independent of market conditions. Message resonance requires deep market understanding —
not intuition or competitor imitation.

---

## Curse of Knowledge / Curse of Expertise Bias (Source: Carl Weische)

Brand founders who know their product deeply write copy that assumes too much baseline awareness
in cold audiences. This makes sophisticated, jargon-heavy copy fail on cold unaware traffic.
Solution: assess market sophistication and awareness level before writing. Use readability tools
to ensure copy is below 7th grade reading level. Donald Trump's political speeches average a 4th
grade readability level.

Verbatim rationale (specimen):
> "If your copy seems too stupid and simple to work, it's just about right."

---

## Sensory Language and Future Pacing (Source: Carl Weische)

Use words with pre-existing emotional/physical associations to shortcut imagination: "cuddly
soft," "toasty warm," "buttery soft," "marshmallow-like softness." Analogies like "hugging a
thousand adorable puppies" create instant vivid mental imagery. Future pacing = describing the
emotional state the prospect will experience after buying. Emotionally loaded language reduces
cognitive effort required to understand benefits. Plain feature descriptions cannot evoke the
same emotional response as sensory storytelling.
