# Route rules — which form for which situation (steering, not wording)

These are selection/sequencing contracts. They pick the SHAPE and APPROACH; they dictate no
specific words. The writer consumes them as steering; the separate scorer uses them as
structural overrides. None of these is a grade — grading lives in `kb-copywriting-score`.

## 1. Awareness → copy approach (specificity rises with awareness)

| Awareness level | Lead with | Notes |
|---|---|---|
| Unaware | Curiosity hook; T2–T3 life-frame | Create problem-awareness first; can't lead with T1. |
| Problem-aware | Their specific problem in their own words (T1) | T2/T3 reinforce. |
| Solution-aware | Failed solutions + unique-mechanism education | Disqualify the alternatives. |
| Product-aware | Objection handles, trust signals, guarantees | Compare variants. |
| Most-aware | Direct offer; value model (urgency/scarcity/discount) | Angle barely matters. |

(Anchors to `term_registry.json`: Awareness level, Awareness × angle tier matrix.)

## 2. Saturated market → angle differentiation
Same product, a NEW pain/desire angle per sub-market. Do not repeat a base claim that 5+
competitors already make — it's discounted regardless of copy quality.

## 3. Dual-persona angle selection
Gift-buyer angle vs self-buyer angle — pick by who is actually reading the piece.

## 4. Section ORDER is structural (don't reorder)
Advertorial (Disney 6-section / PHC 6-paragraph), sales page (8 elements), VSSL (5 P's or
5 W's, by offer familiarity), and the sequential CTA close stack are ordering contracts.
Keep the order; write fresh wording inside each slot.

## 5. Hook / ad structure skeletons
Hook–Meat–CTA · Hook–Retain–Reward · Promise+Proof+Plan · Four-Angle / Plus-Minus-Minus-Plus.
Pick one as a frame; do not treat its parts as required fixed-order slots for the wording.

## 6. Channel selection
Give in public, sell in private. Keep promotional asks integrated and rare relative to value.

## 7. Offer-type → pitch complexity
DIY (lightest) · DFY · DWY (heaviest) — more proof and a clearer path as done-for-you rises.

## 8. Urgency vs Scarcity (legitimate only)
Urgency = a real time limit. Scarcity = a real quantity limit. Never manufacture either.

## 9. Launch pacing
Whisper → Tease → Shout — curiosity first, CTA last; do not open at full volume.

## 10. Research → wording
Mine VOC first; the top recurring theme becomes the angle. Carry only 3–5 core pains and
3–5 core desires so the copy stays focused. Every customer word in copy must appear in the
research (Command+F rule).

## Human-review flag
Weische labels PMBD's M as "Motive"; the registry defines M as **Motif**. Do not silently
reconcile — flagged for human review (likely source naming drift).
