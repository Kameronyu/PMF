# Specimen bank — verbatim winning copy, with the job each one does

Preserved verbatim from `copywriting--carl-weische.md`, `copywriting--mark-builds-brands.md`,
`copywriting--spencer-origins.md`, `copywriting--alex-hormozi.md`. These are the
highest-value asset in the skill — study and adapt, do not abstract into ordered templates.
Each specimen shows the *form* of a good answer; that is what steers a model.

## Steal the structure, not the words (cross-niche transplant)
- "I think I just got scammed" → re-expressed as "My doctor was wrong for 10 years"
  — map the structure (negative event + stakes + curiosity gap), rebuild it in a new niche.

## Punch in the gut (intense emotion, fewest words)
- "Is that a gray hair?" — 5 words triggering fear of aging.
- "I love that you're confident enough to go without makeup" — triggers insecurity without overt aggression.

## Headlines
- "Reveal Your Most Radiant Glow" — action verb implies the glow already exists and needs unlocking, not creating.
- "Perfect Face Minus The Filters" — translates efficacy into the benefit of eliminating Instagram filters.
- "Top PGA Pro says this is the last training aid you will ever need." — credentialed authority validating the claim.
- "the panties the internet goes crazy about" — viral-popularity framing creates FOMO for an unfamiliar category.
- "What happens to your body when you eat beef organs for 30 days" — curiosity + specificity + simplicity.
- "As a vet for 10 years, here's the only supplement I give my dogs" — expert-authority lead.
- "Losing 30 lbs is now as easy as making one swap in your morning routine" — outcome made to feel effortless via a single mechanism.
- "Revealing the unfair advantage that allows some guys to almost magically attract girls and get chased, loved, and adored by 10 out of 10 women while you struggle to get a text back, a match, or serious dates — and no, it's not game, looks, height, money, or any pickup artist technique." — long-form desire headline; opens the gap and pre-empts the obvious guesses.

## Behavior callouts (what the avatar is visibly doing)
- "Are you scrolling Instagram looking at mom body transformations?" — behavior callout, not a demographic label.
- "the mom who already ordered Halloween costumes in August" — hyper-specific identity beats "busy mom."

## Pain hooks / ad body
- "Do you have trouble getting upstairs or going on a walk for a long period of time without a rash forming between your legs?" — names the specific lived pain instead of "Are you overweight?"
- "tired of taking all these calls yourself?" — leads the ad with the avatar's exact pain.
- "In just 10 minutes you will get flexible curves with movement" — hook carrying a concrete value proposition.
- "It's not your fault. The modern world around you is literally designed to destroy your testosterone levels." — externalizes blame off the prospect.
- "Cardiologists are trashing their own compression socks because of this mechanism" — implies superiority without claiming it directly.
- "I have breakfast and I'm still not even hungry by dinner. Sometimes I just skip lunch." — shows the result lived out instead of stating it.
- "This coffee has been a serious game changer for me... Before, I used to spend at least 10 minutes every morning waiting for my coffee to brew, and now I'm out the door in less than 60 seconds." — before/after told in the customer's own voice.
- "I know this sounds unbelievable, but I'm 66 and this has made my memory and energy levels better than when I was 25." — testimonial that names the disbelief, then the specific result.

## Sell the outcome / status, not the feature
- "the way people look at me when I walk in a room" — sells the status moment, not the product (lip filler).
- "picking up your grandchild without struggling" — replaces "feel better" with an exact moment.
- "A thousand songs in your pocket" — one sentence carrying the whole value proposition (iPod).
- "a cookbook so fast and easy that all your friends will wonder how you found the time to be fit and cook for your family." — ties the benefit (fast) to status (how friends see them).

## Positioning / naming
- "I help 45-year-old women who just had kids get back into their high school jeans without giving up time with their family." — Money Mad Lib: WHO + concrete GOOD + BAD avoided.
- "Busy Mom's 30-Day Relaxation Getaway for the Holidays" — MAGIC name (magnetic reason + avatar + goal + interval + container word).
- "The Lazy Funnel Template That Converts Like Crazy" — lead-magnet name: adjective + thing + outcome.

## CTAs / outreach / close
- "I helped the Johnsons (your neighbors) take out their trash. They sent me over here." — warm name-drop opens the cold door.
- "Would you be opposed to me doing it for you?" — no-based question; default bias toward "no" produces agreement.
- "I'm starting a little trash cleaning business. I want to help five or 10 people and just do my service for free. If it's good and you're open to leaving me a review, it would mean the world to me." — compliment-ask-referral warm outreach.

## Damaging admission / guarantee
- "Our websites are ugly as hell, but they convert." — concede a real flaw, pivot to the belief you want.
- "We will never miss a pickup day. If we do, three months free." — pairs a guarantee with the biggest pain.
- "Delivered on time and on budget or I give you my profit (20%)" — profit guarantee: if not X by Y, we give you Z.

## Escalation (humor that compounds the claim)
- "If Mr. Clean invented a humidifier" — escalates the easy-to-clean claim into a vivid image.
- "Take too many and you turn into Chewbacca" — escalates the hair-growth claim into comic exaggeration.

> Note: write in the prospect's verbatim VOC language. Run Command+F on your research for
> every customer word before you keep it — if it isn't in the research, it isn't theirs.
> Feed real VOC, not adjectives; a product brief alone yields generic output.
