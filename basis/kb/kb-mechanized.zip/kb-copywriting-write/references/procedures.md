# Execution procedures — research → wording → AI-assisted production

These are step-by-step methods that FEED the writer (research pipelines, compression loops,
AI-production workflows). They are not gates and dictate no wording — they produce raw
material and tighten drafts. Restored faithfully from source.

---

## 1. Sub-Avatar Research Method (400+ Comment Signal) — Reddit-to-headline pipeline

Source: Spencer Origins. A broad audience is too generic to write to. Split it into
behavioral sub-avatars, mine each one's exact pain on Reddit, capture verbatim language,
then turn raw quotes into headline candidates.

- Break broad audience into 2–4 behavioral sub-avatars.
- Search Reddit per sub-avatar's specific pain/behavior combo.
- **Comment count signal: 400–620+ comments = high pain intensity thread worth mining.**

**Full process:**
1. Define core desire
2. Identify 2–4 sub-avatars behaviorally
3. Reddit search per sub-avatar's exact pain/behavior
4. Document verbatim quotes
5. Feed raw quotes into Claude → generate 3–5 headlines per angle
6. Select and refine

Example sub-avatars for an appetite-control product: **The Dieter, The Water Drinker, The
Bored Eater.** Each sub-avatar is a distinct search and a distinct angle set.

Calls out what people DO (behavior) rather than who they ARE (demographic). Pairs with the
Command+F VOC rule: every customer word that ends up in copy must appear in the captured
research.

---

## 2. Iterative Compression Writing Method + two-adjacent-sentences deletion test

Source: Alex Hormozi. Write a raw long-form draft, then repeatedly cut by half and fill in
gaps with higher-density content, in cycles, until every sentence carries irreplaceable
signal.

- Write the full draft first; figuring out what to say first is the hardest step.
- **Cut 50% → fill in gaps → cut 50% again → repeat until maximally compressed.**
- **Deletion test:** if two adjacent sentences convey the same meaning when only one is
  read, delete one.
- Target: every sentence should be tweet-level signal density.

Scale benchmark from source: a 1,000+ page draft was compressed to ~270 pages; each 25–30
page chapter represents a compressed 150-page book.

Verbatim rule statement (specimen):
> "The rule is always: if we read two sentences and if we only read one of them it still meant the same thing, then one of them is not required."

---

## 3. AI copy-production workflow

Sources: Mark Builds Brands (foundational docs, Claude project, GetHooked, copy-chiefing)
and Spencer Origins (the two reverse-review Claude inputs).

### 3a. Four Foundational Documents System (Mark Builds Brands)

Before any copy is written, build four documents that serve as the persistent knowledge base
for all marketing and AI prompting:
1. **Research Document** — 20–60 pages of customer insights from forums, Reddit, and social
   media (8–20 min AI deep research process using Gemini 2.5 Pro).
2. **Avatar Document** — target customer profile with verbatim pain-point quotes (e.g., "I
   can't afford another huge bill"), demographics, goals.
3. **Offer Brief** — funnel architecture, awareness levels, unique mechanisms, consciousness
   levels, all copy ingredients.
4. **Necessary Beliefs Document** — the specific beliefs a prospect must hold to purchase;
   marketing is reframed as belief-change work (shifting limiting → empowering beliefs).

All four are uploaded into a custom Claude project as persistent context. AI output quality
is directly proportional to input quality. Poor AI output = inadequate prompting, not tool
failure.

### 3b. Claude project workflow (Mark Builds Brands)

Claude (Opus 4.1 for generation, Sonnet 3.5 for production copy) is the preferred LLM for
creative copywriting. A dedicated Claude "project" stores foundational documents and
instructions persistently.

Workflow: upload all four foundational docs + competitor swipe files → generate outline
first → expand to full draft. Simple conversational prompts suffice once context is loaded.
Sales page copy can be produced in under 30 minutes. Competitor sales pages downloaded as
PDFs and uploaded to ChatGPT enable deep-research prompt extraction of buyer psychology and
copywriting frameworks.

### 3c. Hook & ad-script generation (Mark Builds Brands)

- **Hook Generation:** Load foundational documents into Claude; generate multiple hook
  variations via conversational prompts. Use the Go Full Page browser extension to capture
  full competitor product pages as PDFs → feed into ChatGPT for psychological framing
  extraction → instruct AI to generate hooks based on proven market messaging.
- **Ad Script Generation via GetHooked AI:** Input product description, target audience, and
  **creativity score (0.7 recommended)** → AI rewrites proven competitor transcripts for
  your product. Creativity score 0.7 balances proven structure with customization.

### 3d. Copy-chiefing (Mark Builds Brands)

After AI generation, read copy aloud multiple times or use the **ElevenLabs** AI voice tool
to identify friction points. Copy must flow like a "slippery slide with no bumps." AI review
checks alignment with necessary beliefs, research doc, and copywriting principles; personal
review checks natural flow and logical progression.

### 3e. Two Claude inputs not in the standard workflow (Spencer Origins)

- **Input 1: Screenshotted ad comments** — feed as images into Claude. Comments contain
  objections + buying reasons in customer language that reviews don't capture (more
  spontaneous, more emotional, more specific to your exact ad).
- **Input 2: "Where did I mess up?" reverse-review prompt** after completing a draft. Prompt
  Claude to attack the draft as a skeptical customer — surfaces logic gaps before launch.

### 3f. Readability pass (Spencer Origins, augments Mark's readability section)

- Tool: hemingwayapp.com. Target: Grade 6 reading level for all direct-response copy.
- Benchmark: one Claude rewrite pass can move Grade 8 → Grade 4.
- Exact Claude rewrite prompt: "Rewrite this at a sixth grade level. For context, here is the
  original question I am answering."
