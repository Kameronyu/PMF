# Production pipelines — generating hooks & concepts at volume

These are repeatable PRODUCTION procedures for manufacturing creative at the velocity
real accounts run on (the source ties these to $10K+/day performance). The writer's job is
the *wording*; these pipelines are how you get *many* candidate wordings fast, sourced from
validated signals instead of a blank page. Faithful to `ads--mark-builds-brands.md` and
`ads--carl-weische.md`.

---

## Infinite Hook Glitch System (continuous hook generation)

Repeatable pipeline for continuous hook generation capable of sustaining $10K+/day ad
performance.

1. Use AI agents (GenSpark Super Agent or ChatGPT Operator) to search TikTok for
   niche-relevant problem terms (not product terms)
2. Filter for high-view + low-follower count videos — this signals hook/content quality
   rather than audience reach
3. Extract and document winning hooks
4. Upload hooks + product context + foundational documents to Claude or ChatGPT
5. Generate unlimited hook variations in batches (10, 20, or 30 concepts per session)

**Signal:** High views with few followers = hook and content are the driver, not existing
audience. (This is the same "broke influencer syndrome" leverage: creators win attention but
fail conversion — harvest their proven hooks, pair with direct-response copy.)

---

## AI-powered creative production workflows

### Swipe Method (concept pre-validated by competitor spend)
Use Get Hooked to find competitor ads running 7+ days (longevity = profitability signal).
Upload to a pre-configured Gemini Gem → AI outputs: formula for why the ad works, copy
variations with your branding, image generation prompts. Generate images via Highfield with
Nano Banana Pro. Swipes have higher win rates than originals because the concept is
pre-validated by competitor spend.

- **The 7+-day longevity signal:** if a competitor keeps an ad live past a week, it is
  almost certainly profitable — that is the filter for what to swipe.

### Original Concept Creation
Use Claude Sonnet 4.5 loaded with foundational documents. Prompt to identify emotional
triggers and hot points from research, then convert to static ad concepts. Generate 10, 20,
or 30 concepts per session; output includes unique formats and novel spins on proven formats.

### TikTok Hook Mining
AI agents search TikTok for problem-related terms → filter high views + low followers →
extract hook text → feed into Claude or ChatGPT with product context → generate variations.

**Production chain summary (named tools):** GenSpark Super Agent / ChatGPT Operator (mining)
→ Get Hooked (competitor swipe discovery) → Gemini Gem (formula + copy + image prompts) →
Highfield + Nano Banana Pro (image generation) → Claude Sonnet 4.5 / ChatGPT (concept
generation from foundational documents).

---

## Engagement-Driven CPM Reduction Strategy (engineer comments → cheaper traffic)

Meta and social platforms reward ads that drive high comment engagement with lower CPMs
because engagement signals ecosystem health. Engineer controversy, relatability, or
participation prompts.

- **Golf store example:** asked commenters to "share your swing," personally engaged with
  each response → massive comment volume, significantly lower CPMs, cheaper traffic.
- **Persona Nutrition Karen campaign:** 60 million views on a single Meta ad ID; Karens and
  non-Karens arguing in comments organically boosted ad reach.

**As a craft move when writing:** build a participation prompt or a deliberately divisive
relatable beat into the creative so the comment section does free distribution work — the
engagement loop, not just the click, is a lever on cost.

(The Karen hybrid named in `references/route-rules.md` — seven-element controversy + DR
structure — is the structural vehicle that operationalizes this engagement-CPM mechanism.)

---

## Multi-Avatar Creative Strategy (one formula, many faces)

Feature 6-7 different models representing distinct customer avatars differentiated by age,
hair structure, hair color, and hair length. Mix UGC and premium studio shots. Each avatar
variation targets a distinct segment of the potential customer base. Apply the same
copywriting formula across all avatar variations. Creatives are 20-25 seconds long.

- Production pattern: write the copy formula ONCE, then re-shoot/re-cast it across 6-7
  avatars — the wording is held constant; the face/segment is the variable.

---

## Five Native TikTok Ad Styles (+ editing principles)

TikTok requires disruption marketing — users are not actively searching. Five formats that
make content feel native:

1. **Showcasing**: product demos in TikTok-native editing style
2. **Shared formats**: meme culture and POV content
3. **Wow factor**: dopamine-spike content to stop the scroll
4. **Shock factor**: reality-snapping content that breaks pattern recognition
5. **Thirst traps**: attention-grabbing model-based content

**Editing principles:** fast cutting, zoom in/out, native captions, trending background
music.

- Winning example: German news footage with basic CapCut captions contributed to over $1M
  revenue; page converted at 4%+.
