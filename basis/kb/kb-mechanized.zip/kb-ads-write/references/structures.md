# Optional structures — anatomy + a worked example each

Reach for one when it fits the angle and traffic temperature. None is a required slot order;
the source's own note is that order is flexible and should be tested. Use these to vary, not
to standardize — forcing every beat is what produces same-y, compliant ads.

## Viral seven-beat (cold prospecting; order flexible — test sequences)

Hook → Problem → Solution → Product intro → Social proof → Benefit stacking → Objection
handling + CTA + offer.
- Invest 70%+ of creative effort in the **Hook** (emotional or visually weird).
- The body's job is to make something people actually want to watch; the PDP-mirroring tail
  only matters if they're still there.

## PetLab six-beat (curiosity-led DR; the canonical worked example)

Hook → Education (knowledge gap) → Product intro → Benefits → Social proof → CTA with
embedded social proof.
- Worked example (verbatim, study the *moves*):
  - Hook: "Dog owners never ignore these three things in your dog's teeth"
  - Education: "Not many owners know this, but these are three signs your dog's teeth need support"
  - Benefits: "Efficient and affordable way to help their dental health today"
  - CTA: "Join thousands of dog owners seeing amazing results"

## Holy Grail (new-product launch, warm-capable)

Hook → Body (unique mechanism + how it works, 1-2 min) → CTA 1 → Social Proof → CTA 2.
- Tie every body element to a tangible *outcome*, never a feature — people buy outcomes.
- CTA 1: simple, outcome-tied, for the already-convinced. CTA 2: after proof, for skeptics —
  include guarantee + scarcity + offer.
- **PIG (Punch in the Gut):** the hook must create an immediate visceral emotional response;
  if it fails, the rest is irrelevant.

## Curiosity-gap pain-point headline (advertorial / cold)

[name a pain the avatar already feels, in their words] + [withhold the solution].
- Pose it as a present-tense question; never reveal the product in the creative.
- Examples: "Are you tired of menopause brain?" · "Do you have this pain point right now?"

## FOMO prospecting (manufacture inevitability)

[assert the thing is about to blow up] + [route to pre-sell, not PDP].
- Example: "This coffee is about to go viral" paired with a time-saving/lifestyle testimonial.

## Pre-frame promise (experiential / sensory-limited products)

[mine the #1 benefit from reviews] + [pre-frame the watch around getting it].
- Example: "if you buy this, you will get complimented" (campaign: "Prepare to Be Complimented").

## Shopping product title (the ONE formulaic case — feed targeting, not a felt hook)

Main keyword + Brand name + Two main USPs + Product spec + 2-3 additional keywords.
- Google reads the *title* (not description/category) to set Shopping targeting; address
  customer pain points directly in the title. This is composition by formula, not voice.
