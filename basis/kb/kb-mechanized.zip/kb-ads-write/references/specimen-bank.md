# Specimen bank — verbatim winning ad copy, with the angle each executes

Preserved verbatim from `ads--carl-weische.md` / `ads--mark-builds-brands.md`.
These are the highest-value asset in the skill — study and adapt, do not abstract into
templates. Each specimen shows the *form* of a good answer; that is what steers a model.

## Hooks (first beat — open a loop, deliver a Punch in the Gut)

- "Dog owners never ignore these three things in your dog's teeth"
  — angle: pet-parent guilt / care → curiosity via a numbered list. Names the avatar, asserts
  a non-negotiable, opens a "what three?" loop. (PetLab Co, six-beat ad.)

## Pain-point curiosity-gap headlines (advertorial / cold — pain stated, solution withheld)

- "Are you tired of menopause brain?"
  — angle: relatable current pain in the avatar's own words, posed as a question.
- "Do you have this pain point right now?"
  — angle: present-tense self-diagnosis prompt; the gap is the unknown "this."
  These never reveal the product; the curiosity gap drives CTR.

## FOMO prospecting headline (manufacture inevitability)

- "This coffee is about to go viral"
  — angle: get-in-before-everyone; sells the moment, routes to pre-sell content, not the PDP.

## Pre-frame copy (reframe the entire watch around one mined benefit)

- "if you buy this, you will get complimented"
  — angle: substitute social proof of the *outcome* for sensory proof you can't deliver
  online; review-mining found "compliments" is the #1 fragrance benefit.
  (The campaign is named "Prepare to Be Complimented".)

## CTA with embedded social proof (the ask and the proof are one line)

- "Join thousands of dog owners seeing amazing results"
  — angle: herd activation; "join" + "thousands" makes buying feel like catching up to a
  crowd already moving. (PetLab Co, six-beat closing line.)

## Education / knowledge-gap beats (mid-ad, keep the loop open)

- "Not many owners know this, but these are three signs your dog's teeth need support"
  — angle: privileged knowledge; the not-many-owners-know framing flatters the watcher into staying.
- "Efficient and affordable way to help their dental health today"
  — angle: benefit beat — outcome (dental health) + low-friction framing, no feature list.

> Note: an ad executes an **angle** (the emotion invoked to drive purchase) against a real
> **avatar**. Feed real voice-of-customer / review-mining language, not adjectives — a
> product brief alone yields generic copy. The strongest lines above all came from mining
> what real buyers said.
