# Route rules — the controversy + DR structural vehicle

Faithful to `ads--carl-weische.md`. This is the structural vehicle that operationalizes the
engagement-CPM mechanism described in `references/production-pipelines.md`
(Engagement-Driven CPM Reduction Strategy).

---

## Karen Meme Campaign Framework (Controversy + Direct Response Hybrid)

Seven-element structure combining cultural meme with DR narrative:

1. Pattern interrupt hook: protagonist arrives disheveled and relatable (not polished)
2. Problem callout mirroring top-reviewed customer complaints (extracted from CSV review analysis)
3. Product intro solution on clear visual display
4. Second pattern interrupt mid-ad (re-engages dropping viewers)
5. Pre-frame post-click: survey difficulty addressed inside the ad
6. Story loop: protagonist begins journey, viewers want to know outcome
7. Controversy engineering: Karen meme sparked argument in comments, massively boosting organic reach

Results: 60 million views on single Meta ad ID; still running from May 2021. Production cost:
$4,500 (agency ran at a loss). Led to 22 similar productions in subsequent 8 months.
