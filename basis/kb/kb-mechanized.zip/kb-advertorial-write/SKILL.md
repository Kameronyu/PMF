---
name: kb-advertorial-write
description: >-
  Write the copy inside an advertorial — the long-form pre-sell page that educates and
  builds trust before any product, price, or offer appears. Use when drafting or rewriting
  advertorial hooks, resonant openings, root-cause education, listicle headlines, or
  POV leads for cold/problem-aware traffic. Leads with real winning specimens and a few
  craft targets; offers named patterns (POV Pain+Agitation+Hope, Listicle, Comparison-
  Framework) as OPTIONAL shapes, not required slots. This skill WRITES; it does not grade
  its own output — score the draft with kb-advertorial-score (a separate pass). Triggers:
  "write an advertorial", "advertorial hook / lead", "pre-sell page copy", "rewrite this
  advertorial section".
---

# Advertorial — write the editorial that sells without feeling like an ad

An advertorial is a long-form pre-sell page that reads like editorial, not advertising —
it educates the reader about the *problem* and earns trust before revealing the product.
Your job is the *wording* a reader feels: the line that pulls them in, the story that
keeps them, the education that primes desire. Lead from the specimens below; reach for a
pattern only if it helps; stay in an honest editorial voice, not a pitch.

## Start here — real winning specimens (study these before writing)

These are preserved verbatim from the source. They steer you harder than any rule.

- **Hook (pain → hope, first person):** *"My battle with relentless weight gain had me hopeless until I discovered this"*
  — battle and relentless establish and intensify the pain; hopeless deepens the
  agitation; the until-I-discovered-this loop injects hope and curiosity without naming
  anything. The reader feels seen, then leans in to find out what *this* is.

- **Resonant opening (mirror their search):** *"If you find yourself googling 'why can't I lose weight'"*
  — names the reader's own internal search behavior back to them. Recognition is instant:
  "that's me." It enters the desire they already have instead of announcing a benefit.

- **Comparison skeptical-open:** *"Do multivitamins actually work?"*
  — opens on the reader's own doubt about the category, not on a claim. A skeptical narrator
  reads as a trustworthy guide; the question earns the right to educate.

- **Mechanism-framing education:** *"stable weight gain is often just a surface symptom of something much deeper."*
  — reframes the named problem as a symptom of a deeper root cause. This primes the unique
  mechanism reveal *before* the product exists in the reader's mind — desire built on cause.

- **Listicle title:** *"Six Reasons Americans are Switching to These NASA Inspired Sheets."*
  — odd-numbered, concrete (NASA Inspired), social-proof verb (switching), and the
  product stays a category (these sheets) not a brand name. Skimmable on its own.

- **Proven-formula lead (the shape AI mirrors):** *"They laughed when I sat down at the piano"*
  — a curiosity-gap story open: a moment of doubt that demands resolution. Strong structural
  inputs make the model unconsciously reach for leads like this; let it.

More specimens, with the stage each serves, are in `references/specimen-bank.md`.

## Craft targets (steer by these; they are not a rulebook)

- **Educate first, sell second.** Roughly the first half is education and problem
  identification; trust-building and the gentle sell come after. Earn attention before you ask.
- **Skeptical, thorough narrator.** Write as a critical investigator who arrived at the
  answer, not a fan who started there. A narrator who doubts is a narrator readers trust.
- **Enter the desire they already have.** Mirror their search, their doubt, their lived
  frustration — don't announce a benefit they haven't asked for yet.
- **Root cause over symptom.** Reframe the visible problem as a surface symptom of something
  deeper; the deeper cause is what makes the mechanism reveal land.
- **Skimmable.** Write headlines and item titles so that skimming alone delivers the full
  education and trust arc — the body copy rewards, but the headlines already teach.
- **Specific stories, not generic proof.** Concrete, detailed testimonial moments beat
  "customers love it." A named situation out-pulls a superlative every time.

## Optional patterns (reach for one; let it serve the angle)

- **POV (first person):** headline shape **Pain + Agitation + Hope** — see the hook specimen.
  Reach for the pattern that serves the angle; let it shape the page rather than impose a sequence.
- **Listicle:** title shape **"[Number] Reasons [Target Audience] are Switching to [Product]"**;
  odd item count; each item carries a USP, a desired situation, or a trust signal.
- **Comparison Framework:** open skeptical → educate the genuine need → evaluate options →
  let the right product win on transparency.
- **Authority-Mimicry design** (layout, not wording): format the page to mimic a high-authority
  publication (NYT-style) so its credibility transfers; best for older / health-supplement
  audiences — see `references/patterns.md`.

Anatomy and a worked example for each is in `references/patterns.md`. These are shapes to
borrow, not required sequences — forcing a fixed order is what makes advertorials read same-y.

## Contract rules (these DO bind — they pick the shape and placement, not the words)

- **Awareness routing (funnel position Cold Ad → Advertorial → Sales Page):** the advertorial
  bridges cold/problem-aware traffic toward solution-aware. Lead with the problem and root-cause
  education — the product pitch is the sales page's role.
- **Narrative order:** education and problem identification come *before* trust-building and the
  product reveal. (The full stage sequences live as contract in `references/route-contracts.md`
  and in kb-advertorial-score.)
- **Hold the reveal:** keep brand, product name, offer, and price out of the early copy — these
  appear only in the dedicated offer/solution-reveal section, after desire is built.
- **Competitive verticals:** in supplements/beauty, aim the page at lifestyle and educational
  angles rather than direct product/category terms.

## How to use this with the grader

Draft several diverse openings and section variants (vary the pattern and the angle; don't
iterate one toward "safe"). Then hand the draft to **kb-advertorial-score** — a separate skill,
ideally a different model — for the gates (50/50 split, no premature reveal, listicle item
count, CTA stack, objection count) and the pairwise-vs-specimen judgment of narrator posture
and skimmability. Do not grade your own output here; a writer that judges itself optimizes
toward "looks like an advertorial," not "earns the next line." The contains-tests and counts
live there, not here.

## Before handoff (what kb-advertorial-score checks)

Generate several diverse drafts; the separate scorer grades — do not self-grade toward the gate.
These are the dimensions that pass will look at, listed here for awareness, not as a writer gate:

- The opening enters the reader's existing pain, doubt, or search before any claim.
- The narrator reads as skeptical and thorough rather than instantly enthusiastic
  (compare against the hook and comparison specimens above).
- The first stretch is genuine education and problem framing, not a pitch.
- The product (brand, name, price, offer) is held back until desire is built.
- The headlines alone teach and build trust on a skim (compare against the listicle specimen above).
