# Specimen bank — verbatim winning advertorial copy, with the stage each serves

Preserved verbatim from `advertorial--carl-weische.md` / `advertorial--mark-builds-brands.md`.
These are the highest-value asset in the skill — study and adapt, do not abstract into
templates. Each specimen shows the *form* of a good answer; that is what steers a model.

## Hook (the opening line that suggests struggle and injects hope)
- "My battle with relentless weight gain had me hopeless until I discovered this"
  — stage: Hook. battle / relentless set and intensify pain; hopeless deepens
  agitation; the until-I-discovered-this loop opens hope and curiosity without naming anything.

## Resonant opening (mirror the prospect's internal search behavior)
- "If you find yourself googling 'why can't I lose weight'"
  — stage: Resonant opening. Names the reader's own search back to them; recognition is
  instant. Enters the desire they already have rather than announcing a benefit.

## Skeptical category open (Comparison Framework)
- "Do multivitamins actually work?"
  — stage: skeptical question that opens a comparison advertorial. The doubt earns the right
  to educate; a skeptical narrator reads as a trustworthy guide.

## Root-cause / mechanism-framing education
- "stable weight gain is often just a surface symptom of something much deeper."
  — stage: root-cause education. Reframes the named problem as a symptom of a deeper cause,
  priming the unique-mechanism reveal before the product is in the reader's mind.

## Listicle title (numbered-list pre-sell)
- "Six Reasons Americans are Switching to These NASA Inspired Sheets."
  — stage: above-the-fold listicle headline. Odd count, concrete detail, social-proof verb
  (switching), product kept as a category not a brand name, skimmable on its own.

## Proven-formula lead (the direct-response shape AI mirrors with strong inputs)
- "They laughed when I sat down at the piano"
  — stage: lead. A curiosity-gap story open — a moment of doubt that demands resolution.
  Given strong structural inputs the model reaches for leads like this unconsciously.

## Annotated POV craft (why these specific words work — Pain + Agitation + Hope)
- *"Battle"* and *"relentless"* establish and intensify pain
- *"Left me hopeless"* deepens emotional agitation
- *"Until I discovered this"* injects hope and curiosity

> Note: these are the genuine felt specimens the source contains. The structural
> sequences (8-stage, 5-section, 10-section blueprint) are CONTRACT, not specimens —
> they live in `route-contracts.md`. Do not quote a sequence as if it were winning copy.
