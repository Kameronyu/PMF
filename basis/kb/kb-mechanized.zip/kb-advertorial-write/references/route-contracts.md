# Route contracts — structural sequences the writer CONSUMES (these are not specimens)

These dictate ORDER and PLACEMENT, not the words. They steer where a section goes; the
felt wording is yours (lead from the specimen bank). The deterministic checks on these
(50/50 split, no premature reveal, item counts, CTA stack, objection count) are GRADED by
kb-advertorial-score — not here.

## Funnel position
Cold Ad → Advertorial → Sales Page. The advertorial bridges cold/problem-aware traffic
toward solution-aware; it never replaces the ad or the sales page, and it does not pitch
the product directly.

## Narrative order (reach for one; choose by format, do not fuse them)
- **8-Stage narrative:** Hook → Authority signals → Resonant opening → Root-cause education
  → Solution introduction (unnamed) → Social proof → Mechanism explanation → Offer presentation.
- **5-Section psychological:** Problem identification → Motivation to solve → Education about
  causes → Consequences / implications → Solution discovery.
- **10-Section blueprint:** Above the fold → Listicle block → Unique mechanism → Trust
  building → Product introduction → Extensive social proof → Risk reversal → Multiple CTAs
  → Social proof stack → Final close. The final close is a **two-option framework with the
  last CTA** ("**Final close**: Two-option framework with last CTA") — not a single button;
  it presents a two-option choice carrying the page's last call to action.
- **Comparison-framework order:** skeptical question → educate the need → comparison framework
  → eliminate via outliers / qualifiers / transparency → price anchoring → authority via
  ingredient breakdown → in-page purchase.

## Beat-level shapes
- **Listicle item function:** each item serves ≥1 of {USP showcase, desired situation, trust signal}.
- **Four-part paragraph beats:** Pain Point → Ripple Effect of Pain → Product Feature → Benefit/Resolution.
- **Hook-image placement:** the hook image shows the desired transformation outcome;
  future-pacing imagery shows the prospect already using the solution and seeing results.

## Selection rules
- **Hold the reveal:** brand, product name, offer, and price stay out of the copy until the
  dedicated offer / solution-reveal section, after desire is built.
- **Vertical query targeting:** in competitive verticals (supplements, beauty), aim the page at
  lifestyle and educational angles rather than direct product/category terms. WHY: educational/
  comparison search volume is consistent monthly, creating **evergreen compound traffic** —
  identified as essential for 2024 success in supplements and beauty categories. Worked example:
  Kinobody targeted "how this product turns you into an alpha male" instead of competing on
  testosterone supplement terms.
- **Authority-mimicry design selection:** for older demographics and health/supplement
  categories, consider formatting the page to mimic a high-authority publication (NYT-style)
  to transfer institutional credibility; pair with stacked credibility claims (doctor approval,
  studies cited, manufacturing credentials). Full anatomy in `patterns.md`.

## AI production process (Mark Builds Brands — process route, consumed before writing)
Research → build 4 foundational documents → find an actively-running competitor swipe (convert
to PDF, extract structure not content) → write in chunks (headline, lead, body blocks,
transition to offer) → chief the copy. Write section by section, not in one prompt; treat the
model as a junior copywriter in dialogue.

---

## Anchor terms (defined in the registry; never redefine here)
Awareness level · Angle architecture (sequencing in long-form) · UM (Unique Mechanism) ·
Trust signals · Hook · Objection handle. See `term_registry.json` / `definitions.md`.
