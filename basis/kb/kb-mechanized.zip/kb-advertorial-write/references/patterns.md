# Optional patterns — anatomy + a real example each

Reach for one when it fits the angle and awareness stage. None is a required slot order;
the whole failure mode of advertorials is a fixed sequence that makes every page read the
same. Use these to vary, not to standardize.

## POV (First-Person) — headline shape: Pain + Agitation + Hope
[pain word] + [intensifier] + [agitation / hopelessness] + [hope + curiosity loop].
- pain → recognition; agitation → emotional stakes; hope-loop → the reason to keep reading,
  without naming brand, product, or price.
- Example: "My battle with relentless weight gain had me hopeless until I discovered this"
- First-person POV holds an educational, relatable tone throughout; the narrator stays
  skeptical and thorough, not instantly enthusiastic.

## Listicle — title shape: "[Number] Reasons [Target Audience] are Switching to [Product]"
Odd item count (5, 7, or 10). Each item carries at least one of: a USP showcase, a desired
situation (outcome / pain relief), or a trust signal (endorsement, certification, study).
Each item pairs an image with copy; write the headlines so skimming alone teaches.
- Before writing, identify the 5-7 customer objections that most block conversion; each listicle item should address one.
- Example: "Six Reasons Americans are Switching to These NASA Inspired Sheets."

## Comparison Framework — open skeptical, let the right product win
Open on the reader's own doubt about the category → educate on the genuine need or
deficiency → introduce a framework to evaluate all options → let transparency, qualifying
features, and ingredient detail surface the right choice.
- Example open: "Do multivitamins actually work?"
- Particularly effective in skeptical categories (supplements).

## Resonant opening — mirror their internal search
Write the reader's own question or search phrase back to them so recognition is immediate.
- Example: "If you find yourself googling 'why can't I lose weight'"

## Root-cause education — reframe symptom as surface of a deeper cause
State the visible problem, then reveal it as a symptom of something deeper. This plants the
mechanism framing before the product appears.
- Example: "stable weight gain is often just a surface symptom of something much deeper."

## Authority-Mimicry Pre-Sell Design — credibility-transfer via publication formatting
Design the page to visually mimic a high-authority publication (e.g., New York Times
newspaper formatting) so the institution's credibility transfers to the brand. The visual
formatting itself signals editorial authority rather than advertisement — it does the
trust-building before a word is read.
- Pair the mimicry with stacked credibility claims. Nubru's advertorial used this format
  paired with: doctor approval claims, 100,000+ studies cited, and UK manufacturing credentials.
- When to reach for it: most effective for older demographics and health/supplement categories.
- This is a layout/credibility design choice, not a wording pattern — it complements (does not
  replace) the narrative patterns above. The "100,000+ studies" credibility number is also
  graded as an advisory signal in kb-advertorial-score (G4).
