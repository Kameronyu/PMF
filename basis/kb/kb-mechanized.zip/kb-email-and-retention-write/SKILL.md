---
name: kb-email-and-retention-write
description: >-
  Write the felt, customer-facing lines that keep people paying and bring them
  back — rebooking scripts, membership/prepay closes, proactive-update messages,
  upsell pitches, retention DMs, and pain-specific value copy. Use when drafting
  or rewriting retention, rebooking, continuity, upsell, or nurture wording.
  Leads with real winning specimens and a few craft targets; offers named moves
  (Default-Close, Book-The-Next-One, Proactive-Reassurance, Concrete-Pain,
  Either/Or-Close, Maintenance-Pitch) as OPTIONAL patterns. This skill WRITES;
  it does not grade its own output — score separately with the retention scorer.
  Triggers: "write a rebooking line", "membership close copy", "retention DM",
  "upsell pitch", "rewrite this renewal/nurture message".
---

# Email & retention — write the line that keeps them paying

These are the words a customer actually reads at the moment they decide to come
back, formalize, prepay, upgrade, or stay. The job is the *wording* they feel —
not the retention strategy behind it. Lead from the specimens below; reach for a
named move only if it helps; keep it short, concrete, and low-pressure.

## Start here — real winning specimens (study these before writing)

These are preserved verbatim from the source. They steer you harder than any rule.
More, with the moment each one lands in, are in `references/specimen-bank.md`.

- **Book-the-next-one (rebooking script):** *"Your lashes will be done in 2-3 weeks; let's get that on the calendar now since I'm getting booked up"*
  — books the next visit *before* the current one ends, and the scarcity ("getting booked up") is the staff member's, not a pressure tactic aimed at the customer. It reads as a favor, not a sell.
- **Proactive reassurance (push update):** *"Hey, we ran this, everything's moving forward, nothing for you to do"*
  — names a concrete action taken on the customer's behalf, then explicitly removes any work from them. Frequent we-handled-it notes are why people feel served and don't churn.
- **Concrete pain (value copy):** *"stop feeling your thighs chafing when you're out in the sun"*
  — a physical, specific, lived sensation rather than an abstract feeling like confidence. Pain and persuasion only exist in the specific; the reader feels the exact moment, so the promise lands.
- **Default-close (formalize what they already have):** *"you've already been getting this—let's formalize it."*
  — reframes the membership as a thing the customer is *already* receiving, so saying yes is continuing, not starting. No new decision is asked for.
- **Maintenance pitch (anchored upsell):** *"You spent 20 grand on your mouth, spend a thousand bucks a year to keep it looking nice."*
  — anchors the small recurring fee against the large sum already spent; protecting an investment they made beats buying something new.

## Craft targets (steer by these; they are not a rulebook)

- **Concrete over vague.** Name the exact sensation, action, number, or timeframe — "thighs chafing when you're out in the sun," not "discomfort." The specific is what the reader feels.
- **Continue, don't restart.** The easiest yes is to keep going. Frame renewal/membership as formalizing what's already happening, not a fresh purchase decision.
- **Remove the customer's work.** Reassurance copy lands when it ends with "nothing for you to do." Carry the load *for* them and say so.
- **Anchor the ask against something bigger.** A recurring fee feels small next to the big sum already spent or the win already gotten. Put them side by side.
- **Give before you ask, and make the ask itself a give.** Most messages should deliver value; when you do ask, attach value so the ask still serves the reader.
- **Fewest words that keep the meaning.** Draft, then cut every word that adds no new information or pull.

## Optional patterns (reach for one; never force a fixed slot order)

Default-Close · Book-The-Next-One · Proactive-Reassurance · Concrete-Pain ·
Either/Or-Close · Maintenance-Pitch · Prepay-As-Free. Each is a shape to borrow,
not a required sequence. Anatomy and a worked example for each is in
`references/patterns.md`.

Multi-step copy *procedures* (when the brief is a sequence, not a single line) live in
`references/procedures.md`: the **Price-Raise** brace-email + disappearing-loyalty-discount
sequence, the **PS/PPS** placement framework (the two most-read parts; email/ad/recap PS
strategies), the **Handwritten-Card referral** PS, and **Service-Recovery** super-compensation
framing. Reach for one when the ask is a price-increase email, a PS, a referral card, or a
complaint-recovery message. Also there: the **Long-Term-Nurture** one-objection-per-message rule, the
**Dedicated-Onboarding** AB-close (1:1-before-group), and the **Marketplace-to-Owned** package-insert /
BOGO / QR-from-zero copy procedures.

## Contract rules (these DO bind — they pick the shape/moment, not the words)

- **Awareness routes the message.** Non-buyers in long-term nurture get one objection per
  message, ordered most-common-first; existing customers get default-close / continuation
  framing, not first-sale framing.
- **Book before the current service ends.** Rebooking lines belong *during or before* the
  close of the current interaction (BAMFAM), not in a later follow-up.
- **Cadence by stakes.** Lower-ticket / consumer → more frequent contact; affluent /
  high-ticket → less. Escalations climb in frequency; cold leads taper.
- **Maintenance/insurance pitch is offered immediately**, anchored to the purchase just made
  — not surfaced months later.
- **PS placement.** When the format is an email, the PS is high-read real estate (the second
  most-read part after the headline; PPS is third): use it to reward skimmers, qualify-out
  (ad PS), or one-line recap — pick the strategy in `references/procedures.md`.
- **Price increase = disappearing discount, not a hike.** For a price-raise email, follow the
  brace-email -> value-reminder -> loyalty-discount-that-phases-out sequence in `procedures.md`.
- **Referral card PS.** A handwritten-card PS tells the customer to photograph the card and text
  it to a friend as that friend's invite; don't write event-day sales copy. (`procedures.md`)
- **Recovery copy over-compensates.** Make a wrong "more than right," not just refunded. (`procedures.md`)

## How to use this with the grader

Generate several diverse drafts (vary the move and the moment; don't iterate one toward
"safe"). Then hand them to the separate retention scorer — ideally a different model — for
the gates (give:ask ratio, round-number credibility, verbatim-number presence, pain
specificity vs the specimen) and the pairwise judgment. Do not grade your own output here;
a writer that judges itself optimizes toward "looks like retention copy," not "keeps them
paying."

## Before handoff (what kb-email-and-retention-score checks)

Generate several diverse drafts; the separate scorer grades — do not self-grade toward the gate.
These are what that scorer looks at, kept here only as awareness of the target:

- Does the line carry at least one concrete specific (sensation, action, number, timeframe)?
- For a renewal/membership line, does it read as *continuing* rather than a fresh decision?
- For reassurance, does it end by removing the customer's work?
- Is it as short as the meaning allows, and low-pressure rather than salesy?
