# Multi-step copy procedures & placement frameworks (restored from source)

Named, ordered procedures the writer executes when the brief calls for them — a price-raise
sequence, the PS/PPS placement framework, a service-recovery message, and the handwritten-card
referral system. These are *shapes and sequences*, not gates. Felt lines stay verbatim; see
`specimen-bank.md` for the quotable copy. Source: `email-and-retention--alex-hormozi.md`.

---

## Price Raise Process for Existing Customers (named multi-step sequence)

Raise prices on existing customers without losing them. The copy job is Steps 2-6 (the brace email
and the loyalty-discount framing); Step 1 happens on the sales call.

1. **Raise price on new customers first** — just say the higher number on the sales call (validate the market accepts it).
2. **Send a brace/warning email** to existing customers (warn them before the change).
3. **Remind them of the value** you've already provided.
4. **Give context for the increase** — frame it as reinvesting to deliver on promises, not greed.
5. **Soften the blow with a loyalty discount** for 3-6 months equal to current pricing, then phase it out.
6. **Include a PS** offering a personal call if the increase creates genuine hardship.

Why Step 5 works: a disappearing discount feels far better than a rising price.

- Doubling price with close rate dropping from 30% to 20% is still more profitable — let it be a math problem.

> "People are much more comfortable having a discount disappear than a price go up."

**Writer use:** when asked for a price-increase email, draft the brace email (Step 2) + the
value reminder (Step 3) + the loyalty-discount-that-disappears framing (Step 5) + the hardship-call
PS (Step 6). Frame the new price as the customer keeping a temporary discount, not absorbing a hike.

---

## PS / PPS Statement Strategy (placement framework — the two most-read parts)

The two most-read parts of any advertising are the **headline** (first) and the **PS statement**
(second); the **PPS** (post-post-script) is third most-read. Three named PS strategies:

1. **Email PS** — reward readers with jokes/fun to train clicking behavior, then occasionally use the PS for a strong CTA.
2. **Ad PS** — a disclaimer of who this is NOT for.
3. **Recap PS** — restate all main persuasion points in one sentence for skimmers.

- You can use both a PS and a PPS for double impact.

> "The two most red (most read) parts of advertising are: number one, the headline; number two, the PS statement."

**Writer use:** when the format is an email or ad, treat the PS as prime real estate, not an
afterthought. Pick the strategy by intent: reward/train (email), qualify-out (ad), or one-line
recap for skimmers (recap). Reach for a PPS only when a second high-read line earns its place.

---

## Handwritten Card + Event Referral System (execution procedure + referral PS copy)

Send handwritten thank-you cards inviting customers to an appreciation event. The copy job is the PS
that turns each card into a referral invite.

- Handwritten card + a PS with referral instructions.
- The friend photographs the card and texts it as their invitation.
- At the event, 30-50% of attendees are referral prospects.
- **Don't sell at the event** — set follow-up appointments (for Monday).
- Book close appointments — don't let them slip out past 48 hours; interest wanes quickly.

> "Include a PS instructing them to photograph the card and text it to a friend as their invite."
> "Don't sell at the event — set appointments for Monday"
> "Don't book these too far out — Interest wanes really quickly"

**Writer use:** write the card's PS so the customer photographs the card and texts it to a friend as
that friend's invite. Do NOT write event-day sales copy — write appointment-setting copy instead.

---

## Service Recovery Copy (37 Magical Moments — super-compensation framing)

When a tragic moment occurs, recovery copy must make it *more* than right, not merely right. A plain
"here's your refund" forfeits the upside; super-compensation converts the wronged customer into an
ambassador.

- It takes 37 magical moments to overcome one tragic moment (Disney stat) — so over-correct.
- Name the miss, then deliver more than the customer expected as redress.

> "You can't just make it right, you have to make it more than right in order to actually make it right."
> "The people that you wrong and then super compensate become your biggest ambassadors."

**Writer use:** for a complaint/recovery message, write the redress as *more than right* (extra
value, not just a refund), and frame it as the company looking out for them — the same ethical-care
tone that makes proactively-downgraded customers never cancel.

---

## Long-Term Nurture Sequence Strategy (rule + sequencing the writer obeys)

The rule behind the "awareness routes the message" contract line: **every prospect who does not buy
immediately enters a long-term nurture system** (email sequences, groups, or both). No prospect is
discarded. Nurture keeps providing value and answering FAQs to convert the high-information buyers
who need more time and data.

- Every non-buyer goes into long-term nurture — no prospect is discarded
- Use email sequences, groups, or both as nurture vehicles
- Nurture content provides value and answers FAQs over time
- Some people simply need more information to make a decision — nurture delivers it
- More information provided = higher conversion percentage over time

> "Some people just need more information to make a decision. Provide as much information as possible to convert higher percentages."
> "Everyone who doesn't buy immediately goes into long-term nurture."

**Writer use:** when drafting nurture copy for a non-buyer, write to the "needs more information"
state — one objection/FAQ answered per message, value first. Pair this with the contract rule
"one objection per message, ordered most-common-first": this is the *why* (high-information buyers
convert as their FAQs get answered), so each nurture email earns its place by resolving one real doubt.

---

## Dedicated Onboarding Before Group Model (AB close copy + 1:1-before-group framing)

When the brief is closing a new customer into a program that has a group component, the sound shape
is **4-6 one-on-one onboarding sessions before the group**, not dropping them straight in. The copy
job is the AB close and the "you have to earn the group" framing.

- 4-6 one-on-one sessions before graduating to a group setting
- The group sessions become a pedestal — something they have to earn
- Adjust pricing if needed to accommodate the 1:1 onboarding investment
- Use an AB close (offer two yeses): `"Would you rather start in a group or one-on-one with John?"`
- If they choose group, still gift them 1-2 onboarding sessions as a bonus
- Low consumption (7% show rate) preceded the high churn problem — fix consumption first

Benchmarks: 7% show rate to calls was the root cause of 50% churn (30% weighted); backend offer was
$195/month or 4 months for $595.

> "The group sessions are now on a pedestal - it's like you're not ready for that yet, you got to earn that."
> "In order to first get consumption figured out, I like to get attribution in place."

**Writer use:** for an onboarding/close into a group program, write the AB close (the Either/Or shape
in `patterns.md`) and frame the group as earned, not default. Diagnose churn copy against the
root-cause chain: low show-rate (consumption) -> churn — the message should drive the first 1:1
session attended, not just the sale.

---

## Channel Diversification / Marketplace-to-Owned Migration (insert + email-from-zero diagnostic)

When customers are trapped on marketplaces (Amazon, Etsy, TikTok Shop), the copy/operational job is
a package insert that migrates them to an owned website and captures email. Marketplaces drive
discovery and first purchase, but the platform owns the customer data.

- Amazon: high conversion (99.6% relative), but customer data not owned
- TikTok Shop: viral discovery channel, no email capture possible from the platform
- Etsy: an additional discovery channel
- Package inserts with QR codes convert marketplace buyers to website customers
- Email capture from website orders enables direct marketing, reducing platform dependency
- The diagnostic problem: the email list may be **zero** — all customers trapped on platforms

Benchmarks: Amazon $300,000 annual revenue, $7,100/month ad spend, 99.6% conversion rate; Etsy
$70,000 first year (launched 2019); TikTok Shop $270,000 revenue 2023; gag-gift email list: 0 contacts.

> "Include QR code to redirect to site. Leverages existing fulfillment network."
> "No email list for gag gift side — sourced through Amazon, TikTok, Etsy."

**Writer use:** when the brief is "we have no email list, everyone's on Amazon/TikTok/Etsy," write
insert copy with a QR code that redirects to the owned site and captures email — the first move is
building the list from zero, not running a campaign to a list that doesn't exist yet.

---

## Repeat Purchase Offer Engineering via Package Inserts (BOGO upgrade + QR insert)

Insert a compelling physical offer in every outgoing shipment to redirect marketplace customers to
owned channels and drive repeat purchases. The specific upgrade: replace a weak discount code with a
BOGO offer paired with a price increase on the lead product.

- Current insert (10% discount code) is weak — upgrade to Buy One Get One Free or Buy One Get Two Free
- Pair the offer with a price increase on the lead item so the deal economics work
- Include a QR code in the insert redirecting to the owned website (captures the customer from Amazon/Etsy)
- Highlight the top 2-3 best-selling items as suggested follow-up purchases
- Impulse buyers purchase for multiple people — BOGO matches their buying behavior
- Leverages existing fulfillment infrastructure (FBA/FBM) with no new channel cost

Benchmarks: current insert offer 10% discount code (described as a 'weak incentive'); return customer
rate ~50% on website (gut estimate).

> "Buy One Get One Free (or Buy One Get Two Free) on select gag gifts. Pair with price increase — fix pricing on lead item so deal makes sense."
> "Gag gift buyers impulse purchase for multiple people. Higher margin products can subsidize free/discounted items."

**Writer use:** when asked for shipment-insert copy, write the BOGO upgrade (not a thin discount
code), anchor it against a raised lead-item price so the math works, and include the QR-to-owned-site
redirect. Match the offer to impulse/multi-recipient buying behavior.
