# Specimen bank — verbatim winning retention/continuity copy, with the moment each lands in

Preserved verbatim from `email-and-retention--alex-hormozi.md`. These are the highest-value
asset in the skill — study and adapt, do not abstract into templates. Each specimen shows the
*form* of a good line at a specific decision moment; that is what steers a model.

## Rebooking — book the next visit before this one ends (BAFM / BAMFAM)
- "Your lashes will be done in 2-3 weeks; let's get that on the calendar now since I'm getting booked up"
  — moment: end of a 1:1 service. The scarcity is the provider's, framed as a favor to the customer.
- "everybody pull up calendars, when are you showing up again?"
  — moment: close of a group session; books the whole room's next attendance at once.

## Proactive reassurance — the we-handled-it, you're-covered update
- "Hey, we ran this, everything's moving forward, nothing for you to do"
  — moment: any back-end action taken for the client. Names the concrete action, then removes their work.

## Default-close — formalize what they already receive (existing customers)
- "you've already been getting this—let's formalize it."
  — moment: converting an engaged free/ad-hoc user to membership; yes = continue, not start.

## Prepay-as-free — reframe a year of prepay as today being free
- "making today free"
  — moment: pitching annual prepay; accumulated discounts cover today's service.

## Retention DM — qualify the free-content follower
- "Are you here for free content or do you want help?"
  — moment: auto-DM to a new follower; sorts spectators from buyers without pressure.

## Either/Or close — offer a choice between two yeses (onboarding)
- "Would you rather start in a group or one-on-one with John?"
  — moment: graduating a new customer into the program; both answers are commitments.

## Maintenance / insurance pitch — anchor the small recurring fee to the big spend
- "You spent 20 grand on your mouth, spend a thousand bucks a year to keep it looking nice."
  — moment: immediately after a large one-time purchase; protect-the-investment framing.

## Concrete pain — value copy that names the exact lived sensation
- "stop feeling your thighs chafing when you're out in the sun"
  — moment: the desire/pain line in nurture or offer copy. Specific bodily sensation, not "confidence."

## Diagnostic / activation question — quantified, not generic
- "How many days out of 7 did you eat all 3 meals exactly to plan with nothing else?"
  — moment: a results check-in; the specific number forces an honest, useful answer.

## Product-pruning survey — find the one keeper
- "If I got rid of everything except one thing, which would you want to keep?"
  — moment: deciding what to cut; surfaces the load-bearing feature in the customer's own words.

## Payment reframe — same price, financed framing
- "$10,000 program with 36-month 0% interest financing"
  — moment: re-presenting a recurring price as a financed program; same cost, lower-friction frame.

## Skippable-credit membership — value the customer can bank and spend on their terms
- "just execute their credit only on months they have special occasions"
  — moment: framing a credit-style membership so it never feels wasted in slow months.

> Note: these are felt lines at specific decision moments. Feed the writer the real customer
> situation (the service, the spend already made, the avatar's exact pain) — a generic brief
> yields generic copy.
