# Optional patterns — anatomy + a worked example each

Reach for one when it fits the moment. None is a required slot order; forcing a fixed
sequence is what produces same-y, compliant copy. Use these to vary, not to standardize.
Every worked example below is a verbatim specimen — see `specimen-bank.md` for its moment.

## Default-Close
[name the thing they already receive] + [reframe yes as formalizing, not starting].
- Lands when the customer is already engaged; removes the "should I start?" decision entirely.
- Example: "you've already been getting this—let's formalize it."

## Book-The-Next-One (BAFM / BAMFAM)
[state when the result/next need arrives] + [book it now] + [provider-side scarcity as a favor].
- Belongs *during or before* the close of the current interaction, never a later follow-up.
- Example: "Your lashes will be done in 2-3 weeks; let's get that on the calendar now since I'm getting booked up"

## Proactive-Reassurance
[name the concrete action you took for them] + [explicitly remove their work].
- Frequent low-effort we-handled-it notes are why people feel served.
- Example: "Hey, we ran this, everything's moving forward, nothing for you to do"

## Concrete-Pain
[name the exact lived sensation / moment], not the abstract feeling.
- Go physical and situational. Surface, vague pain makes weak copy; specific pain is felt.
- Example: "stop feeling your thighs chafing when you're out in the sun"

## Either/Or-Close
[offer two options, both of which are a yes].
- Removes the start/don't-start choice; the only question becomes which path.
- Example: "Would you rather start in a group or one-on-one with John?"

## Maintenance-Pitch (anchored upsell)
[recall the big sum already spent] + [contrast the small recurring fee to protect it].
- Protecting an investment beats buying something new. Offer immediately after the big purchase.
- Example: "You spent 20 grand on your mouth, spend a thousand bucks a year to keep it looking nice."

## Prepay-As-Free
[reframe accumulated annual discount so today's service costs nothing].
- Turns a year-long prepay into a gift the customer is giving themselves today.
- Example: framing year-long prepay as "making today free"
