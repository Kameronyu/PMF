# Specimen bank — verbatim winning upsell copy, with the angle each executes

Preserved verbatim from `upsells--carl-weische.md` and `upsells--mark-builds-brands.md`.
These are the highest-value asset in the skill — study and adapt, do not abstract into
ordered-slot templates. Each specimen shows the *form* of a good upsell line; that is what
steers a model. The copy surface for this topic is thin — this bank is at/near the floor;
add more as winning upsell copy is collected.

## Soft-conversational (thank-you page / low-friction touchpoint)
- "Did you get a chance to check out...?"
  — angle: friendly nudge, not a pitch; casual register lowers hard-sell resistance while
  order confidence is still settling.
- "You should also order..."
  — angle: peer recommendation framing; the buyer is being advised, not closed.

## Deal-reframe (checkout)
- "today's top deals" (source: Upsells framed as "today's top deals", native Shopify)
  — angle: upsell presented as opportunity the buyer gets, not a charge.

## Free-shipping / threshold nudge (cart)
- "Spend $X more for free shipping"
  — angle: extra spend becomes a reward the buyer unlocks; the threshold makes adding feel
  like winning. (The $ amount is a placeholder the buyer's cart fills.)

## Gift / exclusivity reframe (second-unit OTO)
- framed as a gift for friends/family
  — angle: the second unit is for someone else, dissolving 'I already have one' without a
  discount. (Source line: a second knee massager "framed as a gift for friends/family".)

## Authority + "mistake" narrative angle (mid-tier OTO)
- Frame: doctor explaining a facility "mistake" customers can exploit for better value
  — angle: an authority figure hands the buyer an insider advantage; buyer feels they are
  exploiting a loophole, not being upsold.

## Problem-chain steering maxim (the spine the offer copy is built around)
- "Every product should both solve a problem and create a new problem"
  — angle: each next offer is grounded in a problem the last purchase opened, so every line
  feels necessary rather than bolted on. Not a line you ship to the buyer; it is the logic
  the shipped line must obey.

> Note: the writer needs the buyer's just-purchased product and its logical "next problem"
> as input — a generic offer brief yields generic, disconnected upsells. Feed the real
> purchase context, not adjectives.
