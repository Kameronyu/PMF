# Optional framing devices — anatomy + a worked example each

Reach for one when it fits the placement and offer. None is a required slot order — forcing
a fixed sequence produces same-y, compliant copy, which is the failure mode for anything
whose job is to make a buyer feel a second yes. Use these to vary, not to standardize.

## Soft-conversational
[friendly question or peer recommendation] + [no pressure, no urgency stack].
- Use on the thank-you page and low-friction touchpoints, where order confidence is fragile
  and a pitch would crack trust.
- Example: "Did you get a chance to check out...?" / "You should also order..."

## Deal-reframe
[present the upsell as something the buyer GETS] + [opportunity/deal language, not price].
- The buyer is collecting a deal, not being charged again.
- Example (checkout): "today's top deals".

## Threshold / unlock nudge
[name a threshold] + [the reward unlocked by reaching it].
- Turns extra spend into a game the buyer wins. Works in cart with a progress mechanic.
- Example: "Spend $X more for free shipping".

## Gift / exclusivity reframe
[reposition the extra unit for someone else OR as exclusive] + [dissolve the 'already have
one' objection without a discount].
- Use for second-unit and more-of-the-same OTOs where a plain "buy another" would stall.
- Example: a second unit "framed as a gift for friends/family".

## Authority + "mistake" / insider angle
[authority figure] + [an insider advantage or "mistake" the buyer can exploit] + [better
value framing].
- Use for mid/high-tier OTOs that need cognitive justification; the authority lends proof and
  the "loophole" framing flips the buyer from sold-to into opportunist.
- Example: a doctor "explaining a facility 'mistake' customers can exploit for better value".

## Problem-chain
[the just-bought product created/left a problem] + [this offer resolves exactly that].
- The spine for any multi-step sequence: each offer feels necessary, not predatory, because
  it answers a problem the previous purchase opened.
- Steering maxim: "Every product should both solve a problem and create a new problem".

## Solution-gap / subscription completes
[name a contextual limitation of the front-end product] + [frame the subscription as filling
exactly that gap, not as an optional add-on].
- Use for subscription upsells behind a one-time front-end. Source guidance: "Identify a
  contextual limitation of the front-end product and design a subscription upsell that fills
  that specific gap. This reframes the subscription as a necessary complement rather than an
  optional add-on." Frame the subscription as "completing" the solution.
- Worked example (Nuru funnel): "Knee massager only works at home → knee patch subscription
  at $59/month fills the mobile use case."
