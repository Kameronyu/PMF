---
name: kb-vssl-write
description: >-
  Write the felt prose of a Video Sales Letter (VSL) — the hook, the lead/nightmare
  scenario, the binary-options close, the pattern-interrupt and pain-callout lines that
  decide whether cold traffic keeps watching. Use when drafting or rewriting VSL script
  copy: the opening 3–5s micro lead, the first-20s lead, the hook's three beats, shade
  thrown at alternatives, or the close. Leads with real winning specimens and a few craft
  targets; offers the hook-beat and binary-close shapes as OPTIONAL patterns to reach for.
  This skill WRITES; the separate kb-vssl-score grades — score the script separately
  with kb-vssl-score. Triggers: "write a VSL hook", "draft the VSL lead", "write the VSL
  close", "rewrite this VSL script".
---

# VSL — write the script that converts cold, unaware traffic

A VSL shifts belief through story before it ever pitches. Your job here is the *wording a
viewer feels* — the hook that earns minute two, the nightmare scenario that says "I was like
you, but worse," the close that makes sitting still feel expensive. Lead from the specimens
below; reach for a shape only if it helps; write at a seventh-grade level and tell stories —
every belief installed through a scene someone lived.

## Start here — real winning specimens (study these before writing)

These are preserved verbatim from the source. They steer you harder than any rule.

- **Desired situation (hook beat 2), painted in vivid specifics:** *"get chased, loved, and adored by 10 out of 10 women"*
  — concrete and visceral rather than an abstract promise to improve their dating life; the reader *sees* the outcome and enters a desire they already hold.
- **Current pain (hook beat 3), named precisely:** *"while you may struggle to get a text back, quality matches on Tinder, let alone serious dates"*
  — escalating, specific stakes the avatar recognizes as *their* exact struggle; specificity is what makes it land as true.
- **Pattern interrupt to break from hook into content:** *"let's cut the crap"*
  — a hard tonal cut that resets attention and signals no fluff is coming; place it at the seam between hook and the body.
- **Binary close, inaction option made to feel costly:** *"tomorrow becomes next week, next month, next year"*
  — compounding time language; inaction isn't neutral, it's a slow slide. Pair it with the action option framed upside-only.
- **Risk reversal, stated as the reader feels it:** *"you literally have nothing to lose"*
  — the plain-speech translation of a 30-day guarantee; say what the guarantee *means to them*, not the policy.
- **Micro-lead hook (2-second scroll-stopper), behavior-anchored:** *"Watch this before removing facial hair"*
  — interrupts a specific action the avatar is about to take; curiosity + immediate relevance in five words.

More specimens, plus the felt tone formulas and the registry terms, are in `references/specimen-bank.md`.

## Craft targets (steer by these; they are not a rulebook)

- **Story over facts, always.** Every belief gets installed through a scene someone lived. If
  a line states a fact, ask what story would make the reader *feel* it.
- **Specificity over superlative.** "10 out of 10 women," "next week, next month, next year,"
  "a text back" — named, concrete, countable beats "amazing" / "better" / "fast."
- **Enter the desire / pain they already hold.** Don't announce the outcome; paint it so
  vividly they recognize themselves in it. Name what they're *doing and struggling with* right now.
- **Empathy register for the lead — "I was like you, but worse."** The nightmare scenario
  earns trust by going below the reader's current pain, then climbing out. Lead with felt
  shared experience before any authority.
- **Make inaction feel expensive; make action feel upside-only.** The close is a contrast
  of two futures, ending on identity ("the rare 5% who take action" — an instructed language
  pattern from source, not a transcript line), not on the product spec.
- **Seventh-grade plain speech.** Short words, short sentences, spoken cadence; if a line needs a second read, cut it down.
- **Repeat core pain in fresh phrasings.** The same wound, said three different ways across
  the script, compounds; verbatim repetition does not.

## Optional patterns (reach for one when it earns its place; keep the order fluid)

- **Hook = Unique Mechanism → Desired Situation → Current Pain.** Frame an "unfair
  advantage" others have, paint the vivid outcome, then name the specific present struggle.
  A shape to reach for, not three mandatory boxes.
- **Lead = nightmare scenario in the empathy register.** Worst-case version of the
  prospect's pain, told as "I was like you, but worse," opening loops the reader must close.
- **Binary close = two futures.** Inaction (costly, compounding) vs. action (upside-only,
  risk-reversed), ending on an identity appeal.

Anatomy and a worked example for each is in `references/formulas.md`.

The production stack your words ride on — three-pillar framework, six-step AI research
workflow, three brief documents, swipe-research execution, presentation techniques,
footage/audio sourcing, the clip-by-clip editor-direction sheet, and talent — is in
`references/production.md`. A strong script handed to an undirected editor still fails.

## Contract rules (these DO bind — they pick the shape and sequence, not the words)

These are sequencing/placement contracts, not wording. The narrative *order* binds; what
you say inside each beat is yours.

- **8-stage narrative order (long-form):** Hook → Expand the Promise → Authority →
  Personal-Story Epiphany → Problem Education + Downstream Consequences → Product
  Introduction → Solution Education → Binary CTA.
- **9-ingredient order (paid-social):** Micro Lead → Lead → Discovery Story → Unique
  Mechanism of the Problem → Unique Mechanism of the Solution → Product Reveal → Price Drop
  → Risk Reversal → Social Proof. Social proof comes AFTER product reveal and pricing.
- **Micro lead fires three elements at once:** copy + scroll-stopper visual + audio,
  simultaneously, in the first 3–5 seconds.
- **Lead → Discovery Story:** open emotional loops in the first 20s, then run the hero's
  journey (failed attempts → chance encounter → solution).
- **Shade-throwing placement:** attack alternative solutions only AFTER the founder story
  and problem education, and only believable alternatives the prospect has actually tried.
- **Product stays out of the first half.** First product mention belongs no earlier than the
  midpoint (the score skill enforces the threshold) — write the body to *earn* that reveal.
- **Ad-to-VSL congruence — Stage 1 must match the winning ad's hook.** The VSL must be
  congruent with the ad creative that drives traffic to it — same angle, same language, same
  promise. Write the big promise in Stage 1 to directly match the hook of the winning ad;
  misalignment between ad and VSL causes drop-off and kills conversion.

For which form fits which awareness stage: more unaware / colder traffic → longer-form,
8-stage narrative that builds belief from scratch; warmer / more-aware traffic and paid
social → the 9-ingredient structure with the heaviest investment at the micro lead. The
long-form first-mover thesis, the Hero's-Journey-for-YouTube format, and funnel positioning
are in `references/strategy.md`.

## How to use this with the grader

Generate several diverse drafts — vary the micro lead heavily (it is the primary scaling
lever), vary the hook beats and the nightmare angle, and let each draft commit to a distinct
angle rather than converging on one "safe" version. Then hand the script to **kb-vssl-score**
— a separate skill, ideally a different model — for the gates (product-mention position,
readability grade, beliefs count, swipe filters) and the pairwise-vs-specimen judgment of
ad-to-VSL congruence. The separate scorer grades — the countable thresholds live there, not
here — which keeps the writing aimed at "shifts belief" rather than "looks like a VSL."

## Before handoff (what kb-vssl-score checks)

Generate several diverse drafts; the separate scorer grades — do not self-grade toward the
gate. The dimensions it judges, listed only so you know what it looks for as you vary drafts:

- Whether the hook earns minute two before the product is ever named, and whether the avatar
  would recognize the pain as *theirs*.
- Whether the lead is a lived nightmare scenario in the "I was like you, but worse" register
  rather than a list of facts.
- Whether the copy carries concrete specifics (named outcomes, numbers, behaviors) rather
  than superlatives, at a seventh-grade reading level.
- Whether the close contrasts two futures — costly inaction vs. upside-only action — and ends
  on identity.
- Whether Stage 1's big promise matches the hook of the winning ad (ad-to-VSL congruence).
