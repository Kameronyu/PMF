# Strategic positioning — form selection and the long-form first-mover thesis

These are route-selection rules: which VSL form to reach for given the traffic and the
competitive landscape. They steer *which structure* you write into, not the wording.

## Awareness drives form
- More unaware / colder traffic → longer-form, 8-stage narrative that builds belief from
  scratch.
- Warmer / more-aware traffic and paid social → the 9-ingredient structure with the heaviest
  investment at the micro lead.
- VSL lengths range 13–60 minutes depending on product and audience awareness level. Higher
  VSL consumption time directly correlates with higher purchase probability.

## Long-Form VSL as First-Mover Competitive Advantage (Source: Carl Weische)

A 40-minute VSL using correct psychology can shift deeply held beliefs and convert completely
unaware customers into buyers. Most brands avoid long-form content, creating a first-mover
opportunity for brands willing to test it. Long-form VSLs feed the entire top of funnel with
unaware customers rather than competing for already-aware audiences. Combine VSLs and
advertorials with authoritative figures for maximum credibility. A 10-minute VSL has been
documented to perform well on Facebook if sufficiently interesting.

**Decision rule:** when competitors are clustered on short, already-aware audiences, the
under-tested move is the long-form VSL that opens the unaware top of funnel — a first-mover
edge precisely because the fear of length keeps others out.

## Hero's Journey VSL for YouTube Scaling (Source: Carl Weische)

A structurally distinct VSL format alongside the 8-stage and 9-ingredient structures. Reach
for it when running on a YouTube channel and sending viewers directly to checkout.

VSL format: relatable character with a problem → failed solutions → magical transformative
solution.

- Craft detailed, believable personas with excruciating specificity (e.g., middle-aged woman
  with chronic knee problems) to maximize authenticity.
- Run 10–30 minute VSLs as YouTube ads with simple campaign structure: broad or
  interest-based targeting.
- Send viewers directly to checkout after VSL; no intermediate funnel steps required.
- Scaled example: $0 to $30M in 2021; ad spend from $1K/day to $150K/day using this structure.

## VSL Funnel Positioning (Source: Mark Builds Brands)

The VSL page sits between the advertorial and the order page. The page contains **nothing
except the video** — no navigation, no competing elements, no product listings.

Funnel sequence: **Ad → Advertorial → VSL Page → Order Page**

The VSL is fully scripted and controlled by the operator. Emotional buy-in accumulated
through the VSL is what enables the front-end price increase from ~$50 to $97–$197. This is
why the VSL's belief-shifting role is commercially critical — it is the component that earns
the higher front-end price.
