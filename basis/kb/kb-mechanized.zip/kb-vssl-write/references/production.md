# Production framework, techniques, and stack (faithful to source)

This is the production-and-presentation half of VSL execution: the diagnostic framework that
says *which discipline owns what*, the pre-writing research workflow that feeds the copy, the
clip-by-clip editor handoff, the named presentation techniques, the footage/audio sourcing,
and talent options. The writer's words ride on top of this stack — a strong script handed to
an undirected editor with no psychological strategy still produces a non-converting VSL.

---

## Three-Pillar VSL Production Framework (Source: Carl Weische)

VSLs are built on three interdependent pillars; weakness in any one pillar prevents conversion:

- **Pillar 1 — Psychology**: Market awareness levels, consumer motivations, unique mechanisms,
  desire identification. Founder's responsibility.
- **Pillar 2 — Words**: Script, readability at seventh-grade level or below, storytelling over
  fact-listing, copywriting principles.
- **Pillar 3 — Presentation**: Editing, A-roll talking head, B-roll, text-on-screen, music,
  sound effects. Editor's responsibility.

Handing copy to an editor without psychological strategy produces non-converting VSLs. All
three pillars must be strong simultaneously.

**Use as a diagnostic:** when a VSL underperforms, locate the failing pillar before rewriting.
Weakness in any one pillar collapses conversion — a perfect script (Pillar 2) cannot rescue
absent psychology (Pillar 1) or undirected editing (Pillar 3).

---

## AI-Powered VSL Research Process (Source: Mark Builds Brands)

Six-step pre-writing research workflow — this is what produces the prospect-intelligence
artifact the scorer's G3 counts. Run it *before* any copy is written:

1. Draft research prompts in ChatGPT
2. Execute those prompts in **OpenAI Operator agent** (automated web research)
3. Generate minimum **5 pages** of prospect intelligence output
4. Research must capture: pain points, desires, motivations, and verbatim language patterns
5. Upload research document to AI to auto-populate the three brief documents (Avatar Sheet,
   Offer Brief, Necessary Beliefs Document)
6. Use populated documents as copy foundation — no guessing at prospect psychology

**Tools:** ChatGPT (prompt drafting) + OpenAI Operator (research execution)

---

## Three VSL Brief Documents System (Source: Mark Builds Brands)

All three documents must be completed before any copy is written. AI populates templates from
the research upload.

| Document | Contents |
|---|---|
| **Avatar Sheet** | Demographics, challenges, goals, emotional drivers |
| **Offer Brief** | Product details, pricing, funnel structure, objections, market awareness level |
| **Necessary Beliefs Document** | 3–7 specific beliefs prospect must hold to purchase |

The Necessary Beliefs Document is the most strategically dense — every VSL component is
written to install or reinforce one of these 3–7 beliefs. As a writer, treat every beat you
draft as aimed at one of these pre-specified beliefs.

---

## Swipe research execution (Source: Mark Builds Brands)

The scorer gates the swipe FILTER (duration ≥3 min, run ≥7 days, brand ≥30 active ads). The
execution guidance is here:

- Cross-industry VSL structures transfer — **do not limit research to your product category.**
- Generate full transcripts of winning ads.
- Use swipe as **structural inspiration only**, not copy to plagiarize.
- Adapt the architecture to your product's unique mechanism and avatar.

Tooling: **Get Hooked AI** to locate winning ads.

---

## VSL Editing and Presentation Techniques (Source: Carl Weische)

Five primary production techniques to maximize retention and hook rate:

1. **Talking Head A-Roll**: Presenter speaking to camera as the base layer of all footage.
2. **Text-on-Screen Captions**: Written captions reinforce spoken words for dual-processing.
3. **Smooth Zoom**: Gradual zoom into presenter's face for emphasis at key moments.
4. **Transition Effects**: Visual cuts between segments to prevent viewer drop-off.
5. **Matching B-Roll + Sound Effects + Music**: Visuals literally depicting what is being
   said, synchronized with sound design (e.g., footage of a guy being ignored by a girl
   during the pain section).

All production elements are subtle but directly impact watch time and purchase probability.

---

## VSL Content Production Stack (Source: Mark Builds Brands)

**Three required footage types:**
1. **Product Footage** — UGC of real people using the product (send product to influencers)
2. **B-Roll** — Commercial-free intermediary content from Story Blocks or Grid Bank
3. **UGC Content** — Influencers reading scripted lines on camera

**Audio options:**
- AI-generated voiceover
- Fiverr spokesperson: $50–100

**Editor direction system:** Build a Google Sheets document mapping every line of copy to a
specific video clip. Most editors have no VSL experience; without this map, they will
misinterpret pacing and emotional sequencing. The sheet eliminates ambiguity in
post-production.

---

## Talent options for the VSL presenter (Source: Carl Weische)

**Talent options**: UGC creators, influencers, generative AI presenters, or internal team
members.
