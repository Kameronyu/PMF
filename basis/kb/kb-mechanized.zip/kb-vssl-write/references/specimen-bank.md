# Specimen bank — verbatim winning VSL lines, with what each beat does

Preserved verbatim from `vssl--carl-weische.md` / `vssl--mark-builds-brands.md`. These are
the highest-value asset in the skill — study and adapt, do not abstract into templates.
Each specimen shows the *form* of a good answer; that is what steers a model.

## Hook — Desired Situation (beat 2: paint the vivid aspirational outcome)
- "get chased, loved, and adored by 10 out of 10 women"
  — concrete and sensory; the reader *sees* the outcome. The countable detail (10 out of
  10) beats an abstract promise to improve their dating life. Enter the desire they already hold.

## Hook — Current Pain (beat 3: name the specific present struggle)
- "while you may struggle to get a text back, quality matches on Tinder, let alone serious dates"
  — escalating, precise stakes the avatar recognizes as *their own*; specificity is what
  makes it read as true rather than generic.

## Pattern interrupt (the seam from hook into body content)
- "let's cut the crap"
  — a hard tonal cut that resets attention and promises no fluff. Place it at the boundary
  between hook and body.

## Binary close — inaction option (make sitting still feel costly)
- "tomorrow becomes next week, next month, next year"
  — compounding time language; inaction is a slow slide, not a neutral choice.

## Binary close — risk reversal + identity appeal
- "you literally have nothing to lose"
  — the plain-speech meaning of a 30-day money-back guarantee; say what it *feels like* to
  the reader, not the policy text.
- "rare 5% who take action"
  — identity appeal to close on: the buyer joins a small, admirable group. End here, on who
  the buyer becomes, rather than on the product spec. Note: in the source this phrase appears
  inside instructional prose ("position the buyer as part of a rare 5% who take action"), so
  it represents the *instructed language pattern*, not a verified transcript line the way the
  hook and close fragments above are.

## Micro-lead hook (first 3–5s scroll-stopper, behavior-anchored)
- "Watch this before removing facial hair"
  — interrupts a specific action the avatar is about to take; curiosity + immediate
  relevance in five words. (2-second hook for a facial hair removal product targeting older women.)

## Felt tone formula — keep as steering, not a gate
- The lead's register must read as "I was like you, but worse" — empathetic, below the
  reader's current pain, then climbing out. This is a felt tone, not a phrase to paste.

---

## Registry terms this topic uses (anchor; do not redefine)

- **Hook** — the scroll-stopping opening; the reason to keep watching.
- **UM (Unique Mechanism)** — the unique way the product delivers the transformation; used
  to differentiate against alternatives. Topic uses both Problem UM (why prior solutions
  failed) and Product/Solution UM (why this one works).
- **Belief (B)** — what the buyer must hold true to purchase; the "Necessary Beliefs" 3–7.
- **Awareness level** — where the buyer sits on the unaware → most-aware chain; determines
  VSL length and what must be established first (colder → longer, more belief-building).
