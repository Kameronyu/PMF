# Optional patterns — anatomy + a worked example each

Reach for one when it fits. None is a required slot order; forcing a fixed sequence is what
produces same-y, non-converting scripts. Use these to vary and to reach for, not to
standardize.

## Hook — three-beat shape
[unique mechanism: an "unfair advantage" others have] + [desired situation: vivid, specific
outcome] + [current pain: the precise present struggle, named].
- Unfamiliar advantage → curiosity + social comparison; vivid outcome → desire; precise
  pain → recognition ("that's me"). Then a pattern interrupt cuts into the body.
- Example (beats 2 and 3, verbatim from source):
  "get chased, loved, and adored by 10 out of 10 women" …
  "while you may struggle to get a text back, quality matches on Tinder, let alone serious dates"

## Lead — nightmare scenario in the empathy register
[worst-case version of the prospect's current pain] told in the [register "I was like you,
but worse"], opening [emotional loops] the viewer must close by continuing.
- Goes BELOW the reader's pain first, which buys trust, then opens the loop the rest of the
  script closes. Spans the first 20s after the micro lead.

## Micro lead — three elements firing at once
[copy: the exact words spoken] + [scroll stopper: the visual clip] + [audio: voiceover
tone], simultaneously, in the first 3–5s. The single highest-leverage testing variable.
- Example (verbatim from source): "Watch this before removing facial hair"

## Binary close — two futures
[option 1, inaction: costly and compounding] vs. [option 2, action: upside-only, risk-
reversed], ending on an [identity appeal].
- Make inaction feel like a slow slide; make action feel like there's nothing to lose; close
  on who the buyer becomes.
- Example fragments (verbatim from source):
  inaction → "tomorrow becomes next week, next month, next year"
  risk reversal → "you literally have nothing to lose"
  identity → "rare 5% who take action" (instructed language pattern from source, not a
  transcript line)
