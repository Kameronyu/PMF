# Scoring specimens — the known-hard entries to judge the FELT difficulty read against

Gate 4 (difficulty read) is scored **pairwise against these**, not on an absolute 1–10 and
never by the agent that selected the product. Present the candidate beside one specimen with
order randomized; ask which is harder to enter (more CAC-heavy) and why, criteria before
verdict; record `prefer | tie | weaker`. Treat any single read as noisy — a triage signal, not
a certification. `prefer` = the candidate is harder than the specimen; it steps a COMMIT-READY
band down to RESEARCH-MORE, never to a hard FALSE.

## High-difficulty reference (judge harder-to-enter candidates against these)
- "Higher on all three = higher CAC and more creative investment required before break-even"
- "All three factors interact with CAC — higher on any axis = higher acquisition cost + more creative investment"
- "avoid problem-unaware markets — expensive education required, high CAC, slow feedback loops"

Ask: is the candidate as CAC-heavy to enter as these are? → prefer | tie | weaker.

## Lower-difficulty reference (the easier-entry contrast)
- "solution-aware or product-aware — audience already knows a solution exists, you just need to position better"

A candidate entering at this awareness stage, low on Desire / Market sophistication, reads
`weaker` (easier) than the high-difficulty specimens above.

## How to run the pairwise judge
1. Present candidate + one specimen, order randomized.
2. Ask which is harder to enter for the named axes (Desire × Awareness level × Market
   sophistication) and why — criteria before verdict.
3. Record `prefer|tie|weaker` + the reason. `prefer` (harder than specimen) flags the
   RESEARCH-MORE step-down; `tie`/`weaker` leaves the band where the countable gates put it.
4. Never let the agent that selected the product be the judge.
