# Per-gate membership tests + the COUNTABLE threshold definitions

All COUNTABLE gates lower to a deterministic check a script runs identically every time.
Any test below can return FALSE; that is what makes it a gate, not an assertion.

## Gate 1 — Capital floor (COUNTABLE — script gate)
- `starting_ad_budget >= 3000` (USD). PASS iff true.
- Source rule: "$3K minimum capital figure — do not start ads with less; insufficient to
  generate reliable signal".
- FALSE example: budget = $1,500 → FAIL → caps band at DISCARD.
- Carry as steering context (NOT a gate, never a shape-checkable FALSE): "Personal conviction
  as non-negotiable filter: sell only what you believe actually works" — an operator who does
  not believe will quit at the first 3-day losing streak.

## Gate 2 — 7-signal viability (COUNTABLE — script gate, highest weight)
- `passes = count(rows where row condition is TRUE)`; PASS iff `passes >= 5`.
- Source rule: "no single data point is sufficient — require 5+ passes before committing".
- Per-row pass condition (each row is its own membership test; the tool that supplies it is named):

  | # | Signal | Tool | PASS condition |
  |---|---|---|---|
  | 1 | Sales velocity | Kalodata | Active, growing orders |
  | 2 | Trademark clear | ITRA | No active marks on product OR brand name |
  | 3 | Traffic estimate | SimilarWeb | Meaningful competitor traffic visible |
  | 4 | Demand trend | Google Trends | Stable or growing (not declining spike) |
  | 5 | Pain confirmation | Reddit / TikTok comments | Volume of emotional complaints |
  | 6 | Price anchor | Amazon | Established price point above your COGS target |
  | 7 | COGS validation | AliExpress | Margin achievable at target AOV |

- Trademark row is two checks, both required: "check BOTH the active marks on the product
  category AND the specific brand name".
- FALSE example: only 4 rows pass → FAIL → not COMMIT-READY.

## Gate 3 — Purchase-signal floor (COUNTABLE — script gate)
- `real_purchase_signals >= 10` (target band 10–30). PASS iff true.
- Source rule: "Never commit to Minimum Order Quantity (MOQ) without 10–30 real purchase signals".
- FALSE example: 6 signals → FAIL → caps band at RESEARCH-MORE.

## Gate 4 — Difficulty read (FELT — pairwise only, NEVER a membership gate)
Do **not** write a yes/no test for Gate 4. Estimate entry difficulty across the three axes —
Desire × Awareness level × Market sophistication (registry terms; do not redefine) — then
compare the product to a difficulty specimen in `scoring-specimens.md`: is this harder to enter
than the specimen? Return `prefer | tie | weaker` (where `prefer` = harder, more CAC-heavy than
the specimen). This is the axis the source frames as a felt pull, not a count: "Higher on all
three = higher CAC and more creative investment required before break-even". Keep it a signal —
it only steps a COMMIT-READY down to RESEARCH-MORE, never a hard FALSE.

## Advisory edges (SOFT-CAP — flag, do not hard-gate)
- Beginner AOV ceiling: "Beginner AOV ceiling: $150–170 with break-even math modeled before
  committing". If target AOV > ~$170 for a beginner, SOFT-WARN; do not fail the band on this alone.
- Revenue-ladder bands (membership selects milestone focus, not a pass/fail):
  - $0–10K/month → validate product + avatar, get first purchases
  - $10–50K/month → validate offer, find sub-avatars, stabilize ROAS
  - $50–100K/month → scale proven angle, begin hiring

## Why the tiers
Hard-gating a felt axis (the difficulty read) produces confident-but-wrong FALSEs and pushes
selectors toward gaming the gate. Hard-gating a countable one (a budget is or isn't >= $3K;
5-of-7 either holds or doesn't; signals are counted) is reproducible and safe. Soft-cap the
in-between (AOV ceiling, ladder bands) because they are guidance, not hard lines.
