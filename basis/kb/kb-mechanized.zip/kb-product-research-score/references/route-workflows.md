# Named workflows (ROUTE) — selection and sequencing contracts

These dictate which step / stage / focus is selected by a named trigger. They are contracts,
not scored: no wording is dictated, no quality verdict is assigned. The gates in SKILL.md key
on them (R2 feeds Gate 2's 7 signals; MOQ tactics are context for Gate 3).

## R1 — Awareness-stage entry selection
- Basis: "Product selection difficulty = magnitude of desire × market awareness stage ×
  market sophistication".
- Rule: "avoid problem-unaware markets — expensive education required, high CAC, slow feedback
  loops".
- Preferred entry: "solution-aware or product-aware — audience already knows a solution exists,
  you just need to position better".

## R2 — Kalodata 9-step TikTok Shop research sequence
Ordered, tool-keyed. Produces the inputs for Gate 2's 7-signal table.
1. Kalodata — identify products with active TikTok Shop sales velocity
2. Meta Ad Library — confirm product has active paid traffic (proof of economics)
3. ITRA — trademark check (both product name AND brand name)
4. SimilarWeb — estimate competitor website traffic
5. Reddit / TikTok comments — confirm pain exists at volume
6. Amazon — extract price anchor (what customers are used to paying)
7. AliExpress reverse image search — identify COGS and multiple suppliers
8. Google Trends — confirm sustained vs. spike demand
9. Seasonality check — is primary market currently in-season?

(Tool cost: Kalodata $45–100/month. Beginner AOV ceiling $150–170 — see gate-tests advisory edges.)

## R3 — 6-stage operating loop + diagnostic fallback
Sequence: Study → Research → Create → Test → Feedback → Repeat.
Fallback routing by named trigger:
- "Failed Create → Test: return to Research (wrong avatar, wrong mechanism, wrong desire)".
- "Still failing after Research: return to Study (wrong product, wrong market)".
Study-phase warning (REFERENCE): the over-studying failure mode — "Fear of action masquerades
as wanting more information"; second-pass study (after doing the thing once) beats first-pass.

## R4 — 7-day onboarding sprint + revenue ladder
- Checkpoint 1 (Days 1–7): "commit to product — no switching during sprint".
- Checkpoint 2: "complete customer research + avatar building (do not create before this is done)".
- Revenue-ladder focus selected by MRR band (see gate-tests advisory edges for the bands).

## MOQ negotiation / alternative validation sources (context for Gate 3)
- Negotiation tactic: "negotiate MOQ down (e.g., 500 → 250 units) at slightly higher per-unit
  cost" — extra per-unit cost is cheap insurance against holding dead inventory.
- Alternatives: Etsy US-based suppliers "30–50 domestic units for rapid validation"; pre-orders
  as an intent signal (collect payment before stocking).

## REFERENCE context (no gate, no wording)
- Claude Project context architecture: maintain persistent context files across phases:
  - Brand sophistication document
  - Avatar research (verbatim quote density is the primary quality lever)
  - Product URLs
  - Market sophistication assessment
- Avatar-research quality heuristic (decision rule): the operative lever for judging avatar
  research quality is to **maximize the density of verbatim customer quotes** — source:
  "Avatar research (verbatim quote density is the primary quality lever)".
- The Description field in the Claude Project = system prompt (sets behavioral context for all
  sessions); reuse the same project across all phases — do not start fresh each session.
  Free-tier workaround: drag relevant files into individual chats manually.
