---
name: kb-product-research-score
description: >-
  Score a product for viability and entry difficulty before committing capital or an MOQ.
  Use to gate a product idea (from an operator, a research workflow, or any source) and
  return DISCARD / RESEARCH-MORE / COMMIT-READY with per-gate evidence. Hard-gates only the
  countable thresholds (capital floor, 5-of-7 signal passes, purchase-signal count); treats
  the felt difficulty read as a pairwise-against-specimen signal, never self-graded pass/fail.
  Keeps the named research workflows (Kalodata 9-step, 6-stage loop, 7-day sprint) as ROUTE
  contracts. Run as a SEPARATE pass from any agent that picked the product. Triggers:
  "score this product", "is this product worth committing to", "should I order this MOQ",
  "rank these product ideas".
---

# Product research — gate viability before you commit capital or inventory

Grade a product idea against the gates below, then band it. **Do not run this in the same pass
that selected the product** — a selector grading itself rates its own pick higher. Judge the
felt difficulty read against the specimens in `references/scoring-specimens.md`, ideally on a
different model. Anchor terms (Desire, Awareness level, Market sophistication, Angle, UM) are
defined in the registry — use them, never redefine.

Tier discipline: **hard-gate only the countable**; **soft-cap the advisory edges**;
**compare the felt difficulty read against a specimen — never hard-FALSE it.**

## The gates (each: positive target → how it's judged → tier)

1. **Capital floor** — *target:* starting ad budget **>= $3,000**. *Judge:* **script gate** —
   numeric threshold. Tier: COUNTABLE → **hard-gate** (FAIL below 3000).
2. **7-signal viability** *(highest weight)* — *target:* **>= 5 of the 7** named signals pass
   their per-row condition (sales velocity / trademark clear / traffic estimate / demand trend /
   pain confirmation / price anchor / COGS validation). *Judge:* **script gate** — count passing
   rows. Tier: COUNTABLE → **hard-gate** (FAIL below 5).
3. **Purchase-signal floor** — *target:* **>= 10** real purchase signals collected (target band
   10–30) before any MOQ commitment. *Judge:* **script gate** — numeric threshold. Tier:
   COUNTABLE → **hard-gate** (FAIL below 10).
4. **Difficulty read** — *target:* a difficulty estimate across Desire × Awareness level ×
   Market sophistication; higher on all three warns of higher CAC. *Judge:* FELT — rate severity
   **pairwise against a difficulty specimen**, not a yes/no gate. Tier: FELT (triage signal;
   never a hard FALSE, never self-graded).

Per-gate membership tests, the 7-signal per-row pass conditions, and the COUNTABLE threshold
definitions are in `references/gate-tests.md`. The advisory edges (beginner AOV ceiling,
revenue-ladder bands) are soft caps, defined there too.

## Bands (derive from gates that actually passed — not a hollow count)

- **any COUNTABLE gate FAILs → DISCARD or RESEARCH-MORE** (see override below).
- **all COUNTABLE gates pass, difficulty read = `weaker`/`tie` → COMMIT-READY**.
- **all COUNTABLE gates pass, difficulty read = `prefer` (harder than specimen) → RESEARCH-MORE**
  (flag "high on all three axes → model CAC before committing").

Count only gates that passed their tier's check. The difficulty read never manufactures a band
on its own — it only steps a COMMIT-READY down to RESEARCH-MORE.
**Capital override (structural):** Capital floor FAIL caps the band at DISCARD regardless of
other gates — under the floor, no signal is reliable.
**MOQ override (structural):** Purchase-signal floor FAIL caps the band at RESEARCH-MORE — never
COMMIT-READY — even if the 7-signal gate passed.

## The negatives live here (<=5), each paired with a positive target

Moved out of the selector (where banning a move summons it). Each is a checker rule:

- **Starting ads under $3K** → flag DISCARD. (positive: fund to >= $3,000 before first ad)
- **Committing MOQ on a single strong signal** → fails Gate 2's 5-of-7 rule. (positive: confirm 5+ signals)
- **Ordering MOQ on <10 purchase signals** → flag RESEARCH-MORE. (positive: collect 10–30 real signals first)
- **Entering a problem-unaware market as a beginner** → flag. (positive: enter solution-aware or product-aware)
- **Over-studying instead of testing** → flag. (positive: run the test, study second-pass after)

## Named workflows (ROUTE — selection / sequencing the gates key on)

These are contracts, not scored. Full step lists in `references/route-workflows.md`.
- **R1 Awareness-stage entry** — prefer solution-aware or product-aware; avoid problem-unaware.
- **R2 Kalodata 9-step research** — ordered, tool-keyed sequence feeding Gate 2's 7 signals.
- **R3 6-stage operating loop** — Study → Research → Create → Test → Feedback → Repeat, with
  diagnostic fallback routing.
- **R4 7-day sprint + revenue ladder** — checkpoints and MRR-band focus selection.
- **MOQ negotiation / alt sources** — context for Gate 3 (negotiate down, Etsy domestic, pre-orders).
- **Avatar-research quality lever** — when avatar research feeds the difficulty/desire read, judge
  it by verbatim customer-quote density; see `references/route-workflows.md` (Claude Project context).

## Output contract (per product)

```
product: "<verbatim idea / name>"
gates: [ {n, target, verdict: pass|fail|signal, tier, evidence_quote, source} ]
countable_gates: {capital_floor, seven_signal, purchase_signal}   # script results, pass/fail
seven_signal_detail: {sales_velocity, trademark_clear, traffic_estimate, demand_trend,
                      pain_confirmation, price_anchor, cogs_validation}  # per-row pass/fail
felt_signal: {difficulty_read}     # pairwise-vs-specimen, prefer|tie|weaker
band: DISCARD | RESEARCH-MORE | COMMIT-READY
flags: [ ... ]    # from the negatives list
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every gate has a verdict; the 7-signal detail has all 7 rows; band present.
**SOUNDNESS:** every COUNTABLE verdict came from the script (not eyeballed); the difficulty read
is pairwise-vs-specimen, not self-graded; band derived only from passed gates and the two
structural overrides; each `pass` carries an `evidence_quote` that is a verbatim substring of the
input. `emit_ready` only if SOUNDNESS holds; else `BLOCKED:<gate>`.

## Self-test (is this grader sound?) — any NO, fix

- Are only Gates 1/2/3 hard-gated (by script), with Gate 4 a pairwise-vs-specimen signal?
- Is the felt difficulty read run separately from the selector, against a real specimen?
- Does the band come from gates that passed their tier's check plus the two overrides, not a raw count?
- Are the negatives <=5, here in the checker, each paired with a positive target?
- Are the named workflows (R1–R4, MOQ tactics) kept as ROUTE contracts, not scored?
- Is every quoted specimen a verbatim substring of a source file (no composites)?
