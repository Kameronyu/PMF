# Scoring specimens — judge the FELT field against these (verbatim from source)

The felt field (12, pain specificity) is scored **pairwise against these**, not on an absolute
scale and never by whatever wrote the candidate. Each line below is a verbatim substring of
`email-and-retention--alex-hormozi.md`. `weaker` contributes no pass.

## Pain-specificity reference (judge field 12 against this)

The canonical specific-pain line:

> "stop feeling your thighs chafing when you're out in the sun"

The principle it embodies:

> "Pain and persuasion only exist in the specific, never the vague"

Ask: does the candidate's pain line make the reader picture a specific felt experience as much
as this specimen does? -> prefer | tie | weaker. A vague category ("lose weight fast") is weaker.

## COUNTABLE anchor quotes (the source thresholds the gates enforce)

These are the verbatim source statements behind the gate numbers. Use them as the
`evidence_quote` when a plan's field traces to one of these benchmarks.

- Annual retention: "Target: above 80% annual retention"
- M12 band (B2B): "B2B SaaS: 80%+ M12 retention expected"
- M12 band (prosumer): "Prosumer (between consumer and B2B): 40-50% baseline, 60%+ indicates strong product-market fit"
- Monthly churn (elite): "less than 3% monthly churn for six or eight months"
- Monthly churn (VSNB target): "33% monthly churn vs target of ~10%"
- Golden ratio: "Formula: % customers who refer / % customers who exit = passive growth rate"
- Referral-before-scale: "we're going to stay at this Revenue level until we get referrals over 30%"
- Give:ask ratio: "Recommended personal content ratio: 98% give, 2% ask"
- Email send cap: "send maximum 2 emails to main list to avoid over-promoting the promotion"
- LTV:CAC: "Organic/SEO LTV:CAC: 13:1"
- Worst-month price: "Price recurring subscriptions based on what customers can justify paying in their worst-performing month, not best month. This extends renewal likelihood."
- Compliance: "Include compliance guidelines: don't lie, don't exaggerate, state facts"
- Care x WTP stack: "High Care + High Willingness to Pay: exclusive access, content/courses, events (especially in-person)"
- Billing cadence -> LTV: "Switching from monthly to annual billing increases LTV by 5x, even at same price points."
- Escalation break-even: "If one out of four customers buy something that's four or five times as expensive you actually recovered 100% of the refunds or cancellations."

## How to run the pairwise judge (field 12)
1. Present candidate pain line + the specimen, order randomized.
2. Ask which names a more specific felt pain and why (reason before verdict).
3. Record `prefer|tie|weaker` + the reason. `weaker` is a rewrite signal, not a failure.
4. Never let whatever generated the candidate be the judge.
