# Per-field membership tests + COUNTABLE gate definitions

All YES = the field passes; any can return FALSE. Each gate lowers to a number-vs-threshold a
script runs identically every time. Verdict comes AFTER the test, never before.

## COUNTABLE gates (script — pass|fail)

**1. Annual retention**
- `has_pct = a retention percentage is stated` (not "good retention", "high retention").
- PASS iff `has_pct AND pct >= 80`. FALSE: "70% annual retention" -> fail (below 80% target).

**2. M12 retention band**
- `band_declared = business type named ∈ {consumer, B2B, prosumer}` AND an M12 % stated.
- In-band: consumer 50-60%; B2B 80%+; prosumer 40-50% baseline, 60%+ = strong PMF.
- PASS iff `band_declared AND pct in the named band`. A bare % with no business type -> fail (cannot band it).

**3. Monthly churn**
- `has_churn = a monthly churn % is stated`. Ceiling depends on context: Five Horsemen elite = `< 3%`; VSNB target = `~10%` (flag at `~33%`).
- PASS iff `has_churn AND churn under the named ceiling`. FALSE: "33% monthly churn" against a ~10% target -> fail.

**4. Golden ratio**
- `both = %refer AND %exit both stated`. `ratio = refer / exit`.
- PASS iff `both AND ratio > 1` (growing). FALSE: 2% refer / 10% exit = 0.2 -> fail (shrinking, paid-acquisition treadmill).

**5. Referral-before-scale**
- `has_rate = current referral rate stated` AND a pre-scale threshold named (e.g. 30%).
- PASS iff `has_rate AND rate >= threshold` BEFORE any scale-acquisition decision. FALSE: deciding to scale at 12% referral -> fail (and triggers the scale override band cap).

**6. Give:ask ratio**
- `has_ratio = a give:ask split is stated`. `give_share = give / (give + ask)`.
- PASS iff `has_ratio AND give_share >= 0.98` (98:2; up to 30:1 for max growth). FALSE: 80:20 -> fail (over-asking).

**7. Email send cap**
- `has_count = number of promo emails to the main list is stated`.
- PASS iff `has_count AND count <= 2` during a single promo. FALSE: "blast the list 5 times" -> fail.

**8. LTV:CAC**
- `has_ratio = an LTV:CAC ratio is stated`. Organic/SEO healthy reference = 13:1.
- PASS iff `has_ratio AND ratio >= 1`; flag (warn) if `1 <= ratio < 3`. FALSE: ratio < 1 or none stated -> fail.

**9. Worst-month price**
- `basis_named = the recurring price is justified against a specific month's value`.
- PASS iff `basis_named AND basis is the worst/low-performing month`, not the best. FALSE: priced on the best month -> fail (renewal-fragile).

**10. Compliance**
- Three-part test on each affiliate/marketing claim: does it lie? exaggerate? fail to state facts?
- PASS iff `no claim lies AND none exaggerates AND each states facts`. FALSE: any inflated/false claim -> fail.

## HEURISTIC (soft-cap — ok|warn, never fail)

**11. Care x WTP value-stack**
- Classify each membership/value element into the quadrant: Care (does the customer care about it?) x Willingness-to-Pay.
- Target: High-Care + High-WTP elements (exclusive access, content/courses, in-person events) lead; low-care or low-WTP (merch, generic discounts) deprioritized.
- Verdict: `ok` if high/high elements lead; `warn` if low/low elements lead. A `warn` drops STRONG to SOUND but NEVER causes REWORK — the quadrant is a judged classification, false-positive-prone.

## FELT (pairwise-vs-specimen — prefer|tie|weaker, NEVER a hard gate)

**12. Pain specificity**
- Do NOT write a yes/no test. Compare the plan's pain line to the pain specimen in `specimens.md`:
  does it name a specific, felt, observable pain (the reader can picture it) more than the specimen does?
- Return `prefer | tie | weaker`. `weaker` contributes no pass and is NOT a failure — it is a rewrite signal.
- This is the field a naive mechanizer would launder into "is the pain specific? -> FALSE." Keep it a signal, run it separately from any writer, never let the writer judge its own line.

## Why the tiers
Hard-gating a felt field produces confident-but-wrong FALSEs and pushes proposers toward gaming
the gate. Hard-gating a countable one (a % is or isn't above a threshold; a ratio is what it is)
is reproducible and safe. Soft-cap the in-between (the care/WTP quadrant) because the classifier
over-flags.
