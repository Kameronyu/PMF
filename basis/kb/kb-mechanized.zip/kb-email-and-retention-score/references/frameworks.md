# Retention frameworks, classification schemes & diagnostics (restored from source)

These are the named frameworks, decision rules, and quantitative diagnostics a scorer evaluates a
retention/continuity play *against*. They are NOT extra hard gates on top of the ten countable ones
in `field-tests.md` — they are the structured criteria behind several ROUTE rules and the
care/WTP heuristic. Each traces to `email-and-retention--alex-hormozi.md`. Quotes are verbatim.

---

## Nine C's of Recurring Revenue Stickiness (classification scheme — levers to grade a membership)

True recurring revenue requires **net negative churn**: revenue grows even if you acquire no new
customers. Score a proposed membership/continuity offer against how many of the nine levers it pulls.

Nine levers increase stickiness:

1. **Consumption** — people pay for memberships they use, not ones they don't.
2. **Collateral** — having their stuff (storage, data) creates switching cost.
3. **Cost of switching** — make leaving expensive/painful.
4. **Choice** — give them options inside the membership.
5. **Control** — controlling money flow maintains leverage (Uber, DoorDash).
6. **Cause** — a reason beyond the transaction.
7. **Community** — create community around the membership.
8. **Contracts/commitments** — locked-in terms.
9. **Communication** — always have something for people to look forward to.

Benchmark: churn decreased before events and increased after events in gym businesses.

> "What you really want is net negative churn. This fancy term means: Every month, if you acquired no new customers, you'd still make more money."

**Scorer use:** a membership leaning on only one weak lever (e.g. a generic discount) is REWORK-prone;
a stack pulling several High-Care/High-WTP levers (access, community, consumption) is at the strong end.

---

## Customer Results Flywheel (execution procedure — engineer capture moments)

Every business needs a three-step flywheel: (1) get customers in the door, (2) get those customers
results, and (3) use those results to get more customers. Engineer milestone "wow moments" in the
customer experience where you can capture reactions (photos, videos, reviews) and feed them back
into the marketing machine.

- Three-step flywheel: acquire -> deliver results -> use results to acquire more
- Identify 'wow moments' in the customer journey and be present to capture them
- Weigh-in, weigh-out, before/after photos are engineered capture moments
- Ask for reviews at peak emotional moments
- The flywheel should be self-reinforcing

> "you're going to get customers in the door, step one. You're going to get those customers results, step two. And then step three, you need to use those results to get you more customers"

**Scorer use:** a retention/results plan that delivers results but never *captures* them at peak
emotion is missing step three — flag (it forfeits the compounding referral loop).

---

## 37 Magical Moments Rule (decision rule — service recovery / super-compensation)

It takes 37 magical moments to overcome one tragic moment (Disney stat). Avoid tragic moments at all
costs; but when one occurs, super-compensate rather than just refund — make it *more* than right.

- 37 magical moments to overcome 1 tragic moment (Disney)
- When tragic moments occur, super-compensate rather than just refund
- People you wrong and then super-compensate become your biggest ambassadors

> "You can't just make it right, you have to make it more than right in order to actually make it right."
> "The people that you wrong and then super compensate become your biggest ambassadors."

**Scorer use:** grade a service-recovery play by whether the response *over*-compensates (more than
right). A plain refund that merely "makes it right" fails this rule — it neither neutralizes the
tragic moment nor converts the customer into an ambassador.

---

## Product Improvement Through Deletion (execution procedure + #1-cancel-reason rule)

The number one reason customers cancel across industries is **overwhelm from too many features**. To
improve a product, improvement often comes from *deletion not addition*.

Procedure:
1. List every feature.
2. Survey customers: "If I got rid of everything except one thing, which would you want to keep?"
3. Remove the lowest-ranked feature **silently** — if no one complains, you just reduced costs.
4. If complainers are your worst customers, consider removing them too.

- At Gym Launch, deleted a 35-person tech support department — zero impact on churn or sales

> "A lot of times if you want to improve the quality of a product or service it actually comes from deletion not addition."

**Scorer use:** a "improve retention by adding features" plan should be flagged against the
#1-cancel-reason rule (overwhelm). The deletion test is the sound move.

---

## Proactive Customer Downgrade (counterintuitive retention strategy)

Proactively reach out to customers who aren't using the full suite and downgrade them to a cheaper
plan that still meets their needs. Proactively downgraded customers have the **second-highest LTV**
because they never cancel — they feel the company is ethical and looking out for them.

- Monitor usage — if customers only use 3 of 10 features, proactively offer a cheaper plan
- They never cancel because they feel the company is ethical
- Creates compounding word of mouth, referrals, and testimonials
- Treat customers as important as leads — if not more so

> "when you do a proactive downgrade where it's actually still completely meeting their expectations, those people never cancel."

**Scorer use:** reward a plan that protects retention by *lowering* a mismatched customer's spend;
a plan that keeps over-paying, under-using customers on a too-expensive plan is renewal-fragile.

---

## Education Business Graduation Pathway Model (retention model)

Education businesses naturally graduate customers, creating an acquisition treadmill without backend
products. Continuity comes from offering the next level of learning, not forcing graduates into
unrelated products.

- Structure a learning progression: mentorship (year 1) -> advanced training (year 2) -> certification (year 3)
- Downsell an annual membership ($3,000-5,000) at the point of high-ticket purchase completion for network/vendor access
- Treat the high-ticket program ($12,000) as a customer-acquisition-cost offset; the membership becomes pure margin
- The membership enables higher acquisition spend than competitors (can break even on the $12K sale)

Benchmarks: $12,000 high-ticket year-long mentorship; 20% conversion at live events (600 attendees
each); 80% of attendees never purchase again without a backend; 2 events/year, 600 attendees, $1.3M.

> "Education naturally graduates customers. Continuity comes from offering more learning, not from forcing existing customers into new products."

**Scorer use:** for an education/info business, a continuity plan that pushes graduates into an
unrelated product is weaker than one that offers the next learning level (or a downsell membership).

---

## Consumable Stacking for Continuity (decision rule)

Education **alone** does not create continuity — except under one circumstance: a consumable value
people must repurchase regularly.

- Gym Launch consumable: tested ads from representative markets, sold at 100% gross margin monthly
- 3D printing consumable: monthly list of trending products to manufacture and sell
- Real estate consumable: monthly curated list of qualifying properties
- Community itself is a consumable with network effects that discourage leaving
- Recurring services (marketing, SEO, agency) are consumables by definition

> "Education alone does not create continuity except under one circumstance: consumable value that people must repurchase regularly."

**Scorer use:** an education-only recurring plan with no repurchased consumable cannot hold
continuity — REWORK toward attaching a consumable.

---

## For-Life Offers for Retention (retention mechanism)

Offering a valuable bonus item *for life* (as long as you stay subscribed) increases retention and
reduces CAC, because customers lose the benefit if they cancel.

- The cost of the bonus item is often far less than the CAC savings it creates
- Stack multiple for-life offers over time to create unbeatable retention
- ButcherBox "Bacon for Life" started as a tech bug and became the defining growth driver

Benchmarks: bacon costs $4/box while significantly reducing CAC; top customers accumulated 6-7
for-life offers creating near-zero churn; 430,000 active subscribers, 1.75M households shipped to.

> "For-life offers reduce churn because customers lose the benefit if they cancel"

**Scorer use:** a retention plan that stacks for-life benefits (lost on cancellation) is at the
strong/compounding end of the band.

---

## Negative Word of Mouth / The Invisible Hand (CAC-vs-CPM diagnostic — quantitative test)

If you run advertisements and your cost to acquire a customer increases at a faster rate than the
average market CPM, negative word of mouth is actively working against you. For every customer you
acquire, previous bad experiences are preventing other prospects from buying. Prospects ask others
about you before buying, so the product's reputation shows up in conversion, not just in reviews.

- This is a **quantitative test:** compare your CAC growth rate to the CPM growth rate
- If CAC grows faster than CPMs -> negative word of mouth (fix the product before promoting harder)
- Complaining that "ads don't work" may actually be your product's reputation destroying conversion
- Customers who pay but would never recommend you are stealth detractors

> "if you run advertisements and your cost to acquire customer increases at a faster rate than the average cost of cpms the cost per impression in your market then it means you have Word of Mouth working against you"

**Scorer use:** a countable diagnostic. Given CAC-growth-rate and CPM-growth-rate, PASS = CAC growth
<= CPM growth; FAIL (negative WOM) = CAC growth > CPM growth -> block the "scale acquisition" decision
and route to product fix first.

---

## Churn Diagnosis: Value Demonstration vs Value Delivery (diagnostic decision rule)

When customers churn after two quarters, the issue isn't always lack of value *delivered* — it's
often lack of value *demonstrated*. If you provide results but never show the customer their improved
numbers, they don't perceive the value.

The fix:
- Log into their system and collect metrics yourself rather than relying on them
- Hold monthly meetings showing them *their own* numbers ("this guy knows all my stuff")
- Accept that some products (e.g. education) are naturally non-recurring; price accordingly
- Don't create recurring revenue for its own sake if the product doesn't support it

Benchmark: clients were churning after 2 quarters because the business wasn't showing them their
improved metrics.

> "If you can't fix churn, there's no point in doing any of this. Why would we pour more into a leaky bucket?"

**Scorer use:** before any "scale acquisition" call, diagnose churn as a demonstration gap vs a
delivery gap. A plan that delivers results but has no demonstration/reporting cadence is flagged —
the cure is reporting, not more delivery.

---

## Cumulative Value Reporting for Retention (execution procedure)

Operationalizes the extended look-back window the scorer already references (annual billing /
worst-month pricing). Report customer-success metrics as **cumulative totals**, not monthly
snapshots, to shift evaluation from recent performance to aggregate delivered value.

- Report total clicks delivered (not monthly), total hours saved (cumulative), total revenue generated (running total), pounds lost (cumulative progress)
- Counteracts month-to-month volatility perception
- Most customers still evaluate on recent performance, but cumulative reporting lifts renewal rates
- Operationalizes an extended look-back window without changing billing cadence

> "Extend perceived look-back window through customer success reporting of cumulative metrics: Total clicks delivered (not monthly), total hours saved (cumulative over subscription length), total revenue generated (running total), pounds lost (cumulative progress)."

**Scorer use:** a retention plan that reports value monthly (not cumulatively) leaves LTV on the
table — flag toward cumulative reporting, which pairs with the worst-month pricing and annual-billing gates.

---

## Recurring vs Reoccurring Revenue (decision rule — subscription vs habitual repurchase)

Not every business needs subscriptions. Distinguish **recurring** (a subscription/membership the
customer pays on a cadence) from **reoccurring** (reliable repeat purchases with no subscription).
Coca-Cola has basically no memberships yet has reliable reoccurring revenue. For one-time-purchase
businesses (e.g. permanent holiday lighting), the sound model is reoccurring touchpoints: seasonal
campaigns 2-3x/year, maintenance visits, and upgrade opportunities — and a data point that 50%+ of
customers buy something each year.

- Reoccurring revenue = reliable repeat purchases without a subscription
- Run 2-3 seasonal campaigns per year (Easter, Halloween, Christmas)
- Use seasonal visits as upsell opportunities and maintenance check-ins
- Track data showing half of customers buy something additional each year
- This makes the business valuable even without subscription revenue

Benchmarks: $5,000 average ticket for holiday lighting installation; $300 CAC on a $5,000 LTV
(excellent ratio); ~60% gross margins.

> "Coca-Cola has basically no recurring memberships but we buy Coca-Cola products all the time so we have reoccurring. It's reliable revenue, it's just not on a membership or a subscription."

**Scorer use:** do NOT REWORK a non-subscription plan merely for lacking a membership. Score it
against the reoccurring model instead — if it has no seasonal-campaign / maintenance / repeat
mechanism AND no evidence that ~50%+ of customers buy yearly, flag it; a forced subscription on a
product people won't subscribe to is the wrong fix.

---

## Two Compounding Revenue Mechanisms (taxonomy — recurring vs reoccurring vs distribution-network)

Businesses compound only through two mechanisms: (1) selling products customers never stop buying —
either **recurring** (subscription) or **reoccurring** (habitual repurchase) — or (2) building a
**distribution network** that never stops selling regardless of individual customer churn.

- Mechanism 1 — Recurring: subscription model (Netflix) — customer pays indefinitely
- Mechanism 1 — Reoccurring: habitual repurchase (Coca-Cola, Starbucks) — no subscription but consistent behavior
- Mechanism 2 — Distribution compounding: a distribution base (e.g., 1,000 gym locations selling supplements) creates recurring revenue at scale even as individual end-customers churn
- Company B (retaining customers) vs Company A (100% churn replaced by 200% acquisition) reach the same 300 customers by Year 3, but Company B is stable and continues growing without replacing lost customers
- Average Starbucks customer LTV = $14,000

Benchmarks: average Starbucks customer spends $14,000 over their lifetime; Prestige Labs example —
1,000 gym locations as a distribution base creates stable recurring revenue.

> "Once you acquire a customer, they keep paying you."
> "Both compound, so growth becomes inevitable."

**Scorer use:** when a plan claims it will "compound," verify it actually maps to one of these three
mechanisms (recurring, reoccurring, or distribution). A plan whose only growth lever is more
acquisition compounds through none of them — flag it as a linear/leaky-bucket plan, not a compounding one.

---

## LTV Game — He Who Makes Customers Most Valuable Wins (reframe + LTV formula)

Competitive advantage comes from maximizing customer lifetime value, not from marketing hacks. LTV
is **gross profit per transaction × purchase frequency**, and purchase frequency is directly
proportional to product quality. The biggest companies don't use Instagram hacks because they've
already won the long game of LTV.

- Dan Kennedy: 'He who can spend the most to acquire a customer wins'
- Reframed: he who can make his customers the most valuable wins
- LTV = gross profit x purchase frequency
- Purchase frequency is directly proportional to product quality
- Better product -> referrals -> decreased CAC + increased LTV simultaneously
- Marketing hacks are short-lived; LTV advantage is permanent
- The biggest companies don't use hacks because they don't have to

> "he who can spend the most to acquire a customer wins and I rephrase that as he who can make his customers the most valuable wins"

**Scorer use:** score a growth plan by whether it raises gross-profit-per-transaction or
purchase-frequency (the LTV levers), not just front-end conversion. A plan resting on a short-lived
acquisition hack with no LTV/product-quality lever is fragile — flag it.

---

## Product as Compounding Vehicle (cut-once-sell-1000x + valuation multiples)

The compounding vehicle in most businesses is **product quality**. Marketing is linear (more
marketing = more customers); product improvements compound (work once, benefit every customer).
Businesses that grow through product compounding sell for **20-50x multiples** because acquirers
trust the continued growth; businesses built purely on sales/marketing are valued as cash-flow jobs.

- Product improvement is the highest-leverage activity because every customer receives it
- Cut once, sell 1000 times — product improvements are multiplicative
- Marketing is linear: more effort = proportionally more customers
- Companies with compounding product sell for 20-50x multiples
- Marketing-only companies are valued as cash-flow jobs
- Facebook's growth came from user activation, not more advertising
- Most small businesses fix 1-2 things then immediately want to gas advertising — this creates plateaus

Benchmark: Hormozi's books still sell thousands of copies per month 2.5-3 years after publication
without advertising.

> "improving your product is the highest leverage thing you can do because every single person gets that product and so you work on it one time and then it's cut once sell 100 times cut once sell a thousand times"

**Scorer use:** a plan that proposes to scale by adding marketing while the product is untouched is
choosing the linear lever over the compounding one — flag it (and pair with the leaky-bucket /
invisible-hand gates). The strong move improves the product first, then gases acquisition.

---

## Customer as Goal vs. Sale as Goal (compounding-retention contrast + Year 1/2/3 math)

Making the **customer (relationship)** the goal rather than the **sale** creates compounding growth:
retained customers buy again next year AND refer new customers, removing constant acquisition
pressure. Optimizing for the sale is a treadmill requiring perpetual new acquisition.

- Make sales to get customers, not customers to make sales
- Year 1: N customers. Year 2: N + new customers. Year 3: years 1+2 customers + new customers — this is compounding
- Sale-first approach: need 20 new customers every month just to maintain revenue
- Customer-first approach: first customers never leave, refer the next 100, you can raise prices and operate on your terms
- Both brand and product are expressions of one underlying concept: compounding

> "If you make sales to get customers rather than get customers to make sales, you make the customer the goal and then you get to keep that relationship."
> "I didn't understand compounding. I thought it was normal to have to go out, bang doors, call phones, DM, run ads to get customers every single month."

**Scorer use:** distinguish a sale-first plan (optimizes the transaction, forfeits the relationship)
from a customer-first plan (compounds). A plan that needs a fixed number of new customers every
month just to stay flat is sale-first — flag it as non-compounding.

---

## Product vs. Business Asset Distinction (push-vs-pivot diagnostic + 'relove')

A diagnostic distinguishing a **product** (one widget, one time, one person — needs constant input
to sustain) from a **business asset** (self-sustaining revenue via recurring, upsell, or backend
structures). A business without retention/recurrence is an amplified job, not an asset.

- Product definition: one widget, one time, one person — no backend, no upsell, no recurring revenue
- A business without recurrence is technically a business but not a valuable asset — it dies the day inputs stop
- It is an 'amplified version of you — a slightly fancier or higher leverage job'
- Fix: add a better, extra, or recurring version of the existing product so customers buy again
- For non-subscription businesses: study why customers aren't repurchasing; examine billion-dollar businesses in the same space to identify what recurring/retention mechanism they solved
- **Push vs. pivot question:** 9 times out of 10 you should push — an unsolvable problem is usually an undefined problem
- Exception to push: if the market fundamentally doesn't want the product and there are no billion-dollar businesses in the space doing it, the business may not be worth owning
- Businesses don't die — entrepreneurs lose their drive; learning to 'relove' the business through skill development extends entrepreneurial commitment

Benchmark: Coca-Cola has no subscription model but has guaranteed repeat-purchase behavior built
into product design.

> "You sell one widget one time to one person. No backend, no upsell, no recurring, no revenue retention. It really just means it's an amplified version of you — a slightly fancy or higher leverage job."
> "Businesses don't die. Entrepreneurs fade."

**Scorer use:** when a plan is really "do the same one-time sale harder," classify it as a product,
not an asset, and route to adding a recurring/upsell/repeat mechanism. Apply push-vs-pivot: default
to push (fix the retention mechanism) unless there is genuinely no billion-dollar business in the space.

---

## Newsletter Niche Value Principle (hyper-niche high-LTV rule + content funnel)

Newsletters with the highest LTV are **hyper-niche and high-value**, usually at a higher price point.
Broad newsletters struggle to deliver tremendous value to everyone — you can give a little value to a
lot of people or a lot of value to a few. For creators, top-of-funnel is making great content that
converts into newsletter subscribers.

- Hyper-niche newsletters do best in terms of LTV
- Usually a higher price point but very specific to the audience
- It's very hard to provide tremendous value to everyone
- Top of funnel: get really good at making content → converts to subscribers → sell ads or products

> "The ones that do the best in terms of LTV are typically hyper-niche and high value."

**Scorer use:** score a newsletter/audience monetization plan against niche depth. A broad
"value to everyone" newsletter is LTV-weak — prefer the hyper-niche/high-price configuration and a
content top-of-funnel that converts to subscribers.

---

## Quarterly Cleanup Campaign (re-engagement procedure — 4x/year non-buyer conversion)

Run a structured re-engagement campaign once per quarter to convert non-buyers on the email list.
Test with 10-15% of the list first, optimize funnel metrics, then roll out to the full list. Change
the wrapper seasonally while keeping the core deliverable the same.

- Do one conversion mechanism per quarter for non-buyers
- Test with a small segment (10-15%) before full list rollout
- Change the naming and wrapper each quarter to prevent fatigue while keeping core components the same
- Between quarterly campaigns deposit goodwill by providing value
- Split test subject lines, CTAs, landing pages, and offer naming each iteration
- Once you have four tested promos for the year, they become autopilot cash printers

Benchmarks: first campaign $2.4M from 464K emails; second run to a different segment $2.2M the very
next month.

> "One of my favorite business strategies: do something that works, do it again, do more of it, and ideally do it better"

**Scorer use:** for a list-reactivation plan, check the procedure shape — one mechanism/quarter,
10-15% test segment before full rollout, seasonal wrapper change with constant core, goodwill
deposits between campaigns, split-testing each iteration. A "blast the whole list once, untested"
plan is missing the test-then-roll-out and the seasonal-rotation discipline — flag it.

---

## Hit Your List with All Three (combined-playbook — giveaway + arbitrage + pricing to all owned channels)

Combine all three strategies — arbitrage, giveaways, and pricing — and deploy them to your existing
contacts across **cell phone, email list, and social media followers** as a single blast. Create the
giveaway that generates leads, build the ascension process, then blast it to everyone you already know.

- Look at your cell phone contacts, email list, and social followers as existing assets
- Create a giveaway that reveals a problem, gives a trial, or solves one step of a multi-step problem
- Build an ascension process from the giveaway to your paid product
- No additional acquisition cost since you already have these contacts

Benchmark: largest portfolio company made $2.3M from a three-email blast to an existing list.

**Scorer use:** when grading a "monetize our existing audience" plan, check that it hits all three
owned channels (cell, email, social) and pairs a lead-generating giveaway with a built ascension
path — not a bare promo to one channel.

---

## Portfolio Company Turnaround Case Study (six-horsemen turnaround — green-dye, 90-day result)

A real B2B portfolio turnaround demonstrating all six horsemen fixes: replaced a toxic CS leader,
fired 90% of the underqualified team, hired aggressively at better comp with benefits, implemented
comprehensive data tracking, created a customer journey with scripted renewal/ascension touchpoints,
and contextualized conversations with customer notes.

- Replaced cancerous CS leader who was pitting team against the founder
- Fired 90% of baseline team and hired aggressively at better comp with benefits
- Used the 'green dye' method: hired good people alongside bad, let bad ones self-select out
- Installed note system so reps had full customer history — repeating yourself is friction
- Created renewal events on purpose (quarterly) instead of randomly
- Split compensation: CSMs paid for intro/sets, closers paid commissions on ascension sales
- Built everything back-to-front: fix the bucket before pouring more in

Benchmarks: profit went from 5% to 30% (6x); revenue retention 2% to 30%; ascensions 0-1/month to
5-6/month; added $2M in revenue from ascensions alone; changes took ~90 days.

> "I typically build businesses back to front. I try and solve how do we make this thing so unbelievably profitable so that I can then outspend everybody else on acquisition."
> "The profit is disproportionately made on the back end."

**Scorer use:** the worked benchmark behind the back-to-front / leaky-bucket ROUTE rules. Use its
numbers (5%->30% profit, 2%->30% retention, ~90 days) as the realistic shape of a sound retention-first
turnaround; a plan claiming compounding growth while skipping the team/data/journey fixes is leaning
on acquisition before the bucket is fixed.

---

## Escalation to Ascension (decision rule — cancellation/escalation calls are sales opportunities)

Unhappy customers who get on escalation calls are also a sales opportunity. If 1 in 4 buys a $4,000
upsell from a $1,000 base product, that covers the revenue loss from the other 3 cancellations.
Unhappy customers have high pickup rates because they gave you money and want their value.

- The escalation call is also a sales opportunity
- If 1 in 4 buys a 4x upsell, the revenue loss from the other 3 is covered
- Unhappy customers pick up the phone fast — they gave you money and want value
- Let customers vent first — many will give you more money after feeling heard
- The gold for improving your business comes from talking to unhappy customers

Benchmarks: 25% of escalation call customers chose to buy the higher-priced upsell; if 1 out of 4
buys a $4,000 upsell from a $1,000 product, it covers the 3 cancellations.

> "If one out of four customers buy something that's four or five times as expensive you actually recovered 100% of the refunds or cancellations."
> "Paul Graham from YC has said: you can solve almost every business problem by talking to your customer more."

**Scorer use:** grade a cancellation/escalation handling plan against this — a plan that treats the
escalation call as pure damage control (refund-and-end) is leaving the ascension upside on the table.
The sound move lets the customer vent, then offers the higher-priced upsell; the ~25% (1-in-4)
conversion benchmark is the realistic recovery rate that covers the other three cancellations.
