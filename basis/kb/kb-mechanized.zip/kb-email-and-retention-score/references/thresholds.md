# Threshold + band table (the numbers the COUNTABLE gates compare against)

A consumer reads this to set each gate's comparison value. Every number traces to a verbatim
anchor quote in `specimens.md`.

## Per-field thresholds

| # | Field | Gate comparison | Pass condition |
|---|---|---|---|
| 1 | Annual retention | >= 80% | retention % stated AND >= 80 |
| 2 | M12 retention band | consumer 50-60% / B2B 80%+ / prosumer 40-50% base, 60%+ strong | business type named AND % in its band |
| 3 | Monthly churn | elite < 3%; VSNB target ~10% (flag ~33%) | churn % stated AND under the named ceiling |
| 4 | Golden ratio | %refer / %exit > 1 | both % stated AND quotient > 1 |
| 5 | Referral-before-scale | >= 30% before scaling | referral % stated AND >= threshold pre-scale |
| 6 | Give:ask ratio | give-share >= 98% (98:2) | ratio stated AND give >= 98% |
| 7 | Email send cap | <= 2 per promo to main list | send count stated AND <= 2 |
| 8 | LTV:CAC | >= 1 (organic healthy 13:1; warn if < 3:1) | ratio stated AND >= 1 |
| 9 | Worst-month price | basis = worst/low month | recurring price justified vs worst month |
| 10 | Compliance | no lie / no exaggeration / states facts | every claim passes all three |

## Band logic (derive from passed fields only)

- **REWORK** — any COUNTABLE field (1-10) fails its gate, OR the scale override fires (field 5 fails while a scale decision is on the table).
- **SOUND** — all COUNTABLE pass; heuristic (11) may `warn`; felt (12) is informational.
- **STRONG** — all COUNTABLE pass AND the compounding signals are at the strong end: M12 >= 60%, monthly churn < 3%, golden ratio > 1. A heuristic `warn` drops STRONG to SOUND.

A felt `weaker` never lowers the band; a heuristic `warn` lowers STRONG->SOUND only, never to REWORK.

## Supporting benchmarks (context, not gates)

These inform the verdict reason but are not standalone gates:

- Billing cadence: monthly -> annual billing increases LTV ~5x at the same price (longer interval, lower churn).
- Escalation break-even: 1-in-4 buying a 4-5x upsell recovers 100% of cancellations.
- Email nurture revenue: 30-50% of revenue is typical for mature e-commerce (a health reference, not a pass gate).
- Insurance/maintenance: annual maintenance priced at 5-10% of purchase price.
- Internal plays: expect a 10-20% take rate on a time-boxed quarterly promo.
- Webinar reminders: SMS open rate 95-99%; show-rate lift 18% -> 24%.
- Activation correlates: e.g. 5 workouts in the first month; reverse-engineered from the longest-staying cohort.
