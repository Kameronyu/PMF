# Per-criterion membership tests + the COUNTABLE gate definitions

All YES = the criterion passes. Each test can return FALSE so a wrong value fails by shape.
COUNTABLE gates are run by a SCRIPT against the page (its sections, copy, numbers, images);
FELT criteria are judged pairwise against `references/scoring-specimens.md`; HEURISTIC
criteria soft-warn only.

---

## COUNTABLE gates (script — hard-gate; deterministic presence/number/threshold)

**G1 Above-fold social proof (review count ≥ 3,000)**
- `has_review_count = page surfaces a numeric five-star/review count`
- `count_value >= 3000` AND the element is positioned ABOVE THE FOLD (in the hero, no scroll).
- PASS iff both. Benchmark: "Social proof threshold: 3,000+ five-star reviews displayed on page".
- FALSE example: review count present only after scrolling → FAIL G1 (pitfall: missing
  above-fold social proof).

**G2 Section count (5–8 full sections, not 1–2)**
- `n = count of distinct content sections on the page`.
- PASS iff `n in [5,8]`; SOFT-WARN if `3 <= n <= 4` ("build toward 5–8"); FAIL if `n < 3`
  (the 1–2-section "product + reviews" anti-pattern that leaves objections unhandled).

**G3 Listicle benefit-point count (5–7, each with an image)** — applies only when archetype = listicle bridge page
- `b = count of benefit points`; PASS iff `b in [5,7]` AND every benefit point has a
  supporting image. FALSE example: 9 text-only bullets → FAIL.

**G4 Discount anchor band (30–35%, framed limited-time)**
- `d = the discount percentage presented`; PASS iff `30 <= d <= 35` AND it is framed as
  limited-time/urgency. FALSE example: "20% off" with no urgency → FAIL.

**G5 Structural-pitfall presence checks (each binary; all must pass)**
Each names a structural element that MUST be present (positive target on the left):
- above-fold social proof IS present (not trust only after scrolling)
- urgency/scarcity IS in the offer section (not absent)
- ad-creative ↔ landing-page imagery IS congruent (same imagery/models/value props)
- testimonials ARE distributed throughout (not consolidated in one block)
- hero images show happy customers USING the product (not product-only shots)
Any element absent → FAIL that check (and flag it in `flags`).

---

## HEURISTIC criteria (soft-warn only — never hard-FALSE)

**H1 Education vs over-persuasion (novel/complex products)**
- Target: a category-creating/novel product devotes real estate to mechanism explanation
  and demos, not pure persuasion. Soft-warn if education real estate looks thin —
  "Over-persuading without educating increases refund rates" is a tendency, not a shape gate.

**H2 Optimization-priority hygiene (MBB)**
- Target: copy and media are validated before design investment; copy is written from
  researched customer language, not the brand's perspective. Soft-warn if the page reads
  as design-first or brand-voice copy. Never hard-fail.

---

## FELT criteria (pairwise-vs-specimen — NEVER a membership gate)

Do **not** write a yes/no script test for these. Return `prefer | tie | weaker` against the
matching specimen in `references/scoring-specimens.md`.

**F1 Desire/outcome-led headline (vs feature-led)**
- Judge the hero headline pairwise against a desire-led specimen. Does it lead with the
  buyer's desired identity/outcome the way the specimen does? `prefer | tie | weaker`.
  This is the criterion a naive mechanizer would launder into "is this desire-led? → FALSE";
  keep it a signal, since desire-vs-feature is a felt, language-specificity judgment.

**F2 Objection-specific testimonial (vs generic praise)**
- Judge a sampled testimonial pairwise against the objection-specific specimen. Does it name
  and dissolve a specific objection, or is it generic praise? `prefer | tie | weaker`.

## Why the tiers
Hard-gating a felt criterion produces confident-but-wrong FALSEs and pushes builders to game
the gate. Hard-gating a countable one (a count is what it is; a number is or isn't in band)
is reproducible and safe. Soft-cap the in-between (education depth, design-first) because the
detectors over-flag.
