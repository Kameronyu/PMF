# Benchmark data table — the source numbers the COUNTABLE gates calibrate to

These are the verbatim benchmarks from the source "Key Metrics & Benchmarks" block. The
COUNTABLE gates (G1–G5) in `criteria-tests.md` derive their thresholds from here; this file is
the authority for the numbers so the gates are not eyeballed.

| Benchmark | Value | Gate it feeds |
|---|---|---|
| Social-proof threshold | 3,000+ five-star reviews displayed on page | G1 (above-fold count ≥ 3,000) |
| Countdown timer window | 5-minute urgency window | G4 / G5 urgency presence |
| Discount anchor | 30–35% off presented as limited-time | G4 (discount band) |
| Section count | 5–8 sections for high-performing pages vs. 1–2 for average | G2 |
| Listicle benefit points | 5–7 items with images | G3 |
| Social-proof headline benchmark | "3 million+ people" as FOMO anchor | listicle hook / F-signal |
| Oodie hero reference | 35% discount + installment payment option | G4 worked example |
| Subscribe & Save | pre-selected to increase monthly recurring revenue and LTV | standing contract (G5) |

## Worked references (verbatim from source)
- "Social proof threshold: 3,000+ five-star reviews displayed on page"
- "Countdown timer: 5-minute urgency window"
- "Discount anchor: 30–35% off presented as limited-time"
- "Section count: 5–8 sections for high-performing pages vs. 1–2 for average"
- "Listicle benefit points: 5–7 items with images"
- "Social proof headline benchmark: \"3 million+ people\" as FOMO anchor"
- "The Oodie hero uses 35% discount + installment payment option" — a real in-band example: 35%
  sits at the top of the 30–35% G4 band, paired with an installment-payment value model.
- "Pre-selected Subscribe & Save increases monthly recurring revenue and LTV"

## Common pitfalls checklist (the negatives the scorer flags — full source list)
Each is a structural failure the page must NOT exhibit; G5 + the SKILL.md negatives list test
the top five, but the grader should flag any of these it sees:
- Feature-led headlines instead of desire/outcome-led headlines
- Consolidating all testimonials in one block instead of distributing throughout the page
- Using generic testimonials instead of objection-specific testimonials
- Only 1–2 sections (product + reviews) — leaves most objections unhandled
- Product images showing product only, not happy customers using it
- No congruency between ad creative and landing page imagery
- Over-persuading novel products without educating — drives refund rates up
- Missing above-fold social proof (trust established only after scrolling)
- No urgency or scarcity element in offer section
- Homepage as navigation hub instead of sales page (missed conversion opportunity)
