# ROUTE contracts — archetype selection + section sequencing (named-trigger, no wording)

These are structural contracts: they SELECT a page archetype and ORDER its sections by a
named trigger (traffic temperature, product type, awareness, optimization priority). They
dictate NO wording. The scorer checks them as presence/ordering — never as copy quality.

## Archetype selection (by named trigger)
- **Cold / top-of-funnel traffic → listicle bridge page.** Curiosity headline + 5–7 image
  benefit points (G3) + CTA to the product page. Trust bridge, NOT a conversion page.
- **Desire-based product → Coconut model.** Lead with aspirational identity outcome;
  distribute social proof across all sections; urgency in the offer section.
- **Novel / complex category-creating product → education-first (FEMA) model.** Lead with a
  curiosity hook; dedicate real estate to mechanism explanation + demos (see H1); name and
  neutralize the dominant objection.
- **Homepage as conversion asset → Trojan homepage.** Convert passive navigation into a full
  sales page (hero → press → best-sellers → competitor comparison → unboxing → repeated trust).

## Section-sequence contracts (order is the contract; check order, not wording)
- **Hero required-element order:** announcement bar → happy-customer image → desire headline
  → product explanation + value prop → social proof → trust badges → singular CTA.
  Right-side order: social proof → product title → value proposition → badges → 3–4 sentence
  extended benefit description.
- **Eight-section psychological sequence:** countdown → happy model → benefits → social proof
  → before/after → pain point → mechanism → guarantee.
- **Long-form 6-block architecture:** above-fold → what's inside → before/after + authority →
  objection-specific testimonials → "5 reasons why" → offer section.
- **Four-section benefits sequence:** USP comparison → emotional value prop →
  materials/craftsmanship storytelling → future pacing.
- **Sales-conversation-mirror blueprint:** frame → desired state → early trust → hero story →
  amplify pain / failed alternatives → first CTA → testimonials+press → named objection
  handling → certifications → distributed testimonials → urgency close.

## Standing contracts (apply across archetypes)
- **Congruency:** LP imagery, models, and value props MUST match the ad creative (G5).
- **Distribute testimonials throughout** the page — not consolidated in one block (G5).
- **Eight image questions:** product images must answer what / what's-in-it-for-me /
  is-it-for-me / what-they-get / can-they-trust / who-it's-from / is-it-worth-it / how-it-works.
- **Subscribe & Save pre-select:** pre-select the subscription option to lift recurring
  revenue / LTV.
- **Optimization priority (MBB):** order effort copy → media → design; address design only
  when it creates friction (H2).

## How the scorer uses these
1. Determine the page's declared archetype from its named trigger (traffic temp / product
   type / homepage). If none declared → flag `archetype-undeclared`.
2. Check the archetype's required sections are PRESENT and in the contract ORDER.
3. Run the standing contracts as G5 presence checks.
Selection/sequencing is a CONTRACT (presence + order), not a copy-quality judgment.
