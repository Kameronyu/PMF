# Scoring specimens — the known-good copy to judge FELT criteria against

Felt criteria (F1 desire/outcome-led headline, F2 objection-specific testimonial) are
scored **pairwise against these specimens**, never on an absolute 1–10 and never by the
agent that wrote the candidate. Randomize presentation order; treat any single verdict as
a triage signal (`prefer | tie | weaker`), not a certification. A `weaker` contributes no
pass for that criterion.

## Desire / outcome-led headline reference (judge F1 against these)
These lead with an identity/desire outcome, not a product feature:
- "Reveal Your Most Radiant Glow"
- "Discover what 3 million+ people are going crazy over"
- "Discover the panties the internet goes crazy about"

Ask: does the candidate headline put the buyer's desired identity/outcome first, the way
these do — or does it lead with a feature/spec? → prefer | tie | weaker.

## Objection-specific testimonial reference (judge F2 against this)
The standard is a testimonial that resolves ONE named objection, not generic praise:
- "Testimonials each solving a *specific* objection (not generic praise)"

Ask: does the candidate testimonial name and dissolve a specific buyer objection (price,
fit, will-it-work-for-me, comparison) — or is it generic, non-specific praise?
→ prefer | tie | weaker.

## How to run the pairwise judge
1. Present candidate + one specimen, order randomized.
2. Ask which better satisfies the named criterion and why (criteria stated before verdict).
3. Record `prefer | tie | weaker` + the reason. `weaker` contributes no pass.
4. Never let the model that generated the candidate be the judge — run this as a separate pass.
