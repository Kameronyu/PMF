# Routing contract — named-trigger selection & sequencing

These rules SELECT which framework applies and in what order. They assign no verdict and
dictate no wording (the wording is the writer's job). The scorer uses them to populate the
`route` fields and to decide which gates are even applicable.

## Objection-type → framework (Onion of Blame peel order)
Peel **Circumstances → Others → Self**.
- "I can't afford it" → Circumstances layer → price/money frameworks.
- "I need to talk to my partner" → Others layer → authority/partner sequence.
- "I have to think about it" → Self / avoidance layer (prospect in power) → avoidance branch.

## Avoidance ("I need to think about it") → branch
Handle across **Past** (bad experiences burning you twice) / **Present** (people need
information, not time) / **Future** (only walking out guarantees failure).

## Time objection → angle
**Macro** (busy season → habit persists) / **Micro** (no time in day → doing wrong
things) / **When-Then fallacy** (waiting for the condition the product itself creates).

## Price/money objection → framework
Why-a-Lot-is-Good / Value-Justification / Paying-Either-Way / Resourcefulness-vs-
Resources — selected by how the objection is voiced.

## Authority/partner objection → sequence
Isolate (partner isn't here to object) → reframe permission-vs-support → if the concern is
genuine, offer a short guarantee to nudge.

## Sales-motion selection
Route by ticket size + stakeholder count + delivery standardization:
**Transactional / Diagnostic / Enterprise**. Diagnostic = standardized delivery + custom
presentation = highest-leverage middle. (Sets which gates apply: goal-pricing and tiers
suit Diagnostic; MESO/increment suit Enterprise negotiation.)

## Five-step diagnostic order
Pre-sale questionnaire (agitate) → collect card (complete profile) → current/desired/
obstacle in their language → kill objections early → drill team to automatic script.

## Kill zombies early
Before the appointment ask "is there anyone else required to make this decision?"; if yes,
reschedule with all decision-makers present. (Feeds the Gate 6 Authority criterion.)

## BATNA-first negotiation
Only negotiate from a real alternative (employee: another offer; vendor: multiple bids;
partnership: multiple deals in play). Without a BATNA, the anchor/increment gates (5, 8)
do not apply yet.

## Reciprocity / variable expansion
Trade concessions across **Speed / Price / Risk / Ease** — give what is low-value to you,
high-value to them, to hold price.

## Discount → change-of-terms substitution
Never score a straight discount as SOUND; require a swap for referral intros or a
higher-perceived-value bonus before re-scoring.

## Objection → asset/bonus routing
Map each known objection to a specific content asset (send before/after call) and to a
templated stack bonus deployed only when that objection arises.

## Post-sale commitment step
Immediately after close, route to a public-commitment action (text/call 3 people; a
three-way referral text at peak satisfaction) to pre-empt buyer's remorse.
