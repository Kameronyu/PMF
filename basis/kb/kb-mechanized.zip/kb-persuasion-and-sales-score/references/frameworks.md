# Sales frameworks the scorer leans on — the spine + the execution levers

These are the source frameworks the gates and routing live inside. They are not new gates;
they tell the scorer (a) which job a unit serves so it knows what "sound" means for it, and
(b) the quantified opportunity-volume / team / pricing levers the COUNTABLE gates never touch.
Preserved faithfully from `persuasion-and-sales--alex-hormozi.md`.

## The spine — Three Jobs of a Salesperson (everything maps here)

Source says all nine sales concepts map into three buckets. Use this to classify any artifact
before scoring it: a volume tactic is judged differently from a conversion structure.

- **Job 1 — Maximize the number of opportunities** (lead/appointment volume).
- **Job 2 — Convert the highest percentage of those opportunities** (the conversion structure
  the COUNTABLE gates already grade: guarantee, tiers, MESO, looping, qualification).
- **Job 3 — Do it consistently for a very long period of time** (the long game).

> "If you boil it down a salesperson has three jobs to do: they have to maximize the number of opportunities they have, they have to convert the highest percentage of those opportunities, and they have to do it consistently for a very long period of time"

The skill set historically only graded Job 2. The levers below restore Jobs 1 and 3.

Benchmarks: built multiple nine-figure sales teams; scaled teams 0→40 and 0→60; personally
closed over 4,000 sales.

### Consistency over intensity (Job 3)

Most salespeople have hot months and cold months; the best maintain steady performance, which
compounds. Long-term consistency creates reputation and referral momentum.

> "They have to do it consistently for a very long period of time - and this is the important part"

## Job-1 levers — Maximize Opportunities (quantified)

### Sales Multipliers (immediate volume increases)

- **Sell 7 days/week = +29% instantly.** 52 weeks × 2 weekend days = 104 extra selling days/yr.
- **Sell during off-hours** when consumers are actually available (after 5pm and weekends).
- **Eliminate weekend booking gaps** — they cause Monday stacking and higher no-show rates.
- Fitness benchmark: all sales closed between **4pm–8pm**.

> "If you want to immediately increase your sales by 29% sell on weekends"

### Maximum Hours Availability

The top salesperson in every company is the one who works the most hours. Total hours
available per day is the #1 driver of opportunity volume. Be available when the prospect is,
not when convenient. Businesses pay rent on Sundays too.

> "I've never seen a salesperson who does the most in a company have the lowest amount of hours worked"
> "Businesses also pay rent on Sundays and so you can make sales on Sundays"

### Personalized Outreach at Scale (iMessage tactic)

At companies doing tens/hundreds of millions, use personalized voice notes, personalized
video, and iMessage from real phones rather than automated chat interfaces. Green text from a
chat interface = low response; iMessage = perceived real person = much higher response.
Eventually buy the team iPhones; in the beginning, do it yourself and be more efficient per lead.

> "If I get a green text that's clearly from a chat interface for a sales rep or automation, I'm way less likely to respond. If I get an iMessage, I know it's a real person on the other side."

### Founder-Led Sales Advantage

Founders should sell personally until they physically cannot take more calls. The founder is
the most convicted seller, typically closes at 2x the rate of hired reps, and pays no
commission — a cash-flow advantage and a rapid feedback loop on marketing/offer/pricing.
Keeps the salesperson-quality variable out of conversion diagnosis.

- Benchmark: owner-operator close rates of **50–80%** are reasonable at appropriate price points.

> "I'm a big believer in founders selling the product in the beginning."

### Rejection as Price of Yes (high-volume mindset)

Reframe rejection as a necessary input cost, not personal failure. Each "no" is a coin paid
toward the eventual "yes." Baseline ratio for cold outreach: **100 nos to 1 yes**. Warren
Buffett, Bill Gates, and Mark Cuban all started door-to-door. Getting rejected and moving on
is a base skill for all persuasion (spouses, kids, employees, investors, customers).

> "A 'no' is a coin you toss into a machine to eventually get a 'yes.' Rejection is the price of yes."

## Job-2/3 enabler — Sales Energy Management (Trampoline Technique)

High energy and positive tone give room for error in objection handling; neutral/low energy
means no room to mess up. Use a small trampoline (~$100) between appointments to keep energy
and blood flowing — you cannot be in a bad mood while bouncing. Build systems to keep energy
up across many daily appointments (Hormozi took 15–20 consults/day in person plus phone leads).

> "Try and be in a bad mood on a trampoline. You can't do it."

## Team management lever — Sales Script Adherence Over Closing (reward the process)

Reward reps for **adherence to the script, not for closing**. When everyone follows the script,
close rates rise naturally; if they aren't closing with it, change the script (far easier to
iterate a script everyone follows than to manage lone wolves). Pay a small bonus ($5/call)
for adherence regardless of close — the $5 matters less than the manager approval it signals.
Lone-wolf closers create false positives: close once going rogue, reinforce the wrong
behavior, then fail repeatedly, and damage the brand.

> "if you reward adherence to the script then what happens is you get everyone to follow the script now if they aren't closing then you need to change the script"
> "guess what happens when everybody adheres to the script you close more"

Benchmark: $5 adherence bonus per call regardless of close.

## Ultimate Sales Blueprint — six elements (training index + conviction obligation)

The full sales-training spine: (1) sales multipliers, (2) the conviction framework,
(3) scripting methodology, (4) tone mastery, (5) objection handling, (6) team management.
Built from 4,000+ personal closes over 13 years. Conviction obligation: if you genuinely
believe you help, you have an obligation to close. Script must be memorized — breathing it,
not reading it. Tone: volume/speed/articulation are constants; pauses and pitch are variables.

> "Over the last 13 years I've personally closed 4,000 sales"

(The conviction framework itself, scripting, and tone are WRITE-domain craft — see the
companion WRITE skill for the full treatment; objection handling lives in `routing-contract.md`.)

## SPCL Influence Framework — Status / Power / Credibility / Likeness

A four-part framework for building true influence (defined as high likelihood of compliance
with requests). The four components work independently, but **stacking all four creates
maximum influence**. Treat them as continuums — degrees, not yes/no binaries. Use this to
classify an influence-building unit (a content strategy, an authority play, a personal-brand
move) and to check whether it actually moves a lever vs. just looking impressive.

- **Status** — you control reinforcers (scarce resources) in a given environment. The
  bartender has status while behind the bar. If you control the good stuff people want, you
  have status no matter what it is.
- **Power** — say-do correspondence: you say do X, they do it, a good thing happens, and they
  comply with the next request. Each successful cycle compounds compliance.
- **Credibility** — third-party proof that validates your claims (Guinness at a book launch;
  visible proof like a $10M building).
- **Likeness** — relatability through shared values, behavior, or literal appearance. Just be
  you; there is zero ROI in faking it.
- Parents have maximum SPCL: they control resources, run thousands of reinforcement cycles,
  carry credibility, and literally look like you.

Benchmarks: 32.7 million YouTube views in one month; 35,000 pieces of content posted in one
year; $100 million+ in sales during a 72-hour book launch; 89% male audience for Hormozi vs
54% female for Leila.

> "Power comes from say-do correspondence. If I say something and then you do it and then a good thing occurs, you are more likely to comply with a following request"
> "Status is someone who controls reinforcers in a given environment. If you control the good stuff that people want, then you will have status no matter what it is"

## Three Levels of Brand Communication — Tell / Others Say / They Experience

Brand credibility operates on three levels of **decreasing control and increasing influence**.
Higher levels are more persuasive but require delivering at the lower levels first. Use this to
sequence which proof mode should LEAD at each stage of an artifact — and to flag a unit that
leans on self-promotion (Level 1) when social proof or lived experience (Levels 2–3) is
available and would carry far more.

- **Level 1 — What you tell them:** advertising, claims, promises. Least influential; the
  first level of exposure. For unknown brands, content quality here matters more than personal
  authority.
- **Level 2 — What others say:** word of mouth, social proof. Far more influential than
  self-promotion.
- **Level 3 — What they experience themselves:** direct product experience. Most definitive;
  forms permanent belief. Delivering on promises here converts customers into Level 2
  advocates — completing the loop.
- Top Gun: Maverick example: the trailer (Level 1) plus 10 friends recommending it (Level 2)
  drove the purchase decision.

> "What other people say to them matters way more than what you tell them."
> "The third level is what they experience themselves."

## Affiliate-channel frameworks (three tightly related)

Score affiliate-channel artifacts against all three together — they interlock. The common
failure mode is an incentive that benefits you and the affiliate while extracting the
affiliate's audience goodwill; flag any affiliate unit that wins only two of the three legs.

### Affiliate Trust Equation — audience goodwill is the thing at risk

Affiliates risk their accumulated audience goodwill when promoting an external product. They
require confidence you will overdeliver to accept that risk. Affiliates with genuine product
belief will promote for free when brand goodwill is high enough.

- Promoting your product puts the affiliate's audience trust at risk.
- Strong brand reputation reduces the financial compensation required from affiliates.
- When affiliates genuinely love the product, the relationship mirrors organic friend
  recommendations.
- Relational capital is earned when the affiliate uses and is genuinely satisfied by the
  product.

> "Most affiliates expect financial compensation because promoting your product risks audience trust. However, if you've built sufficient goodwill, some will promote for free if they genuinely believe in your offering."

### The Three-Way Win (Affiliate Tripod) — three parties must win simultaneously

A sustainable affiliate program requires simultaneous wins for three parties. Failure of any
single leg collapses the entire structure.

- **You win:** reach, leads, sales, brand extension.
- **Affiliate wins:** status, exposure, goodwill with their audience, business education.
- **Affiliate's audience wins:** valuable offer, exclusive bonuses, trusted recommendation.
- If the affiliate perceives you as a threat to their audience trust, the relationship fails.

> "If any leg of this tripod fails, the structure collapses. Your affiliate will see you as a threat to their audience trust."

### Status-Based Incentive Design — status beats financial prizes

Top affiliates publicly winning money prizes (e.g., supercars) extracts goodwill from their
audience. Instead, offer rewards that make affiliates look good to their own community,
aligning all three parties.

- Financial prize incentives are affiliate-centric and audience-alienating.
- Status incentives (e.g., an exclusive AMA to their community) make affiliates look like
  providers, not contestants.
- Three-way alignment required: your gain, the affiliate's status gain, the audience's value
  gain.

> "Top affiliates publicly winning supercars doesn't benefit their audience—it extracts goodwill. Instead, offering a live AMA to their community positions the affiliate as a provider, not a contestant."

## One Thing At a Time (Skill Isolation) — team-training rule

Great sales coaches identify a hundred things wrong with a salesperson's game but only work on
**one at a time**. Give someone 10 KPIs and they can't improve any of them — it's
discouraging. Isolate one skill, master it, then move to the next. Sequential mastery beats
simultaneous improvement attempts; this is how basketball coaches, painting coaches, and sales
coaches all work. When scoring a team-development or coaching artifact, flag any plan that
loads a rep with many simultaneous KPIs instead of isolating one.

> "If you look at any good skills coach whether it's a basketball coach or a painting coach or a sales coach they might see you have a hundred things wrong with your game - they're just going to focus on one at a time until they clean them all up"
