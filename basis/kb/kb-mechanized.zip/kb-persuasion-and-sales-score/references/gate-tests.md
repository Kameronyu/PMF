# Per-gate membership tests + the COUNTABLE gate definitions

All YES = the gate passes; any question can return FALSE. Countable gates lower to a
deterministic check a script runs identically every time; felt gates are pairwise-vs-
specimen (see `scoring-specimens.md`) and never hard-FALSE.

## Gate 1 — Guarantee slots (COUNTABLE — script gate)
- `has_X` = a named outcome is present (what the buyer will achieve).
- `has_Y` = a timeline is present (by when).
- `has_Z` = a consideration is present (what the seller puts at stake — "or I will Z").
- PASS iff `has_X AND has_Y AND has_Z`.
  FALSE example: "results guaranteed" → no Z → FAIL → caps band at WEAK.
- Shape to match: **If you don't achieve X by Y time, I will Z.**

## Gate 2 — Goal-pricing arithmetic (COUNTABLE — script gate)
- Extract `weeks_to_goal`, `weekly_rate`, `stated_total`.
- PASS iff `weeks_to_goal * weekly_rate == stated_total` AND the total is framed as an
  outcome-based price (priced to the goal, not a flat sticker).
  FALSE example: a flat "$5,000 program" with no weeks×rate derivation → FAIL.

## Gate 3 — Three-tier anchor (COUNTABLE — script gate)
- Extract the tier prices in presentation order: `anchor`, `core`, `downsell`.
- PASS iff exactly 3 tiers present AND `anchor > core > downsell` (strictly descending),
  with core positioned as the rational middle.
  FALSE example: two tiers, or core priced above anchor → FAIL.

## Gate 4 — MESO count (COUNTABLE — script gate)
- `count` = number of simultaneous offers presented, each acceptable to the seller and
  differing on price/terms.
- PASS iff `count == 3`.
  FALSE example: one take-it-or-leave-it offer → FAIL.

## Gate 5 — Increment ratio (COUNTABLE — script gate)
- Extract `your_move` (your concession this round) and `their_move` (theirs).
- PASS iff `your_move / their_move <= 0.25` AND the first number you stated is the
  highest defensible anchor.
  FALSE example: you move $1.5M when they move $3M (ratio 0.5) → FAIL.

## Gate 6 — Qualification checklist (COUNTABLE — script gate)
- Four named criteria, each present/absent: `Problem`, `Money`, `Urgency`, `Authority`.
- PASS iff all 4 marked present.
  FALSE example: prospect has the Problem and Urgency but is not the decision-maker
  (Authority absent) → FAIL → caps a close at SOUND (zombie deal).

## Gate 7 — Looping re-ask (COUNTABLE — script gate)
- `asks_after_first_no` = count of times the rep re-asked for the sale after the first
  "no", each following a resolved objection.
- PASS iff `asks_after_first_no >= 1`.
  FALSE example: rep stops after the first objection without re-asking → FAIL.

## Gate 8 — Anchor height (FELT — signal, NEVER a membership gate)
Do **not** write a yes/no test. Judge the opening number pairwise against a strong-anchor
specimen: does this number reset the counterparty's increments upward at least as much as
the specimen does? Return `prefer | tie | weaker`. `weaker` contributes no pass.

## Gate 9 — Stack value-build (FELT — signal)
Judge pairwise against a winning-stack specimen: does enough perceived value accrue
before the price reveal that the price lands as a relief? `prefer | tie | weaker`.

## Gate 10 — Never-disagree tone (FELT — signal)
Judge pairwise against a "make-the-prospect-right" specimen: does the copy make the
prospect right rather than winning the argument? Copy that wins the argument loses the
sale. `prefer | tie | weaker`; never a hard FALSE.

## Why the tiers
Hard-gating a felt gate produces confident-but-wrong FALSEs and pushes writers to game
the gate. Hard-gating a countable one (slots present or not; arithmetic balances or not;
prices descend or not; a ratio is over or under threshold) is reproducible and safe.
Soft-cap the in-between.
