# Pricing models & offer-design rules (beyond the goal-pricing gate)

The COUNTABLE Gate 2 grades ONE pricing model (goal-achievement arithmetic). The source
carries additional distinct pricing/offer models and a commitment-mechanism rationale the
scorer should recognize so it does not mis-score a sound-but-different model as WEAK. These
are frameworks, not new hard gates. Preserved faithfully from the source.

## Skin-in-the-Game Offer Structure (commitment mechanism)

A high upfront price tied to a results-based (money-back) guarantee dramatically increases
client commitment and success rates. The commitment mechanism makes results more likely,
which validates the premium price. Competing at $500 vs. $29/month is an advantage, not a
disadvantage — the stake drives compliance.

- Benchmark: **$500 down + money-back if 20 lbs lost in 6 weeks → 78% hit the goal.**
- Most successful weight-loss offer in the industry for nearly five years; $29/month
  competitors could not compete.

> "They had real skin in the game. They wanted their money back. Emotional investment drove results."

Scorer note: when an artifact pairs a premium price with a results guarantee that the buyer
forfeits/recovers, treat the high price as *intended* — do not flag it as overpriced.

## Flat Fee Plus Performance Pricing

A distinct model from goal-pricing: replace hourly billing with a flat fee + performance
commission tied to client outcomes. Hourly is a commodity model — clients buy outcomes, not
time. The flat fee removes billing-hours anxiety; the performance commission signals
confidence. Price is anchored to the **dream outcome**, not hours worked.

- Benchmark: attorney repriced from $250/hour to **$5,800 flat fee + commission** on deals
  worth several hundred thousand dollars.

> "Flat fee plus performance pricing signals to prospects that success is expected. This drives conviction."
> "Price based on the dream outcome, not time or features."

Scorer note: a flat-fee+commission artifact will NOT satisfy Gate 2's weeks×rate arithmetic —
that is a different model. Do not FAIL it for lacking goal-pricing math; check instead that the
fee is anchored to the dream outcome and that the performance leg exists.

## Price as Perceived Value Component

Price and perceived value are bidirectional: higher price raises perceived quality
independent of actual quality (identical wines rated cheap/medium/excellent by price label
alone). Strategic goal: be so much more expensive that the prospect recategorizes the product.
A bargain is defined by price-to-value discrepancy, not absolute price — a $100M product can
be a bargain. Lowering price to compete compresses margin until no one is profitable
(the commodity trap).

- Benchmark: blind taste test — three identical wines rated cheap/medium/excellent by price
  label alone.

> "The goal is to be so much more expensive that consumers think: this can't be the same category of solution. It must be different."
> "You could sell something for $100 million and it could still be a bargain."

Scorer note: do not treat "the highest price" as automatically WEAK. Judge price against
perceived value (value-build, Gate 9), and flag a *reflexive discount-to-compete* move as the
commodity trap.

## AB Offer Strategy (two-tier cash-flow offer structure)

A distinct two-offer model: Offer A pairs a lower upfront price with a monthly subscription;
Offer B pairs a higher upfront price with a free equipment/incentive. Both are engineered so
the upfront cash flow exceeds the cost to serve, solving an immediate profitability problem.
This is NOT a three-tier anchor structure — it is two parallel cash-flow offers.

- Offer A: **$189 upfront + $60/month**
- Offer B: **$360 upfront with free bin included**
- Structure offers so upfront cash flow exceeds cost to serve.
- Target benchmark: 5 more sales guys doing 5–7 sales per day.

> "The outcome of all of this is that your cash flow positive and babies have food."

Scorer note: when an artifact presents exactly two parallel offers each engineered for
positive upfront cash flow (one lower-upfront-plus-subscription, one higher-upfront-plus-free-
incentive), recognize it as the AB Offer Strategy and **suspend Gate 3** — do not FAIL it for
having two tiers instead of three or for tiers that are not strictly descending. Gate 3's
three-tier anchor test applies to the anchor/core/downsell model only, not to this two-tier
cash-flow model.
