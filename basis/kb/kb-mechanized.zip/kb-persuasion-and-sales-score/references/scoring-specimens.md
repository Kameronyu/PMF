# Scoring specimens — the known-good artifacts to judge gates against

Felt gates (8 anchor height, 9 stack value-build, 10 never-disagree tone) are scored
**pairwise against these**, not on an absolute 1–10, and never by the model that wrote
the candidate. Countable gates use these as worked sanity checks. Randomize presentation
order; treat any single score as a triage signal, not a certification. Every quote below
is a verbatim substring of the source KB.

## Countable-gate worked specimens (sanity-check the script results)

**Gate 1 — guarantee slots (X / Y / Z all present):**
- "if you don't achieve X by Y time, I will Z, which is what's the consideration"

**Gate 2 — goal-pricing arithmetic (weeks × rate = total):**
- "40 lbs to lose at 1 lb/week = 40 weeks × $129/week = $5,160. Converts higher percentage of prospects."

**Gate 4 — MESO count (exactly 3):**
- "Present 3 offers with different price/term combinations, all acceptable to you"

**Gate 5 — increment ratio (small move resets their increments):**
- "If you say 'I'll do this work for $100,000' and someone was thinking $10,000, their increments now become $20,000 or higher."

**Gate 6 — qualification (Money criterion):**
- "Without money, you have a nonprofit, not a business."

**Gate 7 — looping re-ask:**
- "The number of sales you make is directly proportional to how many times you ask."

## Anchor-height reference (judge Gate 8 against these)
- "If you say 'I'll do this work for $100,000' and someone was thinking $10,000, their increments now become $20,000 or higher."

Ask: does the candidate's opening number reset the counterparty's increments upward at
least as much as this does? → prefer | tie | weaker.

## Stack value-build reference (judge Gate 9 against these)
- "The stack is a direct sales tactic that has been proven so many times across so many industries that it is effective"
- "You gotta touch the bottom of the pool — that's what makes it memorable"

Ask: does the candidate accrue enough perceived value before the price reveal that the
price lands as a relief? → prefer | tie | weaker.

## Never-disagree / make-the-prospect-right reference (judge Gate 10 against these)
- "If you win the argument in a sale, you lose the sale. The only way to win is by being willing to lose being right."

Ask: does the candidate make the prospect right rather than winning the argument? →
prefer | tie | weaker.

## How to run the pairwise judge
1. Present candidate + one specimen, order randomized.
2. Ask which better satisfies the named gate and why (criteria before verdict).
3. Record `prefer | tie | weaker` + the reason. `weaker` contributes no pass for that gate.
4. Never let the model that generated the candidate be the judge.
