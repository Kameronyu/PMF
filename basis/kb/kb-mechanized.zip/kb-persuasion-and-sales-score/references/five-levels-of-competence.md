# Five Levels of Competence — prospect/learner classification scheme

A 5-level scheme classifying learners and customers by **belief orientation** (positive/
negative) crossed with **energy orientation** (active/passive). Level determines outcomes more
than program quality. Use it to diagnose a prospect's level and to recognize that the highest-
upside prospect (Level 5) is also the one who looks most like a lost cause. Preserved
faithfully from the source.

| Level | Name | Stance | What it produces |
|---|---|---|---|
| 1 | Positive Active | "I will be the best student this person has ever had, no matter how incompetent they are." | Success depends on self, not teacher quality. |
| 2 | Positive Passive | "He did it, so I can do it." | Replicators. A-minus players. Still highly effective. |
| 3 | Neutral Passive | "It's worked for other people, let's see if it works for me." | Open but not committed. The majority sit here. |
| 4 | Negative Passive | "It might work for others but probably won't work for me." | Half-execution, then blames the system. |
| 5 | Negative Active | "I can prove this will work for everyone but me." | Special-snowflake immunity belief. Actively works to prove failure. |

- **Level 5 has the highest upside:** when active energy flips from proving it wrong to proving
  it right, they become top performers and brand ambassadors.
- **Gym-owner case:** moved from Level 5 ("market is different, zip code is different") to
  Level 1; became the top facility out of thousands using the exact same system.
- **Autumn case:** "special thyroid" belief (Level 5), reframed with "do you want to be right
  or do you want to be thin?" — became a top client and brand champion.

> "Level 5 Negative Active: 'I can prove this will work for everyone but me.' Special snowflake immunity belief. Actively works to prove failure."
> "It's never going to be the thing that works—you are going to be the thing that makes it work."
> "When Level 5 becomes Level 1, they become absolute ambassadors and brand champions."

Scorer/diagnostic note: the level reframes the prospect, not the program. A handle aimed at a
Level-5 prospect should attack the immunity belief ("right vs. result"), not add more proof.
