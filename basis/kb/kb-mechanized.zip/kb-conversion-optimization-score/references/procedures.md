# Execution procedures, ordered ROUTE contracts, and audit checklists

Restored from `conversion-optimization--alex-hormozi.md`. These are ordered/sequenced
procedures and checklists. A ROUTE check over any of them returns `ordered: yes|no|n/a` plus a
verbatim evidence quote. All `> "..."` and quoted lines are verbatim source substrings.

---

## Sales Step-Down Commitment Ladder (5 rungs, descending, sequential)

Offer the rungs in order to every customer; accept the first one they choose. No customer
leaves without some level of commitment.

1. **Rung 1 — Prepayment discount (15-20% off)** — frame as "prepayment discount", not "pay in
   full".
2. **Rung 2 — Third-party financing** — partner with industry finance companies; the
   salesperson carries no payment risk.
3. **Rung 3 — Partial down payment** — 50% down, 5-10% discount on the remainder.
4. **Rung 4 — Continuity / recurring payment plan** — spread the entire amount into payments
   matching service delivery.
5. **Rung 5 — Simple rebook** — book the next appointment with no money down.

(Rung labels above are restored verbatim from the source bullet list: "Rung 1: Prepayment
discount (15-20% off)", "Rung 2: Third-party financing", "Rung 3: Partial down payment (50%
down, 5-10% discount on remainder)", "Rung 4: Continuity/recurring payment plan", "Rung 5:
Simple rebook".)

Mantra / verbatim specimens:
> "Everyone buys something. There's no acceptable outcome where customer leaves with zero commitment."
> "Never let customer leave without something purchased, even if just next appointment booked."

---

## Point-of-Sale Discount for Immediate Review (6 steps + latency rule)

Offer an immediate, same-transaction discount in exchange for a verified review at the moment of
payment. The decision rule: **latency kills persuasion** — the reward must be immediate, never
"next visit".

Ordered steps:
1. Present price.
2. Offer the discount for a review.
3. Get agreement.
4. Verify the review was left (show phone).
5. Recalculate the price.
6. Deliver the final check.

Sizing: discount proportional to gross profit / average ticket — e.g. $1 off per person
(~5% of average ticket at a high-volume diner); $5,000 in discounts buys ~5,000 reviews.

Source statement:
> "6-step implementation: (1) present price, (2) offer discount for review, (3) get agreement, (4) verify review was left (show phone), (5) recalculate price, (6) deliver final check"

Latency decision rule + verbatim specimens:
> "Do not say '20% off your next visit.' Instead, offer the discount immediately available at the current transaction. Latency is one of the strongest multipliers of persuasive tools."
> "Someone will take $2 off today over $100 off in a year."

---

## Secret Shopping Your Own Business (baseline audit checklist)

Run a secret shop of your own sales process BEFORE implementing changes, to establish a
baseline and find gaps in execution.

Checklist (audit whether each step is actually being executed by frontline staff):
- Are customers getting a pre-sale questionnaire?
- Is the credit card being collected upfront?
- Are current state and desired state being identified?
- Are customers being asked to commit to a package or membership?

Common failures to look for:
- Customers identify current state but not desired state.
- Customers skip directly to service without any commitment.

(Each checklist line above is restored verbatim from a source bullet: "Checklist: Are customers
getting pre-sale questionnaire?", "Checklist: Is credit card being collected upfront?",
"Checklist: Are current state and desired state being identified?", "Checklist: Are customers
being asked to commit to a package or membership?".)

Verbatim specimen:
> "Conduct secret shop before implementing new sales process."

---

## Seven Retention Tactics to Double Customer Value (ordered by implementation priority)

Derived from surveying the top 1% of 5,000+ gym locations; implementing them took churn from
11% to 6%, doubling LTV. Implement in this order:

1. **Onboarding** — re-sell the decision, set expectations, walk through usage, repeat
   constantly.
2. **Unlockables** — bonuses at milestones for activation, testimonials, referrals, and tenure.
3. **Exit interviews** — angry-boat technique + upsell opportunity; save ~50% of cancellations.
4. **Attendance tracking** — early-warning system; escalate reach-outs (reverse of lead
   follow-up).
5. **Reach outs** — every 14-21 days, personal check-in (not about the product); approximates a
   real relationship to exceed Dunbar's number.
6. **Events** — member appreciation + bring-a-friend lead gen with open loops to the next event.
7. **Handwritten cards** — PS with a photo-text referral mechanic, paired with events every 6
   weeks.

Source statement:
> "Ordered by implementation priority: onboarding, unlockables, exit interviews, attendance tracking, reach outs, events, handwritten cards."

Verbatim specimens:
> "No matter how cheap a gym membership is, a gym membership you never use is never worth it"
> "A lot easier to quit a membership than it is to quit a relationship"

---

## Activation-Driven Retention (activation point + unlockable interval schedule)

Define the **activation point** (the early action that correlates with long-term retention) and
drive all effort toward it; then layer unlockables on an extending schedule.

- Activation examples: Gym Launch — customer's first $2,000 sale in first 7 days; weight loss —
  lose 5+ pounds first week; software — switch to custom URL or get first 5 clients.
- Unlockables: bonuses for activation, testimonials, referrals, tier upgrades, AND tenure.
- **Interval schedule — extend time between unlockables: month 3, month 8, month 15.**
- Single greatest retention action: get customers to buy something else (ascension).

Source statement:
> "Extend time between unlockables: month 3, month 8, month 15"

Verbatim specimen:
> "The single greatest thing that you could do to retain customers is get them to buy something else"

---

## The Angry Boat Framework (customer-recovery protocol)

When you mess up with a customer, get in the angry boat before they do — be angrier about the
mistake than they are. This validates their feelings and causes them to de-escalate. You cannot
minimize someone's pain; only they can.

Protocol:
- Be quicker to get angry about the mistake than the customer.
- Validate, validate, validate — make them feel seen, heard, and felt.
- Confront it head-on; never skirt or minimize (minimizing makes them escalate; amplifying makes
  them de-escalate).
- Offer credit for past payments toward continued service.
- Key recovery question: "what would it take for me to make this right?"

Source statement:
> "get in the angry boat before they do - be angrier about the mistake than they are. This validates their feelings and causes them to de-escalate."

Verbatim specimens:
> "The only person who can say it's not a big deal is them, and the only way for that to happen is for you to make it a bigger deal to you than it is to them"
> "Only one person can be the angry boat"

---

## Reward Every Action in the Email Funnel (reinforcement procedure)

Design every email as a chain of rewards; behavior repeats based on what happened *after* the
last time someone took the action.

- **Opening** → reward immediately with a valuable quote / insight (one-glance payoff).
- **Reading** → deliver one clear tactical concept in the body.
- **Clicking** → ensure what's on the other side of the link delivers on the promise (high-value
  content).
- One terrible email can undo the reinforcement of four good ones.

Source statement:
> "Reward people for opening (immediate value quote), reward them for reading (tactical nugget), reward them for clicking (high-value content on the other side)."

Verbatim specimen:
> "The way Behavior works is that you did that thing because you did it another time in the past and were rewarded for it"
