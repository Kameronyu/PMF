# Frameworks, classification schemes, decision models, metric hierarchies

Restored from `conversion-optimization--alex-hormozi.md`. These are the named schemes and
decision rules an executing agent applies *before* or *alongside* the countable gates. They
are diagnostic / prioritization machinery, not numeric pass-fail gates (except where a
threshold is noted). All `> "..."` lines are verbatim source substrings.

---

## ICE Framework (Impact, Confidence, Ease) — the scoring rubric behind gate 3

The 20%-upside hurdle (SKILL gate 3) is the *minimum threshold*; ICE is the *rubric that picks
which change to make*. Score each candidate change on three axes, then take the change that is
high on all three and clears the hurdle.

- **Impact** — magnitude of the potential upside.
- **Confidence** — probability the change produces the expected result.
- **Ease** — resources required to implement it successfully.
- Ideal bet: high impact + high confidence + easy to execute.
- Minimum viable bet: potential upside must be **greater than 20%** — the typical guaranteed
  performance decrement from making any change.
- Resource scarcity forces prioritization: businesses under 20 employees should pick **one big
  strategic change per year**.

Source statement of the rubric:
> "Each potential change is scored on Impact (how big is the upside), Confidence (how likely is it to work), and Ease (what resources are required). Minimum threshold for action: potential upside must exceed 20%."

Verbatim specimens:
> "The minimum rule for me is that the potential upside has to be over 20%. If I'm going to take a 20% loss, it's got to be worth it."
> "When we have a risk-adjusted return move, we think: 'I think this could double the business. I have super high confidence and I think it could be easy. Then those are the types of bets we want to take.'"

Worked ordering (the second ICE teaching, applied to a $2.3M salon): lead follow-up system
(highest — solves the main growth constraint, high confidence) → weekend pricing (easy,
immediate margin) → before/during/after process improvements (ranks 3-5) → career path /
partnership restructuring (last, despite being foundational).

---

## Maximizer vs. Optimizer Mental Model — when to ignore ROI for absolute scale

Two orientations to resource allocation. Steers the decision of whether to chase relative
efficiency or absolute output.

- **Optimizer** — maximize relative return (ROI, ROAS, conversion-rate percentage).
- **Maximizer** — maximize absolute total output regardless of relative efficiency decline.
- Decision rule: in competitive winner-take-all markets, **maximizers outperform optimizers**
  because absolute output determines who wins.
- You cannot 10x a business by improving a landing page from 30% to 45% conversion; you CAN 10x
  inputs, which guarantees increased absolute output even if relative return drops.
- Example: $100 in → $1,000 out (10:1) vs. $200 in → $1,200 out (6:1) — the maximizer scales to
  $200 spend because net profit is still higher.

Source statement:
> "optimizers seek maximum output per input (relative returns), maximizers seek maximum total output regardless of efficiency. In competitive winner-take-all markets, maximizers outperform optimizers because absolute output determines who wins."

Verbatim specimens:
> "If I had the choice between spending $10,000 and making $100 back (10-to-1) or spending a million dollars and getting $2 million back (2-to-1), I would take a million in to get two back every day of the week and twice on Sunday."
> "Diminishing returns are still returns. You need to do more because you're trying to win, not be cute about saying you had great returns."

---

## ROIC vs LTV:CAC Hierarchy — the two-level unit-economics check

Evaluate unit economics at BOTH levels; a strong micro metric with a weak macro metric is a bad
business.

- **LTV:CAC** = lifetime value ÷ cost to acquire — the *micro* unit of economic arbitrage
  (customer-level).
- **ROIC** = total profit from a business unit ÷ total capital invested in that unit — the
  *macro* unit (business-unit-level). Includes buildout, lobby, licenses, recruiting, admin,
  tech, construction — not just marketing spend.
- Decision rule: **both must be strong** for a business to compound profitably.
- Example: massage studio — $10 CAC for a $1,000 LTV customer is a great LTV:CAC; but if the
  studio costs $100K to open and generates $250K profit = 2.5x ROIC, you must judge both.

Source statement:
> "LTV:CAC is the micro unit of economic arbitrage (customer-level), while ROIC is the macro unit (business-unit-level). Both must be strong for a business to compound profitably."

Verbatim specimens:
> "LTV to CAC: the base unit of economic arbitrage. How much does it cost me to get a customer versus how much do I make from that customer over time?"
> "The underlying principle in all mega-wealthy paths is return on invested capital and the risk taken to justify that return."

---

## Brand as Economic Multiplier — Four Revenue Levers (with benchmarks)

Brand is operationalized trust that produces measurable economic output across four levers;
each compounds the others. Use the benchmarks below as soft reference points, not hard gates.

| Lever | Benchmark |
|---|---|
| Conversion rate | Positive brand ~80% inbound call conversion · neutral ~20% · negative ~0% |
| Click-through rate | Strong brand 5-6% CTR vs ~1% no-brand baseline |
| Price point | Trust lets customers "pay down risk by paying more" — premium pricing |
| Repurchases | Most powerful multiplier — acquire once, sell indefinitely at fixed CAC |

Source statement (the key benchmark this restore re-anchors):
> "Positive brand converts 80% of inbound sales calls vs 20% for neutral brand vs 0% for negative brand"

Verbatim specimens:
> "In a competitive market, if both businesses have the same cost structure but one has brand trust and charges 10% more, that business doubles profit."
> "Brand is trust. Trust is predictive power based on past experience."

---

## Value Through Friction Removal Framework — five friction types (offer-audit scheme)

Once you have a valuable claim (people want what you promise), everything after is removing
friction. Audit an offer against the five friction types; solve them one at a time.

1. **Delay** — time between purchase and value.
2. **Effort** — new things they must do.
3. **Sacrifice** — things they must stop doing.
4. **Risk** — new costs / exposures incurred.
5. **Inconsistency** — unreliable delivery (the most underrated — a 5% failure rate makes people
   hate the product).

Source statement:
> "The five types of friction are: delay, effort (new things they must do), sacrifice (things they must stop doing), risk (new costs/exposures incurred), and inconsistency (unreliable delivery)."

Verbatim specimens:
> "It's very difficult to know what is value but it's very easy to know what's a problem. When you remove all problems what you're left with is value."
> "The iPhone is what's left after you remove everything that sucks from a phone."

---

## Wrong Customer Unit Economics Destruction Model — diagnostic behind the ICP reset

Justifies the ICP-reset ROUTE rule. Wrong customers degrade all three pillars of acquisition
economics simultaneously, compounding so scaling becomes mathematically impossible.

- **LTV destruction** — operational strain raises cost basis + competitors willing to serve bad
  customers compress price = margin elimination.
- **CAC inflation** — negative word-of-mouth spreads **5-10x faster** than positive, raising
  acquisition cost even when CPMs are flat. Diagnostic tell: if CPMs haven't doubled but
  acquisition cost did, an invisible hand (negative reputation) is working against you.
- **Payback-period extension** — lower LTV + higher CAC = longer cash conversion cycle = growth
  limited.
- Secondary damage: team morale (revolving-door churn) and reputation (wrong customers are
  looking for a savior and trash you when you don't save their business).

Source statement:
> "Wrong customers degrade all three pillars of acquisition economics simultaneously — LTV, CAC, and payback period — through a compounding mechanism that makes scaling mathematically impossible."

Verbatim specimens:
> "If CPMs haven't doubled but your acquisition cost doubled, an invisible hand is working against you."
> "Lower LTV plus higher CAC extends how long it takes to recover customer acquisition cost."

---

## Theory of Constraints for Metrics — which metric to fix first

Prioritization rule for choosing the next metric to attack.

- Add 5% to each metric (simulated) and see which yields the most throughput.
- Attack that constraint first.
- Requires integrated metric tracking (move off scattered Google Sheets to a CRM).
- "You can tell how skilled someone is by the metrics they track."

Source procedure (paraphrase): add 5% to each metric and see which yields the most throughput;
attack that constraint first.

Verbatim specimen:
> "You can tell how skilled someone is at anything by the metrics they track."

---

## Buying Questions vs Discovery Questions — FAQ-timing classification + rule

Classify customer questions, then sequence the answers.

- **Discovery questions** — open-ended, early in the process.
- **Buying questions** — signal the customer is already deciding yes/no (e.g. "What if I don't
  have coverage?", "Can I bring my family?", cancellation policy).
- **Rule:** answer buying questions **late in the funnel**, after the main pitch. FAQ sections
  resolve these remaining objections without disrupting main message flow. Each FAQ item
  represents 1-3% of customers with unresolved concerns.

Source rule (paraphrase): buying questions signal high consideration and should be answered late
in the funnel; FAQ sections resolve these remaining objections without disrupting main message
flow.

Verbatim specimen:
> "Buying questions signal high consideration. Questions like 'What are cancellation policies' means the customer is planning exit strategy, which increases purchase likelihood."

---

## The Look Back Window — billing-frequency decision rule

- Customers judge whether a purchase was good based on the last billing cycle, not cumulative
  value ("what have you done for me lately").
- **Rule:** the less frequently you bill, the longer customers stay — fewer moments where value
  dips below cost. Daily billing creates daily churn opportunities; annual billing creates one
  per year.
- 10-15% of customers take a prepaid annual option (paying 12x upfront), roughly doubling
  upfront cash flow; add guarantees to offset the risk they take.

Source statement:
> "The less frequently you bill, the longer customers stay because there are fewer moments where value dips below cost."

Verbatim specimen:
> "Customers determine whether a purchase was good based on the last purchase they made"

---

## Volume-Forced Optimization Effect — method/decision rule

- Commit to an uncomfortably high, fixed, non-negotiable volume (e.g. 100 calls/day, 100
  minutes of content/day).
- The pain of the volume becomes a forcing function: practitioners naturally find efficiencies,
  analyze data (best call times, highest pickup rates), and improve quality.
- Volume and optimization are complementary, not opposing.
- Failure mode: low-will practitioners quit after 1-2 days; volume must be sustained over
  extended periods, not a single burst.

Source statement:
> "Committing to an uncomfortably high fixed volume of activity creates a natural forcing function for optimization."

Verbatim specimens:
> "If you have a fixed work — 'I'm going to do 100 calls no matter what' — what do you think happens? You think, 'Man, it'd be really nice if I got higher pickup rates.' So then you start looking at your time and saying, 'People pick up more in the afternoons for my market.'"
> "You have to put yourself in that pain — the pain of the lack of leverage, the pain of it being inefficient. You have to keep it there."

---

## Test Ordering by Cost-to-Output Ratio — test-prioritization rule (complements gate 3)

- Order all business tests from **lowest cost / highest potential output** to **highest cost /
  lowest potential output**.
- Every test has a guaranteed cost of change but uncertain upside.
- Low-cost-first examples: email subject lines, ad headlines. High-cost examples: offer
  changes, pricing changes, team restructuring (retraining teams and fulfillment).
- Maintain an "ideas list" and let ideas settle (revisit after a month) — emotional investment
  in fresh ideas drives premature action.

Source statement:
> "Order all business tests from lowest cost / highest potential output to highest cost / lowest potential output."

Verbatim specimens:
> "I had about one new idea for our business per day and Leila's like we can do like one a quarter."
> "By having that list it gives you space... you're always emotionally invested when it's fresh."
