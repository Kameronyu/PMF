# ROUTE rules — sequencing / selection contracts

These gate the ORDER of actions by a named trigger; they do not dictate wording. A route
check returns `ordered: yes|no|n/a` with a verbatim evidence quote. All quotes are verbatim
substrings of `conversion-optimization--alex-hormozi.md`.

## More → Better → New (strict order)
- CONTRACT: exhaust More, then Better, then only then New. Jumping to New is the named failure.
- Specimen: "Most small business owners skip directly to New because it feels exciting, which is the primary reason they fail to scale."
- Specimen: "New: only after exhausting More and Better - new channels or strategies"

## Four Growth Levers (route every action or drop it)
- CONTRACT: every action ladders to Traffic / Conversion / Price / Churn; else drop it.
- Specimen: "If what you're doing doesn't ladder up to one of these four things, why are you doing it?"

## Anchor high first
- CONTRACT: present the highest price first as the anchor; never reveal a low price then add fees.
- Specimen: "Always present highest price (full program cost) first as anchor"
- Specimen: "Present full price first as anchor. Then customer feels good about discount for committing early."

## Price anchoring with expensive decoy
- CONTRACT: place a far-more-expensive option on the menu to anchor everything else as cheap.
- Specimen: "Put something 10x or 100x more expensive on your menu as an anchor"

## Onboarding handoff
- CONTRACT: act within 24–48 hours post-purchase; pilot at 15% before full rollout; personal reach-outs every 14–21 days.
- Specimen: "Onboarding happens within 24-48 hours post-purchase"
- Specimen: "Roll out changes as a pilot with 15% of customers first to prove results before scaling"
- Specimen: "Reach outs: every 14-21 days, personal check-in (not about product), approximates real relationship to exceed Dunbar's number"

## ICP reset — transition quota
- CONTRACT: run the six ordered steps; the transition quota allows ≤30% of sales below the revenue threshold, decreasing over time.
- Specimen: "Transition quota example: allow maximum 30% of sales below a certain revenue threshold during transition period"

## Empowerment-box signal (process-problem flag)
- CONTRACT: if frontline staff use the override remedy more than 5/month, flag a process problem.
- Specimen: "If staff use more than 5/month, it signals a process problem to fix"

## Other ROUTE rules carried as contracts (no numeric gate)
- Kill Zombies: handle obstacles BEFORE price, objections AFTER price.
- Upfront card: collect the card before presenting the offer.
- Give solutions time: set the evaluation timeline BEFORE implementing.
- Product-market fit before scaling: fix retention/product before scaling marketing.
- Always start for free: launch new products free first.
- Leading vs lagging: track leading input metrics over lagging outputs.
- Review tactics: peak-end timing; a third party (not the gift-giver) makes the review ask.

## Ordered procedures (full steps live in references/procedures.md)
- Sales Step-Down Commitment Ladder: 5 rungs in order, accept the first chosen.
- Point-of-Sale review discount: 6 ordered steps; reward must be immediate (latency kills persuasion).
- Secret-shop checklist: run before changing the process to baseline execution.
- Seven retention tactics: implement in priority order (onboarding first ... handwritten cards last).
- Activation unlockables: extend intervals — month 3, month 8, month 15.
- Angry-boat recovery: be angrier than the customer before they escalate.
- Email funnel: reward opening, reading, and clicking separately.
