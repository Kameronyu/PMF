# Registry-anchored terms (do NOT redefine)

This topic borrows positioning/offer vocabulary from the shared term registry
(`/tmp/kb-ref/term_registry.json`, `definitions.md`). Anchor to those definitions; the lines
below only name WHICH gate/rule each term feeds. Never restate the definition.

- **5+ saturation rule (for sophistication)** — drives COUNTABLE gate 9: a base claim is
  discounted once ≥5 competitors make it, regardless of copy quality. Membership test and
  the canonical failed instance live in the registry.
- **Value models** (bundle, pricing, discount, guarantee, subscription) — the levers the
  pricing gates (8, 11) and the anchor-high / decoy ROUTE rules operate on.
- **Trust signals / Objection handle** — the proof-system, reviews, guarantee, and FAQ
  routing rules act on these; gate 12 (review volume) sits under trust signals.
- **Market sophistication / Awareness level** — the price-anchoring and offer-staging
  ROUTE selectors lean on these buyer-readiness / competitive-stage axes.
- **Micro test / Macro test** — pilot testing, price testing, and the 20%-upside change
  hurdle (gate 3) are micro tests within a working product × market.
- **Claim / Enhanced claim / Transformation** — the feature-value (gate 4) and
  claim-saturation (gate 9) reasoning operate on these.

No new term definitions are proposed by this skill.
