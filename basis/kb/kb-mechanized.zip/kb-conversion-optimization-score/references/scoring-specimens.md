# Scoring specimens — verbatim source lines the gates are grounded in

This topic has NO felt pairwise judgment — there is no would-a-viewer-feel-X comparison
against a specimen. These specimens exist only to GROUND each countable threshold in its
exact source words, so a
checker can confirm the gate was not invented. Every line is a verbatim substring of
`conversion-optimization--alex-hormozi.md`.

## Threshold specimens (one per countable gate)
- "80% gross margin is the minimum baseline for service businesses."
- "Target: 70-75% calendar utilization; never above 85%, never below 60%"
- "Need at least 20% upside potential to justify guaranteed 20% downside"
- "Each feature should be valuable enough on its own to justify 3-4x its price."
- "Show Rate benchmark: 70% for any appointment-type business"
- "Lifetime months = 1 / monthly churn rate"
- "Call leads within 60 seconds of opt-in"
- "Optimize for: conversion rate × price = total revenue, not maximum price"
- "Permanent CAC = 10x normal acquisition cost if 1 in 10 becomes permanent"
- "Annual renewal fee equals 1-3 months of monthly price, charged after first year"
- "1,000 reviews at 4.6 stars captures 90% of search volume vs. 20 reviews at 5.0 stars"

## ROUTE specimens (sequencing contracts)
- "New: only after exhausting More and Better - new channels or strategies"
- "If what you're doing doesn't ladder up to one of these four things, why are you doing it?"
- "Always present highest price (full program cost) first as anchor"
- "Onboarding happens within 24-48 hours post-purchase"

## How these are used
The grader cites the relevant line as the `evidence_quote` for each gate's verdict. A verdict
with no verbatim citation is not `emit_ready` (SOUNDNESS fails). These are grounding anchors,
NOT a pairwise judge bank — there is no `prefer|tie|weaker` step in this topic.
