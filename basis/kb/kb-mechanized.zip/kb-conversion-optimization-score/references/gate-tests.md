# Per-gate membership tests + COUNTABLE arithmetic

Each gate: the positive target, the script test (returns FALSE on a wrong value), and the
verbatim source specimen the threshold comes from. All quotes below are verbatim substrings
of `conversion-optimization--alex-hormozi.md`.

## 1. Gross-margin floor (hard-gate)
- TEST: `gross_margin >= 0.80 AND net_margin <= gross_margin`. FAIL otherwise.
- Specimen: "80% gross margin is the minimum baseline for service businesses. Net margin cannot exceed gross margin; insufficient gross margins structurally prevent profitability regardless of operational efficiency."
- Specimen: "I won't get into a business with less than 80% gross margins. That's my baseline."

## 2. Calendar-utilization band (hard-gate)
- TEST: `0.60 <= utilization <= 0.85` (sweet spot 0.70–0.75). FAIL outside.
- Specimen: "Target: 70-75% calendar utilization; never above 85%, never below 60%"

## 3. 20%-upside change hurdle (hard-gate)
- TEST: `projected_upside > 0.20`. A change carries a guaranteed ~20% decrement, so the upside must clear it. FAIL below.
- Specimen: "Need at least 20% upside potential to justify guaranteed 20% downside"

## 4. Feature-value multiple (hard-gate)
- TEST: for every retained feature, `standalone_value / feature_cost >= 3`. FAIL if any feature is below the 3–4× multiple.
- Specimen: "Feature test: would customers pay 3-4x the feature's cost if sold standalone at premium pricing?"
- Specimen: "Each feature should be valuable enough on its own to justify 3-4x its price."

## 5. Show-rate benchmark + five-metric set (hard-gate)
- TEST: `show_rate >= 0.70` for appointment businesses; require all five metrics present (show, offer, close, cash, units). FAIL below benchmark or if the five-metric set is not surfaced.
- Specimen: "Show Rate benchmark: 70% for any appointment-type business"

## 6. Churn → lifetime identity (hard-gate)
- TEST: `lifetime_months == 1 / monthly_churn` (within rounding tolerance). FAIL on arithmetic mismatch.
- Specimen: "Lifetime months = 1 / monthly churn rate"
- Specimen: "10% monthly churn = 10 months average lifetime"
- Specimen: "1% monthly churn = 100 months average lifetime"

## 7. Speed-to-lead window (hard-gate)
- TEST: `contact_seconds <= 60` from opt-in / booking attempt. FAIL outside the window.
- Specimen: "Call leads within 60 seconds of opt-in"
- Specimen: "391% average increase in sales from calling leads within 60 seconds (Harvard Business Review)"

## 8. Conversion×price maximization (hard-gate)
- TEST: the chosen price is the argmax of `conversion_rate × price`; raising it further must lower total revenue. FAIL if the rule applied is "set the maximum price".
- Specimen: "Formula: increase price until (conversion rate × price) equals less total revenue"
- Specimen: "Optimize for: conversion rate × price = total revenue, not maximum price"

## 9. 5+ claim-saturation (hard-gate; anchor term)
- TEST: `competitor_count >= 5` making the same base claim → the claim is discounted; FAIL if the plan relies on the un-discounted claim. See `references/registry-terms.md`.

## 10. Permanent-CAC formula (hard-gate)
- TEST: `permanent_CAC == normal_CAC × (1 / permanent_conversion_rate)`. FAIL on mismatch.
- Specimen: "Permanent CAC = 10x normal acquisition cost if 1 in 10 becomes permanent"

## 11. Annual-renewal-fee bound (hard-gate)
- TEST: `1 <= renewal_fee / monthly_price <= 3`, charged after year 1. FAIL outside the band.
- Specimen: "Annual renewal fee equals 1-3 months of monthly price, charged after first year"

## 12. Review-volume priority (hard-gate)
- TEST: review volume is prioritized over a small high-rating count. FAIL if the plan optimizes rating at the cost of volume.
- Specimen: "1,000 reviews at 4.6 stars captures 90% of search volume vs. 20 reviews at 5.0 stars"

## HEURISTIC — Paired-KPI / vanity-metric (soft-cap → WARN, never FAIL)
- TEST: every decision-driving metric pairs a quantity with a quality weight. WARN when a lone vanity metric drives a decision without a paired quality metric.
- Supporting margin-compounding arithmetic specimen: "This compounds to 12%+ profit improvement in 12 months, making the business scalable and investable."
- SEO ratio scaling specimen: "If SEO produces $13 for every $1 invested, every dollar withheld from SEO is money left on the table"

## Worked PASS object (gate 1)
```
gates:
  - n: 1
    name: gross-margin-floor
    target: "service offer >= 80% GM, net <= gross"
    verdict: pass
    tier: countable
    value: {gross: 0.84, net: 0.31}
    evidence_quote: "80% gross margin is the minimum baseline for service businesses."
    source: traces_to:offer_input
```

## Worked FAIL object (proof the gate returns FALSE)
```
gates:
  - n: 8
    name: conversion-price-maximization
    target: "price at argmax(conversion x price), not max price"
    verdict: fail
    tier: countable
    value: "plan sets the highest price the market will bear"
    evidence_quote: "Optimize for: conversion rate x price = total revenue, not maximum price"
    source: traces_to:pricing_plan
=> BLOCKED: conversion-price-maximization      # band = BLOCK
```
