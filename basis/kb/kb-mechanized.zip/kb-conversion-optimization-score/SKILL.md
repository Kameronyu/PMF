---
name: kb-conversion-optimization-score
description: >-
  Score a conversion / offer / unit-economics decision against Hormozi's gates before
  you ship it — gross-margin floor, calendar-utilization band, show-rate benchmark,
  feature-value multiple, churn-to-lifetime identity, the 20%-upside change hurdle, the
  conversion×price maximization rule, speed-to-lead window, and the 5+ claim-saturation
  rule. Returns PASS / WARN / FAIL per gate with an evidence quote, plus the ROUTE
  sequencing contracts (More→Better→New, Four Levers, anchor-high, onboarding handoff).
  Hard-gates only the countable; soft-caps the heuristic; runs as a SEPARATE pass from
  any planning step. Triggers: "is this offer viable", "check my margins / churn / pricing",
  "should I make this change", "score this funnel decision", "what's my customer lifetime".
---

# Conversion optimization — score the decision before you ship it

Grade a proposed offer / operational / pricing decision against the COUNTABLE gates, then
band it. Do NOT run this in the same pass that produced the plan — a planner grading its own
numbers waves them through. Anchor terms (claim, value models, trust signals, market
sophistication, micro/macro test, the 5+ saturation rule) to `references/registry-terms.md`;
never redefine them.

Tier discipline: **hard-gate only the countable** (a margin is or isn't ≥80%); **soft-cap the
heuristic** (a vanity metric is a WARN, never a FAIL); a FELT comparison is judged
**pairwise against a source specimen** (`references/scoring-specimens.md`) → `prefer|tie|weaker`,
never a self-graded FALSE.

## The COUNTABLE gates (each: positive target → script test → tier)

Full per-gate membership tests + arithmetic live in `references/gate-tests.md`. Summary:

1. **Gross-margin floor** — *target:* service offer at ≥80% gross margin, net ≤ gross. *Test:* `gm >= 0.80 AND net <= gm`. FAIL below. **hard-gate.**
2. **Calendar-utilization band** — *target:* 60–85% booked (sweet spot 70–75%). *Test:* `0.60 <= util <= 0.85`. FAIL outside. **hard-gate.**
3. **20%-upside change hurdle** — *target:* projected upside >20% before approving a change (it carries a guaranteed ~20% decrement). *Test:* `upside > 0.20`. FAIL below. **hard-gate.** The hurdle is the floor; the ICE rubric (Impact·Confidence·Ease) picks WHICH change — see `references/frameworks.md`.
4. **Feature-value multiple** — *target:* each retained feature would justify ≥3–4× its cost sold standalone. *Test:* every feature `>= 3x`. FAIL any feature below. **hard-gate.**
5. **Show-rate benchmark** — *target:* show rate ≥70% for appointment businesses; surface all five metrics (show/offer/close/cash/units). *Test:* `show >= 0.70`. FAIL below. **hard-gate.**
6. **Churn→lifetime identity** — *target:* `lifetime_months == 1 / monthly_churn`. *Test:* arithmetic equality (±tolerance). FAIL on mismatch. **hard-gate.**
7. **Speed-to-lead window** — *target:* lead contacted within 60 seconds / 1 minute of opt-in. *Test:* `contact_seconds <= 60`. FAIL outside. **hard-gate.**
8. **Conversion×price maximization** — *target:* price set where `conversion × price` is maximized, not the max price. *Test:* chosen point is the argmax, raising further lowers total revenue. FAIL if "max price". **hard-gate.**
9. **5+ claim-saturation** — *target:* base claim discounted when ≥5 competitors make it. *Test:* `competitor_count >= 5 → discount`. FAIL if relied on un-discounted. **hard-gate.** (anchor term)
10. **Permanent-CAC formula** — *target:* `permanent_CAC == normal_CAC × (1 / permanent_conversion_rate)`. *Test:* arithmetic equality. FAIL on mismatch. **hard-gate.**
11. **Annual-renewal-fee bound** — *target:* renewal fee = 1–3× monthly price, charged after year 1. *Test:* `1 <= fee/monthly <= 3`. FAIL outside. **hard-gate.**
12. **Review-volume priority** — *target:* prioritize review volume; the high-volume/4.6★ business takes ~90% of search volume. *Test:* volume prioritized over a tiny 5.0★ count. FAIL if optimizing rating at the cost of volume. **hard-gate.**

## The HEURISTIC gate (soft-cap — WARN, never FAIL)

- **Paired-KPI / vanity-metric** — *target:* every tracked metric pairs quantity with a quality weight (e.g. RPM pairs views with revenue-per-thousand). *Judge:* WARN when a lone vanity metric (raw views) drives a decision without a paired quality metric. Soft signal, not a hard FALSE.

(No FELT-tier gate: this topic carries no "would a viewer feel X vs. a specimen" judgment. The pairwise machinery exists only to keep heuristics off the hard-fail path.)

## Bands (derive from gates that actually passed — not a hollow count)

- **Any COUNTABLE gate FAILS → BLOCK** (fix the failing gate before shipping; name it).
- **All COUNTABLE pass, ≥1 HEURISTIC WARN → SHIP-WITH-WARN** (proceed, log the warn).
- **All COUNTABLE pass, no WARN → SHIP.**

Count only gates that were actually evaluated against their input; a gate with no input data is `n/a`, not a silent pass.

## ROUTE rules — sequencing / selection contracts (named-trigger, no wording dictated)

These gate ORDER, not wording. Full set in `references/route-rules.md`; ordered execution
procedures + audit checklists (Step-Down Ladder, POS-review 6-step, Secret-Shop checklist, the
7 retention tactics, activation schedule, Angry-Boat, email-reward chain) in
`references/procedures.md`; named decision models / metric hierarchies (ICE rubric,
Maximizer-vs-Optimizer, ROIC-vs-LTV:CAC, Brand four-lever multiplier, five friction types,
wrong-customer destruction model, theory-of-constraints, buying-vs-discovery, look-back window,
volume-forced optimization, test-ordering) in `references/frameworks.md`. The load-bearing ones:

- **More → Better → New** — execute in strict order; exhaust More, then Better, then New. Skipping to New is the named failure mode.
- **Four Growth Levers** — every action must ladder to Traffic / Conversion / Price / Churn, else drop it.
- **Anchor high first** — present the highest price first as the anchor; never reveal a low price then add fees.
- **Kill Zombies** — handle obstacles BEFORE price, objections AFTER price.
- **Upfront card** — collect the card before presenting the offer.
- **Onboarding handoff** — within 24–48 hours post-purchase; pilot at 15% before full rollout; reach-outs every 14–21 days.
- **ICP reset** — six ordered steps; transition quota allows ≤30% of sales below threshold, decreasing over time.
- **Give solutions time** — set the evaluation timeline BEFORE implementing.
- **Step-Down Commitment Ladder** — offer 5 rungs in order, accept the first chosen; everyone buys something (procedure in references).
- **Bill less frequently to retain** (look-back window); **answer buying questions late** (FAQ timing) — decision rules in `references/frameworks.md`.

## The negatives live here (≤5), each paired with a positive target

- **"Maximize price"** → FAIL gate 8; positive: pick the `conversion×price` argmax.
- **Net margin quoted above gross** → FAIL gate 1; positive: net ≤ gross, gross ≥80%.
- **Skipping to New before More/Better** → ROUTE violation; positive: exhaust More then Better first.
- **Reveal low price then add fees** → ROUTE violation; positive: anchor highest price first.
- **Decide a change on a lone vanity metric** → HEURISTIC WARN; positive: pair it with a quality metric.

## Output contract (per decision)

```
decision: "<what is being scored>"
gates: [ {n, name, target, verdict: pass|fail|warn|n/a, tier, value, evidence_quote, source} ]
countable_results: { ... }   # script results, pass/fail/n-a per hard-gate
heuristic_warns:   [ ... ]   # soft-caps tripped
route_checks:      [ {rule, ordered: yes|no|n/a, evidence_quote} ]
band: SHIP | SHIP-WITH-WARN | BLOCK
blocked_on: [ <gate names that FAILED> ]   # empty unless band == BLOCK
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every applicable gate has a verdict; band present; route_checks present for invoked rules.
**SOUNDNESS:** every COUNTABLE verdict came from the arithmetic/threshold test (not eyeballed);
the heuristic is a WARN not a FAIL; band derived only from gates that were actually evaluated;
each non-`n/a` verdict carries a verbatim `evidence_quote` from input or source. `emit_ready`
only if SOUNDNESS holds; else `BLOCKED:<gate>`.

## Self-test (is this grader sound?) — any NO, fix

- Are only the countable gates hard-gated (by threshold/arithmetic), with the paired-KPI gate a soft WARN?
- Is scoring run separately from any planning step that produced the numbers?
- Does the band come from gates that actually passed their tier's check, not a raw count?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Are sequencing rules (More→Better→New, anchor-high, onboarding) kept as ROUTE contracts, not gates?
- Is every quoted specimen a verbatim substring of a source file (no composites)?
