# Frameworks, decision rules & data restored from source

Content that an executing agent needs but that is NOT a countable gate: decision
frameworks (which option to pick under named conditions), data points/benchmarks, and the
per-type construction guidance behind closed enums. All quotes are verbatim substrings of
the source KB files; non-quoted lines paraphrase faithfully. No line budget here — this is
the comprehensive layer the lean SKILL.md points to.

---

## Exit structure selection (asset vs share deal) — decision framework + thresholds
Source: Carl Weische. Use when an operator is choosing how to exit. This SELECTS an option
by named conditions, so the SKILL.md ROUTE section carries the one-liner; the rule set is
here.

Framework for choosing between asset deals and share deals when exiting:
- **Asset deals:** Sell specific assets (Shopify store, inventory, media buying accounts)
- **Share deals:** Sell ownership shares in the company itself
- MBOs and LBOs only relevant for $50M+ e-commerce businesses
- Avoid asset deals with Dubai free zone companies due to structural complications
- Preferred legal entities for smooth transactions: German, Austrian, Swiss, or UK entities
- Spin-offs/carve-outs applicable when selling part of a multi-brand portfolio

Decision rules that fall out of this:
- Threshold: MBO/LBO structures are out of scope below **$50M+** revenue.
- Avoid: building on **Dubai free zone** entities if planning an asset-deal exit (see also
  the SKILL pitfall).
- Prefer: German / Austrian / Swiss / UK entities for smooth transactions.

### E-commerce asset class evolution (context for buyer standards)
Source: Carl Weische. E-commerce matured as an investment asset class between 2021–2023:
- 2021–2022: Investors accepted MVP and partial proof of concept due to COVID funding frenzy
- Post-August 2022: COVID funding cycle ended; investor standards tightened significantly
- Current requirement: clear pathway to profitability, not just growth metrics
- Luxury brands had their best Q1 during the 2022 market downturn (recession-resistance of quality brands)
- Founders must meet institutional-grade standards even for relatively small exits

---

## Bootstrap exit optimization — decision rule + worked example
Source: Carl Weische — Bears with Benefits case study.

Rule: a clean cap table plus strong unit economics can command significant acquisition
premiums even in years of negative profitability.
- Simple ownership structure (two founders, no external investors) eliminates complex
  liquidation preference negotiations
- Strong unit economics can override negative profitability in buyer valuation
- Tax-optimized business location (Grunwald, Bavaria) is part of exit preparation

Worked example (verbatim): "Bears with Benefits — 42–43€ margins on 50€ AOV justified
mid-double-digit million euro acquisition by French cosmetics group Javier; 100%
acquisition with new CEO installed"

---

## Data Intelligence Pillar — tracking stack + three data streams + channel CR segmentation
Source: Carl Weische (Accelerated Growth Model). Use as a paid-diagnostic input alongside
G12. The named tracking stack and the three-data-streams framework live here.

"Generate actionable intelligence from three data streams: market data, website data, and
customer data." Proprietary benchmarking from $4B in customer data across 200+ brands
enables channel-level CR segmentation.
- Required tracking stack: Google Tag Manager, Google Analytics, Hotjar
- Stera case study: TikTok converting at 0.04% CR vs. other channels at 1.2–2%;
  reallocated $140K monthly ad spend after identifying discrepancy
- "Declining overall CR often masks a specific underperforming traffic source, not a
  site-wide issue"

Decision rule: before treating a CR drop as a site-wide problem, segment CR by traffic
source — the decline often hides one underperforming channel.

### Cross-platform attribution via post-purchase surveys (companion)
Source: Carl Weische. Combine on-platform metrics with post-purchase surveys to understand
the true customer journey; on-platform data alone gives an incomplete attribution picture.
- Used by Paul Valentine ($35M+ brand) to reveal multi-touchpoint customer journey
- Particularly critical when scaling across multiple paid channels simultaneously

---

## Data feed restructuring for acquisition cost reduction — technique + 50% benchmark
Source: Carl Weische. Paid-acquisition technique at scale.

"Custom restructuring of product data feeds can cut acquisition costs in half at scale when
standard tools are insufficient."
- Applied at $35M+ brand scale
- Acquisition cost reduction: 50% via custom data feed restructuring
- Competitive edge at scale requires technical differentiation beyond accessible
  off-the-shelf platforms

---

## Six Winning Image Types — per-type construction guidance
Source: Carl Weische. G6 hard-gates only the closed ENUM of the six names; HOW to build and
use each is the teachable content and lives here. Six distinct product image formats derived
from optimizing 200+ products for 8- and 9-figure Amazon brands:

1. **Big Caption:** Lead with ICP photo + large headline stating value proposition clearly
2. **Social Proof:** End sequence with publications, sold unit counts, endorsements, or
   company history — must be verifiably honest
3. **Three-Piece Collage:** Combine multiple angles or use cases in one image to conserve
   carousel slots while demonstrating build quality
4. **Bullet Points:** Product photo + three key USPs; especially effective for supplements
   highlighting ingredients and benefits
5. **Before and After:** Only use when product delivers clear transformational results;
   keep expectations realistic to avoid scam perception and reduce returns
6. **Size and Materials:** Show real-world dimensions using measurement units familiar to
   target audience to reduce returns and purchase regret

(Construction inputs for any image are in `procedures.md` → Product Image Foundation.)

---

## B-roll Andromeda Detection Avoidance — decision rule + named refresh tools
Source: Spencer (Origins). G-table keeps the clip-length bound; the detection rationale and
the named refresh tools live here.

- Meta's Andromeda system detects and penalizes recycled B-roll footage (reach suppression)
- Tools to refresh: Nano Banana (AI video generation) + Kling 2.6
- Clip specs: 3–5 seconds optimal; 30 seconds maximum
- Rotate proactively BEFORE reach suppression triggers — do not wait for performance drop
  to diagnose

Note: this is distinct from the ad-creative skill's "Andromeda" (an 80/20 concept-vs-variation
split). This is Spencer's Meta-reach-suppression rule.

---

## Valley of Despair / Cycle of Change — 5-stage mindset model + decision rules
Source: Spencer (Origins). A framework with an embedded decision rule (quitting at Stage 3
resets accumulated skill). The lone maxim "Skill is permanent; revenue is not" lives as a
writer specimen in kb-ecommerce-write; the full model lives here.

**Valley of Despair / Cycle of Change Model**
- 5-stage psychological progression every operator goes through:
  1. Uninformed Optimism ("this will be easy")
  2. Informed Pessimism ("this is harder than I thought")
  3. Valley of Despair ("this doesn't work / I'm not cut out for this")
  4. Informed Optimism ("I know what to do now")
  5. Success
- Fatal pattern: quitting at Stage 3 resets all accumulated skill — you return to Stage 1
  for the next attempt
- Lucky-skip pattern: some operators accidentally hit a winner early and skip to Stage 5
  without building skills → crash when the lucky product dies
- Timeline: most operators need 30–60 days minimum to reach Stage 4; some take longer —
  the timeline is indefinite but earned

**Conviction vs. Motivation Distinction**
- Motivation: transient, external, unreliable — driven by results
- Conviction: persistent, internal, built through personal feedback loops — survives losing streaks
- Mindset issues persist at $10M/month — skill level does not eliminate psychological challenges
- Build conviction: small wins → documented → reviewed during low periods
- Do not rely on motivation to sustain work during the Valley of Despair — conviction is
  the only reliable fuel

**10,000-Hour Mastery Trajectory**
- Income milestones mapped to hour thresholds with daily schedule variants
- "Skill is permanent; revenue is not" — ROAS drops, ad accounts get banned, products die; skill compounds
- Implication: early losses are skill-building investments, not failures
