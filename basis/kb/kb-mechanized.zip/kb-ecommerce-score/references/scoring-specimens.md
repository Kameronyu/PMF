# Scoring specimens — the known-good lines to judge the FELT gate against

The one felt gate (F1 pain-market fit) is scored **pairwise against these**, not on an
absolute scale and never by the model that selected or built the candidate. Treat any
single judgment as noisy (a triage signal, not a certification). Every line below is a
verbatim substring of a source KB file.

## Pain-market fit reference (judge F1 against these)

The winning pattern names a *specific* felt pain in a passionate market, and frames the
buyer as moving away from pain:

- "back pain, arthritis, joint pain, emotional pain"
- "People moving away from pain are easier to sell to than those moving toward pleasure."
- "Evergreen problems (weight loss, pain relief) never disappear."

Ask: does the candidate solve a specific felt pain as concretely as these, or is it a
category / interest niche? → prefer | tie | weaker. A category like "wellness" or an
interest niche scores `weaker`.

## Thesis / steering reference (anchor the band rationale, not a gate)

These are the felt theses behind the gates; cite them when explaining a CONDITIONAL/NO-GO,
never as a pass on their own:

- "You cannot create mass desire, you channel it."
- "The goal is to compete differently through superior angle, funnel, or execution—not to find products with zero competition, which is counterintuitively harder."
- "When you spend money on ads and aren't immediately profitable, you're not losing money—you're buying data."
- "You can't profit hack your way to a great retention rate"

## Backend value-framing reference (steers F1 toward value, not extraction)

- "How can I provide more value to help customers get better results?"

## Scarcity / pre-order framing reference (context for ROUTE pre-order rule)

- "Sold out four times this year — pre-order now to reserve yours"

## How to run the pairwise judge
1. Present candidate + one specimen, order randomized.
2. Ask which better satisfies the named criterion and why (criteria before verdict).
3. Record `prefer|tie|weaker` + the reason. `weaker` contributes no pass for that gate.
4. Never let the model that generated/selected the candidate be the judge.
