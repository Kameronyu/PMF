# Execution procedures, tool stacks & ops SOPs restored from source

Sequential procedures, tool stacks, and ops playbooks the source teaches. All quotes are
verbatim substrings of the source files. No line budget here.

---

## Five Laws of Product Testing (named framework)
Source: Mark Builds Brands. A named five-law framework. Only Law 4 ("minimize variables")
previously survived as a pitfall; here are all five, in order.

1. **Know your numbers:** Calculate target CPA and break-even ROAS before spending.
2. **Read data and adjust:** A low add-to-cart rate (target: 10%) signals poor ad messaging
   or a weak landing page.
3. **One relaunch rule:** Each product gets exactly one data-informed relaunch; if still
   unprofitable, move on.
4. **Minimize variables:** Never simultaneously test new branding, pricing, market, creative,
   and funnel.
5. **Ultimate detachment:** Emotional attachment to ad outcomes causes poor decisions and
   endless relaunching.

Use: run as a checklist before/after any product test. Laws 1–2 are the countable feeders
(they map to G1/G4/G12); Laws 3–5 are the discipline rules that stop variable-contaminated
relaunches.

---

## Ad Angle Differentiation Research Procedure
Source: Mark Builds Brands. The concept (relaunch a commodity with a new angle) was in the
registry, but the execution procedure was absent. Here it is.

A commodity product relaunched with a new angle competes without direct head-to-head
competition. Example: a shower head repositioned from "filtered water" to "clear skin /
reduced acne" angle. The angle — not the product — is the source of competitive advantage.

**Research process:**
1. Open Get Hooked with filters: winning ads, video format, 7-day runtime, 3–5 min length.
2. Search market keywords (e.g., "skin").
3. Identify the top-performing competitor angles.
4. Use ChatGPT to generate 5 "punch in the gut" story variations.
5. Select the strongest.

**Case study:** "66 failed campaigns" using the lazy-dropshipper mindset → pivoted to
saturated products with untapped angles → $189K/month.

---

## Problem Research Over Product Research Procedure
Source: Mark Builds Brands. Start with the pain point, not the product — identify the root
problem behind a successful competitor product, then find a *different* product addressing
the same problem.

Identify the root problem behind a successful competitor product, then find a different
product addressing the same problem via AliExpress or CJ Dropshipping. Example: a posture
corrector succeeding = back pain is the problem → find an alternative back-pain solution.
This enters proven demand while avoiding direct competition.

**Execution:**
- "Join Facebook support groups" for target problems to harvest authentic emotional language
  for copywriting.
- Use "burner social media accounts" ("fresh accounts, no prior behavior") to train
  algorithms to serve competitor ads organically — described as superior to paid product
  research tools.

---

## YouTube Burner Account Method — procedural detail
Source: Mark Builds Brands. The full free research procedure (the multi-tab mute trick and
the instream-ads-as-graduated-brands signal were dropped).

Create a fresh Google account. Search niche-relevant keywords to train the algorithm. Open
multiple tabs with niche videos playing — and "mute at browser level, NOT YouTube level"
(avoids detection). Once the feed is niche-saturated, "instream ads represent brands that
have graduated from Facebook," indicating proven conversions. Click through → SimilarWeb →
validate traffic.

**Formula:** Monthly visitors × 2.5% CVR × AOV = estimated monthly revenue. Example: a lung
cleansing spray at $34, 300K+ monthly visits → ~$600K/month.

---

## Avatar Narrowing Protocol
Source: Spencer (Origins). Test the top 2–3 avatars at once; on traction, deepen the winner
before broadening. Community terminology from the winner can become a standalone hook.

- "Test top 2–3 avatars simultaneously"
- On traction: immediately expand messaging variations within the winner BEFORE testing new
  avatars (depth within the winning avatar > breadth across avatars at early stage).
- "Community-specific terminology extracted from winning avatar's research can become
  standalone hook"

---

## Trustpilot as Self-Description Mining Source
Source: Spencer (Origins). A distinct VoC mining source for sub-avatar self-identification
language — a different linguistic register from Reddit/Amazon/YouTube.

- Distinct from Reddit/Amazon/YouTube — a different linguistic register.
- Trustpilot reviews are formal, post-purchase, outcome-focused.
- Use specifically for self-identification language ("as a [identity]," "I've always been
  someone who...").
- Mine for the sub-avatar labels the audience applies to themselves (not labels you assign).

---

## 5-Tab Master Document Architecture — creative-context SOP
Source: Spencer (Origins). The persistent context document fed into Claude before any
creative session. The "quote density = primary copy lever" rule is the load-bearing part.

**5-Tab Master Document Architecture**
- Tabs maintained as persistent context fed into Claude before any creative session:
  1. Product — features, COGS, mechanism, differentiation
  2. Research — verbatim customer quotes (density = primary copy quality lever)
  3. Avatars — sub-avatars with visual prompt for static creative
  4. New Information — educational angle material (feeds hook development)
  5. New Mechanism — mechanism candidates (feeds angle matrix)
- Rule: verbatim quote density in the Research/Avatars tab is the primary lever for copy quality
- Update document after every research session or sub-avatar discovery

---

## 7-Step Product Overview Document — sequential pre-copy procedure
Source: Spencer (Origins). Run this ordered procedure to articulate the product BEFORE any
copy is written. The Hemingway Grade-6 check (already a countable gate in G8) is the
validation step at the end.

**7-Step Product Overview Document**
- Sequential pre-copy document to articulate the product before any copy is written:
  1. Features list
  2. Benefits per feature
  3. Desires each benefit addresses
  4. Emotions attached to each desire
  5. Hidden mechanism (what makes it work differently)
  6. Avatar (who feels these desires most acutely)
  7. Competitive gap (what others aren't saying)
- Claude used iteratively throughout — but "outputs are ideation only" — use as starting
  point, validate against research
- Hemingway App: validate Grade 6 reading level on any copy generated from this document

---

## Product Image Foundation — assets + sales-copy inputs before any image
Source: Carl Weische. Two prerequisite inputs before building any product image: quality
visual assets and strategically researched sales copy. Image assets do not require
expensive equipment — decent camera, good lighting, and natural settings suffice.

Five copy research questions to answer before image creation:
1. What keywords resonate with your ideal customer?
2. What problem are you solving and what emotion is connected to that problem?
3. What does the customer need to know to feel safe buying?
4. Where and who uses your product?
5. Who actually makes the purchasing decision? (Account for gatekeepers, e.g., parents for children's products)

(Image FORMAT selection is the six-type framework in `frameworks.md`.)

---

## Shopify-Native Facebook Pixel Setup SOP (6-step)
Source: Spencer (Origins). Referenced by the SKILL Pixel SOP route line.

1. Go to Shopify Admin → Apps → Facebook & Instagram channel app
2. Connect Facebook Business Manager
3. Select existing pixel OR create new
4. Activate Conversions API (CAPI) — required for post-iOS attribution
5. Set data sharing to "Maximum" — share all available events
6. Verify pixel is firing on Shopify checkout (test with Meta Pixel Helper extension)

---

## AI Tool Stack for Branded Dropshipping 2025 — tiered stack + workflows + pre-launch infra
Source: Mark Builds Brands. Time-bound tooling guidance the source teaches. The store-building
workflow and SMS-Bump/Stripe pre-launch infra were dropped entirely from the emitted skills.

**S-Tier:** N8N (workflow automation), Gemini 2.5 Pro Experimental (deep research: 226
sources, 36 pages vs. Perplexity's 50–60 sources, 6–7 pages), Get Hooked (competitor ad
analysis), Manis (autonomous agent tasks)

**A-Tier:** Claude 3.7 Sonnet (copywriting/ad scripts), Cling AI (image-to-video UGC),
ChatGPT 03/04/4.1 (general daily driver), GenSpark Super Agent, Make UGC ($7–10/video for
AI UGC)

**B-Tier:** Gum Loop (N8N alternative with custom API), Pika (adding visual elements to
existing videos)

**C-Tier:** Perplexity (surpassed by Gemini), Grok (disappointing despite benchmark rankings)

**AI Store Building Stack:** Shrine theme (Shopify), ChatGPT-4 image generation for static
assets, Cling AI to animate statics into GIFs, Claude Sonnet 4 for copy. Create creative
briefs before generating images. Workflow: upload foundational docs → provide swipe
inspiration → generate brief → create assets.

**Pre-launch infrastructure:** Klaviyo (abandoned cart email), SMS Bump (abandoned cart
SMS), Stripe or Shopify Payments + PayPal. Build payment processor relationships gradually.

---

## Reverse Logistics Partner in Destination Market — returns SOP + CVR rationale
Source: Spencer (Origins). Companion to Stage 4 of the 4-stage dropshipping escalation.

**Reverse Logistics Partner in Destination Market**
- Local returns partner: inspects returned goods, re-packs, relists for resale
- Conversion benefit: domestic returns address presence signals domestic credibility → improves CVR
- Route returns to local partner rather than back to China — faster resolution, lower cost long-term

### 4-Stage Dropshipping Escalation Protocol (full detail — SKILL carries the triggers)
Source: Spencer (Origins).
- Stage 1 — Pure Dropshipping (validation): supplier ships direct; no inventory commitment;
  use for first 10 sales signal; never commit MOQ without 10+ real purchase signals
- Stage 2 — 50-Unit Pre-Stock (trigger: 10 sales): order 50 units; control shipping quality
  and speed; reduces delivery time; builds supplier relationship
- Stage 3 — Outright Bulk (trigger: 10 units remaining): reorder when stock reaches 10 units;
  60–90 day forward-demand horizon; sea freight 45–48 days from China; Q4 surcharge:
  fulfillment cost rises from $7 → $11–12/unit during Q4
- Stage 4 — Manufacturer + 3PL ($350K+/month): direct manufacturer relationship (no
  middleman); third-party logistics partner in destination market; enables pre-orders,
  domestic returns, faster shipping signals

---

## Hiring Guide for Video Editors & Creative Strategists — sequence + volume + comp models
Source: Spencer (Origins). Ops/delegation procedure with concrete interview-volume and
compensation thresholds.

**Hiring Guide for Video Editors and Creative Strategists**
- Hire sequence: content creator first, video editor second
- Volume benchmarks:
  - 20+ interviews minimum before first hire
  - 30-minute paid brief assessment (test the actual skill, not the interview)
  - Dual requirement: skill AND drive — skill without drive = inconsistent output
- Weekly review cadence with hired editors
- Editor compensation models:
  - $10–25/hour + 5% of ad spend (scales with performance), OR
  - $100 per winning ad (pure output incentive)
- Scale benchmark: $1M+/month achievable with founder + VA + editors only (no large team required)
- Volume benchmark for creative strategist role: 1,500+ applications, 200+ interviews before finding quality hire
- Role reframe: "Job is to create winning ads, not edit videos" — output orientation, not effort orientation

### Video Editor Delegation Brief System (companion)
Source: Spencer (Origins).
- Google Doc brief structure: Lock (brand constraints — font, stroke style, color palette,
  logo usage); Free (creative freedom — transitions, music, pacing, B-roll selection);
  B-roll annotation (note which clips go where in the brief)
- Rate: $40/deliverable for 3 angle variations
- Sourcing: X (Twitter DMs) / Upwork
- Relationship compounds: long-term editor improves faster than constant freelancer cycling

### Edit-It-Yourself Skill-First Scaling Model (companion)
Source: Spencer (Origins).
- For sub-$100K/month: self-editing outperforms cheap editors
- Skill path: self-edit → 2–3 concepts/day → compound until revenue attracts quality talent
  → hire with structured training doc
- Why self-editing wins early: you know the avatar, the angle, and the research — no brief
  required; feedback loop is instant
