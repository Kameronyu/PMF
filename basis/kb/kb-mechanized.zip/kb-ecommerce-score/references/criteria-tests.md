# Per-gate membership tests + the COUNTABLE gate definitions

All COUNTABLE gates lower to a deterministic check a script runs identically every time
(numeric threshold, count bound, length bound, enum/contains). Any can return FALSE.
Topic-local terms (RPU, AOV, ROAS, CPA, dry test, opt-in, CPM, CPC, CTR, CVR, ATC, COGS,
GP) are defined here, not in the term registry. Anchored terms (Niche, Sub-niche,
Transformation, Market, Angle, Trust signals, Hook, Objection handle, Awareness level)
are NOT redefined — use the registry.

## COUNTABLE gates (script-gated, hard-fail)

**G1 Margin**
- `gross_margin = (price - COGS) / price`; PASS iff `gross_margin >= 0.80` (CW 80% rule).
- AND `price >= 3 * COGS` AND `(price - COGS) >= 20` (MBB dual requirement; $20–25 GP/unit).
- FALSE example: $10 COGS sold at $25 → 2.5× multiple, $15 GP → FAIL (below 3× and below $20 GP).

**G2 Criteria filter** (run four-criteria OR six-criteria; all sub-tests must pass)
- Four-criteria: painful-problem market (routes to F1) AND `price >= 3*COGS AND GP >= 20` AND fits shoebox AND high-LTV (consumable OR subscription OR frequently gifted).
- Six-criteria: real problem (no gadget/novelty) AND `>= 3x margin` AND shoebox-or-smaller AND evergreen (year-round) AND a competitor at $300–500K/mo AND upsell potential exists.
- Each sub-test is contains/threshold; missing any → FAIL.

**G3 Validation thresholds** (ALL must be confirmed)
- `competitor_monthly_revenue` in $300K–$500K minimum.
- `monthly_visitors` in 300,000–500,000 (SimilarWeb).
- `monthly_searches >= 30,000` (Keywords Everywhere).
- Google Trends: 5+ year window, steady/increasing, NOT a parabolic spike.
- `count(competitors meeting revenue) >= 2` (multiple, not one).
- Any single threshold unmet → FAIL.

**G4 Revenue / RPU math** (computed)
- `RPU = conversion_rate * AOV`. Front-end profitable iff `CPC < RPU`.
- `estimated_monthly_revenue = monthly_visitors * CVR * AOV` (CVR 2–2.5% for validation).
- PASS iff `CPC < RPU`. FALSE example: CPC $3.00, RPU $1.50 → FAIL.

**G5 Research-method gates** (the named method's thresholds must all hold)
- Native ad: competitor site `>= 200,000–300,000` monthly visitors.
- Get Hooked: ad is 4–5 star AND video format AND runtime `>= 7 days` AND `>= 100` active brand ads AND length 3–5 min.
- Engagement: `likes >= 10,000` AND `shares >= 5,000` (2:1 ratio).
- Triple-method: 30,000+ searches AND 5+ yr steady trend AND 300,000–400,000+ visitors (all three).

**G6 Image-type enum** (closed list; echo the chosen format verbatim)
- ALLOWED VALUES: `Big Caption | Social Proof | Three-Piece Collage | Bullet Points | Before and After | Size and Materials`.
- Each page image classified into exactly one. A value off the list → FAIL.
- CONDITIONAL: `Before and After` allowed ONLY if a genuine transformation exists (anchor: Transformation); else relabel or remove.

**G7 Page-structure counts**
- Long-form: `6 <= images <= 10` AND `5 <= sections <= 8`.
- Optimization checklist: `8 <= images <= 10`.
- Above-fold present: social proof, product title, one-sentence value prop, trust badges, 3–4 benefit sentences.
- CTA buttons clear and unambiguous. Any count out of bounds or missing above-fold slot → FAIL.

**G8 Reading level**
- `hemingway_grade <= 6` on any copy generated for the page. Above 6 → FAIL.

**G9 AOV / funnel math**
- `100 <= AOV <= 400` (sweet spot) AND `AOV >= 2.5 * front_end_price` (2–3× rule).
- FALSE example: $40 front-end product with $50 AOV → ratio 1.25× → FAIL (needs $120 min).

**G10 Dry test**
- `opt_in_rate >= 0.10` viable; `0.08 <= opt_in_rate < 0.10` acceptable iff price > $100; below → do not build.

**G11 Payment method** (enum)
- ALLOWED: `credit_card`. PayPal or connected bank → FAIL (penalized traffic quality).

**G12 Constraint diagnostic** (each metric is a threshold; output the single failing constraint)
- `CPC < 1` else "Ad/targeting problem".
- `CPM < 20` else "Ad/targeting problem".
- `CTR > 0.02` else "Creative problem".
- `CVR > 0.03` else "Funnel problem".
- `ATC > 0.10` else "Ad messaging or landing page problem".
- Good ad metrics + low CVR = funnel problem. Name the ONE real constraint; do not relaunch on multiple variables.

## FELT gate (F1 — pairwise only, NEVER a membership FALSE)

**F1 Pain-market fit** — Do NOT write a yes/no gate. Judge by comparing the candidate's
problem to a winning pain specimen (`references/scoring-specimens.md`): does this solve a
*specific* felt pain in a passionate market as well as the specimen does, or is it a
category/interest niche? Return `prefer | tie | weaker`. `weaker` contributes no pass.
This is the criterion a naive mechanizer would launder into "is this painful? → FALSE";
keep it a signal.

## HEURISTIC gate (H1 — soft-cap, never hard-fail)

**H1 Sleeping-giant / compete-on** — count signals, do not hard-fail.
- Sleeping-giant transformation candidate iff strong organic reach AND retail presence AND
  loyal customers AND unprofitable paid ads. Count of signals; false positives possible →
  soft-cap, flag as candidate, never NO-GO on this alone.
- Compete-on: assert exactly ONE of the nine advantages (budget/data, backend LTV, frontend
  AOV, creative, angles, time investment, AI/automation, traffic arbitrage, obsessive focus).
  Soft-enforce singularity; competing on two is a flag, not a fail.

## Why the tiers
Hard-gating a felt gate (is a pain "painful enough"?) produces confident-but-wrong FALSEs
and pushes builders toward gaming the gate. Hard-gating a countable one (a margin is or
isn't ≥3×; an opt-in rate is or isn't ≥10%) is reproducible and safe. Soft-cap the
in-between (sleeping-giant signal counts, compete-on singularity) because the detectors
over-flag.
