# Restored frameworks — product selection, scaling levers & economics

Named source frameworks an executing agent needs to reason about product selection,
retention, unit economics, supplier and channel relationships. These are decision
frameworks and theses (which path to take under named conditions), NOT countable gates —
the SKILL.md keeps a one-line pointer; the full content lives here. Quoted strings are
verbatim substrings of the source KB files; non-quoted lines paraphrase faithfully. No
line budget.

---

## E-Commerce Success Formula (named thesis)
Source: Mark Builds Brands. The topic-level thesis the whole skill scores against.

"The E-Commerce Success Formula: Good product + Good creatives + Good funnel = Success."
- "Scale-invariant from $1,000/day to $100,000/day."
- "Weakness in any single element undermines the others."
- Use: a candidate strong on product but weak on creatives or funnel is NOT a GO — the
  formula is multiplicative, not additive. This is why the score skill runs product, page,
  funnel and paid-diagnostic gate-sets separately; one strong pillar does not rescue a weak
  one.

---

## Two-Pillar E-commerce Performance Model (named framework)
Source: Carl Weische. The named split behind G12 and the RPU math — front-end performance
divides into TWO pillars, each with its own sub-drivers. Diagnose which pillar is the
constraint before optimizing.

E-commerce front-end performance splits into two distinct pillars:
- **Ad Performance pillar** → drivers: **CPM** and **CTR**.
  - CPM influenced by targeting quality, seasonality, market competition, pixel optimization.
  - CTR depends on creative quality and audience relevance.
- **Website Performance pillar** → drivers: **CR** and **AOV**.
  - CR driven by landing-page congruency, objection handling, anxiety reduction.
  - AOV driven by bundle structure and upsell/cross-sell processes.

Decision rule: "ROAS optimization requires diagnosing which pillar is underperforming."
Map a failing G12 metric to its pillar first (CPM/CTR = Ad pillar; CR/AOV = Website pillar),
then fix that pillar's named driver — do not relaunch across both pillars at once.

---

## Trend-First Product Selection via Social Listening
Source: Carl Weische. A product-discovery framework: enter a niche BEFORE mainstream
adoption by monitoring early adopters.

Identify emerging product trends before mainstream adoption by monitoring Twitter and
tracking influential early adopters (e.g., Huberman, Bryan Johnson) in biohacking and
entrepreneurship niches. Enter the market early, build unit economics at 80%+ gross
margins, and align brand messaging with audience values before competitor saturation.
- Target biohacking, longevity, and entrepreneurship niches as early adopter pools
- Sponsor niche influencers and run ads using influencer content for message-market match
- Build storefront and messaging aligned with audience values, not just product features

---

## Core Desire Problem-First Product Selection
Source: Carl Weische. The contrarian alternative to "winning-product" hunting — start from
the desire/problem, not the product.

Reject the "winning product" search mentality. Identify fundamental human desires and
problems first, then find products that fulfill them. Brand positioning, supplier sourcing,
and product refinement follow problem identification.
- Process takes 2–3 months before launch-ready
- Brand launched February 2022 scaled to "$10M revenue in first year" using this approach
- Brand positioning must be resolved before scaling ad spend

---

## Low-Competition Market Selection Framework
Source: Carl Weische. Select for low QUALITY-FOCUSED competition rather than the largest
markets. Low-quality incumbents in high-demand markets are the opportunity.

Select verticals where intelligent, quality-focused competition is low rather than chasing
the largest markets. Low-quality incumbents in high-demand markets create outsized
opportunity for quality-first entrants.
- German supplement market: 20x competitor revenue achieved by focusing on product quality
- Fitness supplements selected because competitors were not prioritizing product outcomes
- "Achieving 20x revenue vs. competitors possible by simply caring more about product quality"

(Note: this complements MBB's "saturated = validation" thesis — both reject zero-competition
hunting; CW additionally selects on the *quality* gap, not just demand proof.)

---

## Customer Survey-Driven Product Upgrade System
Source: Carl Weische. Turn a commodity dropshipped product into a defensible branded item
by surveying a large customer base, then implementing physical upgrades competitors can't
easily copy.

After accumulating 40,000+ customers, conduct surveys to identify specific product pain
points, then implement targeted physical upgrades competitors cannot easily replicate.
- Upgrades implemented: YKK zippers, magnetic closures, silver branded logos, enlarged
  clutch for modern smartphones with cases, high-quality steel chain
- Upgrades serve dual purpose: reduce refunds and increase conversion rates
- Wait for statistically meaningful customer volume (40,000+) before surveying
- Defensibility rationale: physical upgrades sourced from real customer pain are the moat —
  they convert "commoditized dropshipped product into defensible branded item."

---

## Product Quality Risk Framework for Strict-Regulation Markets
Source: Carl Weische. In high-consumer-protection markets, quality failure is a *legal*
hazard, not just a financial one — and quality is independent of shipping speed.

In high-consumer-protection markets (Germany), product quality failures are legally
dangerous beyond financial cost. Test quality from multiple suppliers immediately after
initial sales validate demand — do not scale before validating quality.
- Failed hair brush product generated mass refunds despite similar shipping times to the
  successful clutch product
- Chinese supplier quality standards frequently misalign with Western market expectations
- "Quality is an independent critical variable from shipping speed" — fast shipping does NOT
  compensate for a quality failure.

---

## Product-as-Marketing Flywheel
Source: Carl Weische. Superior quality creates a self-reinforcing growth loop: the product
becomes the primary marketing vehicle, reducing paid-acquisition dependence.

Superior product quality creates a self-reinforcing growth loop: product becomes primary
marketing vehicle. When customers feel better after using the product, they like the brand
more and continue purchasing, reducing paid acquisition dependence.
- "Mon Nutrition did 20x competitor revenue" attributed primarily to superior product quality
- Customers see results within 2–3 weeks, driving year-round retention vs. seasonal spikes
- Mon Nutrition grows consistently after January, defying typical fitness industry
  post-New-Year drop-off

---

## Customer Retention as Primary Scaling Lever
Source: Carl Weische. For brands at 5–20M revenue, retention rate is the single most
critical scaling metric — small percentage differences compound into qualitatively
different trajectories.

For brands at the 5–20M revenue range, customer retention rate is the single most critical
metric for sustainable scaling. Small differences in retention percentage create
disproportionately large differences in scaling difficulty due to compounding churn effects.
- 80% vs. 70% retention creates a *qualitatively different* scaling trajectory (not merely
  10% better — the compounding churn math diverges)
- High retention reduces dependence on continuous new customer acquisition, lowering effective CAC
- Retention is driven by product results (outcomes within 2–3 weeks) and product enjoyment
- "You can't profit hack your way to a great retention rate"

---

## Front-End Break-Even / Backend Profit Strategy
Source: Carl Weische. Deliberately run break-even (or slight loss) on front-end acquisition;
generate profit through repeat purchases over a 90–180 day horizon. CAC is paid once;
customers buy many times.

Deliberately run break-even or slight losses on front-end customer acquisition while
generating substantial profit through repeat purchases over 90–180 days.
- Profit generation horizon: 90–180 days post acquisition
- Monthly $100K ad spend analysis must include a 90-day backend profit projection — never
  judge a $100K/mo spend on front-end ROAS alone
- Requires strong retention, email/SMS, and repeat purchase mechanisms
- (Companion to MBB funnel economics: same "loss on front, profit on back" logic; CW frames
  the time horizon, MBB frames the AOV math.)

---

## Three Golden Rules for Shopify Store Foundation (named framework)
Source: Carl Weische. Three NON-NEGOTIABLE technical foundations before any CRO work. None
of these three rules previously appeared in any reference.

1. **Mobile First:** 60–80% of e-commerce traffic is mobile; build and QA in mobile view
   primarily.
2. **Page Speed:** Use Shopify 2.0, compress all media, employ skilled developers for custom
   code; a 1-second load time generates significantly more revenue than a 4-second one.
3. **Functionality:** Make buying and navigation frictionless; test with real users to
   identify friction points.

Use: gate these three before scoring any page-level CRO. A page that fails any of the three
foundations is not ready for the G6/G7/G8 page gates.

---

## Professional Supplier Relationship Management for Scale
Source: Carl Weische. Treat suppliers as strategic partners, not transactional dropshipping
arrangements — and synchronize backend operations with ad-spend acceleration.

Treat supplier relationships as strategic partnerships, not transactional dropshipping
arrangements.
- Share revenue projections and scaling timelines proactively
- Negotiate net terms or special inventory deals based on volume commitments
- Manage inventory levels to match ad-spend acceleration
- "Fulfillment failures from insufficient inventory create bad reviews that compound
  negatively"
- Backend operations scaling must be synchronized with front-end ad scaling — a fulfillment
  failure during a scale-up turns into compounding negative reviews.

---

## High-Spending Affiliate Partnership Model
Source: Carl Weische / Martin from Nobro. Work directly with high-spending affiliates as
true partners rather than through anonymized networks; actively help them earn more.

Instead of using anonymized affiliate networks, work directly with high-spending affiliates
as true partners — actively helping them earn more money. This mutually invested
relationship outperforms conventional network-based affiliate marketing.
- Direct partnership model produces stronger relationships and higher sales than traditional
  networks
- Actively help affiliates increase their own earnings as the primary relationship-management
  strategy

---

## Operational Excellence in Influencer Marketing
Source: Carl Weische / Paul Valentine. Treat influencer marketing as an OPERATIONS problem —
actively manage influencers to enforce posting times and deal execution. Applied at a
"$35M+ brand" level as a key competitive lever.

Treat influencer marketing as an operations problem: actively manage influencers to enforce
correct posting times and deal execution.
- Stay actively on top of influencers to enforce correct posting times
- Operational discipline in influencer management is a distinct competitive advantage at scale
- Applied by "Paul Valentine ($35M+ brand)" as a key competitive lever

---

## Funnel Economics vs. Standard Dropshipping Economics (worked math + tools)
Source: Mark Builds Brands. The worked unit-economics contrast and the funnel-sophistication
hierarchy. The G9 AOV gate enforces the numbers; the *reasoning* and tools live here.

Standard dropshipping at $100 CPA on a $50 product = -$50 per customer. Economically
unscalable.

Funnel model: "$97 base + $30 upsell + $15 downsell = $145 AOV" at the same $100 CPA =
**+$45 per customer**.
- AOV sweet spot: $100–$400 for branded dropshipping. As ad spend scales, CPA inevitably
  rises — AOV must absorb the increase.
- AOV testing rule: AOV must be at least 2–3× the front-end product price.
- **Funnel sophistication hierarchy:** Ad → product page → checkout (basic) → pre-sales
  pages, advertorials, quizzes, outcome-focused sales pages (advanced).
- Tools: "Funnelish or Checkout Champ" for greater customization than Shopify allows.
- Backend LTV (subscriptions, email/SMS, continuity) is where real profit comes from; a
  supplement company ran 0.7 ROAS front-end (losing $30K/day) yet profitable via backend.

---

## Seasonal Strategy Integration — broad application
Source: Spencer (Origins). The hemisphere flip is NOT limited to sub-avatar validation — it
applies across three uses. Previously only the sub-avatar-validation use was captured.

Primary market off-season → test in the opposite hemisphere during their peak.
- "Hemisphere flip applies to: product launches, sub-avatar validation, media buying tests"
  — three distinct applications, not one.
- Enter early — late entry compresses the data window and inflates CPMs as competitors flood
  the peak.
- (Companion: Counter-Cyclical Market Flip — seasonal UK/US products → test in AU/NZ during
  their opposite-hemisphere season.)
