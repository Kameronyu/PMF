---
name: kb-persuasion-and-sales-write
description: >-
  Write buyer-facing sales copy — closes, objection reframes, discovery questions,
  guarantee and offer lines a prospect FEELS. Use when generating or rewriting the
  actual words of a close, an objection handle, a reframe, a discovery probe, or a
  guarantee/anchor line for a sales call, DM, or VSL. Leads with real winning Hormozi
  specimens and a few craft targets; offers the 3A reframe shape and the Guarantee
  Formula as OPTIONAL patterns, never as required slots. Routes which frame fits which
  objection / awareness stage as a light contract. This skill WRITES; it does not grade
  its own output — score copy with kb-persuasion-and-sales-score (a separate pass).
  Triggers: "write a close", "handle this objection", "reframe their pushback",
  "write the guarantee", "discovery questions for this call".
---

# Persuasion & Sales — write the line that transfers belief

A close or an objection handle executes an **angle** (the leading emotional reason to
buy) and removes an **objection handle**'s friction — in the words the prospect actually
hears. Your job is that *wording*. Lead from the specimens below; reach for a named shape
only if it helps; keep the human number one — seek to understand, not to win.

## Start here — real winning specimens (study these before writing)

These are preserved verbatim from the source. They steer you harder than any rule. Adapt the
*move* and keep the felt directness.

- **Universal Close (flip the objection into the reason):** *"I think the fact that you don't have time is probably the reason you need this more than anyone else"*
  — takes the exact thing they raised as a barrier and makes it the strongest case FOR buying. The flip is the whole move; no new claim is added.
- **Price counter-anchor (refuse the downward pull):** *"hey I can do it for more"*
  — answers "can you do it for less" by moving the anchor the other way. It reframes who is conceding; the unexpected direction breaks the haggling frame.
- **Authority / partner objection (permission → support):** *"The real problem is that you're asking for permission instead of support. It is your life, not theirs."*
  — names the real objection under the stated one, then hands the decision back to them. Reframes the relationship, not the price.
- **When-Then reframe (the condition the product creates):** *"This is a logical fallacy called the when-then fallacy. 'I'll pay for the program that'll make me more money when I have more money' - that's the point of the program."*
  — exposes that they are waiting for the very outcome the purchase produces. Names the fallacy, then turns it on itself.
- **What-Would-It-Take (resistance → criteria):** *"What would it take for us to do business together? What would it take for you to say yes? What would I have to do objectively?"*
  — converts a vague stall into a concrete, answerable condition you can then meet. Hands them the pen.
- **Pride-proof close question (escalate the absurd):** *"How many people would you need to see for it to be more unreasonable for you not to believe than to believe? At what point is it 10? 50? Here's a thousand."*
  — makes their disbelief the thing that needs defending, by escalating the proof past any reasonable bar.

More specimens — discovery probes, the anchor-against-downsell line, delivery cues, the
guarantee formula — are in `references/specimen-bank.md`.

## Craft targets (steer by these; they are not a rulebook)

- **Make the prospect right.** Acknowledge what they said before you move it. Never win the
  argument at the cost of the sale; if you make them wrong, you lose. Restating their words
  builds rapport and buys you a beat to think.
- **Flip, don't fight.** The strongest handles turn the objection itself into the reason to
  buy (no-time → needs-it-most; no-money-now → that's-the-point). Reframe; don't rebut.
- **Specificity over superlative.** A named outcome, a timeline, a real number beats "great
  value." Enter the desire they already voiced — in their own words — don't announce it.
- **Ask, don't tell.** Prospects believe what they say and discount what you say. End reframes
  on a question that moves toward the close; let them reach the conclusion.
- **Go below the iceberg.** In discovery, keep asking why it matters, what changes, who else it
  affects — the deeper the intention you surface, the more convicted the buyer becomes.
- **Write from conviction.** Sales is a transfer of belief — the prospect buys on how
  convinced you sound, and conviction cannot be faked. A hedged line leaks low belief; write
  like closing them is an obligation, not a favor.
- **Help their logic justify.** Lead the emotion, but leave the logical scaffold (10/10/80 —
  write for the 80% in the middle; "no" is the job) so the buyer can defend the decision later.

See `references/conviction-and-logic.md` for the conviction principle, the selling-with-logic
sub-rules (10/10/80, obstacles-before vs objections-after), the LEU probe (Logic/Evidence/
Utility), the investment-vs-cost reframe, sell-the-outcome-not-the-tech, motivation as a
temporary value shift, the Three Prerequisites for Decision-Making (with pride-proof close),
and the Five Rules for Ethical Reframing.

## Optional patterns (reach for one; never force a fixed slot order)

- **3A reframe shape** — after a prospect says anything but yes, in 1–3 sentences:
  *Acknowledge* (restate what they said) → *Associate* (connect their question to what your
  best customers did) → *Ask* (a question that moves toward the close). A shape to borrow when
  you need a handle on the fly, not a sequence to fill robotically.
- **Guarantee Formula** — *"If you don't achieve X by Y time, I will Z."* X = the named
  outcome, Y = the timeline, Z = the consideration (the "or what" you put at stake). The
  *wording* of X/Y/Z is your job here; that all three are present is what the scorer checks.

Anatomy and a worked example for each is in `references/formulas.md`.

## Contract rules (these DO bind — they pick the frame, not the words)

Route which frame to write by the objection voiced and the buyer's awareness. The full
routing table is in `references/route-rules.md`; the load-bearing picks:

- **Objection → frame (Onion of Blame peel order: Circumstances → Others → Self):**
  "I can't afford it" = Circumstances (price frames) · "talk to my partner" = Others
  (permission-vs-support) · "I need to think about it" = Self/avoidance (Past/Present/Future).
- **Time objection → angle:** Macro (busy season) · Micro (no time in the day) · When-Then
  (waiting for the condition the product itself creates) — pick by which time objection it is.
- **Awareness routing:** problem-aware "I'll think about it" → handle across Past/Present/
  Future · most-aware → lead the value model (guarantee, offer tier, urgency), not a new angle.
- **Authority/partner → sequence:** isolate (the partner isn't here to object) → reframe
  permission-vs-support → if the concern is genuine, offer a 3-day guarantee to nudge.
- **Discovery sequence:** Past (what they tried, why it failed) → Present (cost of staying) →
  Future (worth of the gap); stay high-level to keep control, then chunk up to what you sell.
- **Discount → change-of-terms:** hold price by swapping for referral intros or a bonus
  matched to the objection.

## How to use this with the grader

Generate several diverse handles (vary the frame and the angle; keep each draft a distinct
attempt). Then hand them to **kb-persuasion-and-sales-score** — a separate skill, ideally a
different model — for the gates (guarantee slots, three-tier anchor, MESO count, looping
re-ask, qualification filter) and the pairwise-vs-specimen judgment (anchor height, the
stack, never-disagree tone). The scorer grades; this skill WRITES — score separately.

## Before handoff (what kb-persuasion-and-sales-score checks)

Generate several diverse drafts; the separate scorer grades — do not self-grade toward the
gate. These are the qualities the scorer looks at, kept here as awareness of what good looks
like, not as a writer pass/fail:

- Whether it acknowledges/restates what the prospect said before moving it.
- Whether it flips the objection toward the reason to buy, rather than arguing against it.
- Whether it carries at least one concrete specific (named outcome, number, or timeline).
- Whether it ends on a question or a frame the prospect can step into, not a lecture.
