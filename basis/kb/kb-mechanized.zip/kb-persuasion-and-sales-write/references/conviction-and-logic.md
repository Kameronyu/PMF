# Conviction, logic, and persuasion principles behind the words

The writer's title is "write the line that transfers belief." These are the source principles
that make a line transfer belief — the *why* under the craft targets. Preserved faithfully
from `persuasion-and-sales--alex-hormozi.md`. Use them to choose what to write, not as gates.

## Conviction Transfer (tone and belief) — the core principle

Sales is fundamentally a **transfer of belief**. The prospect buys based on how convinced the
salesperson is, not just what they say. Tone, energy, and genuine belief carry more than
scripted words. **You cannot fake conviction** — if the salesperson isn't convinced, the
prospect won't be either.

- Sales is a transfer of belief from salesperson to prospect.
- Tone and energy communicate more than words.
- You must genuinely believe in what you sell.
- **Conviction obligation:** if you genuinely believe you help, you have an obligation to close.

> "The prospect buys based on how convinced the salesperson is"

Writer implication: write from belief. A hedged, apologetic line leaks low conviction; the
copy should sound like someone who would be doing the prospect a disservice not to close them.

## Selling with Logic (belief transfer) — the job + the operating rules

People decide on a spectrum from emotional to logical. Emotional buyers call back questioning
the decision; when emotion fades, logic must sustain it. The salesperson's job is to help the
prospect's logical brain justify a decision they already want to make.

Operating sub-rules to write toward:

- **People want to believe you and want to buy** — help their logic justify it.
- **Selling happens before the ask; closing happens after.** "Obstacles occur before
  soliciting the sale; objections occur after" — distinguish the two when you write a handle.
- **The 10/10/80 split:** 10% will never buy, 10% will always buy, 80% are in the middle —
  **train and write for the 80%.**
- **"No" is the job.** If they could decide alone, they wouldn't need you.
- The person who cares most about the prospect wins the sale.
- **Record all sales for training and self-correction.**

> "People want to believe you. People want to buy you. You must help their logical brains justify the decision they already want to make."
> "No is the job. If they could make the decision on their own, they would just send you the money."

## Logic-Evidence-Utility (LEU) Detection Framework

A named three-question test for any statement a prospect (or you) makes. Strips false
narratives down to observable, actionable reality:

- **Logic** — *what does this mean to you?* (unbundle the term)
- **Evidence** — *how do you know?* (challenge the causal claim)
- **Utility** — *so what? what do you want to happen?* (drive to action)

Most people make false causal statements unconsciously. The discipline: erase feelings,
intentions, and beliefs from the vocabulary — focus only on observable behavior.

> "You want me to answer a question that you can't Define the word for — so what's the likelihood that you get what you want? Really low."
> "I for the most part have just erased feelings intentions beliefs all of these words from my vocabulary"

Writer use: when a prospect's objection rests on a vague term ("it's too risky," "it won't
work for me"), write a probe that unbundles the term (Logic), challenges the basis (Evidence),
then drives to what they actually want (Utility).

## Framing (investment vs cost)

How you position something determines how it is perceived. **Frame your side as an investment
with returns; frame the other party's side as a cost.** Support the frame with ROI data. Most
people don't understand framing and accept whichever frame is presented.

- Instead of "this costs $5K," say "for a $5K investment, you'll see $15K in savings."
- As an employee: frame yourself as an investment tied to revenue, not a cost center.
- As a vendor: frame services as investments with measurable ROI.
- Pool example: pool costs $100K but adds $100K to home value → "the pool is free, you just
  get to enjoy it."

> "Rather than saying 'Hey, this is going to cost you five grand,' we can say 'For a $5,000 investment, you can see $15,000 in maintenance cost savings.'"

## Sell the Outcome, Not the Technology

When selling emerging tech (AI, automation), never lead with the tech — sell the outcome.
"What if your financials were 100% accurate and updated in real time? What if it cost less than
what you pay now?" The mechanism is irrelevant to the buyer. This is "sell the vacation, not
the plane flight" applied to tech.

- Lead with the outcome; the mechanism (AI, automation) is the plane flight — don't sell it.
- Frame: "If I could give you X, would you want it? What would you pay?"

> "you don't sell emerging Tech... the fact that I'm using AI is irrelevant you just sell the outcome"

## Motivation as Temporary Value Shift — the unifying frame for the whole task

Motivation is **temporarily increasing the relative value of an outcome**, which changes
behavior. This is fundamentally the same mechanism as persuasion and sales. To motivate
someone, find the one thing they value most and connect the desired behavior to that value.
This is the frame to keep in your head while writing any persuasion line: you are not adding
facts, you are raising the felt value of the outcome relative to everything competing for the
prospect's attention.

- Motivation = temporarily changing the relative value of an outcome.
- Motivation, persuasion, and sales are fundamentally the same mechanism.
- Find the one thing that matters most to the person and connect the behavior to it.
- Sometimes reframing the prospect's current struggle as a **skill deficiency on the path to
  their stated goal** is the most motivating move you can make.
- Hormozi's mother tried to lose weight for 30 years; she succeeded only when the doctor
  connected it to seeing her grandkids — proof that the right value connection, not new
  information, is what moves behavior.

> "Somebody who motivates other people is able to temporarily increase the value of an outcome. Fundamentally, that's what motivation is. And that's also what persuasion is. That's also what sales is."
> "Sometimes reframing their current struggle as a skill deficiency on their way to getting what they ultimately want is one of the most motivating things you can do."

## Three Prerequisites for Decision-Making — the 3-belief diagnostic + pride-proof close

For someone to buy, they must believe **three things**. Diagnose which belief is missing and
write toward that one; a missing belief, not a missing fact, is what stalls the close.

1. **It will work the way they want** — the product gets them the goal the way they want to
   get there.
2. **You will support them** — they trust your support and your truthfulness (you and others
   will be there).
3. **It will work for them specifically** — not just for everyone else, but for them.

The third belief is the most common stall ("it works for others, but my situation is
different"). **Pride-proof it** by escalating the proof past any defensible bar, so their
disbelief becomes the thing that needs defending:

> "How many people would you need to see for it to be more unreasonable for you not to believe than to believe? At what point is it 10? 50? Here's a thousand."

## Five Rules for Ethical Reframing — the named checklist behind the 3A shape

Five rules govern ethical use of the 3A reframing framework (Acknowledge → Associate → Ask).
Keep all five in mind whenever you write a reframe; they are the guardrails that keep a handle
persuasive without becoming combative.

1. **Prospects believe their words, not yours** — a prospect believes almost nothing about
   what you say and almost everything they say. Get them to sell themselves.
2. **Never disagree** — you never win a sale by winning an argument.
3. **Tell them what their question means** — use association (the three association types) to
   reframe what they just asked into what it actually implies.
4. **Use straw men for tough truths** — attribute the hard truth to a past customer, an
   earlier conversation, or an authority figure rather than stating it as your own attack.
5. **Retain childlike curiosity at all times** — say "huh" to buy time and stay
   non-combative; cue it with a head tilt and upward inflection.

Keep the human number one — seek to understand, not to win.

> "A prospect believes almost nothing about what you say and almost everything that they say"
> "It's a dance not a fight — it's seduction not rape"
