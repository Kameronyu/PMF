# Optional patterns — anatomy + a worked example each

Reach for one when it fits the objection. Neither is a required slot order; forcing a fixed
sequence is what produces compliant, same-y handles. Use these to vary, not to standardize.

## 3A Reframe shape (after any non-yes)

In 1–3 sentences: [Acknowledge: restate what they said] → [Associate: connect their question
to the behavior of your best customers] → [Ask: a question that moves toward the close].
- Acknowledge builds rapport and buys you a beat. Associate borrows the proof of others
  (straw men — "a past customer once told me…" — carry tough truths without disagreeing).
  Ask hands them the pen so they reach the conclusion themselves.
- Borrow the shape on the fly; do not recite it robotically. Prospects believe what they say
  and discount what you say, so the Ask is load-bearing.

## Guarantee Formula

[If you don't achieve X (named outcome) by Y (timeline), I will Z (the consideration / "or what")].
- The "or what" (Z) is what gives the guarantee its power — "guaranteed" alone is not enough.
  Two strongest types: service-based (keep working until achieved) and unconditional (money
  back if value not perceived).
- Your WRITE job is the actual X/Y/Z wording in the prospect's terms; the scorer checks that
  all three slots are present.
- Example shape stated by the source: "if you don't achieve X by Y time, I will Z, which is
  what's the consideration."

## Counter-anchor (price down → price up)

[They ask for less] → [you move the anchor the other way]. Breaks the haggling frame by
refusing the downward pull and re-establishing that you set the terms. The source line:
"hey I can do it for more."

## When-Then reframe (waiting for what the product creates)

[Name the fallacy: they're waiting for the outcome the purchase itself produces] → [turn the
condition on itself]. Use when the objection is a future condition ("when I have more
money/time…") that the offer is precisely meant to create.
