# Specimen bank — verbatim winning sales copy, with the move each makes

Preserved verbatim from `persuasion-and-sales--alex-hormozi.md`. These are the highest-value
asset in the skill — study and adapt the *move*, do not abstract into ordered templates. Each
shows the form of a good answer; that is what steers a model. Keep the human number one — seek
to understand, not to win.

## Closes — flip the objection into the reason

- "I think the fact that you don't have time is probably the reason you need this more than anyone else"
  — Universal Close. Takes the stated barrier (no time) and makes it the case FOR buying. No new claim; just the flip.
- "How many people would you need to see for it to be more unreasonable for you not to believe than to believe? At what point is it 10? 50? Here's a thousand."
  — Pride-proof close question. Escalates the proof past any defensible bar so their disbelief becomes the thing on trial.
- "What would it take for us to do business together? What would it take for you to say yes? What would I have to do objectively?"
  — What-Would-It-Take. Converts a vague stall into concrete, answerable criteria you can then meet.

## Objection reframes — name the real objection, hand back the decision

- "The real problem is that you're asking for permission instead of support. It is your life, not theirs."
  — Authority/partner objection. Names the real issue under the stated one and returns the decision to the prospect. (Stated source reframe: "I'm not asking your permission, I'm asking for your support.")
- "This is a logical fallacy called the when-then fallacy. 'I'll pay for the program that'll make me more money when I have more money' - that's the point of the program."
  — When-Then. Exposes that they are waiting for the exact outcome the purchase produces.

## Negotiation — refuse the downward pull

- "When someone says 'hey can you do it for less' you can always say 'hey I can do it for more' and every single time I've used that overcome it has worked"
  — Counter-anchor. The line itself is "hey I can do it for more"; moving the anchor the wrong direction breaks the haggling frame.
- "For only $2,800 more, I can ensure it's done right"
  — Anchoring against the downsell. Frames the upgrade as cheap relative to the risk of it being done wrong.

## Discovery — go below the iceberg

- "Why do you want that? What changes? Who else does it affect? Why does that matter?"
  — Intention-based probes beneath a surface answer; the deeper the intention surfaced, the more convicted the buyer.

## Guarantee — the "or what" is what gives it power

- "if you don't achieve X by Y time, I will Z, which is what's the consideration"
  — The formula stated by Hormozi. X = outcome, Y = timeline, Z = consideration. The wording of X/Y/Z is the WRITE job; presence of all three is the gate. Just saying "guaranteed" is not enough.

## Delivery cues (tone-as-words; steering, not copy)

- "I call it childlike curiosity. I always cue it by tilting my head."
  — Probe objections with childlike curiosity and upward vocal inflection; say "huh" to buy time and stay non-combative.
- "The same sentence but simply emphasizing different parts of it communicate different things."
  — Emphasis carries meaning; the words alone are not the whole message.

> Note: these are call/DM/VSL specimens. Feed real prospect language (their voiced objection,
> their stated desire) as input — a generic brief yields generic handles. Adapt the move to
> their exact words; do not paste these verbatim into live copy.
