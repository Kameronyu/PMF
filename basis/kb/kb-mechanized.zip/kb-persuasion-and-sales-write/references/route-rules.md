# Route rules — which frame to write for which trigger (light contract)

These pick the SHAPE, not the words. They bind: write the frame the trigger calls for. The
wording inside the frame is your WRITE job (specimen-bank.md). The scorer gates the structure;
this steers the selection.

## Objection type → frame (Onion of Blame peel order)

Peel **Circumstances → Others → Self** — the prospect's distortion tells you the layer:

| Voiced objection | Layer | Frame to write |
|---|---|---|
| "I can't afford it" / "it's too expensive" | Circumstances | Price/money: Why-a-Lot-is-Good · Value-Justification · Paying-Either-Way (time vs money) · Resourcefulness-vs-Resources — pick by how the price objection is voiced |
| "I have to talk to my partner" | Others | Authority: isolate → permission-vs-support reframe → 3-day guarantee if genuine |
| "I need to think about it" | Self / avoidance | Past (bad experiences burning them twice) · Present (people need information, not time — incl. the Rocking Chair Close) · Future (only walking out guarantees failure) |

**Present-frame execution — the Rocking Chair Close:** name what actually happens if they
"think about it" — they won't sit and deliberate, they'll go back to life and forget. Source:
*"The Rocking Chair Close: you won't sit and deliberate, you'll go back to life and forget."*
Pair it with the point that people don't need more time, they need information, and you are the
information source.

## Price/money frames — what each one says (execution content)

When the objection is "I can't afford it" / "it's too expensive," pick by how the price
objection is voiced. These are the four source frames, with the copy move each makes:

- **Why-a-Lot-is-Good** — turn the size of the price into a feature: more on the line means
  more commitment and a better outcome. Source: *"If the amount is a lot to them, they will be
  more committed and successful."* Write it so the high price is the reason it will work.
- **Value-Justification** — isolate one outcome and test it against the price: "if all this
  does is X, is it worth it?" Anchor for context against a known large spend — *compare value
  to a 4-year degree at $50K–$200K.*
- **Paying-Either-Way (time vs money)** — they will spend either way; the only choice is the
  currency. Source line, verbatim: *"You're going to spend this money either way over the next
  12 months. The question is whether you're going to pay for it in money or pay for it in
  time."* Also: *"You're going to learn these lessons either way — 12 weeks or 12 years."*
- **Resourcefulness-vs-Resources** — reframe "I don't have the money" as a resourcefulness
  question, not a resource one. Source: *self-made billionaires started with nothing — it was
  about resourcefulness, not resources.*

## Time objection → angle

- **Macro** (busy season): the habit persists regardless of season.
- **Micro** (no time in the day): they're spending time on the wrong things.
- **When-Then fallacy**: they're waiting for the condition the product itself creates (write the When-Then reframe).

## Awareness stage → what leads

- **Problem-aware** ("I'll think about it"): handle across Past / Present / Future; speak the named problem in their language.
- **Solution-aware**: disqualify alternatives + educate on the mechanism; the outcome angle leads.
- **Product-aware**: objection handles, social proof, guarantees do the work.
- **Most-aware**: lead the value model (guarantee, offer tier, urgency/scarcity) — angle barely matters.

## Sales motion → approach (route by ticket size + stakeholders)

- **Transactional** (low ticket, single buyer): fast close, minimal discovery.
- **Diagnostic** (standardized delivery + custom presentation): the highest-leverage middle — price by goal, deep discovery, kill objections early.
- **Enterprise** (high ticket, many stakeholders): kill zombies early — before the appointment, ask "is there anyone else required to make this decision?"; if yes, reschedule with all decision-makers present.

## Discovery sequence (Past → Present → Future, below the iceberg)

Past (what they tried, why it failed) → Present (cost of staying) → Future (worth of the gap).
Stay high-level (chunked-up) to keep closer control; alternate "give me an example" / "be more
specific" to extract problems, then chunk up to what you sell.

## Negotiation routing

- **BATNA-first:** only negotiate from a real alternative (another offer / multiple bids / multiple deals in play). Sell when you don't want to sell.
- **Increment anchoring:** state the highest defensible anchor first; concede far less than they do per round.
- **Reciprocity / variable expansion:** trade concessions across Speed / Price / Risk / Ease — give what is low-value to you, high-value to them, to hold price.
- **Discount → change-of-terms:** never discount straight; swap for referral intros or a higher-perceived-value / lower-cost bonus matched to the objection.

## Offer structure routing

- **Anchor-Core-Downsell:** present three tiers ordered anchor > core > downsell; position the core as the rational middle.
- **MESO:** present exactly three simultaneous offers, all acceptable to you, differing on price/terms; let them choose.
- **Objection → asset/bonus:** map each known objection to a content asset (send before/after the call) and to a stack bonus deployed only when that objection arises.

## Post-sale

Immediately after the close, route to a public-commitment action (text/call 3 people; a
three-way referral text at peak satisfaction) to pre-empt buyer's remorse.

## Registry anchors (do not redefine — see term_registry.json)

This topic leans on **Objection handle** (looping, kill-zombies, the four objection
frameworks), **Angle** (the leading emotional reason; reframing, conviction transfer),
**Awareness level** (Transactional/Diagnostic/Enterprise + discovery depth map to readiness),
**Value models** (anchor tiers, MESO, guarantee, discount-for-referrals), and **Trust signals
/ Extraordinary identifier** (conviction/authority, social proof in the stack). The negotiation
mechanics (BATNA, anchoring, MESO, reciprocity-variables) sit under Value models / Objection
handle — no new term needed.
