# Scoring specimens — the verbatim source lines FELT criteria are judged against

The single FELT criterion (the trust acid test, F1) is scored **pairwise against these**,
never on an absolute scale and never by the agent that produced the association/plan under
review. Return `prefer | tie | weaker`. A `weaker` contributes no pass — it is a triage
signal, not a certification.

Every line below is a verbatim substring of a source file (gated by `check_specimens.py`).

## Trust / vetting acid-test reference (judge F1 against these)
- "Acid test: would you send your sister, mom, or friend there"
- "Never risk the empire for a pot of gold."
- "Endorsement trust is transitive: if endorsement is untrustworthy, advice becomes untrustworthy"
- "Life transformation is legitimacy - if people's lives actually change, the brand is legitimate"

Ask: does the candidate association/partner feel as send-your-family trustworthy as these
demand? → prefer | tie | weaker.

## Saturation / differentiation reference (sanity-check the COUNTABLE gates)
- "5+ competitors saying the same thing = claim discounted regardless of copy quality"
- "Black t-shirt in a sea of white shirts"
- "No differentiator on mechanism AND avatar = do not run product"
- "99% of operators should stop at levels 1 and 2"
- "Exhaust one mechanism before moving to next"

## How to run the pairwise judge (F1 only)
1. Present the candidate association + one trust specimen, order randomized.
2. Ask which better satisfies the send-your-family acid test and why (reason before verdict).
3. Record `prefer | tie | weaker` + the reason. `weaker` contributes no pass.
4. Never let the agent that proposed the partner/association be the judge.
