# Per-criterion membership tests + the COUNTABLE gate definitions

Each criterion: a positive target, a FALSE-capable membership test, and its tier.
COUNTABLE = script-gated hard pass/fail. HEURISTIC = soft-cap / warn (never hard-fail).
FELT = pairwise-vs-specimen signal (`prefer|tie|weaker`), never a hard FALSE, never self-graded.

---

## COUNTABLE gates (hard-gate — a script decides; the value fails by shape)

**G1 Awareness-level tag present** *(target: every creative carries an explicit awareness-level tag before launch)*
- `tag ∈ {problem-aware, solution-aware, product-aware, unaware, most-aware}` is present on the ad? PASS iff present.
- FALSE example: ad submitted to launch with no awareness tag → FAIL (BLOCKED).

**G2 5+ saturation rule** *(target: a claim repeated by 5+ competitors is flagged discounted; do not lead on it)*
- `competitor_count_using_claim >= 5` → claim is `saturated` and must NOT be the lead angle.
- PASS iff (no lead claim is saturated) OR (each saturated claim is flagged + dropped from the lead).
- Anchors registry term **5+ saturation rule (for sophistication)**. FALSE: leading on a claim 5+ rivals already run.

**G3 Differentiator presence** *(target: product has a differentiator on mechanism OR avatar)*
- `differentiator_axis ∈ {mechanism, avatar, both}` is non-empty? PASS iff present on at least one axis.
- FALSE branch (verdict = do_not_run): neither mechanism nor avatar differs → "No differentiator on mechanism AND avatar = do not run product".

**G4 Revenue-gated avatar count** *(target: avatar breadth matches the revenue band)*
- Closed band map (monthly revenue → max avatars):
  - `$0–100K` → 1 avatar (deeper, not wider)
  - `$100K–500K` → 1 primary + 1 validated sub-avatar
  - `$500K–1M` → 2–3 avatars
  - `$1M–10M+` → expand further + brand weaponization
- PASS iff `planned_avatar_count <= band_max`. FALSE: $0–100K plan running 3 avatars.

**G5 Differentiation-matrix axis reset** *(target: either a new mechanism OR new avatar resets sophistication to Stage 1; both axes mapped before testing)*
- `mechanism_axis ∈ {new, existing}` AND `avatar_axis ∈ {new, existing}` both filled?
- If either axis = `new` → `sophistication_stage = 1` for that combination. PASS iff both axes mapped before the test sequence is committed.
- FALSE: testing sequence committed with an axis left unmapped.

**G6 Ad-account structure by spend** *(target: account complexity matches the $/day tier)*
- Note: source labels this "Levels of Scale — Ad Account Structure (5-Tier)" but names only 4 spend-band tiers (Tier 1–4) plus "Promo structure: applicable at any tier level." Promo structure is cross-tier (not a spend-band tier), so G6 maps the 4 spend-band tiers only.
- Closed tier map (spend/day → required structure):
  - `$0–3K` → Tier 1: single CBO
  - `$3K–10K` → Tier 2: + Raw Content campaign
  - `$10K+` → Tier 3: + ASC + Whitelisting
  - `$30K+` → Tier 4: segmented CBOs by collection/avatar
- PASS iff `structure_tier == band(spend)`. FALSE branch: Tier-4 complexity at Tier-1 spend ("kills signal and wastes budget").

---

## HEURISTIC caps (soft-cap — warn, never hard-fail; the detectors over-flag)

**H1 Black-t-shirt differentiation** *(target: your ad's claims differ from the competitor board's repeated claims)*
- Do your lead claims overlap the board's repeated claims? WARN if same; do not hard-fail (copy quality can still carry a near-match). Anchors "Black t-shirt in a sea of white shirts".

**H2 Avatar-first / never switch avatar** *(target: products cluster on ONE deeply-understood avatar)*
- Does the plan switch to a different avatar rather than build another product on the same one? WARN on switch; soft-cap (a genuinely validated new avatar at the right revenue band can be legitimate — see G4).

**H3 Delivery + Believability filter** *(target: product can deliver for most customers AND mechanism is plausible for the claimed desire)*
- Delivery: can the product deliver for most customers (not edge cases)? If NO → flag `do_not_run` (delivery-fail).
- Believability: is the mechanism plausible for the claimed desire? If NO → flag `mechanism_education_first`.
- Soft-cap: both have real false positives; warn + branch, never an automatic hard FALSE on the whole plan.

---

## FELT signal (pairwise-vs-specimen only — NEVER a membership gate)

**F1 Trust acid test** *(target: an association/partner feels trustworthy enough to send family to)*
Do **not** write a yes/no gate for F1. Judge pairwise against the trust specimens in
`references/scoring-specimens.md`: would you send your sister/mom/friend to this association
as readily as the specimens demand? Return `prefer | tie | weaker`. `weaker` contributes no
pass and never produces a hard FALSE — it caps confidence on partner/affiliate vetting.

## Why the tiers
Hard-gating a felt judgment ("is this partner trustworthy?") produces confident-but-wrong
FALSEs and invites gaming. Hard-gating a countable one (a count is or isn't ≥5; a revenue
band is what it is) is reproducible and safe. Soft-cap the in-between, because the
differentiation/believability detectors over-flag.
