# Brand frameworks, classification schemes & diagnostics (restored source content)

These are the felt brand-evolution frameworks, classification schemes, and diagnostic
notes that inform the score gates but are NOT themselves hard checks. No line budget here —
faithful to source. Specimens (quoted lines) are verbatim source substrings, gated by
`check_specimens.py`. Use these to *diagnose* a brand plan and to *interpret* why a gate
matters; do not turn the felt frameworks into hard FALSE gates.

---

## Three Brand Eras Framework (Alex Hormozi) — felt brand-evolution scheme

A personal brand naturally passes through distinct eras reflecting genuine shifts in business
focus and personal psychology. Each era has coherent visual identity, audience composition,
and content focus. The visual is secondary — value provided is the brand.

- **Era 1 (Fitness):** neon aesthetic, 70% female audience, fitness/nutrition focus, first gym
- **Era 2 (Gym Lord):** handlebar mustache for 5+ years, 90% male gym owner audience, business operations focus, 5,000+ locations
- **Era 3 (Acquisition.com):** utilitarian appearance, business owner/investor audience, ROI and acquisitions focus
- Language shift from 'Gym Rescue' (ego-threatening) to 'Gym Launch' (fresh start) — changed based on audience feedback
- Wore handlebar mustache for 5+ years because it reflected who he was; shaved it when it no longer did
- Dressing as non-public-facing operator in Era 3 ironically created more public exposure than intended
- The outfit is not the brand; value provided is the brand

Key benchmarks: Era 2 reached 5,000+ gym locations through licensing; Era 1 audience 70% female;
Era 2 audience 90% male gym owners.

Specimens (verbatim):
- "The visual is secondary: outfit is not the brand; value provided is the brand. Outfit is merely representation of who you are at that time."
- "Language shift from 'Gym Rescue' (ego-threatening) to 'Gym Launch' (fresh start framing). Changed based on audience feedback."

Related: see "Shifting Identity / Brand Eras" — personal brands must evolve as the person
evolves; forcing static identity when the authentic self has changed creates fraud feelings
audiences detect ("If brand expectations require fakery, distance grows between authentic
self and public persona. This eventually creates fraud feelings and erodes credibility.").

---

## Brand Metrics: Influence, Direction, Reach (Alex Hormozi) — measurement framework

Brand has three measurable metrics for diagnosing brand health:
1. **Influence** — how likely it changes behavior
2. **Direction** — are they moving toward or away
3. **Reach** — how many people it changes

A strong brand is not necessarily polarizing — Taylor Swift, Mother Teresa, and Apple are
large, strong, and positive without being polar.

- Strong brands don't have to be polarizing
- Brand building is like curating a garden: add good flowers, pull weeds
- One bad pairing can hurt the whole bouquet — recover by overwhelming with positive pairings
- New pairings always risk losing some audience but should net an increase
- Don't let 5 mean comments stop you from gaining 500 new people

Specimens (verbatim):
- "The single most important decision in evaluating business is pricing power. — Warren Buffett"
- "It takes 20 years to build a reputation and 5 minutes to ruin it. — Warren Buffett"

---

## Brand as Garden of Association — curation decision rule (Alex Hormozi)

Brand is the set of associations people learn to connect to you. Anything that doesn't
reinforce the specific association you want — even if neutral or positive in isolation —
dilutes the brand.

- Garden metaphor: anything not the target flower (rose) is a weed, even beautiful flowers like sunflowers or daffodils
- **Even acceptable content that doesn't align with your target association dilutes it** (the actionable curation rule)
- Vigilant curation of all brand touchpoints compounds into trust, which becomes deal-making leverage
- First product delivery is the only marketing that drives all future sales to existing customers

Specimens (verbatim):
- "Branding is like curating a garden. Pretty much anything but the flower that you're trying to grow is a weed."
- "All of the ideas and obsessions around how it was going to market and how I was going to position it—the thing that mattered most was what they had already received from me and how much I had delivered on my first promise."

---

## Brand Foundation vs Product Foundation — classification scheme (Alex Hormozi)

Two foundation types exist; use to decide what foundation a venture needs:
- **Brand foundation:** building reputation and associations over time (e.g. 5 years of content before a product launch), without intent to transact
- **Product foundation:** coding, manufacturing, regulatory work
- **Service businesses require neither**, making them ideal for starting out
- Having one or both foundations enables building something bigger on a longer time horizon
- Bamboo analogy: 5 years of roots, then it shoots up

Specimens (verbatim):
- "From a brand foundation perspective it's how can I build a reputation over a long period of time not necessarily with the intent to transact but simply to build a reputation"
- "They spent 5 years letting the roots go down for the bamboo tree and then eventually it shoots up"

---

## Affiliate Strategy with Brand-Additive Partners — execution rules (Alex Hormozi)

The score skill's F1 trust acid-test vets WHETHER to take an affiliate; these are the
execution rules for HOW to select and structure affiliate relationships:

- **Choose affiliates representing different looks/demographics to capture wider market**
- **Affiliates are a bidirectional brand relationship** — they influence your brand and you influence theirs
- **Treat affiliates as another tier of customer — make them an offer so good they feel stupid saying no**
- **Provide turn-key promotional materials (banners, links) so it's easy for them**
- The best brand deals benefit both parties and increase goodwill on both sides

Benchmarks: School is 65% affiliate traffic; Allen (software) built entirely off affiliates;
Prestige Labs built off gym owner affiliates.

Specimens (verbatim):
- "The Affiliates that you choose have a huge influence on your brand. It's a bidirectional relationship"
- "Affiliates compound - they become permanent nodes of distribution for you"

---

## Diagnostic: Why Bad Marketers Get Rich Quickly (Mechanism Exploitation) — Spencer

Explains the runway/skill interaction behind the mechanism gates (G3 / R7 / R11):
- Unskilled operators accidentally hit new mechanism + low-sophistication product → boom-then-crash (typically 6 months)
- The mechanism is doing the work, not their skill — they can't replicate or maintain it
- Best outcome = skilled marketer + new mechanism product (skill extends the runway)
- Dubai chocolate as worked example: new novelty mechanism + low awareness stage = viral cycle regardless of marketing quality

---

## Diagnostic: Market Saturation Acceleration — Spencer (why G2/G3/G5 matter)

Context for the sophistication gates:
- Timeline compression: historical 6-year sophistication cycle → now 3–6 months due to social media
- 75% of customers now research before purchasing (vs. minority previously)
- Practitioner diagnostic: "99.9% of e-commerce operators are in Stages 3–5"
- Named brand examples per stage:
  - Stage 1: genuinely new product (early Ozempic, early AirPods)
  - Stage 2: early mass market (BlackBerry, Nokia)
  - Stage 3: feature competition (iPhone features, Nike performance claims)
  - Stage 4: claim escalation (anti-aging industry)
  - Stage 5: identity/status play (Rolex, Supreme)

---

## Diagnostic: CTR as Awareness Stage Proxy — Spencer (interpret a failed-ad CTR via its G1 tag)

A decision rule tying CTR back to the G1 awareness-tag gate — when an ad fails, read its CTR
through its awareness tag:
- CTR = hook resonance signal = self-identification signal at the awareness stage
- If hook is calibrated correctly to awareness stage → CTR lifts
- Video ads demand tighter awareness calibration than statics (more time = more expectation of stage-appropriate content)
- When winning message identified: update PDP for full-funnel congruency — message must match from hook → LP → checkout
