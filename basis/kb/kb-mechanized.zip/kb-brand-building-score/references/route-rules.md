# ROUTE rules — named-trigger selection / sequencing (contract, not quality verdicts)

These select or order a response by a NAMED trigger. They dictate no wording and judge no
quality — they are the contract a consumer follows. Each is a `when X → do Y` rule.

## R1 Brand Damage Control Matrix (select response by attacker size × claim type)
- smaller attacker + lying → ignore + 10x your own message.
- bigger attacker + attacking → make them seem petty via humor.
- NEVER attack back; STOP repeating "I am not X" (repetition associates you with X).
- positive target: every attack maps to exactly one quadrant before any response ships.

## R2 Review-mining method selection (conflict resolved by use case)
- large-volume pattern detection across big datasets → AI/ML.
- sub-avatar discovery + nuanced language mining → manual.

## R3 Sophistication Counter Hierarchy (apply IN ORDER 1→2→3)
1. New Information → 2. New Mechanism → 3. New Identity.
- "99% of operators should stop at levels 1 and 2"; Level 3 only with sustained brand investment.
- **Why the order matters (interdependency rationale — restored):** the three responses
  (New Mechanism + New Information + New Identity) are NOT interchangeable; they compound in
  this order. Mechanism requires information to explain why it works; information primes
  mechanism receptivity; identity amplifies both. Sequence the order, do not pick one in
  isolation.

## R4 Hook pattern per awareness level (selection only; wording belongs to the copywriting topic)
- problem-aware → symptom callout.
- solution-aware → category + better solution.
- product-aware → named mechanism or brand.

## R5 Cyclical reset path (select by reset trigger)
- Stage 5 → Stage 3 via new mechanism introduction.
- Stage 5 → Stage 1 via genuinely new product category.
- Calibration anchor (source worked example): new mechanism (GLP-1 pathway) reset a saturated weight loss market from Stage 5 to Stage 1 for a new audience.

## R6 AI New-Mechanism Discovery procedure (sequence)
run prompt (product name + product URL + sophistication PDF) → generate candidates →
validate against research → select most defensible.

## R7 New-Mechanism Testing (5-step, ordered; exhaust one before the next)
map mechanism→desire → build multiple variations per mechanism → place mechanism in BOTH
hook AND body → test before scaling → "Exhaust one mechanism before moving to next".

## R8 Competitive Foreplay Board sequencing
run the board (catalog repeated claims as saturation signals) BEFORE angle selection — not after.

## R9 Desire Elevation selection (select level by pricing goal)
six-level hierarchy: Belonging → Comfort → Control → Sex/Relationships → Status → Health.
move UP for premium pricing / less competition; blue ocean = the level competitors have abandoned.

## R10 New-Mechanism Category Creation (5-step audit, ordered) — restored
Distinct from R7 (mechanism *testing*) and R8 (the Foreplay board): this is the ordered
audit for *creating a new category label* when a claim is saturated.
1. Identify saturation signal (5+ competitors saying same thing = saturated claim)
2. Create new category label (name what they can't call it)
3. Test for credibility (does the new label make claims that are verifiable or defensible?)
4. CPC-reduction rationale: new framing = no ad fatigue against existing creative
5. GLP-1 worked example: "GLP-1 boost" (saturated) → "GLP-1 protect" (new category, different mechanism angle)

## R11 New-Mechanism Differentiation taxonomy (classify which mechanism type you have) — restored
Anchors / extends G3 (which only checks differentiator *presence*). Use these five types to
IDENTIFY which mechanism type you're working with before testing:
1. Product modification (physical feature others don't have)
2. Formulation (ingredient or compound that works differently)
3. Avatar flip (same product, radically different customer — see Stanley Cup)
4. Competitive comparison (named competitor's failure mode)
5. Feature-from-reviews (mechanism discovered in customer descriptions, not marketing materials)
- Decision rule (anchors G3 FALSE branch): "No differentiator on mechanism AND avatar = do not run product".
