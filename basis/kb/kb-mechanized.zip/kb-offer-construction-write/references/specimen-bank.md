# Specimen bank — verbatim winning offer copy, with why each works

Preserved verbatim from the offer-construction source files. These are the highest-value
asset in the skill — study and adapt, do not abstract into ordered templates. Each specimen
shows the *form* of a good answer; that is what steers a model.

## Risk-reversal / guarantee copy (make the worst case attractive)

- "Best case scenario, you change your life forever... Worst case scenario, you work out for 6 weeks basically for free. You tell me I suck and I give you your money back."
  — two-outcome collapse; the downside is reframed as nearly free, and the guarantee is voiced
  the way the buyer would say it, not as legal language.
- Guarantee phrasing fragments to adapt: "risk-free trial," "no questions asked," "no hoops";
  Performance Golf positioned a one-year guarantee with "110% satisfaction" threshold language.
  — confidence-signal framing (the guarantee says *we are sure*), not safety-net framing.

## Outcome-reframe close (sell the after-state as already true)

- "When you pay $4,500, you can count that weight gone. You can put it out of your mind. We're going to get there one way or another as long as you follow the steps."
  — price reframed as the purchase of a finished result; "one way or another" transfers
  responsibility to the seller and removes the buyer's fear of doing it wrong.

## Value-stack / leverage payoff (cost-to-price gap is the whole game)

- "That's how you increase leverage to sell an offer set for 25 bucks for a hundred thousand dollars."
  — the concrete two-number contrast carries the lesson; no adjective does any work.
- Craft bar for stacking, stated by the source: "Each thing we add on its own should be worth the price of the whole thing."
  — the test for whether a bonus belongs in the stack; do not turn it into a per-bonus hard
  gate, use it as the bar you write toward.

## Bonus value-line (named, valued, outcome-first)

- Source bonus-line pattern: "you get X ($497 value) free" — listing each bonus at its
  standalone retail value inflates perceived total package value and beats an equivalent
  price discount. Adapt the dollar figure and the named bonus; keep the (value) free shape.
- "Name bonuses with outcome-oriented titles (not generic labels)" — the title sells the
  result the bonus unlocks, not the format of the thing.

## Narrative repositioning (rename the commodity)

- "30-Day Mojo Mastery Challenge" used in place of the label "testosterone booster" as the offer name.
  — a proprietary-sounding name carrying an outcome and a timeframe replaces the bare category
  label; perceived novelty drives conversion independent of actual product newness.

## Mechanism naming (make the method ownable)

- "muscle confusion" (P90X); "point system" (Weight Watchers).
  — a short, memorable name for *how* the result is delivered turns a method into an asset; reach
  for rhyme or alliteration. P90X sold hundreds of millions using "muscle confusion" as its
  unique mechanism.

## Buyer-language craft target

- "Dream outcome must be stated in the buyer's language, not the seller's terminology" (source craft target).
  — the governing rule for every line above: lift the buyer's own words for the transformation.
