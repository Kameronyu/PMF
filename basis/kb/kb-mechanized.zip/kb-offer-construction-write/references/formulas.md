# Optional formulas — anatomy + a worked example each

Reach for one when it fits the offer. None is a required slot order; forcing a fixed
sequence is what produces same-y, compliant offer copy. Use these to vary, not to standardize.

## Risk-Reversal (best/worst case)

[best case: the dream outcome, fully realized] + [worst case: reframed as nearly free / no real
loss] + [guarantee voiced in the buyer's own words].
- Collapses the decision to two outcomes and makes the floor attractive, not just covered.
- Example: "Best case scenario, you change your life forever... Worst case scenario, you work out for 6 weeks basically for free. You tell me I suck and I give you your money back."

## Outcome-Reframe Close

[name the price] + [the result it buys, stated as already true] + [seller takes responsibility
for getting there].
- Reframes a payment for a service into the purchase of a finished after-state.
- Example: "When you pay $4,500, you can count that weight gone. You can put it out of your mind. We're going to get there one way or another as long as you follow the steps."

## Narrative Repositioning

[outcome word] + [timeframe] + [proprietary-sounding format noun] — replacing the bare category
label.
- Use when the desire is saturated by existing products: a new name plus a new mechanism lets you
  claim the desire again.
- Example: "30-Day Mojo Mastery Challenge" instead of the label "testosterone booster" as the name.

## Bonus Value-Line

[outcome-oriented bonus name] + [($ standalone retail value) free], listed separately from the
core price.
- Listing each bonus at retail value inflates perceived total package value and beats an
  equivalent discount; total stated value should reach or exceed the core price.
- Example shape from source: "you get X ($497 value) free."

## Mechanism Naming

[short memorable name — reach for rhyme or alliteration] for *how* the result is delivered (not
what the product is).
- Turns a method into an ownable asset the buyer can repeat and the competition cannot copy.
- Examples: "muscle confusion" (P90X) · "point system" (Weight Watchers).

### Discovery before naming — Assumed New Mechanism 5-Category Checklist

Before you can name a mechanism you have to *find* one. Run this structured discovery prompt
against the product to surface a genuine differentiator to name (rather than inventing a label
for nothing). Walk all five categories; any one can be the seed of the named mechanism.

Assumed New Mechanism 5-Category Checklist (structured discovery prompt):
  1. Application system (how it's used)
  2. Hardware grade (material/quality differentiator)
  3. Functional placement (where on body/environment)
  4. Integrated systems (what it works with)
  5. Comfort engineering (experience while using)

## Two-Product Reality (Functional Product Mapping) — precondition before building the offer

Before building offer, map the functional product explicitly. The offer copy sells the
*functional* product (the outcomes), not the literal SKU. Do this map first; copy written
straight from features without this bridge consistently underperforms.

**Two-Product Reality (Functional Product Mapping)** [augments existing Offer section]
- Before building offer, map the functional product explicitly:
  - List all problems solved
  - List all benefits delivered
  - List all experiences created
- Features without a functional bridge to customer outcome consistently underperform

## Magic Questions for Feature Prioritization — deciding what stays in the stack

The Trim-and-Stack craft bar ("each thing we add should be worth the price of the whole thing")
says *how good* a stacked item must be. This is the paired method for *deciding which* items
earn the slot — two inverse questions asked to real customers to build a power ranking of
features by perceived value, so you can distill the offer to maximum value for the most people.

- Question 1: 'If I eliminated all features except one, what would it be?' reveals highest value
- Question 2: 'If I eliminated one feature and it changed nothing about your life, which one?' reveals lowest value
- Ask 100 people to create a power ranking of feature value
- Continuously cut, trim, and distill value based on ongoing customer feedback
