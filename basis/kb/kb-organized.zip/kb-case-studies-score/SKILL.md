---
name: kb-case-studies-score
description: >-
  Verdict an e-commerce diagnosis or positioning situation against the case-study gates before
  you act on it, so you stop blaming the ad when the page is broken. Use when deciding if a
  bottleneck is on-site or an ad problem, whether to raise or cut spend during an LP rebuild,
  whether a market is too saturated, or which positioning/desire/delegation move a situation
  triggers. Covers: the 3 countable hard-gates (5+ same-mechanism saturation = FAIL, CTR ≥ 3%
  + zero purchases = on-site, raise-spend during rebuild); 7 trigger-routed moves (dual-lever
  reset, avatar flip, delegation sequence, desire-spike, mechanism discovery); verbatim
  source-case evidence; ≤5 negatives; PASS/FAIL/ROUTE output contract. Does NOT cover scoring
  a product's viability or entry difficulty before you buy in — use kb-product-research-score
  for that; classifying which differentiator axis a product uses — use
  kb-differentiator-score; grading a VOC/qualitative-research PLAN plus analyst synthesis —
  use kb-customer-data-score. This skill SCORES against a rubric. Triggers: "is this an
  on-site problem or an ad problem", "should I raise spend", "is this market too saturated",
  "which channels can this product support".
---

# Case studies — verdict the situation before you act on it

Three things this skill does: (1) HARD-GATE the countable diagnoses (saturation, on-site
vs. ad, spend-during-rebuild) to PASS/FAIL; (2) ROUTE a positioning/desire/delegation move
by its named trigger; (3) attach the verbatim case that earns each call. **Do not run this
in the same pass that diagnoses or strategizes** — a strategist grading its own plan rates it
higher. Score against the cases in `references/case-specimens.md`.

Tier discipline: **hard-gate only the countable** (a competitor count, a CTR threshold, a
purchase count are what they are); **keep selection-by-trigger as a ROUTE contract**; **a
felt fit is a pairwise-vs-specimen signal, never a hard FALSE.** Never redefine a registry
term (`5+ saturation rule`, `market sophistication`, `UM`, `desire`, `awareness level`) —
anchor to it.

## The 3 COUNTABLE gates (each: positive target → script test → tier)

1. **Saturation = failure** — *target:* when ≥5 competitors run the same base mechanism/
   claim, classify the undifferentiated entrant **FAIL** and require a new mechanism OR new
   avatar. *Test:* `competitor_count >= 5 AND same base mechanism` → FAIL. Tier: COUNTABLE →
   hard-gate. Anchors registry **5+ saturation rule (for sophistication)**.
2. **On-site vs. ad bottleneck** — *target:* if CTR ≥ 3% AND purchases = 0, the bottleneck
   is **on-site (landing page), not the ad** → action: iterate LP. *Test:* `ctr >= 0.03 AND
   purchases == 0` → ON-SITE. Tier: COUNTABLE → hard-gate.
3. **Raise spend during LP rebuild** — *target:* if CTR ≥ 3% (soft healthy) AND purchases
   broken, the correct action during an LP rebuild is **INCREASE ad spend** (volume to measure
   the fix). *Test:* `ctr >= 0.03 AND purchases_broken AND rebuilding_lp` → RAISE-SPEND.
   Tier: COUNTABLE → hard-gate.

Per-gate membership tests + the COUNTABLE definitions (what "same base mechanism", "broken",
the CTR threshold mean) are in `references/gate-tests.md`.

## The 4 ROUTE rules (selection/sequencing by named trigger — no verdict, no wording)

Keep these as contract: the named trigger SELECTS the move; it does not grade quality.

- **Desire strength → viable channels/price points** *(trigger: desire strength)* — strong,
  time-bound, identity-stakes desire supports paid ads + high ticket; weak desire → organic
  only, cannot carry paid CAC.
- **Dual-lever positioning** *(trigger: max sophistication reset wanted)* — select new
  mechanism + new avatar simultaneously (each axis alone resets to Stage 1; both = max reset).
- **Avatar-flip lever** *(trigger: Stage 4–5 saturated, no product change available)* —
  select avatar flip to reset sophistication to Stage 1; product change unnecessary.
- **Delegation sequence** *(trigger: scaling creative via editors)* — order is self-edit →
  structured delegation brief → trained editor; skipping to delegation = bad briefs.
- **New-avatar-from-comment** *(trigger: validated outlier comment)* — contact → call →
  transcribe → validate → build dedicated creative for the new avatar.
- **Desire-spike / news-monitoring** *(trigger: category news event)* — hold creative constant,
  scale spend into the spike.
- **Mechanism discovery** *(trigger: need a differentiator)* — run the structured AI mechanism
  prompt (product name + URL + sophistication PDF) + mine competitor reviews.

Trigger→move tables and the verbatim source cases are in `references/route-rules.md`.
Full case data (every source section: market/avatar/mechanism/CRO/email/ops/positioning) is in
`references/case-library.md`; non-gated CRO/email/ops/positioning decision rules are in
`references/heuristics.md`. A new mechanism buys a 6–12+ month runway before Gate 1's 5+ count
fires (see `references/gate-tests.md`).

## The negatives live here (≤5), each paired with a positive target

Held in the checker, not the strategist (where banning a move summons it):

- **Blaming the ad when CTR ≥ 3% and purchases = 0** → flag; the bottleneck is on-site. (positive: iterate the LP)
- **Cutting spend during an LP rebuild while CTR is healthy** → flag. (positive: raise spend to gather measuring volume)
- **"Better creative" to rescue a ≥5-competitor same-mechanism market** → flag FAIL. (positive: new mechanism OR new avatar)
- **Putting paid spend behind a weak-desire product** → flag. (positive: organic-only channel)
- **Delegating to an editor before self-editing** → flag. (positive: self-edit → brief → editor sequence)

## Output contract (per situation)

```
situation: "<verbatim or paraphrased input>"
countable_gates: [ {gate, target, verdict: PASS|FAIL|ON-SITE|RAISE-SPEND, evidence_quote, source} ]
routed_moves:   [ {rule, trigger_observed, selected_move, evidence_quote, source} ]
felt_signals:   [ {what, vs_specimen: prefer|tie|weaker} ]   # optional fit calls, never a hard FALSE
flags: [ ... ]    # from the negatives list
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every fired gate has a verdict; every observed trigger has a routed move.
**SOUNDNESS:** every COUNTABLE verdict came from the script test (counts/threshold, not
eyeballed); every routed move names the trigger that selected it; each PASS/FAIL/route carries
an `evidence_quote` that is a verbatim substring of a source case; no felt signal was promoted
to a hard FALSE. `emit_ready` only if SOUNDNESS holds; else `BLOCKED:<gate-or-rule>`.

## Self-test (is this grader sound?) — any NO, fix

- Are only the three countable gates hard-gated (by competitor count / CTR / purchases)?
- Are the four positioning/desire/sequence moves kept as ROUTE selection rules, not verdicts?
- Is the felt fit (if used) pairwise-vs-specimen, never a hard FALSE, never self-graded?
- Is this run as a separate pass from the diagnosis/strategy that produced the situation?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Is every quoted case a verbatim substring of a source file (no composites, no paraphrase-inside-quotes)?

## See also

- `kb-conversion-optimization-score` — adjacent skill — check its scope/boundary before routing here
- `kb-product-research-score` — adjacent skill — check its scope/boundary before routing here
- `kb-social-proof-score` — adjacent skill — check its scope/boundary before routing here
