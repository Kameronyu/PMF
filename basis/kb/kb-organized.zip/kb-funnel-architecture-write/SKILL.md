---
name: kb-funnel-architecture-write
description: >-
  Write the felt copy that carries a funnel from ad to checkout — advertorial heroes,
  congruent landing-page headlines, first-person transformation leads, low-friction quiz hook
  questions. Use when drafting or rewriting the wording inside a chosen funnel page so the ad
  angle survives onto the page and the reader never feels sold to. Covers: winning specimens
  to steer from, craft targets (congruency, articulating the pain, no sold-to feel,
  specificity, outcome-over-features), awareness-stage page-form routing, CTA placement, and
  the quiz first question. Does NOT cover full long-form advertorial body copy — use
  kb-advertorial-write for that; full quiz question/diagnosis/loading-screen flow — use
  kb-quiz-funnel-write; section-by-section copy for a SINGLE landing/product page — use
  kb-landing-pages-write. This skill WRITES prose; pair with kb-funnel-architecture-score.
  Triggers: "write the advertorial headline", "rewrite this landing page so it matches the
  ad", "draft the quiz hook question".
---

# Funnel copy — write the words that move someone from current state to purchase-ready

A funnel is a chain of pains and beliefs; each page exists to build the next belief in order.
Your job here is the *wording* a reader feels on a given page — the hero that stops them, the
headline that proves the ad told the truth, the first question that costs nothing to answer.
Lead from the specimens below. Reach for structure only to pick the page's FORM; the words
are yours to feel out.

## Start here — real winning specimens (study these before writing)

Preserved verbatim from the source. They steer you harder than any rule. Keep the whole
specimen as the asset — the example is what steers a model; the slot label is secondary.

- **Advertorial hero (outcome/threat framing, not a feature):**
  *"Save your skin, hair and health from disaster with this disruptive shower head"*
  — emotionally charged verbs ("save," "disaster") frame an outcome and a threat the reader
  already fears; the product arrives as the rescue, not the subject. This carried a funnel
  short enough to go advertorial → order page.

- **Congruent landing-page headline (ad → page message-match):**
  *"anywhere all weather shoes made for adventuring"*
  — the winning ad was a travel photographer shooting waterproof shoes in Iceland; the page
  headline repeats that exact promise in the reader's own desire-language. Narrative
  consistency is the conversion driver, not feature copy. The page proves the ad was true.

- **First-person transformation lead (POV-story advertorial):**
  *"From foot pain victim to pain-free in 30 days"*
  — names the before-state (victim), the after-state (pain-free), and a concrete timeframe
  (30 days) in one breath. Written as a relatable consumer's story, not an expert's pitch —
  so it reads as someone like the reader, which is why it disarms.

- **Quiz hook question (low-friction, self-identifying):**
  *"What's your biggest challenge with X?"*
  — the first question must cost nothing to answer and must be about the prospect's own
  problem, not the product. It lets the reader name their pain; you segment off the answer.

More specimens and the angle each executes are in `references/specimen-bank.md`.

## Craft targets (steer by these; they are not a rulebook)

- **Congruency above all.** The page must repeat the winning ad's angle, language, and visual
  promise. If the reader can tell the ad and the page were written by different people, trust
  breaks and conversion drops. Mirror the ad's exact angle and language on the page.
- **Articulate the problem better than the prospect can themselves.** Enter the pain they
  already feel and name it more precisely than they would — that earns the right to the pitch.
- **Doesn't feel sold to.** Advertorial copy reads as editorial or a personal story, third-person
  or first-person, not as an ad. Reduced resistance is the whole mechanism; a salesy line leaks it.
- **Specificity over superlative.** A named before/after state and a concrete timeframe
  ("pain-free in 30 days") beat "amazing results." Concrete scarcity ("only seven pairs left")
  beats "limited time."
- **Outcome and threat, not features.** Lead on what the reader saves, becomes, or escapes.
  The feature is the mechanism that backs the claim, introduced after the desire is live.

## Optional patterns (reach for one that fits the awareness stage)

These are shapes to borrow when they fit the awareness stage, not required sequences. Anatomy
and a worked note for each is in `references/page-patterns.md`.

POV-story advertorial · Authority advertorial · Listicle ("Seven Reasons Why") ·
Congruent LP headline · Quiz hook question · Pre-sale warming lead.

## Contract rules (these DO bind — they pick the FORM, not the words)

These route which kind of page you are writing and where the felt beats fall. They never
dictate wording.

- **Awareness routing.** Unaware / problem-aware → advertorial or POV-story copy; lead with the
  reader's pain and keep the product later. Skeptical / educated → authority (expert-authored) advertorial.
  Solution-aware / product-aware → sales page or VSL copy. Offer-aware only → direct offer /
  BOGO page copy.
- **Page job.** A PDP sells the product; a sales page sells the outcome/transformation. Write to
  the job of the page you are on — outcome language on the sales page, product specifics on the PDP.
- **Congruency is mandatory at every touchpoint.** Ad → page → checkout must carry the same
  angle, language, and visual valence. Write the page headline to mirror the winning ad line.
- **CTA placement.** Introduce the call to action 50–75% through the page, after the belief
  chain is built.
- **Quiz first question.** It must be low-friction and about the prospect's self-identified
  problem; keep it focused on the reader's pain rather than the product.

For full funnel-type selection by awareness stage and the page-section sequences (advertorial
8-step, pre-sale 4-part, six sales-page sections), see `references/route-contract.md`. Those are
structural contracts — they set the order of beats, never the wording inside a beat.

## How to use this with the grader

Draft several diverse versions (vary the angle and the page form across drafts). Then hand them
to **kb-funnel-architecture-score** — a separate skill, ideally a different model — for the
benchmark gates (CPM, CTR, ATC, CVR, AOV thresholds), the diagnostic routing, and the
pairwise-vs-specimen congruency judgment. The separate scorer is what grades; the threshold and
banned-phrase checks live there, not here. A writer that judges itself optimizes toward "looks
like an advertorial," so leave the grading to the scorer and keep generating diverse copy.

## Before handoff (what kb-funnel-architecture-score checks)

Generate several diverse drafts; the separate scorer grades — do not self-grade toward the gate.
These are the dimensions the scorer will look at, kept here only as awareness while you write:

- Whether the page headline mirrors the winning ad's angle and language so the ad reads as true.
- Whether the copy enters the pain the reader already feels and names it more precisely than they would.
- Whether it reads as editorial or a personal story rather than an ad — no sold-to feel.
- Whether it carries at least one concrete specific (named before/after state, timeframe, or scarcity).
- Whether the page is written to its job (outcome on a sales page, product on a PDP).

## See also

- `kb-funnel-architecture-score` — WRITE/SCORE sibling — score a draft this skill writes (separate pass)
- `kb-quiz-funnel-write` — adjacent skill — check its scope/boundary before routing here
- `kb-advertorial-write` — adjacent skill — check its scope/boundary before routing here
