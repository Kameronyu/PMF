---
name: kb-landing-pages-write
description: >-
  Write landing-page copy and section-level prose that turns the scroll into a click — hero
  headlines, benefit sections, urgency/offer copy, objection-handling lines, listicle bridge
  hooks. Use when drafting or rewriting the wording on a product page, advertorial-style
  bridge page, listicle pre-sell, or Trojan homepage, and when routing by awareness/traffic
  temperature or product archetype. Covers: winning hero/urgency/USP/curiosity specimens;
  craft targets (enter the desire, specificity over superlative, mirror buyer language);
  optional page blueprints (hero order, eight-section sequence, sales-conversation mirror,
  Coconut/FEMA models); awareness routing and the copy→media→design and congruency contracts.
  Does NOT cover grading the page against gates — use kb-landing-pages-score for that; on-page
  e-commerce cart/checkout/savings microcopy — use kb-cro-write; the long-form educational
  pre-sell article — use kb-advertorial-write; copy that carries the WHOLE funnel
  ad-to-page-to-checkout (cross-page congruency) — use kb-funnel-architecture-write. This
  skill WRITES prose; pair with kb-landing-pages-score. Triggers: "write landing page copy",
  "rewrite this hero", "draft the offer section", "headline for this product page".
---

# Landing pages — write the copy that converts the scroll into a click

A landing page is the wording, in sequence, that walks a visitor from "why am I here" to "I'll
buy." Your job is the *copy a visitor feels* — the headline, the benefit line, the objection
answer — not the wireframe. Lead from the specimens below. Reach for a blueprint only to order
your sections; let the specimens steer the words inside them. The single most important factor
across all three elements is **clarity**. Confused minds do not buy.

## Start here — real winning specimens (study these before writing)

Preserved verbatim from the source. They steer you harder than any rule. Full bank with the
job each does is in `references/specimen-bank.md`.

- **Desire-led hero headline** (not feature-led): *"Reveal Your Most Radiant Glow"*
  — names the identity outcome the buyer already wants; no ingredient, no spec. The reader sees
  themselves *after*, not the product. This is the headline to beat on a desire-based page.
- **Urgency anchor (countdown copy):** *"Limited time 30% off – ends in 5 minutes"*
  — a concrete discount + a concrete clock. The number and the deadline do the work; "limited
  time" alone is wallpaper, the *5 minutes* is the pressure.
- **USP / not-comparable line:** *"You don't need to compare because it's not comparable"*
  — preempts the Google/Amazon comparison shop by reframing the category instead of out-arguing
  rivals on features. Disarms market-sophistication price-checking in one sentence.
- **Curiosity + social-proof listicle hook:** *"Discover what 3 million+ people are going crazy over"*
  — an open loop on *what* it is, fused to a FOMO social-proof count of 3 million-plus. Sells the
  click, not the product — the right job for a cold-traffic bridge page.
- **Education-first curiosity hook:** *"Discover the panties the internet goes crazy about"*
  — opens a loop on a novel/category-creating product so the reader stays to be *taught* before
  being sold; pure persuasion here would spike refunds.
- **Clarity as the spine:** *"Confused minds do not buy."*
  — the test for every line you write: does it reduce cognitive load or add it?

## Craft targets (steer by these; they are not a rulebook)

- **Enter the desire the reader already has.** Lead with the identity/outcome they want
  ("Radiant Glow"), not the feature that produces it. State the *after*, let the page earn the *how*.
- **Specificity over superlative.** A real number, a named deadline, a concrete contents list
  beats "fast," "amazing," "premium." *30% off, ends in 5 minutes* > "huge sale."
- **Mirror the customer's own language.** Copy that converts is researched from how buyers
  actually talk, then handed back to them — not written from the brand's perspective.
- **Each section does one psychological job.** A benefit section sells desire; a guarantee
  neutralizes risk; a comparison disarms price-shopping. Don't make one block do two jobs.
- **Solve a *specific* objection, by name.** A testimonial or line that answers the one doubt
  this buyer holds ("won't it feel like a diaper?") outpulls generic praise every time.
- **Clarity over cleverness.** If a line makes the reader work to understand it, it leaks. Cut it.

## Optional blueprints (reach for one to order sections; let the specimens steer the words)

These pick the *shape and sequence of a page*, not the wording inside it. Choose the one that
fits the traffic and product, then write each section from the specimens + craft targets above.
Full anatomy of each is in `references/blueprints.md`.

Hero element order · Eight-section psychological sequence · Long-form 5–8 section architecture ·
Four-section benefits sequence · Sales-conversation mirror · Trojan homepage · Listicle bridge.
Each is a frame to borrow, not a required sequence for your sentences. See
`references/blueprints.md` for the full Coconut (desire-based) and FEMA (education-first) model
playbooks — per-model execution checklists for the page spine.

## Contract rules (these DO bind — they pick the page shape and the offer, not the words)

- **Awareness / traffic-temperature routing:** for **cold / top-of-funnel** traffic, write a
  *listicle bridge page* — a curiosity headline + 5–7 image benefit points + a CTA to the
  product page (lead with trust-building curiosity that earns the click). For **product-aware** traffic, write the full
  product/offer page.
- **Archetype by product type:** **desire-based** products lead with an aspirational identity
  outcome (Coconut model — "Reveal Your Most Radiant Glow"); **novel / category-creating**
  products lead **education-first** (FEMA model), naming and neutralizing the dominant objection
  before persuading.
- **Optimization priority:** spend effort in order **copy → media → design**. Write and validate
  the copy first; address design only where it creates friction.
- **Congruency contract:** the page's imagery, models, and value propositions must match the ad
  creative that drove the click — same promise, same faces.
- **Distribute trust:** spread testimonials and social proof *throughout* the
  page across scroll depths, placing fresh proof at each scroll depth where a new doubt arises.

## How to use this with the grader

Draft the page — vary the archetype and the headline angle; generate several diverse drafts.
Then hand it to **kb-landing-pages-score** — a separate skill, ideally a different model — for
the gates (section count, social-proof threshold, discount band, congruency, distribution) and
the pairwise-vs-specimen judgment on the felt copy. Do not grade your own output here; a writer
that judges itself optimizes toward "looks like a landing page," not "converts." The countable
thresholds and pitfall checks live there, not here.

## Before handoff (what kb-landing-pages-score checks)

Generate several diverse drafts; the separate scorer grades — do not self-grade toward the gate.
These are the dimensions that scorer attends to, kept here as awareness:

- The hero names the desire/outcome the buyer already wants before any feature or spec.
- The urgency/offer copy carries a concrete number and a concrete deadline.
- The archetype follows from traffic temperature + product type, with sections written from specimens.
- Each section does one psychological job, and at least one element answers a *named* objection.
- Every line reduces cognitive load — clarity is the spine.

## See also

- `kb-landing-pages-score` — WRITE/SCORE sibling — score a draft this skill writes (separate pass)
- `kb-cro-write` — adjacent skill — check its scope/boundary before routing here
- `kb-funnel-architecture-write` — adjacent skill — check its scope/boundary before routing here
