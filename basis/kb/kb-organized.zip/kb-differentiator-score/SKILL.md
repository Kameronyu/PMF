---
name: kb-differentiator-score
description: >-
  Classify a product's differentiator and return RUN / DONT-RUN before you spend a dollar
  testing it. Use when you must decide which axis a product wins on, when a chooser needs an
  independent second pass on its own pick, or when something looks undifferentiated (the Hair
  Dryer case). Covers: the closed axis enum (Market / Mech-UM / Angle / Offer / Dual / None),
  the transformation-change test that splits Market from Angle, the no-axis DONT-RUN hard
  gate, lever-on-list membership, and the per-product output contract. Does NOT cover overall
  product/offer/page viability gates — use kb-ecommerce-score for that; positioning and
  ad-account go/no-go — use kb-brand-building-score. This skill SCORES against a rubric.
  Triggers: "what's the differentiator", "which axis does this use", "Market or Angle?", "is
  this worth running".
---

# Differentiator — classify the axis before you run

Given a product, decide which differentiator axis it uses and whether it clears the bar to
run. **Do not run this in the pass that picked the product** — a chooser grading its own pick
rates it higher. Score against the anchors in `references/case-studies.md`.

Tier discipline: **hard-gate only the countable** (the no-axis DONT-RUN gate);
**axis labels are membership tests** (checkable via the transformation-change test + lever
presence); **strength-of-differentiator is pairwise vs a case study — never a hard FALSE.**

## The judged fields (each: positive target → how it's judged → tier)

1. **differentiator_axis** — *target:* one of the closed enum
   {Market, Mech, Angle, Offer, Dual, None}. *Judge:* MEMBERSHIP — **run ALL four axis tests
   in `references/axis-membership-tests.md` (do not stop at the first TRUE)**, then assign per
   the decision order in `references/levers-and-routing.md`: Market+Mech → Dual; else the
   highest-priority axis that fired (Market > Mech > Angle > Offer); a co-active non-primary
   axis (e.g. Market+Angle, the Nusk/Maya pattern) is recorded in `why`, never dropped. Each
   test can return FALSE. Tier: COUNTABLE (membership).
2. **lever** — *target:* the specific lever, drawn ONLY from the chosen axis's list in
   `references/levers-and-routing.md` (Market / Mech / Angle / Offer levers). For a single
   axis, one lever; **for Dual, name two — `lever_market` AND `lever_mech`.** *Judge:*
   enum membership — lever ∈ axis's list, else FALSE. Tier: COUNTABLE.
3. **verdict** — *target:* RUN or DONT-RUN. *Judge:* **script-style gate** — if
   differentiator_axis = None → DONT-RUN; else RUN. Tier: COUNTABLE → **hard-gate**.

The load-bearing membership test (Market vs Angle): **if the transformation / core human
driver changes vs competitors → it is a new Market, NOT an Angle. An Angle keeps the SAME
transformation and only changes the emotional frame.** Mech (UM) = a unique way of
delivering the transformation (Problem UM = the cause; Solution UM = what fixes it). Offer =
the commercial wrapper. Full tests + registry anchors in `references/axis-membership-tests.md`.

## The hard gate (the only forced verdict)

**No differentiator on ANY axis → verdict DONT-RUN.** If Market, Mech, Angle, and Offer all
return FALSE, axis = None and the product does not run regardless of copy quality. Canonical
failure: the Hair Dryer (7 competitors, same mech, same market, no UM + no avatar diff).
Everything else (which axis, which lever) is a membership label, not a felt self-grade.

## Routing (kept as contract — order of attack, not wording)

From `references/levers-and-routing.md`. These bias which axis to try first; they dictate no
copy and assign no quality verdict:
- **Market changes are the biggest swings** → try the Market test first.
- **Buyer ≠ user opens uncontested markets, often higher pricing** → favor that Market lever.
- **Changing markets decreases sophistication** → expect a lower differentiation floor.
- **Problem UM + Solution UM compound** → when both exist, state both.

## The negatives live here (≤5), each paired with a positive target

Each is a checker rule, not a writer ban:
- **Hair Dryer pattern** (7 competitors, same mech, same market → no differentiator) → flag
  None → DONT-RUN. (positive: find a UM or avatar difference on at least one axis first.)
- **Angle mislabeled as Market** — emotional frame changed but transformation did not → it
  is an Angle. (positive: confirm a Market lever AND a transformation/driver change.)
- **Market mislabeled as Angle** — transformation/core driver changed → it is a new Market.
  (positive: if alternatives change, label Market.)
- **Copy/VOC named as the differentiator** — copy is constant, not a lever → reject.
  (positive: name a real axis lever; write best copy regardless.)
- **lever off-list** — lever not in the chosen axis's enum → fail. (positive: pick a lever
  from that axis's list, or change the axis.)

## Output contract (per product)

```
product: "<name>"
differentiator_axis: Market | Mech | Angle | Offer | Dual | None
lever: "<lever from the chosen axis's list>"   # single axis; "" if axis = None
lever_market: "<Market lever>"   # ONLY when axis = Dual
lever_mech:   "<Mech lever>"     # ONLY when axis = Dual
market: "<niche × transformation, or —>"
mech:   "<UM described, or —>"
angle:  "<emotional frame, or —>"
offer:  "<commercial wrapper, or —>"
evidence_quote: "<verbatim substring of the product's research/source>"
verdict: RUN | DONT-RUN
why: "<one line: which test fired, anchored to the closest case study>"
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** differentiator_axis, lever (or ""), verdict, and evidence_quote all present.
**SOUNDNESS:** the chosen axis passed its membership test (a FALSE-capable check, not eyeballed);
lever ∈ the chosen axis's enum (for **Dual**: `lever_market` ∈ Market list AND `lever_mech` ∈
Mech list); every axis that fired is recorded (primary in `differentiator_axis`, any co-active
axis in `why`); verdict = DONT-RUN iff axis = None; any strength judgment is
pairwise-vs-case-study, not self-graded; evidence_quote is a real substring of the product's
research. `emit_ready` only if SOUNDNESS holds; else `BLOCKED:<field>`.

## Self-test (is this grader sound?) — any NO, fix

- Is only the no-axis DONT-RUN gate hard-gated, with axis labels as FALSE-capable membership
  tests and strength as pairwise-vs-specimen?
- Is the Market-vs-Angle test (transformation/driver change) encoded and registry-anchored?
- Is the judgment run separately from whatever picked the product?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Are the routing rules kept as contract, with no wording-level rule?
- Is every quoted specimen a verbatim substring of the source (case-studies.md is a faithful copy)?

## See also

- `kb-brand-building-score` — adjacent skill — check its scope/boundary before routing here
- `kb-ecommerce-score` — adjacent skill — check its scope/boundary before routing here
- `kb-ecommerce-write` — adjacent skill — check its scope/boundary before routing here
