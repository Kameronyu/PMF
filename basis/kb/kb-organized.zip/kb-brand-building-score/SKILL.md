---
name: kb-brand-building-score
description: >-
  Grade a brand-building / positioning plan or ad-account decision go/no-go before any budget
  is spent, returning DO-NOT-RUN / NEEDS-WORK / READY with per-criterion evidence. Use to vet
  a launch angle, flag a saturated claim, confirm a differentiator exists, check avatar
  breadth against revenue, or validate ad-account structure for the spend tier. Covers:
  countable hard-gates (awareness tag, 5+ saturation, differentiator presence, revenue-gated
  avatar count, axis reset, account tier-by-spend), heuristic soft-caps (differentiation,
  avatar-first, delivery/believability), the felt trust acid-test (pairwise-vs-specimen),
  ROUTE sequencing rules, and brand-evolution diagnostics. Does NOT cover classifying WHICH
  differentiator axis a product uses — use kb-differentiator-score for that;
  product/offer/page selection-and-margin viability — use kb-ecommerce-score; landing-page
  conversion structure — use kb-landing-pages-score. This skill SCORES against a rubric; run
  it as a separate pass from whoever wrote the plan. Triggers: "score this brand plan", "is
  this angle saturated", "vet this affiliate", "what ad-account tier".
---

# Brand-building — score a plan for go/no-go before you spend

Grade the plan against the criteria below, then band it. **Do not run this in the same pass
that wrote the plan** — an author grading itself rates its own output higher. Score the felt
criterion against the specimens in `references/scoring-specimens.md`, ideally on a different model.

Tier discipline: **hard-gate only the countable; soft-cap the heuristic; compare the felt
against a specimen — never hard-FALSE it, never self-grade it.**

## The criteria (each: positive target → how it's judged → tier)

COUNTABLE (script gate — hard-gate; full membership tests in `references/criteria-tests.md`):
- **G1 Awareness-level tag** — *target:* every creative carries an explicit awareness-level tag before launch. *Judge:* tag present? Tier: COUNTABLE.
- **G2 5+ saturation rule** — *target:* a claim run by 5+ competitors is flagged discounted and not led on. *Judge:* `count>=5` → saturated; lead claim must not be saturated. Tier: COUNTABLE.
- **G3 Differentiator presence** — *target:* product differs on mechanism OR avatar. *Judge:* axis non-empty? FALSE on neither → `do_not_run`. Tier: COUNTABLE.
- **G4 Revenue-gated avatar count** — *target:* avatar breadth matches the revenue band. *Judge:* `planned <= band_max` (closed band map). Tier: COUNTABLE.
- **G5 Axis reset mapped** — *target:* both mechanism/avatar axes mapped; either `new` resets to Stage 1. *Judge:* both axes filled before testing? Tier: COUNTABLE.
- **G6 Ad-account structure by spend** — *target:* account tier matches $/day band. *Judge:* `tier == band(spend)`; FALSE = Tier-4 complexity at Tier-1 spend. Tier: COUNTABLE.

HEURISTIC (soft-cap — warn, never hard-fail):
- **H1 Black-t-shirt differentiation** — *target:* lead claims differ from the board's repeated claims. *Judge:* warn on overlap. Tier: HEURISTIC.
- **H2 Avatar-first** — *target:* products cluster on one avatar. *Judge:* warn on avatar-switch. Tier: HEURISTIC.
- **H3 Delivery + Believability** — *target:* delivers for most customers AND mechanism plausible. *Judge:* delivery-fail → `do_not_run`; believability-fail → `mechanism_education_first`. Tier: HEURISTIC.

FELT (pairwise-vs-specimen signal; never a hard FALSE, never self-graded):
- **F1 Trust acid test** — *target:* an association/partner feels send-your-family trustworthy. *Judge:* `prefer|tie|weaker` against a trust specimen. Tier: FELT.

## Bands (derive from criteria that actually passed — not a hollow count)

- Any COUNTABLE hard-gate FALSE → **DO-NOT-RUN** (fix the gate before any spend).
- All COUNTABLE pass, ≥1 HEURISTIC warn or F1 `weaker` → **NEEDS-WORK** (address the cap, then re-score).
- All COUNTABLE pass, no HEURISTIC warn, F1 `prefer|tie` → **READY**.

Count only criteria that passed their tier's check. A felt criterion contributes only when the
pairwise judge prefers it; it never manufactures a pass on its own.
**Differentiator override (structural):** G3 FALSE forces DO-NOT-RUN regardless of every other
pass — "No differentiator on mechanism AND avatar = do not run product".
**Believability override:** H3 delivery-fail forces DO-NOT-RUN; believability-fail caps at NEEDS-WORK with `mechanism_education_first`.

## The negatives live here (≤5), each paired with a positive target

Moved out of any writer (banning a token summons it). Each is a checker rule:

- **Leading on a saturated claim** (5+ competitors) → flag G2. (positive: lead on a sub-5 / new-category claim)
- **Neither mechanism nor avatar differs** → flag G3 DO-NOT-RUN. (positive: one real differentiator axis)
- **Over-broad avatar set for the revenue band** → flag G4. (positive: avatar count within the band)
- **Tier-4 account complexity at Tier-1 spend** → flag G6. (positive: match structure to $/day tier)
- **Hard-FALSEing an affiliate on the trust feel** → never; F1 is `prefer|tie|weaker` only. (positive: pairwise-vs-specimen + cap, not a gate)

## ROUTE rules (contract — named-trigger selection / sequencing)

Kept as contract in `references/route-rules.md`: R1 damage-control matrix · R2 review-mining
method · R3 sophistication counter hierarchy (in order, + interdependency rationale) · R4
hook-per-awareness · R5 cyclical reset path · R6 AI mechanism-discovery procedure · R7 5-step
mechanism testing · R8 run the Competitive Foreplay Board BEFORE angle selection · R9
desire-elevation selection · R10 new-mechanism category-creation 5-step audit · R11
new-mechanism differentiation taxonomy (5 types — identifies the mechanism type that anchors
G3). These select or sequence by a named trigger; they dictate no wording and produce no
quality verdict.

## Brand frameworks & diagnostics (felt — context for the gates, not gates themselves)

See `references/frameworks.md` for the restored brand-evolution and classification frameworks
and the diagnostics that inform (but never override) the gates: Three Brand Eras (felt
brand-evolution scheme), Brand Metrics (Influence/Direction/Reach), Brand-as-Garden curation
rule, Brand Foundation vs Product Foundation, Affiliate selection/structure execution rules
(beyond the F1 trust feel), plus diagnostics — Why Bad Marketers Get Rich Quickly, Market
Saturation Acceleration (why G2/G3/G5 matter), and CTR as awareness-stage proxy (interpret a
failed ad's CTR via its G1 tag). These are felt/diagnostic — do not turn them into hard gates.

## Output contract (per plan)

```
plan_id: "<id>"
criteria: [ {id, target, verdict: pass|fail|warn|signal, tier, evidence_quote, source} ]
countable_gates: {G1,G2,G3,G4,G5,G6}      # script results, pass/fail
heuristic_caps:  {H1,H2,H3}               # warn|ok (+ branch: do_not_run|mechanism_education_first)
felt_signal:     {F1: prefer|tie|weaker}  # pairwise-vs-specimen
band: DO-NOT-RUN | NEEDS-WORK | READY
route_decisions: [ {rule: R1..R11, trigger, selected} ]  # contract, no quality claim
flags: [ ... ]                            # from the negatives list
```
Each judged field carries `source ∈ {operator_verbatim | traces_to:<input_id> | kb:<cite> |
agent_inference}` and, where it traces to input, a verbatim `evidence_quote`.

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every criterion has a verdict; band present; route_decisions present for any fired trigger.
**SOUNDNESS:** every COUNTABLE verdict came from the script (not eyeballed); every HEURISTIC is
warn/ok with its branch, never a hard FALSE; F1 is pairwise-vs-specimen, not self-graded; band
derived only from passed criteria; each `pass` carries a verbatim `evidence_quote`; G3/H3 overrides
applied. `emit_ready` only if SOUNDNESS holds; else `BLOCKED:<criterion>`.

## Self-test (is this grader sound?) — any NO, fix

- Are G1–G6 hard-gated by script, H1–H3 soft-caps (with H3 delivery-fail override to DO-NOT-RUN), and F1 a pairwise-vs-specimen signal?
- Is the felt judgment run separately from the plan's author, against a real specimen?
- Does the band come from criteria that passed their tier's check, not a raw count?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Are the ROUTE rules kept as named-trigger contract (selection/sequencing), not quality gates?
- Is every quoted specimen a verbatim substring of a source file (no composites)?

## See also

- `kb-ecommerce-score` — adjacent skill — check its scope/boundary before routing here
- `kb-differentiator-score` — adjacent skill — check its scope/boundary before routing here
- `kb-ecommerce-write` — adjacent skill — check its scope/boundary before routing here
