---
name: kb-upsells-and-monetization-score
description: >-
  Grade a proposed upsell or monetization move against Hormozi's countable gates and return
  REJECT / WEAK / SOUND with per-gate evidence before you ship it. Use when checking whether
  an upsell is sized right, validating a prepay or PIF structure, vetting take-rate bands or
  blended-value-to-CAC math, or deciding which monetization lever applies. Covers: upsell ≈5X
  sizing and the 10%-on-10x gate, prepay/take-rate bands and PIF 5x commission, blended-value
  and surge/ROIC math, the four-element product test, and ROUTE rules for which lever/sequence
  to pick. Does NOT cover pure pricing-plan or brand-premium viability — use kb-pricing-score
  for that; order-page + post-purchase AOV sequencing config — use kb-aov-optimization-score;
  OTO-stack/post-purchase felt grading — use kb-upsells-score. This skill SCORES against a
  rubric. Triggers: "check my monetization multiple / take-rate", "is this offer sized right",
  "check my prepay structure", "which monetization lever applies here".
---

# Upsells & Monetization — score the move before you ship it

Grade a proposed monetization move against the countable gates below, then band it. **Do not
run this in the same pass that designed the offer** — a designer grading its own move rates it
too kind. Score the numbers by the gate; for any structural choice, match it to a ROUTE rule.

Tier discipline: **hard-gate only the countable** (a multiple is or isn't 5X; a take rate is
or isn't in band); **the structural choices are ROUTE contract** (which lever / what sequence),
not pass/fail; there are **no FELT gates in this topic** — every gate here is arithmetic or
enum membership. Anchor any Value-model term (Bundle, Pricing, Discount, Guarantee,
Subscription) and Objection-handle to the shared registry; never redefine them here.

## The countable gates (each: positive target → tier). All are COUNTABLE → hard-gate by script.

The arithmetic / enum test and a worked example for each gate are in `references/gate-tests.md`;
verbatim source figures in `references/specimens.md`. Targets:

1. **Upsell sizing** — upsell ≈5X base (`upsell/base ≈ 5`), so ~20% conversion doubles the
   ticket. Reject an undersized upsell (e.g. $100 on a $1,000 base). *(undersized → REJECT.)*
2. **10%-on-10x** — a 10x tier taken by ~10% doubles revenue (`0.10 × 10 × base ≈ base`).
3. **Buy-X-get-Y front-load** — ~3x unit price + "buy N get N free" front-loads upfront cash
   beyond one period.
4. **5-5-5 climb** — raise price 20% every 5 sales (`each step = prior × 1.20`) until conv drops.
5. **Four-element product** — Unique AND Expensive AND Sticky AND Air (Buffett variant adds
   owner-minded operator). Enum membership across all 4 — missing one → fail.
6. **Fractal 80/20 take-rates** — ~80% → ~70% → ~20-30% step-down across tiers; ~1 in 5 ascends.
7. **Med-Spa blended value** — `(upsell conv% × upsell GP) + front-end GP = blended`, then
   `blended ÷ CAC ≥ ~3`.
8. **PIF 5x commission** — paid-in-full commission ≈ 5× the payment-plan commission.
9. **Peak-hour surge math** — +10% on ~50% of volume ⇒ ~5% revenue ⇒ ~20% profit at ~28% margin.
10. **Prepay take-rate bands** — min 10% PIF discount; buy-10-get-2 ⇒ 15-20%; discount +
    ancillary ⇒ 30-40%; financing ⇒ ~+35% sales. Structure must map to its band.
11. **ROIC reinvest** — `ROIC = net profit ÷ fully-loaded capital/unit`; viable unit ≥ ~5x in 12mo.
12. **IP success metric** — PASS only if IP spend drove audience growth AND sales lift; else broken.
13. **Affiliate threshold** — threshold bonus fires at a named count (≥10 referrals).
14. **Guarantee-as-upsell** — ~90% (≈9 in 10) never claim ⇒ near-zero-cost upsell (claim rate ≈10%).

## Bands (derive from gates that actually passed — not a hollow count)

- **0 gates relevant-and-passed → REJECT** (resize / restructure before shipping).
- **partial → WEAK** (one or more relevant gates fail; fix the named gate).
- **all relevant gates pass → SOUND** (ship-ready by the numbers).

Score only gates that are relevant to the move under review and that passed their script. A
gate the move doesn't touch is `n/a`, not a free pass. **Undersized-upsell override:** if Gate
1 fails (multiple < ~5X), cap at REJECT regardless of other gates — an undersized upsell adds
negligible ticket and isn't worth the operational effort.

## ROUTE rules — which lever / sequence / order (contract, not graded)

Selection and sequencing by a NAMED trigger; these dictate structure, never wording. Full
list with triggers in `references/route-rules.md`; strategic decision frameworks (Dollars-Per-Box
unit economics, LTV arms race, Partner-for-deficiencies, Solve-for-zero) in
`references/frameworks.md`. The load-bearing ones:

- **Always have a continuation offer ready before the front-end program ends.**
- **Value/LTV lever menu** (8-ways / 7-ways): pick among raise price · cut delivery cost ·
  cross-sell · upsell · quantity · down-sell · economy tier · frequency · financing · terms.
- **High-ticket high-scarcity tier:** 10-50x price, limited to top ~5%; countdown 4→3→2→1→sold.
- **Milestone-moment upsell:** ask at milestone → next week → last chance (3 shots).
- **In-Person Event Renewal:** day-1 pitch+buyer-dinner → day-2 re-pitch+close; "pitch or don't,
  don't go soft." (full sequence in references/route-rules.md.)
- **Med-Spa menu close:** present the ideal package, let them cross off; start ideal → work down
  (lifts upsell ticket — the Gate-7 constraint).
- **One-time vs consumable split:** high one-time fee + lower recurring, by value type.
- **Peak-hour surge framing:** frame as "peak-hour pricing" not "weekday discount"; membership
  is the escape valve.
- **Profit-maximizer decoy:** place a 10x/100x item you never plan to sell, to anchor.
- **Value-stack ORDER:** core → social proof → scarcity → access → tangible bonuses → expert
  services → network → one-on-one → exposure → guarantee → extreme scarcity.
- **Strategic decision rules** (see `references/frameworks.md`): score on one fully-loaded unit
  metric (Dollars-Per-Box); win on LTV not CAC (CAC only 1-2x movable — don't chase cheaper
  leads); partner for core deficiencies; solve for zero (profitable day-one, outsource the rest).

## The negatives live here (≤5), each paired with a positive target

Moved out of the offer-design pass, each a checker rule:

- **Undersized upsell** (e.g. $100 on a $1,000 base) → REJECT. (positive: size to ~5X base.)
- **Discount that just makes a sale** (no structure, devalues the standard price) → flag.
  (positive: frame as peak-hour pricing or attach a prepay band.)
- **Continuity as opt-in** → flag (take rate collapses). (positive: make continuity opt-out.)
- **Down-sell that cannibalizes higher-ticket buyers** → flag. (positive: down-sell only
  captures the would-be NOs.)
- **Front-loading the whole discount on a multi-quarter deal** → flag (churn). (positive:
  spread the discount across quarters.)

## Output contract (per move)

```
move: "<the proposed monetization move, verbatim or paraphrased>"
gates: [ {n, target, verdict: pass|fail|n/a, tier, evidence_quote, source} ]
countable_results: { <gate_name>: pass|fail|n/a }   # script results only
route_match: { rule: <named ROUTE rule>, trigger: <the condition that selected it> } | none
band: REJECT | WEAK | SOUND
flags: [ ... ]   # from the negatives list
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every relevant gate has a verdict; band present; any structural choice carries a
`route_match` or is marked none.
**SOUNDNESS:** every countable verdict came from the script (not eyeballed); band derived only
from gates that passed their tier's check; each `pass` carries an `evidence_quote` that is a
verbatim substring of source; Gate-1 override applied. `emit_ready` only if SOUNDNESS holds;
else `BLOCKED:<gate>`.

## Self-test (is this grader sound?) — any NO, fix

- Is every gate countable (arithmetic or enum), hard-gated by script — and is no FELT gate invented?
- Are the structural choices kept as ROUTE contract, not laundered into pass/fail?
- Does the band come from relevant gates that passed, with the Gate-1 undersized override applied?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Is every quoted specimen a verbatim substring of a source file (no composites)?
- Are Value-model / Objection-handle terms anchored to the registry, never redefined here?

## See also

- `kb-upsells-score` — adjacent skill — check its scope/boundary before routing here
- `kb-aov-optimization-score` — adjacent skill — check its scope/boundary before routing here
- `kb-pricing-score` — adjacent skill — check its scope/boundary before routing here
