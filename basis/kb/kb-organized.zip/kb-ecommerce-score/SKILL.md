---
name: kb-ecommerce-score
description: >-
  Grade an e-commerce product, offer, page, or funnel for production viability and return GO /
  CONDITIONAL / NO-GO with per-gate evidence before you spend ad budget. Use to vet a
  candidate product, validate a saturated-demand product, audit a product page, check a
  funnel's unit economics, or diagnose underperforming paid traffic. Covers: margin and
  4/6-criteria filters, saturated-validation thresholds and revenue/RPU math, page image-enum
  + structure counts + reading level, AOV/funnel math and dry-test gates, the
  single-constraint paid diagnostic, pairwise pain-market-fit, and ROUTE sequencing contracts.
  Does NOT cover brand/positioning go-no-go — use kb-brand-building-score for that; choosing
  which differentiator axis a product runs on — use kb-differentiator-score; gating a product
  IDEA for entry difficulty before committing capital/MOQ (DISCARD/RESEARCH-MORE/COMMIT-READY)
  — use kb-product-research-score. This skill SCORES against a rubric; pair with
  kb-ecommerce-write. Triggers: "score this product", "is this product worth testing",
  "validate this saturated product", "grade this product page", "diagnose this funnel".
---

# E-commerce — score viability before you spend ad budget

Grade a candidate against the gates that apply to its `subject`, then band it. **Do not run
this in the same pass that selected or built the candidate** — a builder grading itself
rates its own output higher. Judge the one FELT gate against the specimens in
`references/scoring-specimens.md`, ideally on a different model.

Tier discipline: **hard-gate only the countable** (a number is or isn't above a
threshold); **soft-cap the heuristic** (signal detectors over-flag); **compare the felt
against a specimen — never hard-FALSE it.**

## Subject routing (which gate-set applies)

Pick `subject` ∈ {product, saturated-validation, page, funnel, paid-diagnostic}; run only
its gates. A candidate may carry more than one subject — run each.
- **product** → G1 margin, G2 four/six-criteria, F1 pain-market (felt)
- **saturated-validation** → G3 validation thresholds, G4 revenue/RPU math, G5 research-method gates
- **page** → G6 image-type enum, G7 page-structure counts, G8 reading level
- **funnel** → G9 AOV/funnel math, G10 dry-test, G11 payment method
- **paid-diagnostic** → G12 constraint diagnostic, H1 sleeping-giant (heuristic)

## The gates (each: positive target → how it's judged → tier)

COUNTABLE gates are **script-gated** (hard-fail). Full membership tests, thresholds, and
enums are in `references/criteria-tests.md`.

1. **G1 Margin** — *target:* gross margin ≥ 80% (CW) AND sell price ≥ 3× COGS with ≥ $20–25 GP/unit (MBB). COUNTABLE → hard-gate.
2. **G2 Criteria filter** — *target:* all four (painful problem, ≥3× COGS + $20–25 GP, fits shoebox, high-LTV consumable/subscription/gifted) OR all six (real problem, ≥3× margin, shoebox, evergreen, competitor $300–500K/mo, upsell). COUNTABLE → hard-gate (the pain sub-test routes to F1).
3. **G3 Validation thresholds** — *target:* ALL of competitor rev $300–500K/mo, 300–500K monthly visitors (SimilarWeb), 30,000+ monthly searches, 5+ yr steady/increasing trend (not parabolic), multiple competitors meet revenue. COUNTABLE → hard-gate.
4. **G4 Revenue/RPU math** — *target:* RPU = CR × AOV; front-end profitable iff CPC < RPU; est. revenue = visitors × CVR × AOV. COUNTABLE (computed) → hard-gate.
5. **G5 Research-method gates** — *target:* the named method's thresholds met (native ad 200–300K+ visitors; Get Hooked 4–5 star + video + ≥7-day + 100+ ads + 3–5 min; engagement ≥10,000 likes AND ≥5,000 shares). COUNTABLE → hard-gate.
6. **G6 Image-type enum** — *target:* each page image classified into exactly one of the six named formats; before/after ALLOWED only if genuine transformation. COUNTABLE (enum + conditional) → hard-gate. Per-type construction guidance (how to build each of the six) is in `references/frameworks.md`.
7. **G7 Page-structure counts** — *target:* 6–10 long-form images (or 8–10 optimization images), 5–8 content sections, above-fold slots present, CTA unambiguous. COUNTABLE → hard-gate.
8. **G8 Reading level** — *target:* generated copy validates at Hemingway Grade 6 or below. COUNTABLE → hard-gate.
9. **G9 AOV/funnel math** — *target:* AOV in $100–$400 sweet spot AND AOV ≥ 2–3× front-end price. COUNTABLE → hard-gate.
10. **G10 Dry test** — *target:* opt-in ≥10% (8–9% acceptable for $100+); below → do not build. COUNTABLE → hard-gate.
11. **G11 Payment method** — *target:* payment method == credit card (PayPal/bank → penalized). COUNTABLE (enum) → hard-gate.
12. **G12 Constraint diagnostic** — *target:* CPC <$1, CPM <$20, CTR >2%, CVR >3%, ATC >10%; each "signal if below" names the constraint. COUNTABLE → hard-gate (names the single constraint to fix). Pair with the Data Intelligence Pillar (3 data streams + GTM/Analytics/Hotjar tracking stack + channel-level CR segmentation) in `references/frameworks.md` before calling a CR drop site-wide.
13. **F1 Pain-market fit** — *target:* solves a *specific* felt pain in a passionate market (back pain, gut health), not a category ("wellness") or an interest niche. FELT — signal **pairwise against a pain specimen**, return prefer|tie|weaker; never a hard FALSE.
14. **H1 Sleeping-giant / compete-on** — *target:* transformation candidate iff strong organic + retail + loyal + unprofitable paid (count of signals); compete on exactly ONE of the nine advantages. HEURISTIC → soft-cap, never hard-fail.

## Bands (derive from gates that actually passed — not a hollow count)

- **NO-GO** — any COUNTABLE gate for the subject hard-fails (e.g. margin <3× COGS, validation incomplete, AOV below sweet spot, dry test below threshold).
- **CONDITIONAL** — all COUNTABLE gates pass but F1 returns `tie`/`weaker`, or an H1 soft-cap flag is set, or a "signal if below" constraint is open.
- **GO** — all COUNTABLE gates pass AND F1 returns `prefer` AND no soft-cap flag is set.

Count only gates that passed their tier's check. A felt gate contributes only when the
pairwise judge prefers it over the specimen; it never manufactures a pass.
**Single-constraint override (G12):** when paid-diagnostic gates fail, name the ONE
constraint the table points to and fix it before relaunch — do not relaunch on multiple
variables. **Page override:** a page that hard-passes counts but uses before/after without
genuine transformation fails G6 — drop to CONDITIONAL and note "remove before/after or prove transformation."

## ROUTE rules (contract — named-trigger sequencing, not quality verdicts)

- **Validate-then-brand:** transition to original content at $500–800K rev; quality upgrades at $1.5–1.7M + 40,000 customers; delegate only after systems proven.
- **4-stage escalation:** pure DS until 10 sales → 50-unit pre-stock at 10 sales → bulk reorder at 10 units remaining (60–90 day horizon) → manufacturer + 3PL at $350K+/mo. Stage-4 reverse-logistics returns SOP (local partner inspects/re-packs/relists; domestic returns → CVR lift) in `references/procedures.md`.
- **Exit structure:** asset deal vs share deal by named conditions (MBO/LBO only $50M+; avoid asset deals on Dubai free-zone entities; prefer DE/AT/CH/UK entities; spin-off for multi-brand portfolios). Clean cap table + strong unit economics can override negative profitability (Bears with Benefits). Full rule set in `references/frameworks.md`.
- **Purple-ocean / two-phase:** validate proven demand → reverse-engineer competitor → select ONE advantage → execute.
- **Charging-for-shipping:** test removing free gifts first → then introduce shipping charge; free-ship floor above single-unit AOV.
- **Peak-season-only validation:** validate new sub-avatars during peak season only; off-season → opposite-hemisphere peak, enter early.
- **Pixel SOP:** 6 steps incl. CAPI + data sharing "Maximum" + Pixel Helper verify.
- **Sub-avatar signal:** ≥5–10 independent self-descriptions before declaring (anchor: Sub-niche); ≥$3,000 ($100/day × 30) validation budget; statics belief signals 1 purchase OR 10+ positive comments OR CTR 3%+ (CTR <1% = kill).
- **B-roll length:** clip 3–5s optimal, ≤30s max; rotate before reach suppression — Meta's Andromeda system detects/penalizes recycled B-roll; refresh with Nano Banana + Kling 2.6 (rationale + tools in `references/frameworks.md`).
- **Pre-copy procedures (run before scoring page copy):** 7-Step Product Overview doc and 5-Tab Master Document architecture (quote density = primary copy lever); Pixel 6-step SOP; AI tool stack + store-building workflow + pre-launch infra; hiring guide (interview-volume + comp models); data-feed restructuring (−50% CAC at scale) — all in `references/procedures.md` and `references/frameworks.md`.
- **Product-selection & scaling frameworks:** E-Commerce Success Formula thesis, Two-Pillar performance model (Ad pillar CPM/CTR vs Website pillar CR/AOV), trend-first/problem-first/low-competition selection, survey-driven upgrade system, quality-risk-in-strict-markets, product-as-marketing flywheel, retention-as-primary-lever, front-end-break-even/backend-profit, Three Golden Rules (mobile-first/page-speed/functionality), supplier-relationship mgmt, funnel-vs-dropshipping economics, affiliate-partnership & influencer-ops levers, seasonal hemisphere-flip — all in `references/restored-frameworks.md`.
- **Research procedures:** Five Laws of Product Testing, Ad-Angle Differentiation research, Problem-Research-over-Product-Research, YouTube Burner Account method, Avatar Narrowing Protocol, Trustpilot self-description mining — in `references/procedures.md`.

## The negatives live here (≤5), each paired with a positive target

Moved out of any builder (where banning a token summons it). Each is a checker rule:

- **Full branding pre-validation** → flag. (positive: validate demand first, then brand)
- **ROAS as primary KPI** → flag. (positive: track RPU = CR × AOV)
- **Single-platform attribution** → flag. (positive: add post-purchase survey)
- **PayPal/bank payment on Facebook** → flag G11. (positive: credit card only)
- **Simultaneous variable testing** → flag. (positive: minimize variables, one relaunch)

## Output contract (per candidate)

```
subject: product | saturated-validation | page | funnel | paid-diagnostic
gates: [ {id, target, verdict: pass|fail|signal, tier, evidence_quote, source} ]
countable_gates: { <id>: pass|fail }     # script results
felt_signals:    { pain_market: prefer|tie|weaker }   # pairwise-vs-specimen
heuristic_flags: [ ... ]                  # soft-cap signals (sleeping-giant, compete-on)
band: GO | CONDITIONAL | NO-GO
flags: [ ... ]                            # from the negatives list
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every gate for the subject has a verdict; band present.
**SOUNDNESS:** every COUNTABLE verdict came from the script (not eyeballed); F1 is
pairwise-vs-specimen, not self-graded; H1 is soft-cap, never a hard FALSE; band derived
only from passed gates; each `pass` carries a verbatim `evidence_quote`. `emit_ready` only
if SOUNDNESS holds; else `BLOCKED:<gate>`.

## Self-test (is this grader sound?) — any NO, fix

- Are only the countable gates (G1–G12) hard-gated by script, with F1 pairwise-vs-specimen and H1 soft-capped?
- Is the felt/heuristic judgment run separately from the builder, against a real specimen?
- Does the band come from gates that passed their tier's check, not a raw count?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Are sequencing rules kept as ROUTE contract (named triggers), not quality verdicts?
- Is every quoted specimen a verbatim substring of a source file (no composites)?

## See also

- `kb-ecommerce-write` — WRITE/SCORE sibling — write the prose this skill scores
- `kb-brand-building-score` — adjacent skill — check its scope/boundary before routing here
- `kb-product-research-score` — adjacent skill — check its scope/boundary before routing here
