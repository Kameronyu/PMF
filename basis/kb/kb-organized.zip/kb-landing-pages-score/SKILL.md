---
name: kb-landing-pages-score
description: >-
  Grade a landing page's conversion structure and get a defensible REBUILD / VIABLE /
  SHIP-READY verdict before you spend build or traffic budget. Use when auditing an LP someone
  built, deciding if a page is ready to ship paid traffic, or sanity-checking a page from
  kb-landing-pages-write. Covers: countable hard-gates (above-fold review count, 5–8 section
  count, listicle benefit points, 30–35% discount band, structural-pitfall checks); felt
  pairwise-vs-specimen signals (desire-led headline, objection-specific testimonial);
  archetype selection/sequencing as ROUTE contracts; band overrides. Does NOT cover
  advertorial pre-sell pages — use kb-advertorial-score; funnel-wide CRO benchmarks — use
  kb-cro-score; offer/unit-economics gates — use kb-conversion-optimization-score. This skill
  SCORES against a rubric; pair with kb-landing-pages-write. Triggers: "score this landing
  page", "is this LP ready to ship", "audit this landing page structure".
---

# Landing pages — score structural viability before you spend build budget

Grade the page against the countable gates, the felt signals, and the ROUTE contracts, then
band it. **Do not run this in the same pass that wrote the page** — a writer grading itself
rates its own output higher. Judge felt criteria pairwise against the winning specimens in
`references/scoring-specimens.md`, ideally on a different model.

Tier discipline: **hard-gate only the countable**; **soft-cap the heuristic**; **compare the
felt against a specimen — never hard-FALSE it.**

## The criteria (each: positive target → how it's judged → tier)

COUNTABLE → script gate (hard). Full predicates in `references/criteria-tests.md`; the source
benchmark numbers each gate calibrates to (incl. the Oodie 35%+installment example and the full
pitfall checklist) are in `references/benchmarks.md`.
- **G1 Above-fold social proof** — *target:* a numeric five-star review count ≥ 3,000 visible
  above the fold. *Judge:* script. Tier: COUNTABLE.
- **G2 Section count** — *target:* 5–8 full sections (not the 1–2 product+reviews anti-pattern).
  *Judge:* script (PASS 5–8, WARN 3–4, FAIL <3). Tier: COUNTABLE.
- **G3 Listicle benefit points** *(listicle archetype only)* — *target:* 5–7 benefit points,
  each with a supporting image. *Judge:* script. Tier: COUNTABLE.
- **G4 Discount anchor band** — *target:* 30–35% off, framed limited-time. *Judge:* script.
  Tier: COUNTABLE.
- **G5 Structural-pitfall presence** — *target:* above-fold social proof present; urgency in
  offer section; ad↔LP imagery congruent; testimonials distributed (not one block); hero shows
  customers USING the product. *Judge:* script, each binary. Tier: COUNTABLE.

HEURISTIC → soft-warn (never hard-FALSE).
- **H1 Education vs over-persuasion** *(novel/complex products)* — *target:* real estate for
  mechanism + demos. Soft-warn only — refund-rate tendency, not a shape check.
- **H2 Optimization-priority hygiene** — *target:* copy & media validated before design;
  copy from researched customer language. Soft-warn only.

FELT → pairwise-vs-specimen signal (`prefer | tie | weaker`); NEVER a hard FALSE.
- **F1 Desire/outcome-led headline** — *target:* hero leads with desired identity/outcome,
  not a feature. *Judge:* pairwise vs a desire-led specimen.
- **F2 Objection-specific testimonial** — *target:* a testimonial names and dissolves one
  specific objection (not generic praise). *Judge:* pairwise vs the objection-specific specimen.

## ROUTE contracts (archetype selection + sequencing — checked as presence/order, not wording)

Select the archetype by named trigger (cold traffic → listicle bridge; desire product →
Coconut; novel product → education-first; homepage → Trojan), then check its required
sections are present and in contract order. Standing contracts (congruency, distributed
testimonials, eight image questions, Subscribe & Save pre-select, copy→media→design priority)
run as G5 presence checks. Full contracts in `references/route-contracts.md`.

## Bands (derive from criteria that actually passed — not a hollow count)

- **REBUILD** — any COUNTABLE gate FAILs (G2 < 3 sections, missing above-fold social proof,
  no urgency, ad↔LP incongruent). Fix structure before any traffic.
- **VIABLE** — all COUNTABLE gates pass or warn; ≤1 felt signal is `weaker`. Moderate budget.
- **SHIP-READY** — all COUNTABLE gates PASS (no warns); both felt signals `prefer` or `tie`;
  archetype sections present and in order. Top budget.

Count only criteria that passed their tier's check. A felt criterion contributes only when the
pairwise judge returns `prefer`/`tie`; it never manufactures a pass on its own.
**Section override:** a page that fails G2 (< 3 sections) caps at REBUILD regardless of other
passes — the 1–2-section page leaves objections unhandled. **Archetype override:** if the
declared archetype's required sections are missing/out of order, drop one band and flag.

## The negatives live here (≤5), each paired with a positive target

Moved out of the writer (where banning a pattern summons it). Each is a checker rule:

- **Feature-led headline** → flag; rewrite desire/outcome-led. (positive: lead with the desired identity/outcome — F1)
- **Testimonials consolidated in one block** → flag; distribute throughout. (positive: testimonials throughout the page)
- **Only 1–2 sections (product + reviews)** → REBUILD. (positive: 5–8 full sections — G2)
- **Missing above-fold social proof** → flag; surface the review count in the hero. (positive: count ≥ 3,000 above fold — G1)
- **No congruency between ad creative and LP imagery** → flag. (positive: same imagery/models/value props — G5)

## Output contract (per page)

```
page_id: "<id or url>"
archetype: listicle | coconut | education-first | trojan | general   # from named trigger
criteria: [ {id, target, verdict: pass|warn|fail|signal, tier, evidence_quote, source} ]
countable_gates: {G1, G2, G3, G4, G5}            # script results, pass|warn|fail
heuristic_warnings: {H1, H2}                       # soft-warn flags
felt_signals: {F1_headline, F2_testimonial}        # pairwise-vs-specimen: prefer|tie|weaker
route_check: {archetype_declared: bool, sections_present: bool, order_ok: bool}
band: REBUILD | VIABLE | SHIP-READY
flags: [ ... ]                                     # from the negatives list
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every criterion has a verdict; archetype declared; band present.
**SOUNDNESS:** every COUNTABLE verdict came from the script (not eyeballed); every felt verdict
is pairwise-vs-specimen, not self-graded; band derived only from passed criteria; each `pass`
carries an `evidence_quote` that is a verbatim substring of the page or source; route check
ran against the declared archetype. `emit_ready` only if SOUNDNESS holds; else `BLOCKED:<id>`.

## Self-test (is this grader sound?) — any NO, fix

- Are only G1–G5 hard-gated (by script), with F1/F2 as pairwise-vs-specimen signals?
- Is the felt judgment run separately from the writer, against a real specimen?
- Does the band come from criteria that passed their tier's check, not a raw count?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Are archetype selection/sequencing kept as ROUTE contracts (presence/order, not wording)?
- Is every quoted specimen a verbatim substring of a source file (no composites)?

## See also

- `kb-landing-pages-write` — WRITE/SCORE sibling — write the prose this skill scores
- `kb-cro-score` — adjacent skill — check its scope/boundary before routing here
- `kb-funnel-architecture-score` — adjacent skill — check its scope/boundary before routing here
