---
name: kb-upsells-write
description: >-
  Write upsell and AOV-optimization wording that makes a second purchase feel like a reward,
  not an add-on tax. Use when drafting or rewriting post-purchase OTO copy, in-cart
  free-shipping nudges, downsell popups, cross-sell recommendations, or order-bump lines.
  Covers: real winning specimens, soft-conversational thank-you framing, deal/gift/exclusivity
  reframes, the authority "mistake" and problem-chain angles, and
  placement-to-narrative-weight contract rules. Does NOT cover the offer's value stack,
  guarantee, or core close — use kb-offer-construction-write for that; AOV/OTO benchmark
  bands, price-tier ceilings, and sequencing gates — use kb-aov-optimization-score for those;
  pre-purchase on-page conversion microcopy (product page, cart/checkout affirmation, savings)
  — use kb-cro-write. This skill WRITES prose; pair with kb-upsells-score. Triggers: "write
  the upsell copy", "rewrite this OTO", "thank-you page upsell line", "cart upsell nudge",
  "downsell popup copy".
---

# Upsells — write the line that makes a second purchase feel like a reward

The mechanics of an upsell (where it sits, what it costs, which offer type) are decided
elsewhere — this skill writes the *wording* a buyer feels at the moment they are most
receptive. Your job is the felt line: soft enough not to break order confidence, framed so
the extra spend reads as a deal, a gift, or the obvious next step — never an add-on tax.
Lead from the specimens below; reach for a framing device only if it helps; keep it short.

> The bank for this topic is small (the source copy surface is thin). Treat the specimens
> as the asset; do not pad with invented lines. [NEAR SPECIMEN FLOOR — bank meets the
> minimum of 3 but barely; a human should add more winning upsell copy as it is collected.]

## Start here — real winning specimens (study these before writing)

Preserved verbatim from the source. They steer harder than any rule. Full bank with the
angle each executes is in `references/specimen-bank.md`.

- **Soft-conversational thank-you framing:** *"Did you get a chance to check out...?"* /
  *"You should also order..."*
  — phrased as a friendly nudge, not a pitch; the casual register lowers hard-sell
  resistance at the exact moment order confidence is fragile.
- **Deal-reframe at checkout:** *"today's top deals"*
  — the upsell is presented as something the buyer *gets to have*, not something sold to
  them; "deals" reframes spend as opportunity.
- **Free-shipping nudge (cart):** *"Spend $X more for free shipping"*
  — turns extra spend into a reward the buyer unlocks; the threshold makes adding more feel
  like winning, not paying.
- **Gift/exclusivity reframe (second-unit OTO):** *framed as a gift for friends/family*
  — the second unit is not 'more of what you bought', it is for someone else; this dissolves
  the 'I already have one' objection without a discount.
- **Authority + "mistake" narrative angle (mid-tier OTO):** *Frame: doctor explaining a
  facility "mistake" customers can exploit for better value*
  — an authority figure hands the buyer an insider advantage; the buyer is exploiting a
  loophole, not being upsold.
- **Problem-chain steering maxim (the offer's spine):** *"Every product should both solve a
  problem and create a new problem"*
  — the next offer is grounded in a problem the last purchase logically opened, so each line
  feels necessary, not bolted on.

## Craft targets (steer by these; they are not a rulebook)

- **Soft over hard.** At the post-purchase peak, order confidence is fragile — a
  conversational nudge converts where a pitch breaks trust. Write like a friend pointing
  something out, not a closer.
- **Reframe spend as reward.** Deal, gift, unlocked threshold, insider value. The buyer
  should feel they *gain* by adding, not that they are charged again.
- **Ground the next offer in the last purchase.** The strongest upsell line answers a
  problem the just-bought product logically created or left open. Earn the offer; don't
  assert it.
- **Specificity over superlative.** A named outcome, a concrete threshold, a real person
  (the doctor, the friend) beats "amazing value" or "limited time."
- **Fewest words that keep the pull.** Draft, then cut every word that adds no new
  information or no new reason to say yes.

## Optional framing devices (reach for one; never force a fixed order)

Soft-conversational · Deal-reframe · Gift/exclusivity · Authority+"mistake" · Problem-chain.
Each is a shape to borrow when it fits the placement and offer, not a required sequence.
Anatomy and a worked example for each is in `references/framing-devices.md`.

## Contract rules (these DO bind — they pick the shape, not the words)

- **Soft framing belongs on the thank-you page and low-friction touchpoints** (cart nudge,
  recommendation slider); high-justification OTO copy (mid/high-tier) carries an authority
  or problem-chain narrative instead.
- **Match the narrative weight to the placement the mechanics chose:** a one-line nudge for a
  cart/thank-you touchpoint; a fuller narrative angle (authority, "mistake," gift) for a
  post-purchase OTO. (The dollar-tier→format thresholds themselves are a SCORE gate — see
  kb-upsells-score — not a thing you decide here.)
- **The offer the copy frames must be logically connected to what was just bought.** Write
  the line as a continuation of the buyer's situation, not a random product pivot.
- **Reframe, do not discount, by default.** Reach for gift/exclusivity/deal framing before
  reaching for a price cut; the discount line (e.g. a downsell popup) is a fallback the
  mechanics trigger, not the first move.

## How to use this with the grader

Generate several diverse upsell lines (vary the framing device and the placement; don't
iterate one toward "safe"). Then hand them to **kb-upsells-score** — a separate skill,
ideally a different model — for the gates (AOV:front-end ratio, OTO1 price ceiling, count,
price-tier→format) and the pairwise-vs-specimen judgment of relevance and offer-fit. Do not
grade your own output here; a writer that judges itself optimizes toward "looks like an
upsell," not "earns the next yes." The countable thresholds and the relevance check live
there, not here.

## Before handoff (what kb-upsells-score checks)

Generate several diverse drafts; the separate scorer grades — do not self-grade toward the
gate. These are what the scorer will look at, listed so you write with them in mind, not as
a writer pass/fail:

- Whether the line reads as a reward, gift, deal, or insider advantage.
- Whether it is soft enough for the placement it targets.
- Whether the offer is legibly connected to what the buyer just bought.
- Whether it carries at least one concrete specific (a real person, a named outcome, a threshold).
- Whether you produced several diverse candidates rather than one polished safe line.

## See also

- `kb-upsells-score` — WRITE/SCORE sibling — score a draft this skill writes (separate pass)
- `kb-offer-construction-write` — adjacent skill — check its scope/boundary before routing here
- `kb-email-and-retention-write` — adjacent skill — check its scope/boundary before routing here
