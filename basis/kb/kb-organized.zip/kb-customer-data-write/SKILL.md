---
name: kb-customer-data-write
description: >-
  Write open-ended customer research questions that return prospects' exact words — survey and
  message-mining prompts surfacing why they bought, what almost stopped them, and the outcome
  they wanted. Use when drafting questions for converted customers, churned or
  near-converters, or VOC interviews that feed headline tests, FAQ structure, and
  objection-handling copy. Covers: winning specimen questions
  (motivation/hesitation/alternatives/outcome), open-ended single-clause craft targets,
  optional PMBD question shapes, mine-before-you-ask ordering, both-cohort coverage, and
  routing answers to copy consumers. Does NOT cover grading a research plan — use
  kb-customer-data-score for that; scoring a product before sourcing — use
  kb-product-research-score. This skill WRITES prose; pair with kb-customer-data-score.
  Triggers: "write survey questions", "VOC research questions", "customer interview
  questions", "mine customer language".
---

# Customer Data — write the question that returns the customer's own words

A good research question is wording you deploy to a real customer. Its whole job is to make
the answer come back in the customer's vocabulary — not yours — so the response can be lifted
verbatim into headlines, FAQs, and objection handling. Lead from the specimens below; keep
each question open-ended and single-clause; reach for nothing fancier than that.

## Start here — real winning specimens (study these before writing)

These are preserved verbatim from the source. They steer you harder than any rule. Each
surfaces a different slice of **PMBD** (Pain, Belief, Motif, Desire) in the buyer's language.

- **Motivation (surfaces purchase drivers):** *"What was the primary reason you decided to purchase today?"*
  — past-tense, single clause, asks for the *one* reason; "today" anchors it to a real decision
  the customer just made, so the answer is concrete rather than aspirational.
- **Hesitation (surfaces objections → Belief):** *"What almost stopped you from buying?"*
  — "almost stopped" names the friction without leading the witness; it pulls the live
  objection that becomes an objection handle on the PDP or checkout.
- **Alternatives considered (surfaces the competitive set):** *"What other solutions did you consider before choosing us?"*
  — maps the buyer's real consideration set in their own framing, which is rarely the set you'd assume.
- **Outcome expectation (surfaces Desire in the buyer's words):** *"What result were you hoping to achieve?"*
  — asks for the wanted outcome as the customer phrases it; this is Desire copy you can mirror
  directly, under the Command+F verbatim rule (keep only words that actually appear in research).

More on what each question feeds, plus the cohorts to ask, is in `references/specimen-bank.md`.

## Craft targets (steer by these; they are not a rulebook)

- **Open-ended, always.** A yes/no or multiple-choice question returns your categories, not the
  customer's language. The entire point is to capture vocabulary you didn't write.
- **One clause, one thing.** A question that asks two things returns a blurred answer. Split it.
- **Anchor to a real moment.** "today," "before choosing us," "almost" — tie the question to an
  event the customer actually lived, so the answer is specific, not a tidy abstraction.
- **Don't lead the witness.** Name the slot (reason, hesitation, alternative, hoped-for result)
  and let them fill it; a question that suggests its own answer just echoes your assumptions back.
- **Mirror, don't invent.** Mine real unprompted language first; let the words customers already
  use shape the question, then carry their phrasing straight into copy.

## Optional question shapes (reach for one; never force a fixed set)

Motivation · Hesitation · Alternatives-considered · Outcome-expectation. These are slots to
reach for when they fit the funnel stage, not a required questionnaire. Anatomy and the cohort
each is best asked of are in `references/question-shapes.md`.

## Contract rules (these DO bind — they pick the form and the audience, not the words)

- **Mine before you ask.** Draft questions *after* message mining (support inboxes, reviews,
  social comments, community threads), not before — so real unprompted language drives the
  wording instead of internal assumptions. A recurring high-frequency phrase signals either
  unaddressed friction (a conversion killer → objection handle/fix) or an underemphasized value
  prop (a copy opportunity → lead with it); see `references/message-mining.md` for the rule.
- **Both cohorts.** A research plan must ask **converted customers** (purchase drivers) AND
  **near-converters or churned customers** (abandonment reasons). Either alone is half the funnel.
- **Route the answers.** Open-ended responses feed specific consumers — headline testing, FAQ
  structuring, and objection-handling sections on PDPs and landing pages. Write the question
  knowing where its answer lands.

## How to use this with the grader

Write a diverse set of questions across cohorts and funnel stages; don't polish one safe
question. Then hand the research plan to the separate score pass for the gates — cohort
coverage, mine-before-survey ordering, fix-type tagging of findings. Do not grade your own
output here; the writer that judges itself optimizes toward "looks like a survey," not "returns
the customer's own words."

## Self-test (is this a real research question?) — any NO, revise

- Is it open-ended — impossible to answer with yes/no or a checkbox?
- Does it ask exactly one thing, anchored to a moment the customer actually lived?
- Will the answer come back in the customer's vocabulary rather than echoing your framing?
- Did you cover both cohorts (converted AND near-converters/churned), and did you mine real
  language before drafting?

## See also

- `kb-customer-data-score` — WRITE/SCORE sibling — score a draft this skill writes (separate pass)
- `kb-consumer-psychology-score` — adjacent skill — check its scope/boundary before routing here
- `kb-social-proof-score` — adjacent skill — check its scope/boundary before routing here
