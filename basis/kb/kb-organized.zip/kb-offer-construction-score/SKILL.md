---
name: kb-offer-construction-score
description: >-
  Grade a constructed offer for structural viability and return REWORK / VIABLE / SHIP before
  you waste test budget. Use when checking whether an offer is worth testing, ranking
  competing offers, or auditing an offer's economics (margin, ROAS, cash). Covers: countable
  hard-gates (2x compare-at, margin floors, RPS band, break-even ROAS, value-equation
  direction, 3-tier pricing, bonus-stack sum, NTPMA order, 30-day-cash self-funding override,
  seven-component section, promise specificity, close-rate); felt pairwise-vs-specimen signals
  (irrational-not-to-buy, must-have framing); offer-testing-hierarchy and landing-page-testing
  route contracts. Does NOT cover pricing-only premium positioning — use kb-pricing-score;
  upsell / OTO / post-purchase AOV scoring — use kb-upsells-score or
  kb-aov-optimization-score; grading a 1:1 SALES move (guarantee, anchor, MESO/negotiation,
  qualification) — use kb-persuasion-and-sales-score. This skill SCORES against a rubric; pair
  with kb-offer-construction-write. Triggers: "score this offer", "is this offer worth
  testing", "rank these offers", "check my offer economics".
---

# Offer construction — score viability before you spend test budget

Grade each offer against the gates below, then band it. **Do not run this in the same pass
that built the offer** — a builder grading itself rates its own output higher. Score felt
gates against the winning offers in `references/scoring-specimens.md`, ideally on a
different model.

Tier discipline: **hard-gate only the countable**; **soft-cap the heuristic**; **compare
the felt against a specimen — never hard-FALSE it.** Anchor terms (Niche, Transformation,
UM, Awareness level) are defined in the registry — never redefine them here.

## The COUNTABLE gates (script-checked; each: positive target → tier)

Each gate's membership test, formula, and FALSE example live in `references/gate-tests.md`.
A gate is a script result: `pass | fail`. Any `fail` is a real hard-gate FALSE.

1. **Compare-at ratio** — *target:* compare-at price == exactly 2× selling price. → hard-gate.
2. **Margin floor** — *target:* margin ≥ type floor (50% absolute / 52% BOGO / 60% standard discount / 60% ad-funded). → hard-gate. *(When an offer lowers margin to expand a discount, also run the **Revenue Illusion** advisory check — margin-adjusted net profit vs baseline, not ROAS/gross revenue; emits a flag, see `references/gate-tests.md`.)*
3. **RPS band** — *target:* RPS = CVR×AOV (Meta CVR) computed and routed to the right band (<$1 intervene / $1–2 bundle / >$2 media-buy). → hard-gate.
4. **Break-even ROAS** — *target:* BE-ROAS = 1 ÷ gross-margin% (round up), modeled before launch. → hard-gate.
5. **Value-equation direction** — *target:* offer moves Dream Outcome ↑, Perceived Likelihood ↑, Time Delay ↓, Effort/Sacrifice ↓ (all four addressed). → hard-gate.
6. **Three-tier pricing** — *target:* exactly 3 tiers, middle highlighted, highest-AOV pre-selected default. → hard-gate.
7. **Bonus-stack sum** — *target:* Σ(stated bonus values) ≥ core offer price. → hard-gate.
8. **NTPMA order** — *target:* plan solves Niche→Transformation→Price→Mechanism→Access in order; market validated by committed money before mechanism built. → hard-gate.
9. **30-day cash** — *target:* 30-day cash collected ≥ 2×CAC + COGS. → hard-gate.
10. **Seven-component section** — *target:* all 7 named slots present (countdown, social proof, 1-line value prop, price+anchor, 4 benefit bullets, repeated urgency, payment logos). → hard-gate.
11. **Promise specificity** — *target:* offer copy carries ≥1 specific number, named outcome, or concrete timeframe; niche named, not generic. → hard-gate.
12. **Close-rate band** *(advisory, service offers)* — *target:* close rate mapped to its underpricing multiple; <30% flags avatar/sales-motion, not price. → hard-gate (advisory: fails route to a flag, not REWORK).

## The FELT gates (pairwise-vs-specimen; never a hard FALSE)

13. **Irrational not to buy** — *target:* the stacked offer makes refusal feel irrational.
    *Judge:* FELT — rate pairwise against a winning offer specimen; return `prefer|tie|weaker`.
14. **Must-have framing** — *target:* reads as all-in-one must-have, not nice-to-have add-on.
    *Judge:* FELT — signal pairwise against a must-have specimen; never a hard FALSE.

## Bands (derive from gates that actually passed — not a hollow count)

- **any COUNTABLE hard-gate fails → REWORK** (fix the structural defect before any test).
- **all hard-gates pass, ≤1 felt prefer → VIABLE** (moderate test budget).
- **all hard-gates pass, both felt `prefer` → SHIP** (top test budget).

Advisory gate 12 never forces REWORK on its own — it emits a pricing flag. The Revenue
Illusion check (paired with gate 2) likewise emits a flag, never a REWORK, when a gate-2 PASS
hides a net-profit collapse from an expanded discount. A felt gate
contributes a band-lift only when the pairwise judge returns `prefer`; `weaker`/`tie`
never manufactures a pass. **Self-funding override (structural):** if gate 9 (30-day cash)
fails, cap the band at REWORK regardless of other passes — a non-self-funding front-end
cannot scale on paid cold traffic.

## ROUTE rules — contract (named-trigger selection/sequencing, not graded)

These are selection/sequence contracts the offer must obey; check shape, do not grade copy.
Full list in `references/route-rules.md`.

- **NTPMA dependency order** (also gate 8): never build mechanism before validating N-T-P.
- **Offer Testing Hierarchy:** Bundle&Save → Price test → MOQ → BOGO → %-off-qty → free-ship threshold → free gift.
- **Offer-to-Landing-Page Testing Protocol (5-step):** how to validate a new offer cleanly before banding (duplicate page, isolate offer, new ad set, 7+ days in Meta, compare Meta-level CVR/AOV) — see `references/route-rules.md`. An offer not tested this way is a flag, not a band.
- **BOGO iteration sequence:** Buy 1 get 1 → Buy 2 get 1 → Buy 2 get 3 free; MOQ protects the 52% floor.
- **Charging-for-shipping isolation:** remove free gifts first; if sales hold, then test charging shipping.
- **Funnel type → front-end model:** high-AOV bundle (cover CAC on first sale) vs low-price entry + backend upsell.
- **Guarantee type by stage:** unconditional / conditional / implied / anti-guarantee.

## The negatives live here (≤5), each paired with a positive target

- **Non-round compare-at** (e.g. 1.7× price) → fail gate 1. (positive: compare-at == 2× price)
- **Discount below the type floor** → fail gate 2. (positive: ≥ floor for the offer type)
- **Mechanism built before N-T-P validated** → fail gate 8. (positive: validate with committed money first)
- **Bonus stack worth less than core price** → fail gate 7. (positive: Σ bonus values ≥ core price)
- **Generic promise, no number/outcome/timeframe, or unnamed niche** → fail gate 11. (positive: ≥1 specific number/outcome/timeframe AND niche named, not generic)

## Output contract (per offer)

```
offer_id: "<id>"
countable_gates: [ {n, target, verdict: pass|fail, tier: COUNTABLE,
                    value, evidence_quote, source} ]   # script results
felt_signals: [ {n, target, verdict: prefer|tie|weaker, specimen_id,
                 evidence_quote, source} ]             # pairwise-vs-specimen
band: REWORK | VIABLE | SHIP
flags: [ ... ]    # from the negatives list + advisory gate 12
```
`source` ∈ `{traces_to:<input_id> | kb:<cite> | agent_inference}`. Every `pass` and every
felt verdict carries an `evidence_quote` that is a verbatim substring of the offer input.

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every gate (1–14) has a verdict; band present.
**SOUNDNESS:** every COUNTABLE verdict came from the script (not eyeballed); every felt
verdict is pairwise-vs-specimen, not self-graded; band derived only from passed gates +
the self-funding override; each `pass`/felt verdict carries an `evidence_quote`.
`emit_ready` only if SOUNDNESS holds; else `BLOCKED:<gate>`.

## Self-test (is this grader sound?) — any NO, fix

- Are only gates 1–12 hard-gated (by script), with 13/14 as pairwise-vs-specimen signals?
- Is the felt judgment run separately from the writer, against a real specimen?
- Does the band come from gates that passed their tier's check, not a raw count?
- Is the self-funding override (gate 9 → cap REWORK) applied before banding?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Is every quoted specimen a verbatim substring of a source file (no composites)?

## See also

- `kb-offer-construction-write` — WRITE/SCORE sibling — write the prose this skill scores
- `kb-pricing-score` — adjacent skill — check its scope/boundary before routing here
- `kb-persuasion-and-sales-score` — adjacent skill — check its scope/boundary before routing here
