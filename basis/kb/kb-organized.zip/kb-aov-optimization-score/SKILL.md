---
name: kb-aov-optimization-score
description: >-
  Grade an order-page + post-purchase AOV config against benchmark bands and the sequencing
  contract before you ship it, returning WEAK / ACCEPTABLE / OPTIMIZED with per-field
  evidence. Use when reviewing an order-bump and OTO/downsell stack, checking quantity-tier
  and bump pricing, or verifying upsell sequencing obeys the order. Covers: countable gates
  (attach rate, quantity lift, OTO conversion, stack lift, element count, bump price ratio),
  felt signals (placement, relevance, AOV-not-volume, value-add), and the R1-R5
  sequencing/selection route contract. Does NOT cover writing upsell/thank-you/cart wording —
  use kb-upsells-write; broad monetization-multiple and blended-value gates — use
  kb-upsells-and-monetization-score; core offer-structure scoring — use
  kb-offer-construction-score; grading an OTO-stack PLAN (ratios, OTO1 price, count) — use
  kb-upsells-score. This skill SCORES against a rubric. Triggers: "score this AOV stack", "is
  this order page optimized", "review my upsell sequence", "check my order bump pricing".
---

# AOV Optimization — score a stack before you ship it

Grade an order-page + upsell config against benchmark bands and the sequencing contract,
then band it. **Do not run this in the same pass that built the config** — a builder grading
itself rates its own work higher. Score felt fields against the specimens in
`references/scoring-specimens.md`, ideally on a different model.

Tier discipline: **hard-gate only the countable** (as advisory flags, never a kill);
**soft-cap the heuristic** as pairwise-vs-specimen signals; **never hard-FALSE a felt field.**

## The judged fields (each: positive target → how it's judged → tier)

**COUNTABLE — script gates, advisory flags (full tests in `references/benchmark-tests.md`):**
1. **B1 attach rate** — order-bump attach is 20-40% of converting customers. COUNTABLE.
2. **B2 quantity lift** — multi-unit tier lifts AOV 25-60% over single-unit. COUNTABLE.
3. **B3 OTO 1** — converts 15-35% at a 1.5-2x core price ratio. COUNTABLE.
4. **B4 stack lift** — quantity+bump+variations lift AOV 20-30% at fixed ad spend. COUNTABLE.
5. **E1 element count** — order page carries ≤3 high-impact elements. COUNTABLE (hard cap).
6. **E2 bump price** — bump priced 10-30% of core ("no-brainer"). COUNTABLE (hard cap).

**HEURISTIC — pairwise vs specimen (`prefer|tie|weaker`), never a hard FALSE:**
7. **H1 placement** — testimonials adjacent to CTA/price, not below fold. FELT signal.
8. **H2 relevance** — every upsell is a logical extension of the core purchase. FELT signal.
9. **H3 AOV-not-volume** — AOV gain weighted equal to same-size conversion gain. FELT signal.
10. **H4 value-add** — stacking preserves the relationship; reads as value-add. FELT signal.

## Bands (derive from fields that actually passed their tier's check — not a hollow count)

- **0-3 → WEAK** (rebuild before shipping).
- **4-6 → ACCEPTABLE** (ship; close the flagged gaps).
- **7-10 → OPTIMIZED** (ship as-is).

Count a COUNTABLE field only when its band/cap check passed; count a HEURISTIC field only
when the pairwise judge returns `prefer`. A `weaker` or out-of-band field contributes no
pass. Out-of-band COUNTABLE fields produce flags, not band-kills.
**Element-count override (structural):** if E1 > 3, cap the band at ACCEPTABLE regardless of
count — cognitive overload causes abandonment that the other gains can't outrun.

## ROUTE rules — sequencing & selection contract (kept; dictate no wording)

Full rules + source quotes in `references/route-rules.md`. The scorer checks the config
OBEYS them; it grades no prose:
- **R1** order page optimized BEFORE upsell sequences begin; stack, don't single-mechanism.
- **R2** post-purchase order is OTO 1 (1.5-3x core) → OTO 2 (complementary) → Downsell.
- **R3** prefer order-page bumps over post-purchase OTOs where the offer fits the bump format.
- **R4** maximize offers while preserving the relationship (felt clause judged as H4).
- **R5** offer-variation tiers anchored (high tier above a mid "most popular"); optimize for AOV-shift, not top-tier take. See `references/route-rules.md`. Quantity-booster anchoring rationale: `references/benchmark-tests.md` (B2).

## The negatives live here (≤5), each paired with a positive target

Moved out of the builder. Each is a checker flag:
- **Overloaded order page** (E1 > 3) → flag `cognitive-overload`. (positive: 2-3 high-impact elements)
- **Bump priced too high** (E2 > 30%) → flag `bump-priced-too-high`. (positive: 10-30% "no-brainer" add-on)
- **Testimonials below the fold** → flag (H1 `weaker`). (positive: adjacent to CTA/price)
- **Disconnected upsell** → flag (H2 `weaker`). (positive: logical extension of core purchase)
- **Volume-only scaling** (AOV ignored) → flag (H3 `weaker`). (positive: weight AOV = conversion)

## Output contract (per config)

```
config_id: "<id>"
fields: [ {n, target, verdict: pass|flag|signal, tier, evidence_quote, source} ]
countable_gates: {B1, B2, B3, B4, E1, E2}   # script results: in_band/within_cap or flag
felt_signals: {H1, H2, H3, H4}              # pairwise-vs-specimen: prefer|tie|weaker
route_check: {R1, R2, R3}                    # config obeys ordering/selection: pass|fail
band: WEAK | ACCEPTABLE | OPTIMIZED
flags: [ ... ]    # from the negatives list
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every field has a verdict; route_check present; band present.
**SOUNDNESS:** every COUNTABLE verdict came from the script (not eyeballed); every HEURISTIC
verdict is pairwise-vs-specimen, not self-graded; band derived only from passed fields with
the E1 override applied; each `pass` carries an `evidence_quote`. `emit_ready` only if
SOUNDNESS holds; else `BLOCKED:<field>`.

## Self-test (is this grader sound?) — any NO, fix

- Are only B1-B4/E1/E2 hard-gated (by script, as advisory flags), with H1-H4 as pairwise signals?
- Is the felt judgment run separately from the builder, against a real specimen?
- Does the band come from fields that passed their tier's check (with the E1 override), not a raw count?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Are the ROUTE rules (R1-R4) kept as a sequencing/selection contract, not graded as prose?
- Is every quoted specimen a verbatim substring of a source file (no composites)?

## See also

- `kb-upsells-score` — adjacent skill — check its scope/boundary before routing here
- `kb-upsells-and-monetization-score` — adjacent skill — check its scope/boundary before routing here
- `kb-offer-construction-score` — adjacent skill — check its scope/boundary before routing here
