---
name: kb-ads-write
description: >-
  Write the direct-response ad copy a cold viewer feels — the scroll-stopping hook, the
  pain-point or curiosity-gap headline, the FOMO/social-proof CTA. Use when generating or
  rewriting the WORDING of a paid Meta/TikTok/Native ad, mining hooks at volume, or shaping
  copy by traffic temperature (indirect-cold vs direct-retargeting). Covers: real winning
  specimens (PetLab, menopause-brain, fragrance), craft targets (Punch-in-the-Gut, pain-first,
  specificity), optional structures (Viral seven-beat, Holy Grail), and contract rules mapping
  temperature/awareness/audience to ad form. Does NOT cover cold-only qualification/POV-opener
  creative — use kb-ad-creative-write for that; offer-hook variations and promo-wrapper naming
  — use kb-advertising-write; broader direct-response copy beyond paid-ad wording (outreach
  scripts, naming, positioning across ads/LPs/advertorials) — use kb-copywriting-write. This
  skill WRITES prose; pair with kb-ads-score. Triggers: "write an ad hook", "rewrite this ad
  copy", "pain-point headline for this product", "cold-traffic ad".
---

# Ads — write the creative that stops the scroll and earns the click

An ad executes an **angle** (the emotion you invoke to drive purchase) in the first
3-5 seconds of video, or instantly in an image. Your job is the *wording* a cold viewer
feels — not the campaign structure, not the targeting. Lead from the specimens below;
reach for a structure only if it helps; keep it direct.

The single highest-leverage thing you write is the hook. Spend most of your effort there.

## Start here — real winning specimens (study these before writing)

These are preserved verbatim from the source. They steer harder than any rule. Do not
abstract them into ordered slots — borrow the *move*, then write your own line.

- **Curiosity-via-numbered-list hook (PetLab Co, bootstrapped to ~$100M):**
  *"Dog owners never ignore these three things in your dog's teeth"*
  — names the avatar, asserts a thing they *must not* miss, and the number opens a loop the
  viewer has to close by watching. No product, no price — pure attention.

- **Pain-point curiosity-gap headline (advertorial funnel):**
  *"Are you tired of menopause brain?"*
  — enters a pain the avatar already feels, in their own words, as a question. The gap
  between the named pain and the unrevealed solution is what drives the click.

- **FOMO prospecting headline:**
  *"This coffee is about to go viral"*
  — manufactures inevitability; the viewer clicks to get in before everyone else. Sells the
  moment, not the mug.

- **Pre-frame promise (fragrance, "Prepare to Be Complimented"):**
  *"if you buy this, you will get complimented"*
  — substitutes social proof of the *outcome* for sensory proof you can't deliver online;
  pre-frames the entire watch around the one benefit review-mining surfaced.

- **CTA with embedded social proof (PetLab Co, herd activation):**
  *"Join thousands of dog owners seeing amazing results"*
  — the ask and the proof are the same line; "join" + "thousands" makes buying feel like
  catching up to a crowd already moving.

More specimens, with the angle and structure each executes, are in
`references/specimen-bank.md`.

## Craft targets (steer by these; they are not a rulebook)

- **Make something people actually want to watch.** This is the primary creative constraint.
  Boring, value-free, or non-educational kills an ad — length never does.
- **Punch in the Gut (PIG).** The hook must create an immediate visceral emotional response.
  If the hook fails, the rest of the ad is irrelevant.
- **Pain first, product never (on cold).** Enter the problem the avatar lives in; let the
  curiosity gap between named pain and unrevealed solution do the pulling.
- **Specificity over superlative.** A named avatar ("dog owners"), a number ("three things"),
  a concrete outcome ("complimented") beats "fast" / "amazing."
- **The first sentence is most of the hook.** Copy carries far more than visual or audio —
  lead with the line, not the b-roll.
- **Social proof as motion.** Make buying feel like joining a crowd already in motion, not
  taking a risk alone.
- **Engineer the comment section.** A participation prompt or a relatable/divisive beat that
  drives comments earns lower CPMs (engagement signals platform health) — cheaper traffic, not
  just clicks. See `references/production-pipelines.md` (Engagement-Driven CPM Reduction).

## Optional patterns (reach for one; never force a fixed slot order)

Offer these as shapes to borrow, not sequences to fill. Forcing every beat produces same-y,
compliant ads — the opposite of what stops a scroll. Anatomy + a worked example for each is
in `references/structures.md`.

- **Viral seven-beat** · **PetLab six-beat** · **Holy Grail (Hook→Body→CTA1→Proof→CTA2)**
- **Curiosity-gap pain-point headline** · **FOMO prospecting** · **Pre-frame promise**

The Shopping-title composition (`references/structures.md`) is the one place wording is
formulaic — feed-targeting, not a felt hook.

To generate candidates at volume — named AI/hook pipelines (Infinite Hook Glitch, Swipe
Method via Get Hooked + Gemini + Highfield/Nano Banana, Original Concept, TikTok Hook Mining),
the multi-avatar production pattern (6-7 models, one copy formula, 20-25s), and the five native
TikTok styles + editing principles — see `references/production-pipelines.md`.

## Contract rules (these DO bind — they pick the shape, not the words)

- **Traffic temperature → ad type.** Cold/prospecting → *indirect* ad: sell an idea, place
  the viewer in the emotional problem state, **never reveal product, price, or purchase**;
  route to advertorial/pre-sell. Warm/retargeting → *direct* ad: product shown, clear CTA,
  testimonials, proof.
- **Awareness stage → form.** Problem-aware → pain-point / authority-press format on cheap
  upper-funnel angles; solution/purchase-intent → product-forward, offer-driven copy.
- **Audience type → register.** TikTok/young → organic, native, entertaining ("three reasons
  why", "what I ordered vs what I got"; five native styles in `references/production-pipelines.md`);
  older (MPC) → testimonial straight-to-camera; mass market → VSL + advertorial with authority
  figures.
- **Retargeting milestone → next asset.** 75% video view → advance to the next asset in the
  sequence (unboxing → product → testimonial); vary content to keep frequency low.

## How to use this with the grader

Generate several diverse drafts — vary the angle and the structure; do not iterate one line
toward "safe." Use the named production pipelines in `references/production-pipelines.md` to
source candidates at volume (mine validated hooks, swipe 7+-day competitor winners, batch
10/20/30 concepts) rather than writing from a blank page. Then hand them to **kb-ads-score** — a separate skill, ideally a different
model — for the gates (hook-rate / hold-rate targets, ad-side thresholds, CVR floor,
banned-phrase / length checks) and the pairwise-vs-specimen judgment. Do not grade your own
output here; the writer that judges itself optimizes toward "looks like an ad," not "stops
the scroll." All the numeric gates live there, not here.

## Before handoff (what kb-ads-score checks)

Generate several diverse drafts; the separate scorer grades — do not self-grade toward the
gate. For awareness only, kb-ads-score is what weighs whether the first beat buys attention
with a visceral hit before any product claim, whether cold-traffic copy keeps product/price/
purchase-ask out of the ad, whether the angle is legible in one read on a concrete specific
(avatar, number, outcome), and whether you produced several diverse candidates rather than one
polished safe line.

## See also

- `kb-ads-score` — WRITE/SCORE sibling — score a draft this skill writes (separate pass)
- `kb-ad-creative-write` — adjacent skill — check its scope/boundary before routing here
- `kb-advertising-write` — adjacent skill — check its scope/boundary before routing here
