---
name: kb-persuasion-and-sales-score
description: >-
  Grade a sales offer, guarantee, anchor, or negotiation move for structural soundness before
  a prospect ever sees it, returning WEAK / SOUND / STRONG with per-gate evidence. Use to vet
  a close, a pricing-tier stack, a guarantee, a MESO/negotiation move, or to confirm a
  prospect was qualified. Covers: countable hard-gates (guarantee slots, goal-pricing math,
  three-tier anchor, MESO count, increment ratio, qualification checklist, looping re-ask),
  felt pairwise-vs-specimen signals (anchor height, value-stack, never-disagree tone),
  guarantee/qualification overrides, and objection-routing (Onion of Blame, BATNA,
  discount-to-terms). Does NOT cover scoring a cold-traffic persuasion stack
  (scarcity/social-proof/authority) — use kb-persuasion-score; buyer/market/desire diagnosis
  before any copy exists — use kb-consumer-psychology-score; grading the OFFER
  STRUCTURE/economics (margin, ROAS, value-equation, bonus stack) — use
  kb-offer-construction-score. This skill SCORES against a rubric; pair with
  kb-persuasion-and-sales-write. Triggers: "score this sales close", "is this guarantee
  tight", "check this anchor structure", "did I qualify this prospect", "rank these pricing
  tiers".
---

# Persuasion & Sales — score the structure before the prospect sees it

Grade a sales artifact against the gates below, then band it. **Do not run this in the
same pass that wrote the artifact** — a writer grading itself rates its own output
higher. Score felt gates against the winning specimens in
`references/scoring-specimens.md`, ideally on a different model.

Tier discipline: **hard-gate only the countable**; **soft-cap the heuristic**;
**compare the felt against a specimen — never hard-FALSE it.**

Classify the artifact first by the **Three Jobs** spine (maximize opportunities · convert · do
it consistently); the gates below grade Job 2. Job-1 volume levers, Job-3 consistency, team
management, SPCL influence, affiliate tripod/trust, brand-communication levels, Blueprint spine
→ `references/frameworks.md`. Pricing beyond Gate 2 → `references/pricing-and-offer-models.md`
(don't WEAK a sound-but-different model). Prospect diagnosis → `references/five-levels-of-competence.md`.

## The gates (each: positive target → how it's judged → tier)

COUNTABLE gates (1–7) are **hard-gated by script**. FELT gates (8–10) are
**pairwise-vs-specimen** signals (`prefer|tie|weaker`), never a hard FALSE.

1. **Guarantee slots** (COUNTABLE) — *target:* all 3 slots — X (outcome) + Y (timeline)
   + Z (consideration / "or what"). *Script:* all three present; bare "guaranteed" no Z → FAIL.
2. **Goal-pricing arithmetic** (COUNTABLE) — *target:* outcome-based price == weeks-to-goal
   × weekly rate. *Script:* the three numbers multiply out to the stated total.
3. **Three-tier anchor** (COUNTABLE) — *target:* 3 tiers, core the rational middle.
   *Script:* exactly 3 prices, strictly descending anchor > core > downsell.
4. **MESO count** (COUNTABLE) — *target:* 3 simultaneous offers, all acceptable to seller,
   differing on price/terms. *Script:* count == 3.
5. **Increment ratio** (COUNTABLE) — *target:* your concession << theirs; first number is
   the highest defensible anchor. *Script:* your_move / their_move ≤ 0.25.
6. **Qualification checklist** (COUNTABLE) — *target:* passes all 4 — Problem, Money,
   Urgency, Authority. *Script:* all 4 marked present.
7. **Looping re-ask** (COUNTABLE) — *target:* resolve each objection THEN re-ask for the
   sale. *Script:* count of asks after the first "no" ≥ 1.
8. **Anchor height ("get the gasp")** (FELT) — opening number resets their increments upward; *judge* pairwise vs a strong-anchor specimen.
9. **Stack value-build** (FELT) — perceived value accrues before the price reveal; *judge* pairwise vs a winning-stack specimen.
10. **Never-disagree tone** (FELT) — copy makes the prospect right vs winning the argument; *judge* pairwise vs a "make-the-prospect-right" specimen.

Per-gate membership tests and the COUNTABLE definitions (slot tokens, the arithmetic
check, descending-tier test, ratio threshold) are in `references/gate-tests.md`.

## Bands (derive from gates that actually passed — not a hollow count)

Only the gates that APPLY to the artifact count (a lone guarantee has no MESO gate).

- **0–40% of applicable countable gates passed → WEAK** (restructure before showing it).
- **41–80% → SOUND** (usable; tighten flagged gates).
- **81–100% → STRONG** (ship-ready structure).

Count only gates that passed their tier's check. A felt gate contributes only when the
pairwise judge prefers the artifact over the specimen; it never manufactures a pass on its own.
**Guarantee override:** a guarantee that fails Gate 1 (no Z) caps at WEAK regardless of count
— a guarantee with no consideration is the empty promise the structure exists to prevent.
**Qualification override:** a deal/close missing the Authority or Money criterion (Gate 6)
caps at SOUND regardless of count — closing an unqualified prospect is a zombie deal.

## The negatives live here (≤5), each paired with a positive target

Moved out of the writer (where banning a move summons it); each is a checker rule:

- **"Guaranteed" with no consideration** → fails Gate 1; flag. (positive: name the Z —
  "or I will Z")
- **Round flat price with no goal math** → fails Gate 2; flag. (positive: weeks × rate
  = total)
- **Two tiers, or tiers not descending** → fails Gate 3; flag. (positive: anchor > core
  > downsell)
- **Conceding as much as they do** → fails Gate 5; flag. (positive: small move vs their
  large move)
- **Closing before qualifying** → fails Gate 6; flag. (positive: confirm Problem, Money,
  Urgency, Authority first)

## Routing contract (ROUTE — selection/sequencing, not a verdict)

These select WHICH framework applies; they gate routing, not wording. Full table in
`references/routing-contract.md`.

- **Objection-type → framework (Onion of Blame):** peel Circumstances → Others → Self
  ("can't afford it" = Circumstances; "talk to my partner" = Others; "think about it" = Self).
- **Kill zombies early:** ask pre-appointment if anyone else decides; if yes, reschedule with all.
- **BATNA-first:** only negotiate from a real alternative, else anchor/increment gates don't apply.
- **Discount → change-of-terms:** never score a straight discount SOUND; require a swap first.
- **Post-sale commitment:** after a close, route to a public-commitment action to pre-empt remorse.

## Output contract (per artifact)

```
artifact: "<verbatim or id>"
applicable_gates: [<gate numbers that apply to this artifact type>]
gates: [ {n, target, verdict: pass|fail|signal, tier, evidence_quote, source} ]
countable_gates: {guarantee, goal_pricing, tiers, meso, increment, qualification, looping}  # script results
felt_signals: {anchor_height, stack_build, never_disagree}   # pairwise-vs-specimen: prefer|tie|weaker
band: WEAK | SOUND | STRONG
flags: [ ... ]   # from the negatives list
route: {objection_layer, motion, batna_present, decision_makers_present}
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every applicable gate has a verdict; band + route fields present.
**SOUNDNESS:** every COUNTABLE verdict came from the script (not eyeballed); every felt
verdict is pairwise-vs-specimen, not self-graded; band derived only from passed applicable
gates; each `pass` carries an `evidence_quote` verbatim from the artifact; overrides applied.
`emit_ready` only if SOUNDNESS holds; else `BLOCKED:<gate>`.

## Self-test (is this grader sound?) — any NO, fix

- Are only Gates 1–7 hard-gated (by script), with 8/9/10 as pairwise-vs-specimen signals?
- Is the felt judgment run separately from the writer, against a real specimen?
- Does the band come from applicable gates that passed their tier's check, not a raw count?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Are routing rules kept as selection/sequencing (ROUTE), assigning no verdict?
- Is every quoted specimen a verbatim substring of source (no composites)?
- Was the artifact classified by job (1/2/3) and pricing model before scoring?

## See also

- `kb-persuasion-and-sales-write` — WRITE/SCORE sibling — write the prose this skill scores
- `kb-persuasion-score` — adjacent skill — check its scope/boundary before routing here
- `kb-offer-construction-score` — adjacent skill — check its scope/boundary before routing here
