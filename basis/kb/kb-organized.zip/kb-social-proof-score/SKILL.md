---
name: kb-social-proof-score
description: >-
  Grade a planted comment-section testimonial for objection/belief fitness before you paste it
  under a paid ad, and return DISCARD / VIABLE / DEPLOY with per-field evidence. Use when
  vetting testimonials pulled from reviews, DMs, or copy, ranking which comment proof to
  plant, or checking a deployment plan replies to all ad comments. Covers: four countable
  hard-gates (function-fit, target-named, not-generic, reply-to-all-planned), customer-voice
  judged pairwise against a specimen, specific-outcome and slot-overload heuristic warns,
  banding, and the R1–R3 placement/sequencing contract. Does NOT cover scoring VOC/customer
  research synthesis — use kb-customer-data-score for that; classifying case-study positioning
  situations — use kb-case-studies-score; WRITING cold-traffic persuasion copy
  (guarantee/scarcity/authority/objection lines) — use kb-persuasion-write (that one writes,
  this one scores). This skill SCORES against a rubric (no write sibling); run it as a
  separate pass from whatever wrote or selected the testimonial. Triggers: "score this
  testimonial", "is this testimonial worth planting", "rank these comment testimonials", "vet
  this social proof".
---

# Social proof — score a comment-section testimonial before you plant it

Grade each testimonial against the fields below, then band it. **Do not run this in the
same pass that wrote or selected the testimonial** — a selector grading itself rates its
own pick higher. Judge customer-voice against the specimens in
`references/voice-specimens.md`, ideally on a different model.

Anchor terms (Trust signals, Objection handle, Belief, Awareness level) are defined in the
registry — do not redefine them. `references/field-tests.md` carries every membership test
and the countable gate definitions.

Tier discipline: **hard-gate only the countable; soft-cap the heuristic; compare the felt
against a specimen — never hard-FALSE it.**

## The judged fields (each: positive target → how it's judged → tier)

1. **Function-fit** — *target:* the testimonial maps to exactly ONE of
   {overcome a specific objection, install a purchase-driving belief}. *Judge:* script
   gate — exactly one function selected from the closed enum. Tier: COUNTABLE → hard-gate.
2. **Target-named** — *target:* names a known objection (price / skepticism / complexity /
   etc.) OR states a core purchase belief. *Judge:* script gate — an objection token or a
   belief statement is present. Tier: COUNTABLE → hard-gate.
3. **Not-generic** — *target:* it is NOT bare praise — it addresses an objection or installs
   a belief (inverse of generic). *Judge:* script gate — fails if it addresses no objection
   AND installs no belief. Tier: COUNTABLE → hard-gate.
4. **Reply-to-all-planned** — *target:* the deployment plan replies to ALL ad comments, not
   only planted testimonials. *Judge:* script gate — flag present/absent. Tier: COUNTABLE →
   hard-gate (selective reply signals inauthenticity).
5. **Customer-voice** — *target:* reads as authentically customer-written, not polished /
   brand-voiced. *Judge:* FELT — rate pairwise against a customer-voice specimen; never a
   yes/no gate. Tier: FELT (triage signal: prefer | tie | weaker; never a hard FALSE).
6. **Specific-outcome** — *target:* specific and outcome-oriented (a named outcome or
   concrete detail), not generic adjectives. *Judge:* HEURISTIC — soft-cap/warn; specificity
   of language over-flags. Tier: HEURISTIC → warn, do not hard-fail.
7. **Slot-not-overloaded** — *target:* the comment slot reads organic, not manufactured by
   too many testimonials. *Judge:* HEURISTIC — soft-cap/warn; source gives no numeric
   threshold. Tier: HEURISTIC → warn, do not hard-fail.

## Bands (derive from fields that actually passed — not a hollow count)

- **DISCARD** — any COUNTABLE hard-gate (fields 1–4) returns FALSE. Rewrite or re-select.
- **VIABLE** — all four COUNTABLE gates pass, but a HEURISTIC warns or Customer-voice is
  `weaker`/`tie` against the specimen. Plant with revision.
- **DEPLOY** — all four COUNTABLE gates pass, no heuristic warning, and Customer-voice is
  `prefer` against the specimen. Plant as-is.

Count only fields that passed their tier's check. Customer-voice contributes a DEPLOY-lift
only when the pairwise judge `prefer`s it over the specimen; it never manufactures a pass on
its own and never forces a DISCARD.

## ROUTE rules (deployment contract — selection / placement / sequencing)

- **R1 — One-per-objection mapping:** first identify the top 3–5 product objections, then
  match exactly one real testimonial (from reviews or DMs) per objection.
- **R2 — Placement trigger:** post testimonials as COMMENTS on the running paid ad, NOT in
  the ad copy itself.
- **R3 — Reply-to-all trigger:** reply to every ad comment (including planted ones), not
  only the testimonials — gates Field 4 above.

## The negatives live here (≤5), each paired with a positive target

Moved out of the writer (where banning a phrasing summons it). Each is a checker rule:

- **Brand-voiced testimonial** (polished, adjective-heavy, no specific outcomes) → flag.
  (positive: natural customer language with a concrete outcome — Fields 5 + 6)
- **Generic praise** that addresses no objection and installs no belief → DISCARD.
  (positive: map it to one objection or belief — Fields 1–3)
- **Selective replies** (answering only planted testimonials) → flag inauthentic.
  (positive: reply to all ad comments — Field 4 / R3)
- **Overloaded comment slot** (too many testimonials) → warn manufactured-not-organic.
  (positive: one testimonial per objection — Field 7 / R1)
- **Testimonial in the ad copy** instead of the comments → flag misplacement.
  (positive: plant it as a comment on the running ad — R2)

## Output contract (per testimonial)

```
testimonial: "<verbatim>"
fields: [ {name, target, verdict: pass|fail|signal|warn, tier, evidence_quote, source} ]
countable_gates: {function_fit, target_named, not_generic, reply_to_all_planned}  # script, pass/fail
felt_signal: {customer_voice}        # pairwise-vs-specimen: prefer|tie|weaker
heuristic_warns: {specific_outcome, slot_not_overloaded}  # warn|ok
function: overcome_objection | install_belief    # the single enum value chosen (Field 1)
band: DISCARD | VIABLE | DEPLOY
flags: [ ... ]    # from the negatives list
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every field has a verdict; `function` enum chosen; band present.
**SOUNDNESS:** every COUNTABLE verdict came from the script (not eyeballed); `function` is
exactly one value from {overcome_objection, install_belief}; Customer-voice is
pairwise-vs-specimen, not self-graded; band derived only from passed fields; each `pass`
carries an `evidence_quote` that is a verbatim substring of the testimonial. `emit_ready`
only if SOUNDNESS holds; else `BLOCKED:<field>`.

## Self-test (is this grader sound?) — any NO, fix

- Are only Fields 1–4 hard-gated (by script), with Customer-voice as a pairwise-vs-specimen
  signal and Fields 6–7 as soft-cap warnings?
- Is the felt judgment run separately from the writer, against a real specimen?
- Does the band come from fields that passed their tier's check, not a raw count?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Are R1–R3 kept as ROUTE contract (selection / placement / reply-to-all), not quality verdicts?
- Is every quoted specimen a verbatim substring of a source file (no composites)?

## See also

- `kb-customer-data-score` — adjacent skill — check its scope/boundary before routing here
- `kb-case-studies-score` — adjacent skill — check its scope/boundary before routing here
- `kb-customer-data-write` — adjacent skill — check its scope/boundary before routing here
