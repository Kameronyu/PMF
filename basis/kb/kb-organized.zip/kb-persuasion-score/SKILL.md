---
name: kb-persuasion-score
description: >-
  Grade a cold-traffic persuasion stack and ship only what survives, returning REWORK / VIABLE
  / STRONG with per-criterion evidence. Use when grading offer copy or landing-page elements
  (from a human, kb-persuasion-write, or any source), checking if a guarantee/scarcity claim
  is credible, or ranking competing offers before spending traffic. Covers: the 7 criteria
  across three tiers (hard-gate countable guarantee specificity and reset-timer tell, soft-cap
  heuristic scarcity/prominence/authority, pairwise-vs-specimen felt proof), bands and the two
  COUNTABLE overrides, ROUTE selection rules (objection→element, Cialdini sequencing, ethical
  gate, channel), and a ≤5 negatives list. Does NOT cover scoring a 1:1 sales offer / anchor /
  negotiation move — use kb-persuasion-and-sales-score for that; classifying the
  buyer/market/desire before any copy exists — use kb-consumer-psychology-score. This skill
  SCORES against a rubric; pair with kb-persuasion-write. Triggers: "score this cold-traffic
  persuasion stack", "is this guarantee credible", "grade this persuasion stack".
---

# Persuasion — score a cold-offer stack before you spend traffic

Grade each offer against 7 criteria, then band it. **Do not run this in the same pass that
wrote the offer** — a writer grading itself rates its own output higher. Score FELT criteria
against the winning specimens in `references/scoring-specimens.md`, ideally on a different model.

Tier discipline: **hard-gate only the countable**; **soft-cap the heuristic**;
**compare the felt against a specimen — never hard-FALSE it.** Anchor terms (Trust signals,
Objection handle, Awareness level, Extraordinary identifier) are used, never redefined.

## The 7 criteria (each: positive target → how it's judged → tier)

1. **Guarantee specificity** — *target:* a stated guarantee CONTAINS a concrete timeframe
   AND risk-reversal language. *Judge:* **script gate** — `has_timeframe AND has_risk_reversal`.
   Tier: COUNTABLE → **hard-gate** (guarantee present but timeframe-absent → FAIL).
2. **No reset/recycling timer** — *target:* no scarcity/urgency device that resets on reload.
   *Judge:* **script gate** — a countdown that recycles per visit = FAIL. Tier: COUNTABLE → hard-gate.
3. **Scarcity credibility** — *target:* scarcity/urgency claim is plausible and substantiated
   (a real reason given, non-contradictory quantity). *Judge:* HEURISTIC — soft-cap/warn on
   implausible or unexplained scarcity; never hard-fail on judgment alone.
4. **Guarantee prominence** — *target:* risk reversal leads as a headline feature AND repeats
   at checkout, not buried in fine print. *Judge:* HEURISTIC — soft-cap on burial.
5. **Authority substance** — *target:* authority claims show evidence (credential, media,
   demonstrated proof — an Extraordinary identifier counts), not a bare claim. *Judge:*
   HEURISTIC — soft-cap on claimed-without-shown; never hard-fail.
6. **Social-proof specificity** — *target:* proof is specific, named, relatable, not a bare
   star rating. *Judge:* FELT — signal pairwise against a proof specimen; never a hard FALSE.
7. **Proof-audience match** — *target:* testimonials match the prospect's identity/aspiration.
   *Judge:* FELT — signal pairwise against a specimen; never a hard FALSE.

Per-criterion membership tests and the COUNTABLE gate definitions (timeframe tokens,
risk-reversal tokens, reset-timer tell) are in `references/criteria-tests.md`.

## Bands (derive from criteria that actually passed — not a hollow count)

- **0–3 → REWORK** (fix before any traffic).
- **4–5 → VIABLE** (moderate traffic budget).
- **6–7 → STRONG** (top traffic budget).

Count only criteria that passed their tier's check. A felt criterion contributes only when
the pairwise judge `prefer`s it over the specimen (`tie`/`weaker` = no pass). A heuristic
criterion contributes a pass unless it is soft-capped; a soft-cap does not hard-fail the band
but is recorded and drops the band one step.
**Guarantee override (COUNTABLE):** an offer that makes a guarantee CLAIM but fails C1 caps
at REWORK regardless of count — a vague guarantee on cold traffic reads as no guarantee.
**Reset-timer override (COUNTABLE):** any offer failing C2 caps at REWORK — a detected reset
timer is the deterministic tell of manufactured scarcity (fatal to Trust signals).

## ROUTE rules (contract — selection/sequencing by named trigger; no wording, no verdict)

- **Objection → element (Objection handle selection):** "I don't know this brand" →
  Authority + Social Proof; "What if it doesn't work for me?" → Certainty (guarantee);
  "I'll think about it" → Urgency + Scarcity; "Anyone can buy this" → Exclusivity.
- **Stack priority:** Social Proof + Certainty first (trust + risk removal), then
  Urgency/Scarcity to close; Authority amplifies the others when present.
- **Cialdini sequencing:** liking/similarity → authority → social proof → reciprocity (give
  first) → micro-commitment → scarcity (genuine only) → the ask; isolated tactics underperform.
- **Ethical gate (when NOT to deploy):** never deploy leverage against the target's actual
  interest; introduce scarcity only when genuine — never manufacture false deadlines. (Full
  dual-use framework, with defensive recognition-of-manipulation as the named PRIMARY use,
  in `references/route-rules.md`.)
- **Channel selection:** online, social proof + reciprocity lead (Trust signals substitute
  for in-person); prefer video testimonials over text when credibility cues matter.

Full ROUTE contract (placement, channel detail) in `references/route-rules.md`. Named
baseline stacks for judging stack completeness (the validated Nusk stack, Cogut Beauty) are
in `references/scoring-specimens.md`.

## The negatives live here (≤5), each paired with a positive target — checker rules, not writer bans

- **Vague guarantee** (no timeframe / no risk-reversal) → flag, cap REWORK. (positive: a concrete
  N-day + money-back window — see the guarantee specimen)
- **Reset/recycling timer** → flag, cap REWORK. (positive: a real fixed deadline)
- **Round/implausible scarcity number** ("limited stock", a clean "100 left") → soft-cap C3.
  (positive: an oddly specific, real count)
- **Authority claimed but not shown** (expertise asserted, no credential/media/proof) → soft-cap
  C5. (positive: a demonstrated credential or media logo)
- **Generic star-rating-only proof** with no named, relatable testimonial → C6 `weaker`.
  (positive: a named, specific, audience-matched testimonial)

## Output contract (per offer)

```
offer_id: "<id>"
criteria: [ {n, target, verdict: pass|fail|signal|soft-cap, tier, evidence_quote, source} ]
countable_gates: {guarantee_specificity, no_reset_timer}      # script results, pass/fail
heuristic_caps: {scarcity_credibility, guarantee_prominence, authority_substance}  # pass|soft-cap
felt_signals: {proof_specificity, proof_audience_match}       # pairwise-vs-specimen: prefer|tie|weaker
band: REWORK | VIABLE | STRONG
flags: [ ... ]    # from the negatives list
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every criterion has a verdict; band present.
**SOUNDNESS:** every COUNTABLE verdict came from the script (not eyeballed); every FELT
verdict is pairwise-vs-specimen, not self-graded; every heuristic soft-cap names the burial/
implausibility it found; band derived only from passed criteria with overrides applied; each
`pass` carries an `evidence_quote` that is a verbatim substring of the offer.
`emit_ready` only if SOUNDNESS holds; else `BLOCKED:<criterion>`.

## Self-test (is this grader sound?) — any NO, fix

- Are only C1/C2 hard-gated (by script), with C3/C4/C5 soft-capped and C6/C7 pairwise-vs-specimen?
- Is the FELT judgment run separately from the writer, against a real specimen?
- Does the band come from criteria that passed their tier's check, with the two COUNTABLE overrides?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Are ROUTE rules kept as contract (selection/sequencing by named trigger), assigning no verdict?
- Is every quoted specimen a verbatim substring of a source file (no composites)?

## See also

- `kb-persuasion-write` — WRITE/SCORE sibling — write the prose this skill scores
- `kb-persuasion-and-sales-score` — adjacent skill — check its scope/boundary before routing here
- `kb-consumer-psychology-score` — adjacent skill — check its scope/boundary before routing here
