---
name: kb-email-and-retention-score
description: >-
  Grade a retention, email, or lifecycle play against Hormozi's countable thresholds before
  you act on it, and get back REWORK / SOUND / STRONG with per-field evidence. Use to judge a
  retention/churn number, a give:ask ratio or send cap, a membership/billing change, a nurture
  cadence, or a "are we ready to scale yet?" call. Covers: countable gates (retention %, M12
  band, churn, golden ratio, referral-before-scale, give:ask, send cap, LTV:CAC, worst-month
  price, compliance), the care x WTP soft-cap, pain-specificity signal, bands with a scale
  override, and ROUTE rules (nurture cadence, ascension timeline, membership stickiness). Does
  NOT cover writing the retention copy itself — use kb-email-and-retention-write for that;
  scoring an e-commerce email/SMS channel setup against a retention floor — use
  kb-email-marketing-score. This skill SCORES against a rubric; pair with
  kb-email-and-retention-write. Triggers: "is this retention number healthy", "score this
  email cadence", "are we ready to scale", "grade this membership plan".
---

# Email & Retention — score the play before you act on it

Grade each field a plan asserts against its tier's check, then band the plan. **Do not run this
in the pass that wrote the plan** — a proposer grading itself rates its own numbers higher.
Score felt fields pairwise against the specimens in `references/specimens.md`.

Tier discipline: **hard-gate only the countable; soft-cap the heuristic; compare the felt
against a specimen — never hard-FALSE it.** Countable gate definitions and per-field membership
tests live in `references/field-tests.md`; the threshold/band table lives in `references/thresholds.md`.
The named frameworks, classification schemes and diagnostics the ROUTE rules below evaluate against
(Nine C's, Results Flywheel, deletion test, proactive-downgrade, education graduation/consumable,
for-life, the CAC-vs-CPM invisible-hand test, churn-demonstration diagnosis, cumulative reporting,
escalation-to-ascension)
live in `references/frameworks.md` — see it before scoring a membership/continuity/recovery play. The
business-model diagnostics (recurring-vs-reoccurring, two/three compounding mechanisms, LTV-game,
product-as-compounding-vehicle, customer-vs-sale, product-vs-asset push/pivot, newsletter-niche,
quarterly-cleanup, hit-all-three, the green-dye turnaround case) also live there.

## The judged fields (each: positive target -> how judged -> tier)

COUNTABLE (script gate — a number/threshold/timeframe is or isn't present; pass = `pass|fail`):

1. **Annual retention** — *target:* states a retention % AND it clears 80%. *Judge:* gate — number present AND >= 80%.
2. **M12 retention band** — *target:* M12 % matches its business-type band (consumer 50-60%, B2B 80%+, prosumer 40-50% baseline / 60%+ strong). *Judge:* gate — band declared AND number in band.
3. **Monthly churn** — *target:* churn % AND it clears the ceiling (Five Horsemen <3%; VSNB target ~10%, flag ~33%). *Judge:* gate — number present AND under the named ceiling.
4. **Golden ratio** — *target:* %refer / %exit stated AND ratio > 1 (growing). *Judge:* gate — both numbers present AND quotient > 1.
5. **Referral-before-scale** — *target:* referral rate stated AND it clears the pre-scale threshold (e.g. 30%). *Judge:* gate — number present AND >= threshold before any scale decision.
6. **Give:ask ratio** — *target:* personal-content give:ask stated AND >= 98:2. *Judge:* gate — ratio present AND give-share >= 98%.
7. **Email send cap** — *target:* promo sends to main list stated AND <= 2. *Judge:* gate — count present AND <= 2.
8. **LTV:CAC** — *target:* ratio stated; organic healthy at 13:1. *Judge:* gate — ratio present AND >= 1 (flag if < 3:1).
9. **Worst-month price** — *target:* recurring price justified against the customer's worst month, not best. *Judge:* gate — basis named AND it is the worst/low month.
10. **Compliance** — *target:* affiliate/marketing claims don't lie, don't exaggerate, state facts. *Judge:* gate — no claim fails the three-part test.

HEURISTIC (soft-cap / warn, never hard-fail):

11. **Care x WTP value-stack** — *target:* membership elements that are High-Care + High-WTP (access, courses, in-person events) are prioritized; merch/discounts deprioritized. *Judge:* classify each element into the quadrant; warn (don't fail) if low-care/low-WTP elements lead.

FELT (pairwise-vs-specimen signal, NEVER a hard FALSE):

12. **Pain specificity** — *target:* the pain is stated specifically, not vaguely. *Judge:* signal pairwise against the pain specimen in `references/specimens.md`; return `prefer | tie | weaker`. Never a hard FALSE, never self-graded.

## Bands (derive from fields that actually passed — not a hollow count)

- **any COUNTABLE field fails its gate -> REWORK** (fix the number before acting).
- **all COUNTABLE pass, heuristic clean -> SOUND** (act with normal confidence).
- **all COUNTABLE pass AND retention/churn/referral fields are at the strong end (M12 60%+, churn <3%, golden ratio > 1) -> STRONG** (compound; safe to scale).

Count only fields that passed their tier's check. A felt signal contributes nothing to the
band on its own; a heuristic warn drops STRONG to SOUND but never to REWORK.
**Scale override (ROUTE):** never advance to a scale-acquisition decision while field 5
(referral-before-scale) fails — cap the band at REWORK regardless of the other counts. Fix the
bucket before pouring water in.

## ROUTE rules kept as contract (named-trigger selection / sequencing)

- **Build back-to-front:** fix retention/fulfillment BEFORE scaling acquisition; gate 5 enforces it.
- **Activation-first order:** activate existing -> refine front-end -> scale acquisition.
- **Inverse nurture cadence:** leads = decreasing cadence; escalations = increasing (1x->2x->3x), multi-lane.
- **Email nurture architecture:** broadcast 1x/wk B2B, 3x/wk consumer; behavioral flows 5+ emails; start conservative, raise with health metrics.
- **Five-Point Ascension timeline:** offer the ascension at <=24h, first win, halfway, milestone, end — not only the end.
- **Invisible-hand / negative-WOM gate (countable diagnostic):** if CAC growth-rate > CPM growth-rate, negative word of mouth is active — block "scale acquisition" and route to product fix first. (`frameworks.md`)
- **Diagnose churn before scaling:** treat post-Q2 churn as a value-*demonstration* gap, not only delivery — require a reporting cadence (log into their system, show their own numbers). (`frameworks.md`)
- **Membership stickiness levers:** grade a continuity offer against the Nine C's toward net-negative churn; education needs a repurchased consumable or a graduation/next-level pathway, not an unrelated product. (`frameworks.md`)
- **Improve via deletion, not addition:** overwhelm is the #1 cancel reason — prefer the keep-one-thing survey + silent prune over feature-stacking. (`frameworks.md`)
- **Service recovery must over-compensate:** a plain refund fails the 37-magical-moments rule; make it more than right. (`frameworks.md`)
- **Escalation = ascension:** grade a cancellation/escalation plan against the sales-opportunity rule — let the customer vent, then offer the higher-priced upsell; ~25% (1-in-4) conversion covers the other 3 cancellations. A refund-and-end plan forfeits this. (`frameworks.md`)

## The negatives live here (<=5), each paired with a positive target

Moved out of any writer. Each is a checker rule:

- **Round / vague retention claim** ("good retention") -> fails the gate. (positive: a stated % vs the named threshold)
- **Best-month pricing** -> flag; reprice. (positive: price against the worst month)
- **Scaling before referral threshold** -> cap at REWORK. (positive: hit the pre-scale referral rate first)
- **Give:ask below 98:2** (over-asking) -> flag. (positive: 98% give, 2% ask)
- **Exaggerated affiliate claim** -> fails compliance. (positive: don't lie, don't exaggerate, state facts)

## Output contract (per plan)

```
plan: "<verbatim or paraphrase of the play being scored>"
fields: [ {n, target, verdict: pass|fail|warn|signal, tier, evidence_quote, source} ]
countable_gates: {annual_retention, m12_band, monthly_churn, golden_ratio,
                  referral_before_scale, give_ask, send_cap, ltv_cac, worst_month_price, compliance}
heuristic: {care_wtp_stack: ok|warn}
felt_signals: {pain_specificity: prefer|tie|weaker}
band: REWORK | SOUND | STRONG
flags: [ ... ]   # from the negatives list
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every judged field has a verdict; band present.
**SOUNDNESS:** every COUNTABLE verdict came from the number-vs-threshold gate (not eyeballed);
the heuristic is a warn not a fail; the felt verdict is pairwise-vs-specimen, not self-graded;
band derived only from passed fields and honors the scale override; each `pass` carries a
verbatim `evidence_quote`. `emit_ready` only if SOUNDNESS holds; else `BLOCKED:<field>`.

## Self-test (is this grader sound?) — any NO, fix

- Are only fields 1-10 hard-gated (by number-vs-threshold), with 11 soft-capped and 12 pairwise-vs-specimen?
- Is the felt judgment run separately from any writer, against a real specimen?
- Does the band come from fields that passed their tier's check, not a raw count?
- Are the negatives <=5, here in the checker, each paired with a positive target?
- Is the scale override kept as a ROUTE rule (cap at REWORK while referral gate fails)?
- Is every quoted specimen a verbatim substring of a source file (no composites)?

## See also

- `kb-email-and-retention-write` — WRITE/SCORE sibling — write the prose this skill scores
- `kb-email-marketing-score` — adjacent skill — check its scope/boundary before routing here
- `kb-conversion-optimization-score` — adjacent skill — check its scope/boundary before routing here
