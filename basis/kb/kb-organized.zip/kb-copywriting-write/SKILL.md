---
name: kb-copywriting-write
description: >-
  Write direct-response copy that buys attention before it sells — the line a reader feels.
  Use when generating or rewriting headlines, hooks, ad body, CTAs, outreach scripts, naming,
  or positioning lines for ads, landing pages, or advertorials. Covers: real winning specimens
  to steal structure from, craft targets (attention-before-claim, specificity, prospect's
  verbatim language, sell-the-outcome), optional named formulas (Money Mad Lib,
  Feature→HOW→Outcome, Push-Pull, Damaging Admission, Contrast Headline), and
  awareness→approach / angle-differentiation selectors. Does NOT cover grading or gating copy
  — use kb-copywriting-score for that; full VSL scripts — use kb-vssl-write; paid
  Meta/TikTok/Native ad wording specifically — use kb-ads-write. This skill WRITES prose; pair
  with kb-copywriting-score. Triggers: "write a headline / hook / ad / CTA", "rewrite this
  ad", "punch up this landing page copy".
---

# Copywriting — write the line that sells

Copy executes an **angle** (the emotion you invoke) and a **claim** (what the product does)
in the prospect's own language. Your job is the *wording* a reader feels — the line that
buys attention before any product claim, then earns the next line. Lead from the specimens
below; reach for a formula only if it helps; keep it specific, plain, and short.

## Start here — real winning specimens (study these before writing)

These are preserved verbatim from the source. They steer you harder than any rule. Read
them, feel why each lands, then write your own — do not fill them into a template.

- **Steal the structure, not the words (the marquee move):**
  *"I think I just got scammed"* → re-expressed cross-niche as *"My doctor was wrong for 10 years"*
  — map the psychological structure (negative event + stakes + curiosity gap) and rebuild it
  in your own niche. The further from the original niche, the more novel the transplant.
- **Punch in the gut (PIG):** *"Is that a gray hair?"*
  — an intense low-energy emotion (fear of aging) triggered in the fewest words possible;
  effectiveness scales *inversely* with word count.
- **Externalize the blame:** *"It's not your fault. The modern world around you is literally designed to destroy your testosterone levels."*
  — lifts shame off the prospect and onto the environment, so the pain reads as solvable.
- **Positioning in one line (Money Mad Lib):** *"I help 45-year-old women who just had kids get back into their high school jeans without giving up time with their family."*
  — names exactly WHO, the concrete GOOD, and the BAD avoided; specificity does the work.
- **Tie the benefit to status:** *"a cookbook so fast and easy that all your friends will wonder how you found the time to be fit and cook for your family."*
  — sells not the feature (fast) but how others will see them (status), the deeper driver.
- **Damaging admission:** *"Our websites are ugly as hell, but they convert."*
  — concede a real flaw, then pivot to the belief you want; the admission buys credibility.

More specimens — headlines, ad body, CTAs, outreach, naming — are in
`references/specimen-bank.md`. Study them before drafting.

## Craft targets (steer by these; they are not a rulebook)

- **Attention before claim.** The first line buys attention (curiosity, pain, a gut-punch)
  before it sells anything. Make line one make line two necessary.
- **Specificity over superlative.** A concrete number, named moment, or timeframe beats
  "fast" / "amazing." *"Do you have trouble getting upstairs"* beats *"Are you overweight?"*
- **Their words, not yours.** Write in the prospect's verbatim language from VOC research,
  not inferred synonyms. If they said "smoother and less dry," don't write "hydrated."
- **Sell the outcome / identity, not the feature.** People buy the transformation and how
  it makes them look to others — translate every feature into a felt benefit or a moment.
- **Clear over clever.** Wit that hides the angle is a leak. Plain words, low reading grade.
- **Fewest words that keep the pull.** Draft, then cut every word that adds no information
  or no pull. The concrete mechanic — cut 50% → fill gaps → cut 50% → repeat, plus the
  two-adjacent-sentences deletion test — is in `references/procedures.md`.

## Optional patterns (reach for one; never force a fixed slot order)

Money Mad Lib · Feature→HOW→Outcome · Push-Pull · Damaging Admission · Contrast Headline ·
Status-Benefit · MAGIC/Lead-Magnet naming · Externalize-Blame · "How to X without Y, even if Z."
Each is a shape to borrow, not a required sequence — forced slots produce same-y copy, the
one failure mode for work whose whole job is to stand out. Anatomy and a worked example for
each is in `references/formulas.md` — which also holds the Desire-to-Headline 12×2 Matrix, a
generative scaffold for exhausting 24 angles per product before you select. Full anatomy for
the named source frameworks (Sequential CTA Close Stack 6-step, Epiphany Bridge testimonial,
Masterson's Six Lead Types, Halbert Hypothetical Maximum, Eight-Element Sales Page, Problem
Amplification Cascade, Two-Option Close, objection-mapped testimonial placement, New
Information as Mechanism, Avatar Revenue Scale, Price-Per-Unit reframe, Vague Discount rule,
YouTube-transcript research, Casual Referral extraction, Congruence Chain) is in
`references/frameworks.md`.

## Contract rules (these DO bind — they pick the shape, not the words)

These are steering selectors: which form/approach fits the situation. They dictate no wording.

- **Awareness → copy approach** (rises in specificity with awareness):
  - *Unaware* → curiosity hook; create problem-awareness first (lead T2–T3, life-frame).
  - *Problem-aware* → describe their specific problem in their own words (lead T1).
  - *Solution-aware* → reference the failed solutions; educate on the unique mechanism.
  - *Product-aware* → compare variants; lead objection handles, trust signals, guarantees.
  - *Most-aware* → direct offer; the value model (urgency/scarcity/discount) is the lever.
- **Saturated market → angle differentiation:** same product, a new pain/desire angle per
  sub-market; don't repeat the base claim 5+ competitors already make.
- **Dual-persona angle:** gift-buyer angle vs self-buyer angle — pick by who's reading.
- **Section ORDER is structural, not creative:** advertorial / sales-page / VSL / CTA-stack
  sequences (e.g. Spencer's 6-step close) are ordering contracts — don't reorder them.
- **Urgency = time, Scarcity = quantity, and both must be legitimate** (real deadline / real
  limit) — never manufactured.
- **Offer-type → pitch complexity:** DIY (light) / DFY / DWY (heavier proof + path).

See `references/route-rules.md` for the full selection contract and the awareness×angle map.
For the research→wording and AI-production pipelines that FEED this writer — the Sub-Avatar
Reddit method (400+ comment signal → verbatim quotes → 3–5 headlines/angle), the iterative
compression loop, the Four Foundational Documents + Claude-project workflow, GetHooked (0.7),
read-aloud/ElevenLabs copy-chiefing, and the two reverse-review Claude inputs — see
`references/procedures.md`.

## How to use this with the grader

Generate several diverse candidates (vary the angle and the formula; don't iterate one
line toward "safe"). Then hand them to **kb-copywriting-score** — a separate skill, ideally
a different model — for the gates and the pairwise-vs-specimen judgment. The reading-grade
gate, the 7-point hook checklist, Facebook-compliance, the Valence×Intensity quadrant, and
all banned-phrase checks live THERE, not here. Do not grade your own output in this skill;
a writer that judges itself optimizes toward "looks like copy," not "makes them buy."

## Before handoff (what kb-copywriting-score checks)

Awareness only — these are what the separate scorer will look at, not a writer gate.
Generate several diverse drafts; the separate scorer grades — do not self-grade toward the gate.

- Whether the first line buys attention before any product claim and makes the next line necessary.
- Whether it is specific (a number, named moment, or timeframe) rather than superlative.
- Whether it is in the prospect's verbatim language, clear enough for a low reading grade.
- Whether it sells the outcome / identity, not just a feature.

## See also

- `kb-copywriting-score` — WRITE/SCORE sibling — score a draft this skill writes (separate pass)
- `kb-persuasion-write` — adjacent skill — check its scope/boundary before routing here
- `kb-vssl-write` — adjacent skill — check its scope/boundary before routing here
