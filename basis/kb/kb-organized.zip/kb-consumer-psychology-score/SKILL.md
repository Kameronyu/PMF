---
name: kb-consumer-psychology-score
description: >-
  Classify the buyer, market, and desire and gate the copy-architecture contracts BEFORE a
  word of copy is written or test budget is spent, returning per-field enum labels plus
  PASS/BLOCKED with verbatim evidence. Use to grade a prospect's awareness stage, a market's
  sophistication, an offer's mass desire, an avatar's completeness, a VOC/testimonial set, or
  a necessary-beliefs doc. Covers: awareness/sophistication/desire-quadrant/mass-drive
  classification, verbatim-VOC and testimonial-mapping gates, the 3-7 belief count, >=3
  angles, 95/5 split, 5-category avatar, 4 audience criteria, and the saturation override.
  Does NOT cover scoring a cold-traffic persuasion stack
  (guarantee/scarcity/social-proof/authority) — use kb-persuasion-score; nor scoring a live
  sales offer, anchor, or negotiation move — use kb-persuasion-and-sales-score. This skill
  SCORES against a rubric (no writer sibling — run as a separate pass from any writer).
  Triggers: "what awareness stage is this", "classify this market sophistication", "is this
  avatar complete", "is this VOC verbatim".
---

# Consumer psychology — classify the buyer, gate the contracts, before copy

Classify each judged field against its enum, run the countable gates by script, then route the
messaging strategy. **Do not run this in the same pass that writes copy** — a writer grading its
own classification rates it as fitting. Resolve all enum labels against the term registry; never
redefine a registry term. Anchor terms used here: *Awareness level*, *Market sophistication*,
*Stage → required levers matrix*, *Four core human drivers*, *Angle*, *Trust signals*,
*UM / Problem UM / Product UM*, *Command+F verbatim rule (for desire)*, *Source venues by tier*.

Tier discipline (the rule a fused skill breaks): **hard-gate only the countable; soft-cap the
heuristic; compare the felt against a specimen — never hard-FALSE it.**

## Judged fields (each: positive target → enum/template → tier)

1. **Mass-market drive** — *target:* offer maps to exactly one of `{Reproduction | Social-Comparison | Social-Belonging | Safety-Security}` (or the 6 Mass-Instinct enum). *Judge:* **script gate** — value ∈ enum, with an evidence_quote. COUNTABLE → hard-gate.
2. **Awareness stage** — *target:* prospect/asset ∈ `{Unaware | Problem-Aware | Solution-Aware | Product-Aware | Most-Aware}`. *Judge:* script gate — value ∈ enum. COUNTABLE → hard-gate.
3. **Sophistication stage** — *target:* market ∈ `{New | Early | Growing | Established | Saturated}` (defers to *5+ saturation rule*). *Judge:* script gate — value ∈ enum. COUNTABLE → hard-gate.
4. **VOC verbatim** — *target:* every stored phrase is verbatim (survives Command+F vs the research doc), clustered into `{pains | objections | excuses}`; no paraphrase. *Judge:* script gate — each quote is a substring of the research corpus. COUNTABLE → hard-gate.
5. **Angle count** — *target:* ≥3 distinct angles tested on cheap ads before any VSL/funnel build. *Judge:* script gate — count ≥3, each row distinct. COUNTABLE → hard-gate.
6. **Necessary-Beliefs count** — *target:* a Necessary Beliefs Document lists 3–7 specific blocking beliefs before copy. *Judge:* script gate — 3 ≤ count ≤ 7, each row a specific belief. COUNTABLE → hard-gate.
7. **95/5 copy split** — *target:* ≥95% of copy on outcomes/results, ≤5% on product features/specs. *Judge:* script gate — feature-share ≤ 5%. COUNTABLE → hard-gate (advisory cap).
8. **Testimonial mapping** — *target:* each testimonial maps to one strategic function `{pre-handle | seed}` AND to a named belief from the Beliefs Doc. *Judge:* script gate on the mapping; "specific enough?" is the FELT edge → pairwise-vs-specimen, never a hard FALSE. COUNTABLE (+FELT edge).
9. **Desire quadrant** — *target:* desire ∈ one Intensity × Scope cell `{niche | commodity | scaling | low-low}`. *Judge:* script gate — value ∈ enum. COUNTABLE → hard-gate.
10. **Sub-avatar completeness** — *target:* all 5 categories `{Desires | Demographics | Emotions | Behaviors | Product-Experiences}` present; avatar count matches revenue band. *Judge:* script gate — 5 keys non-empty; count keyed to band. COUNTABLE → hard-gate.
11. **Emotion unpack** — *target:* each reported (secondary) emotion is unpacked to its primary-cluster enum. *Judge:* script gate — each secondary has a primary mapping. COUNTABLE → hard-gate.
12. **Audience criteria** — *target:* candidate scored on all 4 `{growing | can-pay | easy-to-target | in-pain}`. *Judge:* script gate — 4 verdicts present. COUNTABLE → hard-gate.
13. **WIIFM read** — *target:* copy reads as answering "What's in it for me?" *Judge:* FELT — pairwise vs a winning specimen in `references/scoring-specimens.md`; return `prefer | tie | weaker`; never a hard FALSE.

Per-field membership tests, enum definitions, and gate thresholds are in
`references/field-tests.md`. Stage→strategy routing is in `references/route-rules.md`. The models
behind the gates (Dual-System 99/1, Pain-Threshold 3 levers + loss-aversion 2x, Two-Forces-of-Desire
+ Mass Education, Cognitive-Bias stack, Social-Proof/Mere-Exposure/Trigger numbers, Self-Efficacy)
are in `references/frameworks.md`; the upstream SOPs that produce the gated artifacts (Foundational
Docs SOP, 5-category Reddit protocol, Amazon review-mining) are in `references/procedures.md`; the
seasonal/Desire-Calendar data feeding R9 is in `references/data-calendar.md`.

## Bands / verdict (derive from gates that actually passed — not a hollow count)

- **Any COUNTABLE gate fails → BLOCKED** (fix before copy/test). Report `BLOCKED:<field>`.
- **All COUNTABLE gates pass, WIIFM `weaker` → REVISE-COPY** (classification sound; copy below specimen).
- **All COUNTABLE gates pass, WIIFM `prefer|tie` → READY.**

A felt signal never manufactures a pass; it only downgrades READY→REVISE-COPY. **Saturation override
(structural):** if Sophistication = `Saturated` and the messaging strategy carries no *Extraordinary
identifier*, cap at BLOCKED regardless of other gates — the enum membership is countable, the
identifier-absence is read off the routed strategy. See `references/route-rules.md`.

## The negatives live here (≤5), each paired with a positive target

Moved out of any writer (where banning a token summons it). Each is a checker rule:

- **Paraphrased VOC** ("hydrated" for "smoother and less dry") → fails field 4. (positive: verbatim, Command+F-passing phrase)
- **Generic testimonial** ("This product is great!") → fails field 8 mapping. (positive: specific pain + named belief)
- **<3 angles before funnel build** → fails field 5. (positive: ≥3 distinct angles validated on cheap ads first)
- **Copy before the Beliefs Doc** → fails field 6. (positive: 3–7 beliefs documented first)
- **Surface demographics over deep motivation** → soft-cap (HEURISTIC), warn not fail. (positive: desire-led avatar)

## Output contract (per assessed asset)

```
asset: "<verbatim or id>"
fields: [ {n, target, value|verdict, tier, evidence_quote, source} ]
countable_gates: {drive, awareness, sophistication, voc, angles, beliefs, split,
                  testimonials, quadrant, avatar, emotion, audience}  # script pass/fail
felt_signal: {wiifm: prefer|tie|weaker}                              # pairwise-vs-specimen
routed_strategy: "<lever from Stage → required levers matrix>"        # ROUTE output
verdict: READY | REVISE-COPY | BLOCKED:<field>
flags: [ ... ]   # from the negatives list
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every applicable field has a value/verdict; routed_strategy present; verdict present.
**SOUNDNESS:** every COUNTABLE value ∈ its enum AND came from the script (not eyeballed); every
enum label carries an evidence_quote that is a verbatim substring of the asset/source; counts (3–7
beliefs, ≥3 angles, 5 avatar keys, 4 criteria) each pass their per-item predicate; the WIIFM signal
is pairwise-vs-specimen, not self-graded; saturation override applied. `emit_ready` ONLY if every
SOUNDNESS box holds; else `BLOCKED:<field>`.

## Self-test (is this grader sound?) — any NO, fix

- Is every judged field given a positive target + an enum/template + a FALSE-capable test?
- Are ONLY the countable fields hard-gated by script, with WIIFM kept as pairwise-vs-specimen?
- Is the felt read run separately from any writer, against a real specimen?
- Does the verdict come from gates that passed their tier's check, not a raw count?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Are ROUTE rules (stage→lever, awareness→funnel, saturation override) kept as contract, not wording?
- Is every quoted specimen a verbatim substring of a source file (no composites)?

## See also

- `kb-persuasion-score` — adjacent skill — check its scope/boundary before routing here
- `kb-copywriting-score` — adjacent skill — check its scope/boundary before routing here
- `kb-customer-data-score` — adjacent skill — check its scope/boundary before routing here
