---
name: kb-offer-construction-write
description: >-
  Write the felt copy that makes an offer's price feel small — the value-stack pitch,
  guarantee and risk-reversal language, the outcome-reframe close, bonus names with value
  lines, and the narrative repositioning that renames a commodity into a proprietary-sounding
  offer. Use when drafting or rewriting offer copy, wording a guarantee, naming and stacking
  bonuses, or coining a mechanism name. Covers: best/worst-case risk-reversal, outcome-reframe
  closes, bonus value-line stacks, narrative repositioning/mechanism naming, buyer-language
  craft targets, and contract rules (awareness routing, guarantee type, front-end model, NTPMA
  order). Does NOT cover setting the price number or compare-at math — use kb-pricing-score
  for that; backend/cart upsell and OTO wording — use kb-upsells-write; a standalone
  cold-traffic, skeptic-facing guarantee or scarcity line not tied to the value stack — use
  kb-persuasion-write. This skill WRITES prose; pair with kb-offer-construction-score.
  Triggers: "write the offer", "write the offer's guarantee", "name these bonuses", "stack the
  value", "reframe this as an outcome".
---

# Offer construction — write the words that make the price feel small

An offer executes a **Market** (Niche × Transformation) through a **value model** — bundle,
pricing, guarantee, bonus, mechanism. Your job is the *wording the buyer feels*: the line
that makes the dream outcome vivid, the guarantee that removes the risk, the stack that
makes saying no feel irrational. You manipulate the value side, not the price side. Lead
from the specimens below; reach for a formula only if it helps; say it in the buyer's
language, not the seller's.

## Start here — real winning specimens (study these before writing)

These are preserved verbatim from the source. They steer you harder than any rule.

- **Risk-reversal frame (best/worst case):** *"Best case scenario, you change your life forever... Worst case scenario, you work out for 6 weeks basically for free. You tell me I suck and I give you your money back."*
  — collapses the decision to two outcomes and makes the downside itself attractive ("basically for free"); the guarantee is spoken in the buyer's own voice ("you tell me I suck"), not legal boilerplate.
- **Outcome-reframe close:** *"When you pay $4,500, you can count that weight gone. You can put it out of your mind. We're going to get there one way or another as long as you follow the steps."*
  — reframes the price as the purchase of a finished result, not a service; "count that weight gone" sells the after-state as already true, and "one way or another" transfers the responsibility to the seller.
- **Leverage / value-stack payoff:** *"That's how you increase leverage to sell an offer set for 25 bucks for a hundred thousand dollars."*
  — names the gap between cost and price as the whole game; the concrete two-number contrast ($25 → $100k) carries the lesson without a single adjective.
- **Narrative repositioning (rename the commodity):** *"30-Day Mojo Mastery Challenge"* used instead of *"testosterone booster"* as the offer name.
  — a proprietary-sounding, outcome-and-timeframe name replaces the category label; perceived novelty drives conversion independent of actual product newness.

More specimens — guarantee phrasing, bonus value lines, mechanism names, the bonus-stack
craft target — are in `references/specimen-bank.md`.

## Craft targets (steer by these; they are not a rulebook)

- **Buyer's language, not the seller's.** State the dream outcome the way the buyer would say
  it to a friend. Seller terminology ("testosterone booster") names the product; buyer
  language ("get your Mojo back") names the transformation. When in doubt, lift their words.
- **Sell the after-state as already true.** "You can count that weight gone" beats "this helps
  you lose weight." Write from the far side of the result.
- **Make the downside attractive, not just covered.** A guarantee removes risk; the best
  risk-reversal makes even the worst case sound like a win ("for 6 weeks basically for free").
- **Specificity over superlative.** A number, a named outcome, or a concrete timeframe
  ("30-Day," "$4,500," "6 weeks") beats "amazing" or "life-changing." Enter the desire the
  buyer already has; don't announce it.
- **Each stacked item earns its keep.** The craft bar for the value stack: *"Each thing we add
  on its own should be worth the price of the whole thing."* Name bonuses by the outcome they
  unlock, not by a generic label. To *decide which* items make the stack, use the Magic Questions
  prioritization method (two inverse customer questions → power ranking) in `references/formulas.md`.
- **Map the functional product first.** Before writing, run the Two-Product Reality map — list the
  problems solved, benefits delivered, experiences created — and write copy from those outcomes,
  not the bare features. Procedure in `references/formulas.md`. (Discovering a nameable mechanism
  to reposition with: the Assumed New Mechanism 5-Category Checklist, same file.)

## Optional patterns (reach for one; never force a fixed slot order)

Risk-Reversal (best/worst case) · Outcome-Reframe Close · Narrative Repositioning ·
Bonus Value-Line ("you get X ($497 value) free") · Mechanism Naming (rhyme/alliteration,
e.g. "muscle confusion"). Each is a shape to borrow, not a required sequence. Anatomy and a
worked example for each is in `references/formulas.md`.

## Contract rules (these DO bind — they pick the shape, not the words)

- **Awareness routing:** cold-friendly offers target *Unaware + Problem-Aware* — lead with a
  disruptive angle, a named unique mechanism, and a precise avatar. An organic-validated offer
  does not transfer to paid cold traffic unchanged.
- **Guarantee type by stage/risk:** *unconditional* (starting out — maximum lift and exposure)
  · *conditional* (filters the uncommitted) · *implied-performance* · *anti-guarantee* (only
  when reputation is strong enough that none is needed). Pick the type by stage; the *wording*
  of whichever you pick is your job here.
- **Front-end model by funnel:** high-AOV bundle front-end (covers CAC on first sale) **vs**
  low-price entry ($5/$9) + backend upsell stack. Write the value copy to fit the chosen model.
- **Desire-saturation precondition:** a desire already met by existing products cannot be
  claimed again without a new mechanism — so when the category is saturated, the *name* and the
  *mechanism* are what you reposition (this is why narrative repositioning exists).
- **NTPMA order:** the offer is built Niche → Transformation → Price → Mechanism → Access.
  Write the transformation copy before you name the mechanism, never the reverse.

## How to use this with the grader

Generate several diverse offer drafts (vary the guarantee type, the reframe, the naming;
don't iterate one toward "safe"). Then hand them to **kb-offer-construction-score** — a
separate skill, ideally a different model — for the gates (compare-at ratio, margin floors,
value-equation direction, bonus-stack ≥ core price, seven-component section, three-tier
pricing) and the pairwise-vs-specimen judgment ("does it make saying no feel irrational?").
Do not grade your own output here; the writer that judges itself optimizes toward "looks like
an offer," not "makes the price feel small." The numeric and presence checks live there, not here.

## Before handoff (what kb-offer-construction-score checks)

Generate several diverse drafts; the separate scorer grades — do not self-grade toward the gate.
For awareness only, these are the dimensions that pass downstream:

- The dream outcome stated in the buyer's language, written from the after-state.
- A guarantee/risk-reversal that makes even the worst case feel acceptable or attractive.
- At least one concrete specific (number, named outcome, or timeframe).
- Bonuses named by outcome, with each stacked item plausibly worth the whole price.
- A spread of diverse drafts rather than one polished safe one.

## See also

- `kb-offer-construction-score` — WRITE/SCORE sibling — score a draft this skill writes (separate pass)
- `kb-persuasion-write` — adjacent skill — check its scope/boundary before routing here
- `kb-upsells-write` — adjacent skill — check its scope/boundary before routing here
