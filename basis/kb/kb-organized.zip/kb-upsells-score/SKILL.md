---
name: kb-upsells-score
description: >-
  Grade an upsell / AOV plan against countable gates and felt signals before you build the
  funnel, returning DISCARD / VIABLE / SHIP with per-field evidence. Use when checking an OTO
  stack, a post-purchase sequence, a price-tier format choice, or an AOV:front-end ratio
  before spend. Covers: the 5 countable gates (AOV≥2x ratio, OTO1 max price, 2-4 post-purchase
  OTO count, price-tier→format match, 50%-off downsell popup); two felt signals (offer
  relevance, OTO1 problem-fit) scored pairwise-vs-specimen; band derivation with ratio +
  relevance overrides; the ≤5 negatives; and ROUTE placement/offer-type contracts. Does NOT
  cover Hormozi pricing-multiple / take-rate / blended-value monetization math — use
  kb-upsells-and-monetization-score for that; order-page sequencing-config benchmark scoring —
  use kb-aov-optimization-score. This skill SCORES against a rubric; pair with
  kb-upsells-write. Triggers: "score this upsell", "is this AOV plan viable", "grade this OTO
  stack", "check this post-purchase sequence".
---

# Upsells — score an AOV plan before it ships

Grade an upsell plan against the gates below, then band it. **Do not run this in the same
pass that wrote the plan** — a writer grading itself rates its own output higher. Score felt
fields pairwise against the winning specimens in `references/scoring-specimens.md`, ideally
on a different model.

Tier discipline: **hard-gate only the countable**; **soft-cap the heuristic**; **compare the
felt against a specimen — never hard-FALSE it.** Inputs: an upsell/AOV plan (front-end price,
OTO prices, sequence, formats). Output: the contract below. Consumer: the human or
orchestrator deciding whether to build the funnel.

## Countable gates (script-checkable; each → pass|fail by shape)

1. **AOV:front-end ratio** — *target:* planned AOV ≥ 2× front-end price (minimum); 2–3× target.
   *Gate:* `ratio = AOV / front_end`; PASS iff `ratio >= 2`. `ratio == 1` (1:1) → FAIL.
2. **OTO1 max price** — *target:* OTO1 priced no more than 10× the front-end price.
   *Gate:* PASS iff `oto1_price <= 10 * front_end`.
3. **Post-purchase upsell count** — *target:* 2–4 one-time offers in the dopamine window.
   *Gate:* PASS iff `2 <= post_purchase_oto_count <= 4`.
4. **Price-tier → format match** — *target:* format complexity scales with front-end tier.
   *Gate:* `<$50 → simple one-section`; `$50–$150 → five-section TSL`; `$150+ → VSL w/ authority`.
   PASS iff the chosen format equals the tier's required format; mismatch → FAIL.
   (The 5 named TSL sections + Collagen/Truly-Free/Nuru worked examples: see `references/frameworks-procedures.md`.)
5. **Downsell on rejection** — *target:* OTO1 reject → same product at 50% off via popup.
   *Gate:* PASS iff `downsell_discount == 50%` AND `downsell_channel == popup` (not a page).

Per-gate predicates, the tier-format table, and benchmark reference numbers (AOV lift 10–30%,
in-cart ~50% take / ~$20, cross-sell 3× margin, OTO $200–300) are in `references/criteria-tests.md`.

## Felt signals (pairwise-vs-specimen — prefer|tie|weaker; NEVER a hard FALSE)

6. **Offer relevance / logical connection** — *target:* every upsell is logically connected to
   the just-purchased item, not random. *Judge:* FELT — signal against a relevance specimen;
   `weaker` contributes no pass. Never a script gate.
7. **OTO1 problem-fit** — *target:* OTO1 solves the original problem better/faster/easier OR a
   new problem the first purchase created. *Judge:* FELT — signal against a problem-fit specimen.

## Bands (derive from gates+signals that actually passed — not a hollow count)

Count only fields that passed their tier's check. A felt signal contributes only when the
pairwise judge returns `prefer`; it never manufactures a pass on its own.

- **0–2 → DISCARD** (rework before building).
- **3–4 → VIABLE** (build, monitor AOV).
- **5+ (all countable pass, both felt prefer) → SHIP** (top funnel priority).

**Ratio override (structural):** if Gate 1 fails (AOV:front-end < 2:1, including 1:1), cap the
band at DISCARD regardless of count — a sub-2:1 plan is the "sell one product and stop"
anti-pattern. The ratio is countable; this override is a hard cap.
**Relevance override:** if Signal 6 returns `weaker` (a random/disconnected upsell), drop one
band and note "re-anchor the offer to the just-purchased item."

## The negatives live here (≤5), each paired with a positive target

Moved out of the writer (where banning a pattern summons it). Each is a checker rule:

- **1:1 AOV ratio** → flag DISCARD. (positive: price a post-purchase OTO so AOV ≥ 2× front-end)
- **Format–tier mismatch** (simple copy on a $200 upsell; VSL on a $10 upsell) → flag Gate 4 fail. (positive: match format to the tier table)
- **Logically unrelated upsell** (random product after add-to-cart) → flag Signal 6 `weaker`. (positive: offer logically connected to the item just added)
- **Separate downsell page** instead of popup → flag Gate 5 fail. (positive: same product 50% off via popup)
- **Generic thank-you page** as a dead end → flag. (positive: replace with the OTO sequence; soft thank-you recommendation below confirmation)

## ROUTE — placement & offer-type contracts (named-trigger selection; no verdict)

These are sequencing/selection rules, not scored fields. Enforce as a contract:

- **Funnel stage map:** product/collection → add-to-cart → cart → checkout → post-purchase
  (pre-thank-you) → thank-you → email/SMS. Deploy at every stage. Per-stage execution
  mechanics in `references/frameworks-procedures.md`.
- **Product/collection stage:** lifestyle imagery (4 people, normalize multi-unit/gifting),
  data-driven "frequently bought together" slider, bundle pre-selection (anchoring). See refs.
- **Cart stage:** spend-threshold progress bar unlocking a free gift + one-click add (the
  gamification mechanic, not just the "free shipping" copy). See frameworks-procedures.md.
- **AOV stack order:** quantity discount → order bump → OTO1 → downsell popup → OTO2/OTO3 → email/SMS.
- **OTO placement:** strictly post-payment, pre-thank-you; redirect to OTO page (NOT thank-you);
  after accept/decline → thank-you. Never place an OTO pre-purchase.
- **Offer-type selection:** four types (more-of-the-same / faster results / longer-term results /
  complementary problem); MOTS vs problem-chain; upgrade vs quantity-bundle.
- **Cross-sell strategy:** 3× margin math + demographic expansion (widens addressable market without
  changing front-end targeting). See frameworks-procedures.md.
- **Adaptive logic:** smaller front-end purchase → upsell to larger quantity; larger → downsell to
  incremental addition.
- **Post-purchase window:** ~24h anxiety/price-elasticity window; recapture via email/SMS if the
  buyer exits before finishing the OTOs; email repurposes OTO content + retargets past buyers. See refs.
- **Diagnostic gate (the WHY):** treat AOV as the lever ONLY after ad-side (CPM/CTR/CPC) and
  funnel-side (landing page, checkout) problems are ruled out. AOV = the competitive acquisition
  advantage (Dan Kennedy: spend-the-most-to-acquire wins). See frameworks-procedures.md.

## Output contract (per plan)

```
plan: "<id or short label>"
gates: [ {n, target, verdict: pass|fail, tier: countable, evidence_quote, source} ]   # gates 1–5
felt_signals: [ {n, target, verdict: prefer|tie|weaker, tier: felt, evidence_quote, source} ]  # 6–7
band: DISCARD | VIABLE | SHIP
flags: [ ... ]    # from the negatives list
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every gate (1–5) and signal (6–7) has a verdict; band present.
**SOUNDNESS:** every countable verdict came from the script (not eyeballed); every felt verdict
is pairwise-vs-specimen, not self-graded; band derived only from passed fields with the ratio +
relevance overrides applied; each `pass`/`prefer` carries an `evidence_quote` that is a verbatim
substring of the plan. `emit_ready` only if SOUNDNESS holds; else `BLOCKED:<field>`.

## Self-test (is this grader sound?) — any NO, fix

- Are only Gates 1–5 hard-gated (by script), with Signals 6–7 as pairwise-vs-specimen?
- Is the felt judgment run separately from the writer, against a real specimen?
- Does the band come from fields that passed their tier's check, with the ratio cap applied?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Are placement/offer-type rules kept as ROUTE contracts, not scored fields?
- Is every quoted specimen a verbatim substring of a source file (no composites)?

## See also

- `kb-upsells-write` — WRITE/SCORE sibling — write the prose this skill scores
- `kb-upsells-and-monetization-score` — adjacent skill — check its scope/boundary before routing here
- `kb-aov-optimization-score` — adjacent skill — check its scope/boundary before routing here
