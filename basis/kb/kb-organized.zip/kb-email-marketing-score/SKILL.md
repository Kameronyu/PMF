---
name: kb-email-marketing-score
description: >-
  Grade an e-commerce email/SMS retention setup against the countable retention floor and
  return GAP / VIABLE / OPTIMIZED before anyone calls it production-ready. Use when auditing a
  flow set, broadcast cadence, or lifecycle config (built by an operator, agency, or any
  source) for whether the floor is actually met. Covers: the 8 hard-gates (baseline-flow
  floor, flow length, cadence/promo/SMS ratio, LTV:AOV, 180-day engaged window, day-one
  discount pop-up, refund survey, affiliate commission), diagnostic revenue benchmark bands,
  the ROUTE contract (capture placement, flow priority, channel roles, tool/platform/review
  routing), and the negatives list. Does NOT cover Hormozi's retention thresholds
  (rebooking/membership/churn plays) — use kb-email-and-retention-score for that; writing the
  actual lifecycle copy — use kb-email-and-retention-write. This skill SCORES against a
  rubric; pair with its sibling. Triggers: "score this email setup", "is this retention flow
  production-ready", "audit my Klaviyo flows".
---

# Email marketing — score the retention setup before calling it production-ready

Grade a setup against the COUNTABLE checks below, apply the ROUTE contract, then band it.
**Do not run this in the same pass that built the setup** — a builder grading itself rates
its own work higher. Each judged field is decided from a NAMED signal in the setup, never
from vibes. Diagnostic benchmarks are scored as bands against the figures in
`references/benchmark-specimens.md`, not as pass/fail.

Tier discipline: **hard-gate only the countable** (enum/threshold/count/ratio/window);
**band the diagnostic** (revenue-contribution figures); **the ROUTE rules are a contract,
not a score** — a missing/violated route emits a `route_flag`, never a hard FALSE on copy.

## The 8 countable checks (each: positive target → how it's judged → tier)

1. **Baseline-flow floor** — *target:* the flow set contains all four of welcome series,
   abandoned checkout, sunset/re-engagement, engagement. *Judge:* **script gate** —
   `contains-all` of the 4-flow enum. Tier: COUNTABLE → hard-gate. Below 4 → not "minimum viable."
2. **Flow length** — *target:* overall flow length ≥ 15 emails. *Judge:* **script gate** —
   count ≥ 15. Tier: COUNTABLE → hard-gate.
3. **Broadcast cadence + ratio** — *target:* 3 broadcast emails/week; promo share ≤ 20%;
   SMS ≤ 1 per 2 weeks. *Judge:* **script gate** — email/wk == 3 AND promo ≤ 20% AND
   SMS ≤ 0.5/wk. Tier: COUNTABLE → hard-gate.
4. **LTV:AOV ratio** — *target:* LTV ≥ 3 × AOV. *Judge:* **script gate** — ratio ≥ 3.0;
   below → flag underperformance. Tier: COUNTABLE → hard-gate.
5. **Engaged-segment window** — *target:* sends target the engaged segment (opened OR
   clicked in last 180 days) only; unengaged excluded. *Judge:* **script gate** — window == 180
   AND send audience excludes >180-day-unengaged. Tier: COUNTABLE → hard-gate.
6. **Day-one discount pop-up** — *target:* pop-up live at launch, discount ≥ 10%. *Judge:*
   **script gate** — present AND offer ≥ 10%. Tier: COUNTABLE → hard-gate.
7. **Refund-survey** — *target:* refund-incentivized survey shipped with ≥ 2 questions.
   *Judge:* **script gate** — question count ≥ 2. Tier: COUNTABLE → hard-gate.
8. **Affiliate commission floor** — *target:* commission ≥ 10%. *Judge:* **script gate** —
   rate ≥ 10. Tier: COUNTABLE → hard-gate.

Per-check membership tests + the gate definitions (enum lists, count/window/ratio bounds)
are in `references/check-tests-specimens.md`. Diagnostic revenue benchmarks (15–30% contribution,
~15% cart, 9/10 brands, CAC headroom) are bands, not gates — see `references/benchmark-specimens.md`.
The theses/procedures behind the floor (custom-CRM differentiator, cross-channel MER mechanic,
manual affiliate-seeding steps) are in `references/frameworks.md`; the generative worked example
(personalized cart Email-2: named persona + video + 1:1 chat page) and the post-purchase
"family"/identity framing copy live verbatim in `references/worked-examples-specimens.md`.

## Bands (derive from checks that actually passed — not a hollow count)

- **0–3 passed → GAP** (fix the floor before claiming retention exists).
- **4–6 passed → VIABLE** (floor mostly built; close the remaining gates).
- **7–8 passed → OPTIMIZED** (countable floor met; differentiate on ROUTE quality).

Count only checks that passed their tier's gate. A diagnostic benchmark contributes no
pass on its own — it only positions the setup within a band for narrative, never manufactures a count.
**Floor override (structural):** if Check 1 (baseline-flow floor) FAILS, cap the band at
GAP regardless of count — basic flows are table stakes; nothing above them counts as
retention if the floor is absent. The enum membership is countable.

## The negatives live here (≤5), each paired with a positive target

Each is a checker rule against the setup, moved out of any builder:

- **Capture at checkout** → flag; positive: capture contact pre-checkout, on the sales/advertorial page.
- **Too-short cart sequence** → flag (fails Check 2); positive: overall flows 15–20 emails minimum.
- **Paid retargeting before threshold** → flag; positive: activate paid retargeting only at ≥ $500–$1,000/day ad spend (owned email/SMS from day one).
- **Over-sending SMS** (more than 1–2/month) → flag (fails Check 3); positive: SMS 1 per 2 weeks.
- **Measuring email in isolation** → flag; positive: measure email + SMS + retargeting as one ecosystem.

## ROUTE contract (named-trigger selection / sequencing — emits route_flag, not a score)

Full rule text + triggers in `references/route-specimens.md`. The contract:
- **Capture placement:** newsletter capture at the BOTTOM of the LP, after conversion sections; contact captured pre-checkout, not at checkout.
- **Flow priority order:** abandoned checkout → abandoned cart → browse abandonment → welcome → post-purchase.
- **Channel roles:** email = long-form recovery; SMS = immediate urgency; stack both.
- **Post-purchase sequence (CW):** shipping confirmation → welcome (membership framing) → discount code → community invitation → ambassador CTA.
- **Post-purchase must-includes (SP):** shipping-address confirmation, shipping-timeline expectation, refund-incentivized survey.
- **Platform migration:** Shopify native sub-$10K/mo → Klaviyo as the list scales; not prematurely.
- **Tool stack:** Klaviyo or Omnisend (email); SMSBump or Omnisend (SMS); Omnisend single-platform; Klaviyo+SMSBump for segmentation depth; UpPromote (affiliates).
- **Review routing by star rating:** 1–3 stars → Judge.me (private); 4–5 stars → Trustpilot (public).
- **UGC affiliate trigger:** Klaviyo trigger 2–3 weeks post-delivery; two binary questions + Drive upload link.
- **Peak cadence:** Black Friday → 9+ campaigns across email+SMS+WhatsApp; segment by geography (US-only Thanksgiving).
- **Value-withheld CTA:** voucher CTA omits the numeric value (states "a gift voucher," not the amount).

## Output contract (per setup)

```
setup: "<identifier>"
checks: [ {n, target, verdict: pass|fail, tier: COUNTABLE, evidence_quote, source} ]
countable_gates: {baseline_flows, flow_length, cadence_ratio, ltv_aov, engaged_window, day_one_popup, refund_survey, commission}   # script results, pass/fail
benchmark_bands: {revenue_contribution, cart_contribution, ...}   # diagnostic position, not pass/fail
route_flags: [ ... ]    # from the ROUTE contract (violated/missing routes)
band: GAP | VIABLE | OPTIMIZED
flags: [ ... ]          # from the negatives list
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every check has a verdict; band present; route contract evaluated.
**SOUNDNESS:** every COUNTABLE verdict came from the script (not eyeballed); benchmarks are
banded, not self-graded pass/fail; band derived only from passed checks; floor override
applied when Check 1 fails; each `pass` carries an `evidence_quote` that is a verbatim
substring of the setup. `emit_ready` only if SOUNDNESS holds; else `BLOCKED:<check>`.

## Self-test (is this grader sound?) — any NO, fix

- Are only the 8 countable checks hard-gated (by script), with the revenue benchmarks kept as bands?
- Is the grading run separately from any builder, deciding each field from a named setup signal?
- Does the band come from checks that passed their gate, not a raw count, with the floor override applied?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Is the ROUTE contract kept as named-trigger rules emitting route_flags, not scored?
- Is every quoted specimen a verbatim substring of a source file (no composites)?

## See also

- `kb-email-and-retention-score` — adjacent skill — check its scope/boundary before routing here
- `kb-email-and-retention-write` — adjacent skill — check its scope/boundary before routing here
- `kb-conversion-optimization-score` — adjacent skill — check its scope/boundary before routing here
