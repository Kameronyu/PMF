---
name: kb-quiz-funnel-write
description: >-
  Write the felt copy a prospect actually reads inside a quiz funnel — questions, objection
  cards, the named-diagnosis slide, projection/finality lines, loading-screen micro-copy, and
  personalized result-page headlines that prime them to buy. Use when drafting or rewriting
  quiz-funnel wording, named-diagnosis verdicts, yes-street micro-commitment questions, or
  quiz-to-sales-page result framing. Covers: real winning specimens, the five optional
  patterns (Named-Diagnosis, Yes-Street, Projection/Finality, Result-Frame, Objection-Card),
  priming-over-personalization craft targets, awareness-arc and objection-placement contract
  rules. Does NOT cover funnel structure, screen order, or KPIs — use kb-quiz-funnel-score for
  that; broader funnel-wide hero/landing copy — use kb-funnel-architecture-write; long-form
  pre-sell pages — use kb-advertorial-write. This skill WRITES prose; pair with
  kb-quiz-funnel-score. Triggers: "write quiz funnel copy", "diagnosis slide wording",
  "micro-commitment questions", "quiz result page headline".
---

# Quiz funnel — write the copy the prospect feels

A quiz funnel primes a cold prospect into a purchase-ready state by extracting
micro-commitments, seeding beliefs, and pre-handling objections before the offer.
Your job is the **wording** on each screen — not the funnel's structure (which screen
goes where, default pre-selections, KPIs — that is the score skill's contract). Lead
from the specimens below; reach for a named pattern only if it helps; keep it concrete.

**The mechanism you write for is emotional priming — NOT personalization or AOV.** Even a
three-question quiz beats sending traffic straight to a sales page; the copy moves the prospect
*progressively* into a purchase-ready emotional state, and personalization is a supporting lever,
not the engine. See `references/mechanism.md` (the priming decision rule + three revenue levers)
and `references/frameworks.md` (Three Pillars rationale; the advanced Bionic custom-formulation
model). The AI drafting workflow + design rules live in `references/procedures.md`.

## Start here — real winning specimens (study these before writing)

These are preserved verbatim from the source. They steer you harder than any rule.

- **Objection-card (neutralize a surfaced objection in-funnel):**
  *"A busy schedule doesn't have to stop you from looking and feeling years younger."*
  — names the prospect's just-surfaced barrier (time) and dissolves it with the desired
  identity, not a feature; lands right after the behavioral question that raised it.

- **Named-Diagnosis (aggregate their answers into an evidence-sounding verdict):**
  *"Stage 2 Hair Loss — caused by genetic predisposition and high stress levels"*
  — a specific named stage plus a cause built from *their own* quiz answers; reads like a
  medical result, which makes the solution feel diagnosed rather than sold.

- **Yes-Street micro-commitments (consistency-bias questions answerable "yes"):**
  *"Are you determined to finally stop your hair loss?"* (emotional commitment)
  then *"Does a simple hair care routine sound good?"* (practical commitment)
  — each is phrased so the honest answer is yes; the pair escalates emotional → practical
  so the prospect arrives at the offer already having agreed.

- **Loading-screen micro-copy (manufacture anticipation + personalization):**
  *"Analyzing your profile…"*
  — three words that make a canned result feel individually generated; the pause is the point.

- **Result-Frame sales-page headlines (deliver a result, not an offer):**
  *"Hair profile matched"* and *"Here's your growth plan"* — frame the page as the delivery
  of a personalized verdict; the urgency line *"X people are looking at this right now"*
  adds live social pressure without a discount.

- **Finality framing (make the multi-month plan feel necessary, not expensive):**
  *"the last plan you'll ever need"* — closes comparison-shopping by framing this as terminal.

More specimens, with the funnel moment each occupies, are in `references/specimen-bank.md`.

## Craft targets (steer by these; they are not a rulebook)

- **Optimize for priming, not "looks personalized."** When two lines compete, prefer the one
  that advances emotional readiness to buy; personalization serves priming, it is not the goal.
- **Deliver a verdict, not a pitch.** The diagnosis and result page should read like a
  medical-style result built from the prospect's own answers — diagnosed, not sold.
- **Specificity from their answers.** A named stage, a specific cause, a concrete future
  month beats "personalized" or "great results." Echo back what *they* told you.
- **Every question earns a yes.** Micro-commitment questions are phrased so the honest
  answer is agreement; escalate emotional → practical so consent compounds.
- **Handle the objection where it surfaces.** When a behavioral question raises a barrier,
  the very next card dissolves it — name the barrier, answer with the desired identity.
- **Make the plan feel necessary, not costly.** Projection and finality copy frames the
  multi-month supply as the time required to reach the promised transformation.
- **Fewest words that keep the pull.** Draft, then cut every word that adds no new pull.

## Optional patterns (reach for one; use a pattern in any order that fits the screen)

Named-Diagnosis · Yes-Street · Projection/Finality · Result-Frame · Objection-Card.
Each is a shape to borrow per screen, not a required sequence for the whole funnel.
Anatomy and a worked example for each is in `references/patterns.md`.

## Contract rules (these DO bind — they pick which copy goes where, not the words)

- **Awareness arc:** the funnel moves a cold/unaware prospect to purchase-ready; write the
  early screens to engage the problem (pain-diagnostic), the late screens to assume the sale
  (yes-street, result-frame). Match the copy's job to the screen's moment.
- **Objection copy fires after its trigger:** write the neutralizing card to follow the
  behavioral question that surfaces the objection — not before it exists in the prospect's mind.
- **Diagnosis aggregates prior answers:** the named-diagnosis line must be built from answers
  already collected (severity, timeline, causation) — the named stage reflects only what the quiz measured.
- **Personalization callback on the sales page:** echo collected attributes back on the result
  page (e.g. the *"recommended based on your quiz results"* label) for funnel-to-purchase continuity.

## How to use this with the grader

Write the copy for each screen; vary the pattern and stay concrete. Then hand the funnel to
**kb-quiz-funnel-score** — a separate skill, ideally a different model — for the structural
gates (question-role membership, format variation, length 3–20 / 8–12, 30% completion KPI,
5–7 email sequence) and the pairwise-vs-specimen judgment on the felt copy. Generate several
diverse drafts and let the separate scorer grade them; that keeps the writing aimed at making
the prospect feel diagnosed rather than at "looks like a diagnosis slide."

## Before handoff (what kb-quiz-funnel-score checks)

Generate several diverse drafts; the separate scorer grades — do not self-grade toward the
gate. These are awareness of what the scorer attends to, not a binary writer gate:

- Does the diagnosis/result copy read like a verdict built from the prospect's own answers?
- Is each micro-commitment question phrased so the honest answer is yes, escalating in stakes?
- Does the objection card name the just-surfaced barrier and answer with the desired identity?
- Does the projection/finality copy make the multi-month plan feel necessary rather than expensive?
- Did you keep each line as short as the pull allows, with at least one concrete specific?

## See also

- `kb-quiz-funnel-score` — WRITE/SCORE sibling — score a draft this skill writes (separate pass)
- `kb-funnel-architecture-write` — adjacent skill — check its scope/boundary before routing here
- `kb-advertorial-write` — adjacent skill — check its scope/boundary before routing here
