---
name: kb-vssl-score
description: >-
  Grade a VSL (video sales letter) script or plan for production-readiness before you spend ad
  budget, returning REWORK / SHIP-READY / SCALE-READY with per-gate evidence. Use to check a
  VSL from a human, from kb-vssl-write, or any source — "is this ready to ship," does it pass
  the framework. Covers: the six countable hard-gates (product-mention position, seventh-grade
  readability, research depth, 3–7 necessary beliefs, swipe filter, micro-lead test volume);
  the felt ad-to-VSL congruence signal judged pairwise-vs-specimen; the 8-stage / 9-ingredient
  / funnel ROUTE ordering contract; banding with G1 and congruence overrides. Does NOT cover
  writing or fixing VSL prose — use kb-vssl-write for that; scoring non-video direct-response
  copy (ads, hooks, headlines, advertorials) — use kb-copywriting-score for that. This skill
  SCORES against a rubric; pair with kb-vssl-write. Triggers: "score this VSL", "is this VSL
  ready to ship", "grade this sales video script".
---

# VSL — score production-readiness before you spend ad budget

Grade a VSL against the countable gates + the ordering contract, then band it. **Do not run
this in the pass that wrote the VSL** — a writer grading itself rates its own output higher.
Judge the one FELT signal against the specimens in `references/scoring-specimens.md`.

Tier discipline: **hard-gate only the countable; keep ordering as a ROUTE contract; compare
the felt against a specimen — never hard-FALSE it.** Hook, UM, Belief, and awareness level
are anchor terms — used here, defined in the registry, never redefined.

## The countable gates (each: positive target → script test → tier)

| # | Gate | Positive target (PASS) | Script test |
|---|------|------------------------|-------------|
| G1 | Product-mention position | first product mention at ≥50% of runtime, ideally ≥66% | `first_mention_pct ≥ 50`; warn if `< 66` |
| G2 | Readability | script at seventh-grade reading level or below | `grade_level ≤ 7` |
| G3 | Research depth | ≥5 pages of prospect-intelligence research produced before writing | `pages ≥ 5` |
| G4 | Necessary-beliefs count | Necessary Beliefs Document lists 3–7 specific purchase beliefs | `3 ≤ belief_count ≤ 7` |
| G5 | Swipe filter | swipe qualifies only if duration ≥3 min AND run ≥7 days AND brand ≥30 active ads | `dur_min ≥ 3 AND run_days ≥ 7 AND active_ads ≥ 30` |
| G6 | Micro-lead test volume | 10–20 VSL variants tested per week, varied at the micro-lead | `10 ≤ variants_per_week ≤ 20` |

Each gate is COUNTABLE → **hard-gate**. Full membership tests + token definitions are in
`references/gate-tests.md`. Each gate carries an `evidence_quote` (verbatim from the input).

## The felt signal (pairwise-vs-specimen — never a hard FALSE)

- **Ad-to-VSL congruence** — *target:* the Stage-1 big promise matches the winning ad hook
  (same angle, same language, same promise). *Judge:* FELT — rate congruence **pairwise
  against a congruence specimen** in `references/scoring-specimens.md`; return
  `prefer | tie | weaker`. Never a script FALSE; `weaker` flags a rework, never auto-bands.

## Bands (derive from gates that actually passed — not a hollow count)

- **0–2 gates pass → REWORK** (fix before any spend).
- **3–5 gates pass → SHIP-READY** (limited test budget).
- **6 gates pass → SCALE-READY** (full creative budget).

Count only gates that passed their script test. The felt signal contributes no count; it can
only **cap** the band.
**Position override:** any VSL that fails G1 (product named before 50% of runtime) caps at
REWORK regardless of count — an early pitch collapses cold-traffic conversion.
**Congruence cap:** if the felt signal returns `weaker`, drop one band and flag
"realign Stage-1 promise to the winning ad hook."

## ROUTE contract (named-trigger ordering — dictates no wording)

These are sequencing checks, not quality verdicts. Full ordering + placement rules in
`references/route-order.md`.

- **8-stage order** (Carl Weische): Hook → Expand Promise → Authority → Personal-Story
  Epiphany → Problem Education → Product Introduction → Solution Education → Binary CTA.
- **9-ingredient order** (Mark Builds Brands): Micro Lead → Lead → Discovery Story →
  UM-of-Problem → UM-of-Solution → Product Reveal → Price Drop → Risk Reversal → Social
  Proof. **Social proof placed AFTER product reveal + pricing, not before.**
- **Prerequisite gate:** all three briefs (Avatar Sheet, Offer Brief, Necessary Beliefs)
  complete BEFORE any copy. Missing brief → ROUTE violation, flag (does not auto-band).
- **Production prerequisite:** a clip-by-clip editor-direction Google Sheet exists (every
  copy line → a clip). Missing → flag "no editor direction system" (does not auto-band).
- **Funnel order:** Ad → Advertorial → VSL Page → Order Page; VSL page contains nothing
  but the video.

Upstream procedures that produce the gated artifacts (the six-step AI research workflow
behind G3, the swipe-research execution behind G5, the editor-direction system) are in
`references/upstream-procedures.md`.

## The negatives live here (≤5), each paired with a positive target

Moved out of the writer (where banning a thing summons it). Each is a checker rule:

- **Product named before 50% of runtime** → fail G1, cap REWORK. (positive: first mention ≥50%, ideally ≥66%)
- **Above seventh-grade reading level** → fail G2. (positive: grade level ≤ 7)
- **Social proof before product reveal/pricing** → ROUTE violation, flag. (positive: social proof last)
- **Skipping any of the three brief documents** → prerequisite violation, flag. (positive: all three complete before copy)
- **Ad and VSL misaligned in angle/language** → congruence returns `weaker`, drop one band. (positive: Stage-1 promise matches the ad hook)

## Output contract (per VSL)

```
vsl_id: "<id>"
gates: [ {n, target, verdict: pass|fail, tier: COUNTABLE, measured, evidence_quote, source} ]
felt_signal: {congruence: prefer|tie|weaker, specimen_ref, reason}
route_checks: [ {rule, ordered: true|false, evidence} ]   # 8-stage, 9-ingredient, briefs, funnel
band: REWORK | SHIP-READY | SCALE-READY
flags: [ ... ]    # from the negatives list
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every gate has a verdict; felt signal present; band present.
**SOUNDNESS:** every COUNTABLE verdict came from the script (not eyeballed); the felt verdict
is pairwise-vs-specimen, not self-graded; band derived only from passed gates with overrides
applied; each `pass` carries a verbatim `evidence_quote`; ROUTE checks ran. `emit_ready` only
if SOUNDNESS holds; else `BLOCKED:<gate>`.

## Self-test (is this grader sound?) — any NO, fix

- Are only G1–G6 hard-gated (by script), with congruence kept as pairwise-vs-specimen?
- Is the felt judgment run separately from the writer, against a real specimen?
- Does the band come from gates that passed their script test, with the G1/congruence overrides applied?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Is the stage/ingredient/funnel ordering kept as a ROUTE contract, not a quality verdict?
- Is every quoted specimen a verbatim substring of a source file (no composites)?

## See also

- `kb-vssl-write` — WRITE/SCORE sibling — write the prose this skill scores
- `kb-copywriting-score` — adjacent skill — check its scope/boundary before routing here
- `kb-advertorial-score` — adjacent skill — check its scope/boundary before routing here
