---
name: kb-persuasion-write
description: >-
  Write cold-traffic persuasion copy that converts skeptical strangers with zero prior trust —
  the line a braced-for-the-pitch buyer actually feels. Use when drafting or rewriting the
  guarantee, the scarcity/urgency line, the authority signal, or the objection-voiced counter
  on a cold offer, ad, or landing page. Covers: concrete time-bound risk-reversal guarantees,
  credible non-round scarcity, borrowed-credibility authority shorthand,
  voice-the-objection-then-answer copy, objection-to-element routing, the Cialdini stack
  sequence, and the ethical bright line. Does NOT cover warm/1:1 sales closes, discovery
  questions, or negotiation moves — use kb-persuasion-and-sales-write for that; upstream
  buyer/market/desire classification before any copy — use kb-consumer-psychology-score; a
  guarantee built inside an offer's value-stack/bonus structure — use
  kb-offer-construction-write; SCORING a planted comment-section testimonial for fitness — use
  kb-social-proof-score. This skill WRITES prose; pair with kb-persuasion-score. Triggers:
  "write a cold-traffic guarantee line", "scarcity line for this offer", "answer this
  objection in copy", "make this cold offer convert".
---

# Persuasion — write the line that converts a cold stranger

A cold buyer has zero trust and zero brand relationship. Persuasion copy's job is to
neutralize a specific objection in the buyer's own words, then remove the risk of acting.
You are writing the *wording* the skeptic feels — not naming an abstract "element." Lead
from the specimens below; reach for an element only because it answers a real objection.

> **Concept-heavy topic note.** The source is mechanism-rich but literal-copy-sparse: the
> winning fragments are short and load-bearing, not full long-form passages. Treat them as
> micro-specimens to adapt — never as ordered slot templates to fill.

## Start here — real winning specimens (study these before writing)

Preserved verbatim from the source. They steer you harder than any rule. More in
`references/specimen-bank.md`.

- **Concrete, time-bound, no-friction guarantee:** *"30-day no-questions-asked refund"*
  — WHY: a number-plus-window (the 30-day part) and explicit risk-reversal (the
  no-questions-asked part) make the promise feel real and falsifiable. A generic money-back
  guarantee makes the skeptic supply the doubt; this one removes it before they can.
- **Oddly-specific, credible scarcity:** *"Only 47 units left at this price,"*
  — WHY (round-number contrast): 47 reads as a real count pulled from real inventory,
  unlike a round-and-fake only-a-few-left line. Specificity *is* the credibility; a
  believable number does the loss-aversion work without tipping into the manipulation the
  buyer is braced for.
- **Authority by borrowed-credibility shorthand:** *media logos ("as seen in")*
  — WHY: three words transfer third-party credibility into the headline region without a
  claim the reader has to take on faith — the logo carries it. Short-circuits the
  trust-building timeline a cold audience would otherwise demand.
- **Voice the objection, then answer it (buyer-voice + counter):** the buyer thinks
  *"Will it actually work for me?"* → you answer with *guarantees, before/after proof,
  specificity of claims*.
  — WHY: saying the doubt out loud in the buyer's own phrasing earns the right to answer
  it; the answer is mapped to that exact objection, not decoratively placed on the page.
- **The ethical bright line (the boundary your copy stays inside):**
  *Persuasion that helps → ethical. Persuasion that exploits → unethical and long-term
  brand-destructive.*
  — WHY: the line that keeps scarcity and urgency honest. Trust compounds; manufactured
  pressure converts once and destroys the relationship — write to the help side of it.

**[BELOW SPECIMEN FLOOR for sustained copy]** — 5+ verbatim micro-specimens above (over the
floor of 3), but the source has no full hook/headline/body passages. A human should add ≥3
longer real passages when available. Do NOT fabricate; adapt the micro-specimens and steer
with the targets below.

## Craft targets (steer by these; they are not a rulebook)

- **Specific over generic.** A number, a named window, a real count beats "fast,"
  "guaranteed," "limited." The "30-day no-questions-asked" feel and the "47 units" feel —
  let the detail carry the credibility.
- **Voice the objection, then answer it.** Write the buyer's actual doubt in their words,
  then map the answering element to *that* objection in the same copy. Persuasion placed
  decoratively does not convert; persuasion mapped to a named objection does.
- **Credible beats aggressive.** Scarcity and urgency must read as real and substantiated
  (a true reason, a non-round number). Fake scarcity is detectable and fatal — the cold
  audience is already braced for it.
- **Remove the downside before asking.** Lead the risk-reversal as a feature, repeat it at
  the moment of action. The skeptic's first question is "what if I waste my money" — answer
  it before they ask.
- **Show, don't claim, authority.** Credentials, media logos, demonstrated evidence — let
  the proof carry the claim; a bare "we're experts" backfires with a skeptic.

## Optional patterns (reach for one; never force a fixed slot order)

Risk-Reversal Guarantee · Credible-Scarcity Line · Authority-Shorthand · Objection-Voiced
Counter. Each is a shape to borrow, not a required sequence. Anatomy, a worked example, and
the per-element execution menus (Urgency, Exclusivity, scarcity, social proof, authority,
certainty, reciprocity) are in `references/patterns.md`. Named real offer stacks (Nusk,
Cogut Beauty) are in `references/specimen-bank.md`.

## Contract rules (these DO bind — they pick the element, not the words)

These route *which* element answers *which* objection. They dictate no wording and assign
no verdict. Full routing table and the Cialdini sequence are in `references/routing.md`.

- **Objection → element:** *"I don't know this brand"* → Authority + Social Proof;
  *"What if it doesn't work for me?"* → Certainty (guarantee); *"I'll think about it"* →
  Urgency + Scarcity; *"Anyone can buy this"* → Exclusivity.
- **Universal cold-traffic objections → counter:** Time (*"Will this take too long?"*) →
  speed/ease proof; Effort (*"Is this too complicated?"*) → simplicity / done-for-you;
  Results (*"Will it actually work for me?"*) → guarantee / before-after / specificity.
- **Stack priority for cold offers:** Social Proof + Certainty first (trust + risk
  removal), then Urgency/Scarcity to close; Authority amplifies all others.
- **Cialdini sequence (when building a full sequence):** liking/similarity → authority →
  social proof → reciprocity (give first) → micro-commitment → scarcity (genuine only) →
  the ask. Laws compound when sequenced; isolated tactics underperform.
- **Awareness routing:** cold = lowest trust; trust-building elements (social proof,
  authority, certainty) must establish credibility before persuading toward the ask.
- **Channel:** online, social proof + reciprocity lead (they substitute for in-person
  trust); prefer video testimonials over text when credibility cues matter.
- **Ethical gate:** deploy leverage only where it helps the buyer reach a decision that
  serves their actual interest, and use scarcity only when it is genuine — write to the help
  side of the bright line, never the exploit side. (The full dual-use framework — defensive
  recognition-of-manipulation as the named PRIMARY use, offensive use as the constrained
  secondary — is in `references/routing.md`.)

These are anchor registry terms — use them, never redefine: **trust signals**,
**objection handle**, **awareness level**, **extraordinary identifier**.

## Before handoff (what kb-persuasion-score checks)

Generate several diverse drafts (vary the element and the objection answered; don't iterate
one toward "safe"); the separate scorer grades — do not self-grade toward the gate. Hand the
drafts to the **persuasion scorer** (a different pass, ideally a different model) for the
gates and the pairwise-vs-specimen judgment. These are what that scorer will look at, kept
here only as awareness of the target:

- whether the copy voices a specific buyer objection and answers it with the mapped element;
- whether the guarantee is concrete and time-bound (a window + risk-reversal language);
- whether scarcity/urgency numbers are substantiated and non-round;
- whether the risk-reversal leads as a feature rather than hiding in fine print;
- whether you produced several diverse candidates rather than one polished safe line.

The guarantee-specificity check, the reset-timer / fake-scarcity checks, and the
proof-specificity judgment all live in the scorer, not here.

## See also

- `kb-persuasion-score` — WRITE/SCORE sibling — score a draft this skill writes (separate pass)
- `kb-persuasion-and-sales-write` — adjacent skill — check its scope/boundary before routing here
- `kb-offer-construction-write` — adjacent skill — check its scope/boundary before routing here
