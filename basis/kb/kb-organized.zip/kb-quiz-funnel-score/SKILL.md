---
name: kb-quiz-funnel-score
description: >-
  Grade a quiz funnel's structure and return REWORK / VIABLE / SHIP-READY with per-field
  evidence before you launch or spend. Use when a quiz funnel exists (human-built,
  kb-quiz-funnel-write, or any source) and you must verify it before traffic, audit it against
  the benchmarks, or decide if it's ship-ready. Covers: countable hard-gates (question-role
  membership, consecutive-format bound, question count, completion-rate KPI,
  email-before-reveal, four foundational docs, email-sequence length); the dopamine-format
  soft-cap; pairwise-vs-specimen felt signals (diagnosis naming, micro-commitment escalation,
  projection framing, result-page framing); the funnel/sales-page ROUTE sequencing contract;
  and band derivation. Does NOT cover scoring a broader D2C funnel build — use
  kb-funnel-architecture-score for that; advertorial pre-sell pages — use
  kb-advertorial-score. This skill SCORES against a rubric; pair with kb-quiz-funnel-write.
  Triggers: "score this quiz funnel", "is this funnel ready to launch", "grade this quiz",
  "check my quiz funnel against the benchmarks".
---

# Quiz funnel — score structure before you launch or spend

Grade the funnel against the countable benchmarks + the contract, then band it. **Do not run
this in the same pass that built the funnel** — a builder grading itself rates its own output
higher. Judge felt copy pairwise against the verbatim specimens in
`references/scoring-specimens.md`, ideally on a different model.

Tier discipline: **hard-gate only the countable; soft-cap the heuristic; compare the felt
against a specimen — never hard-FALSE it.** Anchor terms (Transformation, social proof,
objection handle, belief) trace to the registry — do not redefine them here.

## The judged fields (each: positive target → how it's judged → tier)

COUNTABLE — **script gate** (full tests in `references/criteria-tests.md`):
1. **Question-role membership** — every question maps to exactly one of
   `{micro-commitment, objection-pre-handling, belief-seeding}`; none exists purely for data
   collection. COUNTABLE → hard-gate.
2. **Consecutive-format bound** — no run of >3 consecutive questions in the same format.
   COUNTABLE → hard-gate.
3. **Question count** — total within 3–20; sweet spot 8–12. COUNTABLE → hard-gate (warn if
   outside 8–12).
4. **Completion-rate KPI** — a completion-rate target is set and ≥30%. COUNTABLE → hard-gate.
5. **Email before reveal** — name + email collected at quiz end, before the results reveal.
   COUNTABLE → hard-gate.
6. **Four foundational docs** — `{offer, avatar, research, beliefs}` all exist before AI
   question-generation. COUNTABLE → hard-gate.
7. **Email-sequence length** — post-quiz sequence within 5–7. COUNTABLE → hard-gate.

HEURISTIC — **soft-cap** (warn, never hard-fail):
8. **Dopamine-format presence** — interactive formats (sliders, image selects) present, not a
   text-button-only quiz. Count plain-text questions, warn, never hard-fail.

FELT — **pairwise-vs-specimen** (`prefer | tie | weaker`, never a hard FALSE):
9. **Diagnosis-slide naming** · 10. **Micro-commitment escalation** ·
11. **Projection / finality framing** · 12. **Result-page framing** — each judged against its
specimen; `weaker` contributes no pass.

## Bands (derive from fields that actually passed — not a hollow count)

- **REWORK** — any COUNTABLE hard-gate FALSE (rebuild before spend).
- **VIABLE** — all COUNTABLE gates pass; some felt fields `weaker` or heuristic warns present.
- **SHIP-READY** — all COUNTABLE gates pass AND every felt field is `prefer` or `tie` AND no
  heuristic warn.

Count only fields that passed their tier's check. A felt field contributes only when the
pairwise judge prefers/ties it; it never manufactures a pass on its own.
**Structural cap:** if any anti-pitfall presence check in `references/route-contract.md` fails
(e.g. social proof fired before the desired situation; quiz data not carried to the sales
page; or the spec's optimization rationale treats personalization/product-matching as the
primary lever instead of emotional priming), cap the band at VIABLE regardless of count — the
contract break costs conversion.

## The negatives live here (≤5), each paired with a positive target

Each is a checker rule, not a writer ban:

- **Data-only question** → fails field 1; flag the question. (positive: assign a persuasion role)
- **Uniform format run >3** → fails field 2. (positive: vary format every 2–3 questions)
- **Social proof too early** (before desired situation stated) → caps band VIABLE. (positive:
  fire proof only after the outcome is stated)
- **Quiz data not carried to sales page** → caps band VIABLE. (positive: echo answers on the SP)
- **Four docs skipped before AI generation** → fails field 6. (positive: complete all four first)

## ROUTE contract (sequencing — keep, dictate no wording)

The funnel/sales-page sequence is a named-trigger contract in `references/route-contract.md`
(5-question pain-diagnostic opening ordered by function → pivot then social proof →
individualization → in-funnel objection handle → causation-then-diagnosis; above-the-fold
order; bundle default-state; gradualization; intraquiz cards; drop-off triage; email
branching). The scorer references it as presence/ordering checks.

## Output contract (per funnel)

```
funnel_id: "<id>"
countable_gates: {role_membership, consecutive_format, question_count, completion_kpi,
                  email_before_reveal, four_docs, email_seq_len}  # script, pass|fail
fields: [ {n, target, verdict: pass|fail|signal, tier, evidence_quote, source} ]
heuristic: {dopamine_formats: ok|warn}
felt_signals: {diagnosis_naming, micro_commitments, projection_framing, result_framing}
              # pairwise-vs-specimen: prefer|tie|weaker
contract_checks: [ {rule, present: true|false} ]   # from route-contract.md anti-pitfall duals
band: REWORK | VIABLE | SHIP-READY
flags: [ ... ]    # from the negatives list
```

## COMPLETENESS — PRESENCE vs SOUNDNESS

**PRESENCE:** every judged field has a verdict; every countable gate has a script result;
band present.
**SOUNDNESS:** every COUNTABLE verdict came from the script (not eyeballed); every felt
verdict is pairwise-vs-specimen, not self-graded; band derived only from passed fields plus
the structural cap; each `pass` carries an `evidence_quote` that is a verbatim substring of
the funnel spec. `emit_ready` only if SOUNDNESS holds; else `BLOCKED:<field>`.

## Self-test (is this grader sound?) — any NO, fix

- Are only fields 1–7 hard-gated (by script), with 9–12 as pairwise-vs-specimen signals?
- Is the felt judgment run separately from the writer, against a real specimen?
- Does the band come from fields that passed their tier's check, not a raw count?
- Are the negatives ≤5, here in the checker, each paired with a positive target?
- Is the sequence kept as a ROUTE contract, not laundered into a hard FALSE?
- Is every quoted specimen a verbatim substring of a source file (no composites)?

## See also

- `kb-quiz-funnel-write` — WRITE/SCORE sibling — write the prose this skill scores
- `kb-funnel-architecture-score` — adjacent skill — check its scope/boundary before routing here
- `kb-advertorial-score` — adjacent skill — check its scope/boundary before routing here
